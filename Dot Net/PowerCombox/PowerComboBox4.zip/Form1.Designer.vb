<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
Me.Label1 = New System.Windows.Forms.Label
Me.Label2 = New System.Windows.Forms.Label
Me.Label3 = New System.Windows.Forms.Label
Me.Label4 = New System.Windows.Forms.Label
Me.Label5 = New System.Windows.Forms.Label
Me.PowerComboBox5 = New xComboBox.PowerComboBox
Me.PowerComboBox4 = New xComboBox.PowerComboBox
Me.PowerComboBox3 = New xComboBox.PowerComboBox
Me.PowerComboBox2 = New xComboBox.PowerComboBox
Me.PowerComboBox1 = New xComboBox.PowerComboBox
Me.Label6 = New System.Windows.Forms.Label
Me.TextBox1 = New System.Windows.Forms.TextBox
Me.Button1 = New System.Windows.Forms.Button
Me.SuspendLayout()
'
'Label1
'
Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Label1.Location = New System.Drawing.Point(3, 5)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(117, 26)
Me.Label1.TabIndex = 3
Me.Label1.Text = "Linux"
Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
'
'Label2
'
Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Label2.Location = New System.Drawing.Point(125, 5)
Me.Label2.Name = "Label2"
Me.Label2.Size = New System.Drawing.Size(117, 26)
Me.Label2.TabIndex = 5
Me.Label2.Text = "Microsoft"
Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
'
'Label3
'
Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Label3.Location = New System.Drawing.Point(248, 5)
Me.Label3.Name = "Label3"
Me.Label3.Size = New System.Drawing.Size(117, 26)
Me.Label3.TabIndex = 7
Me.Label3.Text = "Databases"
Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
'
'Label4
'
Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Label4.Location = New System.Drawing.Point(371, 5)
Me.Label4.Name = "Label4"
Me.Label4.Size = New System.Drawing.Size(117, 26)
Me.Label4.TabIndex = 10
Me.Label4.Text = "Software"
Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
'
'Label5
'
Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Label5.Location = New System.Drawing.Point(495, 5)
Me.Label5.Name = "Label5"
Me.Label5.Size = New System.Drawing.Size(117, 26)
Me.Label5.TabIndex = 12
Me.Label5.Text = "Programming"
Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
'
'PowerComboBox5
'
Me.PowerComboBox5.CheckBoxes = True
Me.PowerComboBox5.DividerFormat = "---"
Me.PowerComboBox5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
Me.PowerComboBox5.FormattingEnabled = True
Me.PowerComboBox5.GridColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer))
Me.PowerComboBox5.GroupColor = System.Drawing.Color.Crimson
Me.PowerComboBox5.Items.AddRange(New Object() {"---Desktop", "VB.NET", "C#", "Delphi", "Java", "C++", "---Web", "ASP", "PHP", "Ruby", "Java", "Perl"})
Me.PowerComboBox5.ItemSeparator1 = Global.Microsoft.VisualBasic.ChrW(44)
Me.PowerComboBox5.ItemSeparator2 = Global.Microsoft.VisualBasic.ChrW(38)
Me.PowerComboBox5.Location = New System.Drawing.Point(495, 34)
Me.PowerComboBox5.Name = "PowerComboBox5"
Me.PowerComboBox5.Size = New System.Drawing.Size(117, 21)
Me.PowerComboBox5.TabIndex = 13
'
'PowerComboBox4
'
Me.PowerComboBox4.CheckBoxes = False
Me.PowerComboBox4.DividerFormat = "---"
Me.PowerComboBox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
Me.PowerComboBox4.FormattingEnabled = True
Me.PowerComboBox4.GridColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer))
Me.PowerComboBox4.GroupColor = System.Drawing.SystemColors.WindowText
Me.PowerComboBox4.Items.AddRange(New Object() {"---Microsoft", "Vista", "Visual Studio", "DirectX", "Office2007", "---Open Source", "FileZilla", "NSIS", "Notepad++", "WinMerge", "UltraVNC", "---MySQL", "SQL Server Community Edition", "GUI-TOOLS", "NET\Connector", "ODBC\Connector"})
Me.PowerComboBox4.ItemSeparator1 = Global.Microsoft.VisualBasic.ChrW(44)
Me.PowerComboBox4.ItemSeparator2 = Global.Microsoft.VisualBasic.ChrW(38)
Me.PowerComboBox4.Location = New System.Drawing.Point(371, 34)
Me.PowerComboBox4.Name = "PowerComboBox4"
Me.PowerComboBox4.Size = New System.Drawing.Size(117, 21)
Me.PowerComboBox4.TabIndex = 11
'
'PowerComboBox3
'
Me.PowerComboBox3.CheckBoxes = True
Me.PowerComboBox3.DividerFormat = ""
Me.PowerComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
Me.PowerComboBox3.FormattingEnabled = True
Me.PowerComboBox3.GridColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer))
Me.PowerComboBox3.GroupColor = System.Drawing.SystemColors.WindowText
Me.PowerComboBox3.Items.AddRange(New Object() {"SQL Server", "Access", "Oracle", "DB2", "FileMaker", "MySQL"})
Me.PowerComboBox3.ItemSeparator1 = Global.Microsoft.VisualBasic.ChrW(44)
Me.PowerComboBox3.ItemSeparator2 = Global.Microsoft.VisualBasic.ChrW(38)
Me.PowerComboBox3.Location = New System.Drawing.Point(248, 34)
Me.PowerComboBox3.Name = "PowerComboBox3"
Me.PowerComboBox3.Size = New System.Drawing.Size(117, 21)
Me.PowerComboBox3.TabIndex = 9
'
'PowerComboBox2
'
Me.PowerComboBox2.CheckBoxes = False
Me.PowerComboBox2.DividerFormat = ""
Me.PowerComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
Me.PowerComboBox2.FormattingEnabled = True
Me.PowerComboBox2.GridColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer))
Me.PowerComboBox2.GroupColor = System.Drawing.SystemColors.WindowText
Me.PowerComboBox2.Items.AddRange(New Object() {"NT31 NT", "NT40 2000", "NT51 XP", "NT52 2003", "NT60 Vista", "NT60 2008", "NT70 Vienna"})
Me.PowerComboBox2.ItemSeparator1 = Global.Microsoft.VisualBasic.ChrW(44)
Me.PowerComboBox2.ItemSeparator2 = Global.Microsoft.VisualBasic.ChrW(38)
Me.PowerComboBox2.Location = New System.Drawing.Point(125, 34)
Me.PowerComboBox2.Name = "PowerComboBox2"
Me.PowerComboBox2.Size = New System.Drawing.Size(117, 21)
Me.PowerComboBox2.TabIndex = 6
'
'PowerComboBox1
'
Me.PowerComboBox1.CheckBoxes = False
Me.PowerComboBox1.DividerFormat = ""
Me.PowerComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
Me.PowerComboBox1.FormattingEnabled = True
Me.PowerComboBox1.GridColor = System.Drawing.Color.White
Me.PowerComboBox1.GroupColor = System.Drawing.SystemColors.WindowText
Me.PowerComboBox1.Items.AddRange(New Object() {"Ubunta 7.04", "Fedora 7", "openSuse 10.2", "Madriva 2007 Spring", "Knoppix 5.1.1", "Debian 4.0"})
Me.PowerComboBox1.ItemSeparator1 = Global.Microsoft.VisualBasic.ChrW(44)
Me.PowerComboBox1.ItemSeparator2 = Global.Microsoft.VisualBasic.ChrW(38)
Me.PowerComboBox1.Location = New System.Drawing.Point(3, 34)
Me.PowerComboBox1.Name = "PowerComboBox1"
Me.PowerComboBox1.Size = New System.Drawing.Size(117, 21)
Me.PowerComboBox1.TabIndex = 4
'
'Label6
'
Me.Label6.AutoSize = True
Me.Label6.Location = New System.Drawing.Point(12, 238)
Me.Label6.Name = "Label6"
Me.Label6.Size = New System.Drawing.Size(68, 14)
Me.Label6.TabIndex = 14
Me.Label6.Text = "SelectedItem"
'
'TextBox1
'
Me.TextBox1.Location = New System.Drawing.Point(86, 235)
Me.TextBox1.Name = "TextBox1"
Me.TextBox1.Size = New System.Drawing.Size(164, 20)
Me.TextBox1.TabIndex = 15
'
'Button1
'
Me.Button1.Location = New System.Drawing.Point(5, 113)
Me.Button1.Name = "Button1"
Me.Button1.Size = New System.Drawing.Size(75, 23)
Me.Button1.TabIndex = 16
Me.Button1.Text = "Button1"
Me.Button1.UseVisualStyleBackColor = True
'
'Form1
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.ClientSize = New System.Drawing.Size(619, 261)
Me.Controls.Add(Me.Button1)
Me.Controls.Add(Me.TextBox1)
Me.Controls.Add(Me.Label6)
Me.Controls.Add(Me.PowerComboBox5)
Me.Controls.Add(Me.Label5)
Me.Controls.Add(Me.PowerComboBox4)
Me.Controls.Add(Me.Label4)
Me.Controls.Add(Me.PowerComboBox3)
Me.Controls.Add(Me.Label3)
Me.Controls.Add(Me.PowerComboBox2)
Me.Controls.Add(Me.Label2)
Me.Controls.Add(Me.PowerComboBox1)
Me.Controls.Add(Me.Label1)
Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.KeyPreview = True
Me.Name = "Form1"
Me.Text = "PowerComboBox - Grouping | CheckBoxes | BackColoring | Hovering"
Me.ResumeLayout(False)
Me.PerformLayout()

End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PowerComboBox1 As xComboBox.PowerComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PowerComboBox2 As xComboBox.PowerComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PowerComboBox3 As xComboBox.PowerComboBox
    Friend WithEvents PowerComboBox4 As xComboBox.PowerComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PowerComboBox5 As xComboBox.PowerComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
