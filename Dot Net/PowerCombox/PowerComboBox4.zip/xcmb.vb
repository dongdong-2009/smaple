Option Explicit On

'http://www.codeproject.com/vb/net/xComboBox.asp                    ' VB-2005  | combobox with grouping + checkbox      |
'http://www.codeproject.com/cs/combobox/ImageCombo_NET.asp          ' C#-2003  | combobox with images                   |
'http://www.codeproject.com/useritems/CheckComboBox.asp             ' C#-2005  | combobox with checkboxs                | * DropDownBox doesn't stick while checking items
'http://www.codeproject.com/cs/combobox/ComboBoxFiringEvents.asp    ' C#-2005  | combobox with hover event
'Namespace System.Windows.Forms

Public Class PowerComboBox
Inherits ComboBox


'APIs
<System.Runtime.InteropServices.DllImport("user32.dll")> Private Shared Function SendMessage(ByVal hWnd As System.IntPtr, ByVal Msg As Integer, ByVal wParam As System.Int32, ByVal lParam As System.IntPtr) As Integer
End Function


'properties
Private mDividerFormat As String = ""
Private mGroupColor As Color = System.Drawing.SystemColors.WindowText 'ForeColor 'mediumblue
Private mItemsChecks() As Boolean
Private mCheckBoxes As Boolean
Private mGridColor As Color = Color.FromArgb(240, 248, 255)

'vars - last selected item
Private mRedrawingUnselected As Boolean
Private mGraphics As Graphics
Private mBounds As Rectangle
Private mIndex As Int32
Private mItemSeparator1 As Char = ","c
Private mItemSeparator2 As Char = "&"c
Private mGraphics_t As Graphics
Private mBounds_t As Rectangle
Private mIndex_t As Int32

Private mHoverIndex As Long

Private WithEvents mTimer1 As Timer

'events
Event ItemHover(ByVal eIndex As Int32)

'vars
Private mLastSelectedIndex As Int32 = -1


'constructor
Public Sub New()

    ' set draw mode to owner draw
    Me.DrawMode = Windows.Forms.DrawMode.OwnerDrawFixed 'DrawMode.OwnerDrawFixed

End Sub


'properties
<System.ComponentModel.Description("Use this property to set divider flag.  Recommend you use three hyphens ---.")> _
<System.ComponentModel.Category("Power Properties")> Public Property DividerFormat() As String
Get

    Return mDividerFormat

End Get
Set(ByVal value As String)

    mDividerFormat = value

End Set

End Property
<System.ComponentModel.Description("Use this property to set the ForeColor of the grouping text.")> _
<System.ComponentModel.Category("Power Properties")> Public Property GroupColor() As Color

Get

    Return mGroupColor

End Get
Set(ByVal value As Color)

    mGroupColor = value

End Set

End Property
<System.ComponentModel.Description("Use this property to set the BackColor of the grid.")> _
<System.ComponentModel.Category("Power Properties")> Public Property GridColor() As Color

Get

    Return mGridColor

End Get
Set(ByVal value As Color)

    mGridColor = value

End Set

End Property
<System.ComponentModel.Description("Use this property to get/set corresponding checkboc values.")> _
<System.ComponentModel.Category("Power Properties")> Public Property ItemsChecks(ByVal xIndex As Int32) As Boolean

    Get
    Return mItemsChecks(xIndex)
    End Get

    Set(ByVal value As Boolean)
    mItemsChecks(xIndex) = value
    End Set

End Property
<System.ComponentModel.Description("Use this property to enable checkboxes.")> _
<System.ComponentModel.Category("Power Properties")> Public Property CheckBoxes() As Boolean
    Get
    Return mCheckBoxes
    End Get
    Set(ByVal value As Boolean)
    mCheckBoxes = value
    End Set
End Property
<System.ComponentModel.Description("Use this property to set item separator1 character.")> _
<System.ComponentModel.Category("Power Properties")> Public Property ItemSeparator1() As Char
    Get
    Return mItemSeparator1
    End Get
    Set(ByVal value As Char)
    mItemSeparator1 = value
    End Set
End Property
<System.ComponentModel.Description("Use this property to set item separator2 character.")> _
<System.ComponentModel.Category("Power Properties")> Public Property ItemSeparator2() As Char
    Get
    Return mItemSeparator2
    End Get
    Set(ByVal value As Char)
    mItemSeparator2 = value
    End Set
End Property


'overrides
Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)


    MyBase.OnTextChanged(e)

End Sub
Protected Overrides Sub OnSelectedIndexChanged(ByVal e As System.EventArgs)

        'cancels SIC when user try to select a group
        If Me.DividerFormat.Length > 0 AndAlso Me.Text.Contains(Me.mDividerFormat) Then
        Me.SelectedIndex = mLastSelectedIndex 'NOTE restorre last valid selection
        Exit Sub
        End If

    mLastSelectedIndex = Me.SelectedIndex
    MyBase.OnSelectedIndexChanged(e)

End Sub
Protected Overrides Sub OnDrawItem(ByVal e As DrawItemEventArgs)

Dim zX1 As Int32
Dim zPen As Pen
Dim zWidth As Single
Dim zText As String
Dim zFont As Font
Dim zFore As Color
Dim zState As System.Windows.Forms.VisualStyles.CheckBoxState

        If e.Index < 0 Then
        MyBase.OnDrawItem(e)
        Exit Sub 'fix for designer error - hope doesnt effect runtime drawing
        End If

        'NOTE 1st part of if statement draw group item, 2nd draws actual item
        If Me.Items(e.Index).ToString.Contains(Me.mDividerFormat) And mDividerFormat.Length > 0 Then
        'background
           If e.Index = SelectedIndex Then
            e.DrawBackground()
            End If
        zText = Me.Items(e.Index).ToString
        zText = " " + zText.Replace(Me.mDividerFormat, "") + " "
        zFont = New Font(Font, FontStyle.Bold)      'group item
            If e.BackColor = System.Drawing.SystemColors.Highlight Then
            zFore = Color.Gainsboro 'Color.LightGray 'Color.Silver 'gray colr lets user know that shouldn't be selecting a group item
            Else
            zFore = Me.GroupColor 'e.ForeColor
            End If
        zPen = New Pen(zFore)
        'draw group
        zWidth = e.Graphics.MeasureString(zText, zFont).Width
        zX1 = Convert.ToInt32(e.Bounds.Width - zWidth) \ 2
        e.Graphics.DrawRectangle(zPen, New Rectangle(e.Bounds.X, e.Bounds.Y + e.Bounds.Height \ 2, zX1, 1))
        e.Graphics.DrawRectangle(zPen, New Rectangle(e.Bounds.Width - zX1, e.Bounds.Y + e.Bounds.Height \ 2, e.Bounds.Width, 1))
        e.Graphics.DrawString(zText, zFont, New SolidBrush(zFore), zX1, e.Bounds.Top)
        Else

            If mRedrawingUnselected Then
                If mIndex Mod 2 = 0 Then
                e.Graphics.FillRectangle(New SolidBrush(Color.White), mBounds) 'e.Bounds)'FIX for wrong bound being passed
                Else
                e.Graphics.FillRectangle(New SolidBrush(mGridColor), mBounds) 'e.Bounds) 'FIX for wrong bound being passed
                End If
            Else
                If e.Index = SelectedIndex Then
                e.DrawBackground()
                Else
                    If e.Index Mod 2 = 0 Then
                    e.Graphics.FillRectangle(New SolidBrush(Color.White), e.Bounds)
                    Else
                    e.Graphics.FillRectangle(New SolidBrush(mGridColor), e.Bounds)
                    End If
                End If
            End If


            'checkbox work
            If mCheckBoxes Then
                If e.BackColor = System.Drawing.SystemColors.Highlight Then
                    If Me.ItemsChecks(e.Index) Then
                    zState = VisualStyles.CheckBoxState.CheckedHot
                    Else
                    zState = VisualStyles.CheckBoxState.UncheckedHot
                    End If
                Else
                    If Me.ItemsChecks(e.Index) Then
                    zState = VisualStyles.CheckBoxState.CheckedNormal
                    Else
                    zState = VisualStyles.CheckBoxState.UncheckedNormal
                    End If
                End If
            zX1 = Me.FontHeight '/ 2 'variable re-use
            zPen = New Pen(Color.Black, 1)
            zPen.DashStyle = Drawing2D.DashStyle.Dot
            'e.Graphics.DrawLine(zPen, e.Bounds.Left, e.Bounds.Top + zX1, e.Bounds.Left + e.Bounds.Width, e.Bounds.Top + zX1)
            Windows.Forms.CheckBoxRenderer.DrawCheckBox(e.Graphics, New System.Drawing.Point(e.Bounds.X + e.Bounds.Width - 15, e.Bounds.Y + 1), e.Bounds, "", Me.Font, False, zState)
            End If

        'text work
        e.Graphics.DrawString(Me.Items(e.Index).ToString, Font, New SolidBrush(e.ForeColor), e.Bounds.Left, e.Bounds.Top)
        End If

        'exits here when redrawing unselected
        If mRedrawingUnselected Then
        mRedrawingUnselected = False
        Else

            'NOTE just seems to work 100% when timer is used in conjunction with .Bound override of old graphics property
            If SelectedIndex = e.Index Then
            mGraphics_t = e.Graphics
            mBounds_t = e.Bounds
            mIndex_t = e.Index
            mTimer1 = New Timer()
            mTimer1.Interval = 5
            mTimer1.Enabled = True
            End If

        End If

    MyBase.OnDrawItem(e)

End Sub
Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)

Const WM_SETCURSOR As Int32 = 32
Const WM_WINDOWPOSCHANGING As Int32 = 70
Const WM_COMMAND As Int32 = 273
Const WM_CTLCOLORLISTBOX As Integer = 308
Const CB_ADDSTRING As Int32 = 323
Const CB_GETCURSEL As Int32 = 327
Const WM_LBUTTONUP As Int32 = 514
Const OCM_COMMAND As Int32 = 8465

Dim yPos As Int32

        Select Case True
        Case m.Msg = WM_WINDOWPOSCHANGING  '.DropDownClose (more effective catching of )



        Case m.Msg = WM_CTLCOLORLISTBOX Or m.Msg = WM_SETCURSOR '.ItemHover (more effective catching of )
        yPos = Me.PointToClient(Cursor.Position).Y
            If Me.DropDownStyle = ComboBoxStyle.Simple Then
            yPos -= (Me.ItemHeight + 10)
            Else
            yPos -= (Me.Size.Height + 1)
            End If
        mHoverIndex = yPos / Me.ItemHeight

            If mHoverIndex >= 0 Then 'FIX for not raising event on mouse over text
            mHoverIndex = Convert.ToInt32(mHoverIndex)
                If mHoverIndex > -1 And mHoverIndex < Me.Items.Count And Me.DroppedDown Then
                RaiseEvent ItemHover(mHoverIndex)
                End If
            Else
            'NOTE should really raisevent with -1
            End If

        Case m.Msg = CB_ADDSTRING And m.WParam = New IntPtr(0) '.AddItem(s) for stretching ItemChecks array
        StretchCheckList()



        Case m.Msg = WM_COMMAND And m.WParam = New System.IntPtr(66536) 'intercepts WM_COMMAND (which prevent DropDownBox from closing after WM_LBUTTONDOWN)
'.(.ToString)

            '0. normal behaviour when no checkboxes
            If Not Me.mCheckBoxes Then
            MyBase.WndProc(m)
            Exit Sub
            End If

            'cancels SIC when user try to select a group
            If Me.DividerFormat.Length > 0 AndAlso Me.Items(mHoverIndex).Contains(Me.mDividerFormat) Then
            'Me.SelectedIndex = mLastSelectedIndex 'NOTE restorre last valid selection
            'Exit Sub
            MyBase.WndProc(m)
            Exit Sub
            End If

        '1. reconstructs (cancelled) child events from WM_COMMAND MSG
        PowerComboBox.SendMessage(Me.Handle, OCM_COMMAND, 591814, New IntPtr(1705748))  '1 event reconstruuction
        PowerComboBox.SendMessage(Me.Handle, OCM_COMMAND, 67526, New IntPtr(1705748))   '2 flagging redraw
        PowerComboBox.SendMessage(Me.Handle, CB_GETCURSEL, 0, New IntPtr(0))            '3 event reconstruuction
        PowerComboBox.SendMessage(Me.Handle, WM_LBUTTONUP, 0, New IntPtr(721012))       '4 flagging redraw

            '2. toggle checkbox
            If SelectedIndex > -1 Then
            Me.ItemsChecks(SelectedIndex) = Not Me.ItemsChecks(SelectedIndex)
            End If

        ' Me.ItemsChecks(mHoverIndex) = Not Me.ItemsChecks(mHoverIndex)

            '3. throw 'hover' \ Msg308 Or Msg32  so item is repainted
            If Me.SelectedIndex = 0 Then
            yPos = Me.Font.Height
            Else
            yPos = Me.Font.Height * -1
            End If
        Windows.Forms.Cursor.Position = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y + yPos)
        Application.DoEvents()
        Windows.Forms.Cursor.Position = New Point(Windows.Forms.Cursor.Position.X, Windows.Forms.Cursor.Position.Y - yPos)

        Me.Text = GetCommaText() 'NEW CSV test for checkboxes

        '4. cancels event
        Exit Sub
        End Select

    MyBase.WndProc(m)

End Sub


'private
Private Sub StretchCheckList()

    ReDim Preserve mItemsChecks(Me.Items.Count - 1)

End Sub
Private Sub mTimer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles mTimer1.Tick

    mTimer1.Enabled = False
    mRedrawingUnselected = True
    MyBase.OnDrawItem(New System.Windows.Forms.DrawItemEventArgs(mGraphics, Me.Font, mBounds, mIndex, DrawItemState.Default))
    mGraphics = mGraphics_t
    mBounds = mBounds_t
    mIndex = mIndex_t

End Sub
Private Function GetCommaText() As String

Dim i As Int32
Dim sb As New System.Text.StringBuilder("")
Dim s As String
Dim zFirst As String
Dim zLast As String
Dim zLastComa As Int32

        If Not Me.CheckBoxes Then Return Me.Text

        For i = 0 To Me.Items.Count - 1
            If Me.ItemsChecks(i) = -1 Then
            sb.Append(Me.Items(i))
            sb.Append(mItemSeparator1)
            End If
        Next

    s = sb.ToString
        If s.Length = 0 Then Return Me.Text
    s = s.Substring(0, s.Length - 1)
    zLastComa = s.LastIndexOf(mItemSeparator1)
        If zLastComa = -1 Then Return Me.Text
    zLast = s.Substring(zLastComa)
    zFirst = s.Substring(0, zLastComa)
    s = zFirst + " " + zLast.Replace(mItemSeparator1, mItemSeparator2 + " ")
    Return s

End Function
End Class
