Public Class Form1



Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    Me.PowerComboBox1.DroppedDown = True
    Me.PowerComboBox2.DroppedDown = True

End Sub

Private Sub PowerComboBox1_ItemHover(ByVal eIndex As Integer) Handles PowerComboBox1.ItemHover

    Me.TextBox1.Text = "(" + eIndex.ToString + ") " + Me.PowerComboBox1.Items(eIndex)

End Sub

Private Sub PowerComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PowerComboBox1.SelectedIndexChanged

End Sub

Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

End Sub

Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
  Trace.WriteLine(Me.PowerComboBox1.SelectedIndex.ToString)
End Sub
End Class
