//INSTANT C# NOTE: Formerly VB.NET project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace xComboBox
{
	public partial class Form1
	{



		internal Form1()
		{
			InitializeComponent();
		}
	private void Button1_Click(object sender, System.EventArgs e)
	{

		this.PowerComboBox1.DroppedDown = true;
		this.PowerComboBox2.DroppedDown = true;

	}

	private void PowerComboBox1_ItemHover(int eIndex)
	{

		this.TextBox1.Text = "(" + eIndex.ToString() + ") " + this.PowerComboBox1.Items[eIndex];

	}

	private void PowerComboBox1_SelectedIndexChanged(object sender, System.EventArgs e)
	{

	}

	private void Form1_Load(object sender, System.EventArgs e)
	{

	}

	private void Button1_Click_1(object sender, System.EventArgs e)
	{
	  Trace.WriteLine(this.PowerComboBox1.SelectedIndex.ToString());
	}
	}

} //end of root namespace