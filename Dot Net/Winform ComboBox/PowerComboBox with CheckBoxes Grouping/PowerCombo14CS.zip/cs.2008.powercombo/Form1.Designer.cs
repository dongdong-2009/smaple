//INSTANT C# NOTE: Formerly VB.NET project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace PowerComboBox
{
	[Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
	public partial class Form1 : System.Windows.Forms.Form
	{

		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		//Required by the Windows Form Designer
		private System.ComponentModel.IContainer components;

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]
		private void InitializeComponent()
		{
	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
	this.Label1 = new System.Windows.Forms.Label();
	this.Label2 = new System.Windows.Forms.Label();
	this.Label3 = new System.Windows.Forms.Label();
	this.Label4 = new System.Windows.Forms.Label();
	this.Label5 = new System.Windows.Forms.Label();
	this.TextBox1 = new System.Windows.Forms.TextBox();
	this.Label6 = new System.Windows.Forms.Label();
	this.PowerComboBox5 = new PowerComboBox();
	this.PowerComboBox4 = new PowerComboBox();
	this.PowerComboBox3 = new PowerComboBox();
	this.PowerComboBox2 = new PowerComboBox();
	this.PowerComboBox1 = new PowerComboBox();
	this.SuspendLayout();
//
//Label1
//
	this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	this.Label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label1.Location = new System.Drawing.Point(3, 5);
	this.Label1.Name = "Label1";
	this.Label1.Size = new System.Drawing.Size(117, 26);
	this.Label1.TabIndex = 3;
	this.Label1.Text = "Linux";
	this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//Label2
//
	this.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	this.Label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label2.Location = new System.Drawing.Point(125, 5);
	this.Label2.Name = "Label2";
	this.Label2.Size = new System.Drawing.Size(117, 26);
	this.Label2.TabIndex = 5;
	this.Label2.Text = "Microsoft";
	this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//Label3
//
	this.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	this.Label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label3.Location = new System.Drawing.Point(248, 5);
	this.Label3.Name = "Label3";
	this.Label3.Size = new System.Drawing.Size(117, 26);
	this.Label3.TabIndex = 7;
	this.Label3.Text = "Databases";
	this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//Label4
//
	this.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	this.Label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label4.Location = new System.Drawing.Point(371, 5);
	this.Label4.Name = "Label4";
	this.Label4.Size = new System.Drawing.Size(117, 26);
	this.Label4.TabIndex = 10;
	this.Label4.Text = "Software";
	this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//Label5
//
	this.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	this.Label5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label5.Location = new System.Drawing.Point(495, 5);
	this.Label5.Name = "Label5";
	this.Label5.Size = new System.Drawing.Size(117, 26);
	this.Label5.TabIndex = 12;
	this.Label5.Text = "Hardware";
	this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//TextBox1
//
	this.TextBox1.Location = new System.Drawing.Point(4, 217);
	this.TextBox1.Name = "TextBox1";
	this.TextBox1.Size = new System.Drawing.Size(116, 20);
	this.TextBox1.TabIndex = 15;
//
//Label6
//
	this.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	this.Label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Label6.Location = new System.Drawing.Point(3, 189);
	this.Label6.Name = "Label6";
	this.Label6.Size = new System.Drawing.Size(117, 26);
	this.Label6.TabIndex = 19;
	this.Label6.Text = "Selected Item";
	this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//
//PowerComboBox5
//
	this.PowerComboBox5.CheckBoxes = true;
	this.PowerComboBox5.Checked = System.Windows.Forms.CheckState.Unchecked;
	this.PowerComboBox5.DividerFormat = "---";
	this.PowerComboBox5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
	this.PowerComboBox5.FormattingEnabled = true;
	this.PowerComboBox5.GridColor = System.Drawing.Color.FromArgb(System.Convert.ToInt32(System.Convert.ToByte(240)), System.Convert.ToInt32(System.Convert.ToByte(248)), System.Convert.ToInt32(System.Convert.ToByte(255)));
	this.PowerComboBox5.GroupColor = System.Drawing.Color.Crimson;
	this.PowerComboBox5.Items.AddRange(new object[] {"---Networking", "Adapters", "Broadband Accessories", "Hubs", "NICs", "VOIP", "Print Servers", "---Storage", "Floppy drives", "DVD -RW/+RW", "HDD -IDE", "HDD -SATAI", "HDD -SATAII", "HDD -SCSI", "---Laptops", "Batteries", "Dongles", "Charges", "Drives", "Memory", "Hubs", "---Components", "RAM", "Processor", "Motherboard", "PSU", "Cooling", "Cables", "---Input", "Scanner", "Joystick", "Keyboard", "Mice", "Infrared"});
	this.PowerComboBox5.ItemSeparator1 = (char)(44);
	this.PowerComboBox5.ItemSeparator2 = (char)(38);
	this.PowerComboBox5.Location = new System.Drawing.Point(495, 34);
	this.PowerComboBox5.Name = "PowerComboBox5";
	this.PowerComboBox5.Size = new System.Drawing.Size(117, 21);
	this.PowerComboBox5.TabIndex = 13;
//
//PowerComboBox4
//
	this.PowerComboBox4.CheckBoxes = false;
	this.PowerComboBox4.Checked = System.Windows.Forms.CheckState.Unchecked;
	this.PowerComboBox4.DividerFormat = "---";
	this.PowerComboBox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
	this.PowerComboBox4.FormattingEnabled = true;
	this.PowerComboBox4.GridColor = System.Drawing.Color.FromArgb(System.Convert.ToInt32(System.Convert.ToByte(240)), System.Convert.ToInt32(System.Convert.ToByte(248)), System.Convert.ToInt32(System.Convert.ToByte(255)));
	this.PowerComboBox4.GroupColor = System.Drawing.SystemColors.WindowText;
	this.PowerComboBox4.Items.AddRange(new object[] {"---Microsoft", "Vista", "Visual Studio", "DirectX", "Office2007", "---Open Source", "FileZilla", "NSIS", "Notepad++", "WinMerge", "UltraVNC", "---MySQL", "SQL Server Community Edition", "GUI-TOOLS", "NET\\Connector", "ODBC\\Connector"});
	this.PowerComboBox4.ItemSeparator1 = (char)(44);
	this.PowerComboBox4.ItemSeparator2 = (char)(38);
	this.PowerComboBox4.Location = new System.Drawing.Point(371, 34);
	this.PowerComboBox4.Name = "PowerComboBox4";
	this.PowerComboBox4.Size = new System.Drawing.Size(117, 21);
	this.PowerComboBox4.TabIndex = 11;
//
//PowerComboBox3
//
	this.PowerComboBox3.CheckBoxes = true;
	this.PowerComboBox3.Checked = System.Windows.Forms.CheckState.Unchecked;
	this.PowerComboBox3.DividerFormat = "";
	this.PowerComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
	this.PowerComboBox3.FormattingEnabled = true;
	this.PowerComboBox3.GridColor = System.Drawing.Color.FromArgb(System.Convert.ToInt32(System.Convert.ToByte(240)), System.Convert.ToInt32(System.Convert.ToByte(248)), System.Convert.ToInt32(System.Convert.ToByte(255)));
	this.PowerComboBox3.GroupColor = System.Drawing.SystemColors.WindowText;
	this.PowerComboBox3.Items.AddRange(new object[] {"SQL Server", "Access", "Oracle", "DB2", "FileMaker", "MySQL"});
	this.PowerComboBox3.ItemSeparator1 = (char)(44);
	this.PowerComboBox3.ItemSeparator2 = (char)(38);
	this.PowerComboBox3.Location = new System.Drawing.Point(248, 34);
	this.PowerComboBox3.Name = "PowerComboBox3";
	this.PowerComboBox3.Size = new System.Drawing.Size(117, 21);
	this.PowerComboBox3.TabIndex = 9;
//
//PowerComboBox2
//
	this.PowerComboBox2.CheckBoxes = false;
	this.PowerComboBox2.Checked = System.Windows.Forms.CheckState.Unchecked;
	this.PowerComboBox2.DividerFormat = "";
	this.PowerComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
	this.PowerComboBox2.FormattingEnabled = true;
	this.PowerComboBox2.GridColor = System.Drawing.Color.FromArgb(System.Convert.ToInt32(System.Convert.ToByte(240)), System.Convert.ToInt32(System.Convert.ToByte(248)), System.Convert.ToInt32(System.Convert.ToByte(255)));
	this.PowerComboBox2.GroupColor = System.Drawing.SystemColors.WindowText;
	this.PowerComboBox2.Items.AddRange(new object[] {"NT31 NT", "NT40 2000", "NT51 XP", "NT52 2003", "NT60 Vista", "NT60 2008", "NT70 Vienna"});
	this.PowerComboBox2.ItemSeparator1 = (char)(44);
	this.PowerComboBox2.ItemSeparator2 = (char)(38);
	this.PowerComboBox2.Location = new System.Drawing.Point(125, 34);
	this.PowerComboBox2.Name = "PowerComboBox2";
	this.PowerComboBox2.Size = new System.Drawing.Size(117, 21);
	this.PowerComboBox2.TabIndex = 6;
//
//PowerComboBox1
//
	this.PowerComboBox1.CheckBoxes = false;
	this.PowerComboBox1.Checked = System.Windows.Forms.CheckState.Unchecked;
	this.PowerComboBox1.DividerFormat = "";
	this.PowerComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
	this.PowerComboBox1.FormattingEnabled = true;
	this.PowerComboBox1.GridColor = System.Drawing.Color.White;
	this.PowerComboBox1.GroupColor = System.Drawing.SystemColors.WindowText;
	this.PowerComboBox1.Items.AddRange(new object[] {"Ubunta 7.04", "Fedora 7", "openSuse 10.2", "Madriva 2007 Spring", "Knoppix 5.1.1", "Debian 4.0"});
	this.PowerComboBox1.ItemSeparator1 = (char)(44);
	this.PowerComboBox1.ItemSeparator2 = (char)(38);
	this.PowerComboBox1.Location = new System.Drawing.Point(3, 34);
	this.PowerComboBox1.Name = "PowerComboBox1";
	this.PowerComboBox1.Size = new System.Drawing.Size(117, 21);
	this.PowerComboBox1.TabIndex = 4;
//
//Form1
//
	this.AutoScaleDimensions = new System.Drawing.SizeF((float)(6.0), (float)(14.0));
	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
	this.ClientSize = new System.Drawing.Size(619, 244);
	this.Controls.Add(this.Label6);
	this.Controls.Add(this.TextBox1);
	this.Controls.Add(this.PowerComboBox5);
	this.Controls.Add(this.Label5);
	this.Controls.Add(this.PowerComboBox4);
	this.Controls.Add(this.Label4);
	this.Controls.Add(this.PowerComboBox3);
	this.Controls.Add(this.Label3);
	this.Controls.Add(this.PowerComboBox2);
	this.Controls.Add(this.Label2);
	this.Controls.Add(this.PowerComboBox1);
	this.Controls.Add(this.Label1);
	this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(0));
	this.Icon = (System.Drawing.Icon)(resources.GetObject("$this.Icon"));
	this.KeyPreview = true;
	this.Name = "Form1";
	this.Text = "PowerComboBox - Grouping, CheckBoxes, BackColoring, Hovering";
	this.ResumeLayout(false);
	this.PerformLayout();

		//INSTANT C# NOTE: Converted event handlers:
		PowerComboBox1.ItemHover += new PowerComboBox.ItemHoverEventHandler(PowerComboBox1_ItemHover);
		PowerComboBox5.ItemChecked += new PowerComboBox.ItemCheckedEventHandler(PowerComboBox5_ItemChecked);

	}
		internal System.Windows.Forms.Label Label1;
		internal PowerComboBox PowerComboBox1;
		internal System.Windows.Forms.Label Label2;
		internal PowerComboBox PowerComboBox2;
		internal System.Windows.Forms.Label Label3;
		internal PowerComboBox PowerComboBox3;
		internal PowerComboBox PowerComboBox4;
		internal System.Windows.Forms.Label Label4;
		internal PowerComboBox PowerComboBox5;
		internal System.Windows.Forms.Label Label5;
		internal System.Windows.Forms.TextBox TextBox1;
		internal System.Windows.Forms.Label Label6;

	}

} //end of root namespace