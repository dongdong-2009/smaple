//INSTANT C# NOTE: Formerly VB.NET project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace PowerComboBox
{
	public partial class Form1
	{
		internal Form1()
		{
			InitializeComponent();
		}
	private void PowerComboBox1_ItemHover(int eIndex)
	{
		this.TextBox1.Text = "(" + eIndex.ToString() + ") " + this.PowerComboBox1.Items[eIndex]; //Item Hover demonstration
	}
	private void PowerComboBox5_ItemChecked(int eIndex)
	{
		Trace.WriteLine("PowerComboBox5_ItemChecked" + eIndex.ToString());
	}
	}
} //end of root namespace