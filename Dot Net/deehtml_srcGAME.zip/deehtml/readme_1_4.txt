DeeHTML v1.41
by PK 2006-07

=========================================
Web Address	
=========================================
www.codeproject.com/useritems/deehtml.asp


=========================================
Notes
=========================================
-A simple DHTML platform game & Level Designer created entirely out of HTML+CSS+Javascript.

-Requires IE5+ or Mozilla 1.7 or Firefox 1.03+.
-See disclaimer at bottom of this file for terms.

-Ideally this should be run with a minimal set of applications running in the background.
Coding was done with a "let's see if this works" approach as I have never attempted a game before. At any moment browser limitations may have put a halt to the exercise, but thankfully each problem was tackled, sometimes assisted by up to 3 cups of tea.Please be aware this is an unorthodox use of DHTML, and it ain't perfect.
Post your comments and levels links to the web address above on codeproject!

Made in Ireland
=========================================
Disclaimer
=========================================

   This software is provided "AS IS" without warranty of any kind, either
   expressed or implied, including, but not limited to, the implied
   warranties of merchantability and fitness for a particular purpose. The
   entire risk as to the quality and performance of this software is with
   you.

   In no event will the author, distributor or any other party be liable to
   you for damages, including any general, special, incidental or
   consequential damages arising out of the use, misuse or inability to use
   this software (including but not limited to loss of data or losses
   sustained by you or third parties or a failure of this software to operate
   with any other software), even if such party has been advised of the
   possibility of such damages.

