﻿namespace ColorComboTestApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.colorComboBox2 = new ColorComboTestApp.ColorComboBox();
            this.colorComboBox1 = new ColorComboTestApp.ColorComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Extended Colors:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Basic Colors:";
            // 
            // colorComboBox2
            // 
            this.colorComboBox2.Extended = false;
            this.colorComboBox2.Location = new System.Drawing.Point(154, 61);
            this.colorComboBox2.Name = "colorComboBox2";
            this.colorComboBox2.SelectedColor = System.Drawing.Color.Black;
            this.colorComboBox2.Size = new System.Drawing.Size(103, 23);
            this.colorComboBox2.TabIndex = 3;
            // 
            // colorComboBox1
            // 
            this.colorComboBox1.Extended = true;
            this.colorComboBox1.Location = new System.Drawing.Point(154, 26);
            this.colorComboBox1.Name = "colorComboBox1";
            this.colorComboBox1.SelectedColor = System.Drawing.Color.Black;
            this.colorComboBox1.Size = new System.Drawing.Size(103, 23);
            this.colorComboBox1.TabIndex = 0;
            this.colorComboBox1.ColorChanged += new ColorComboTestApp.ColorChangedHandler(this.OnColorChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 110);
            this.Controls.Add(this.colorComboBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.colorComboBox1);
            this.Name = "Form1";
            this.Text = "ColorCombo Test Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ColorComboBox colorComboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private ColorComboBox colorComboBox2;



    }
}

