using System;
using System.Collections.Generic;
using System.Web;
using System.Web.SessionState;

namespace Activa.ProMesh
{
    public class AjaxProHandler : IHttpHandler , IRequiresSessionState
    {
        private static readonly Type _ajaxProFactoryType;

        static AjaxProHandler()
        {
            _ajaxProFactoryType = Type.GetType("AjaxPro.AjaxHandlerFactory, AjaxPro.2", false);
        }

        public void ProcessRequest(HttpContext context)
        {
            ProMeshHttpContext.CreateSessionContext(context);

            IHttpHandlerFactory ajaxProFactory = (IHttpHandlerFactory)Activator.CreateInstance(_ajaxProFactoryType);

            IHttpHandler httpHandler = ajaxProFactory.GetHandler(context, context.Request.RequestType, context.Request.RawUrl, context.Request.PhysicalApplicationPath);

            httpHandler.ProcessRequest(context);
        }

        public bool IsReusable
        {
            get { return true; }
        }
    }
}
