//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;

namespace Activa.ExpressionParser
{
	public enum ElementType 
	{ 
		Term, 
		Operator, 
		UnaryOperator , 
		Function , 
		LeftParen , 
		RightParen ,
        PropertyOperator
	};

	internal class ElementDefinition<T>
	{
		private readonly ElementType _elementType = ElementType.Term;
		private readonly string       _pattern;
		private readonly int          _precedence;

		public ExpressionEvaluator<T> Evaluator = null;

		public ElementDefinition(ElementType elementType , string pattern)
		{
			_elementType = elementType;
			_pattern = pattern;

			switch (elementType)
			{
				case ElementType.LeftParen  : _precedence = -1;           break;
				case ElementType.RightParen : _precedence = -1;           break;
				case ElementType.Function   : _precedence = 0;            break;
				case ElementType.Term       : _precedence = int.MaxValue; break;
                case ElementType.PropertyOperator: _precedence = 1000;    break;
				default                      : _precedence = 0;           break;
			}
		}

		public ElementDefinition(ElementType Type, int Precedence , string Pattern)
		{
			_elementType = Type;
			_precedence = Precedence;
			_pattern = Pattern;
		}


		public ElementType Type
		{
			get { return _elementType;}
		}

		public string Pattern
		{
			get { return _pattern; }
		}

		public int Precedence
		{
			get { return _precedence; }
		}
	}
}
