//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;

namespace Activa.ExpressionParser
{
    public class Expression<T>
	{
        private readonly ElementStack<T> _operatorStack = new ElementStack<T>();
        private readonly ElementQueue<T> _elementQueue = new ElementQueue<T>();

        private Element<T>[] _exprElements = null;

//        public ExpressionEvaluator<T> Evaluator = null;
//		public T EvaluatorData = default(T);

        private readonly ExpressionParser<T> _parser;

        public Expression(ExpressionParser<T> parser)
        {
            _parser = parser;
            
        }

        internal void ApplyElement(Element<T> element)
		{
            if (element.IsFunction)
            {
                ElementDefinition<T> elDef = new ElementDefinition<T>(ElementType.Term, element.ElementDefinition.Pattern);

                elDef.Evaluator = _parser.FunctionNameEvaulator;

                ApplyElement(new Element<T>(elDef , element.Text));

                element.Text = "f";
            }

			if (element.IsTerm)
			{
				_elementQueue.Enqueue(element);

				if (_operatorStack.Count > 0 && _operatorStack.Peek().IsLeftParen)
					_operatorStack.Peek().NumTerms++;

				return;
			}

			if (element.IsLeftParen)
			{
				_operatorStack.Push(element);
				return;
			}

			if (element.IsRightParen)
			{
				while (_operatorStack.Count > 0)
				{
                    Element<T> stackElement = _operatorStack.Pop();

					if (stackElement.IsLeftParen)
					{
						if (_operatorStack.Count > 0 && _operatorStack.Peek().IsFunction)
						{
							_operatorStack.Peek().NumTerms = stackElement.NumTerms;

							_elementQueue.Enqueue(_operatorStack.Pop());

//							if (_operatorStack.Count > 0 && _operatorStack.Peek().IsLeftParen)
//								_operatorStack.Peek().NumTerms++;
						}

						break;
					}

					_elementQueue.Enqueue(stackElement);
				}

				return;
			}

			// When we get here, it certainly is an operator or function

			while (_operatorStack.Count > 0)
			{
                Element<T> stackElement = _operatorStack.Peek();

				if (stackElement.Precedence >= element.Precedence && !stackElement.IsUnary)
					_elementQueue.Enqueue(_operatorStack.Pop());
				else
					break;
			}

			_operatorStack.Push(element);
		}

		internal void Start()
		{
			_operatorStack.Clear();
			_elementQueue.Clear();
		}

		internal void Finish()
		{
			while (_operatorStack.Count > 0)
				_elementQueue.Enqueue(_operatorStack.Pop());

			int numElements = _elementQueue.Count;

            _exprElements = new Element<T>[numElements];

			for (int i = 0 ; i < numElements ; i++)
				_exprElements[i] = _elementQueue.Dequeue();

			_elementQueue.Clear();
			_operatorStack.Clear();
		}

		public object Evaluate(T data)
		{
			Stack tempStack = new Stack();

            foreach (Element<T> exprElement in _exprElements)
			{
                ExpressionEvaluator<T> exprEvaluator = exprElement.ElementDefinition.Evaluator;

				if (exprElement.IsTerm)
				{
					tempStack.Push(exprEvaluator(data,null,new object[] {exprElement.Text}));
				}
				else
				{
                    int numTerms = exprElement.NumTerms;

                    if (exprElement.IsFunction)
                        numTerms++;

					object[] arr = new object[numTerms];
					
					for (int i = numTerms - 1; i >= 0 ; i--)
						arr[i] = tempStack.Pop();

					tempStack.Push(exprEvaluator(data,exprElement.Text , arr));
				}
			}

			object result = tempStack.Pop();

            if (_parser.FinalEvaluator != null)
                return _parser.FinalEvaluator(data, null, new object[] { result });
            else 
                return result;
		}
	}
}
