//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;

namespace Activa.ExpressionParser.DotNet
{
    public interface IDotNetParserContext
    {
        bool Exists(string name);
        object Get(string name);
        int GetCurrentListIndex(string name);

        NamespaceSpecificiation[] Namespaces {get;}
    }

    public class NamespaceSpecificiation
    {
        public NamespaceSpecificiation(string namespaceName)
        {
            NamespaceName = namespaceName;
        }

        public NamespaceSpecificiation(string namespaceName, Assembly assembly)
        {
            NamespaceName = namespaceName;
            Assembly = assembly;
        }

        public string NamespaceName;
        public Assembly Assembly;
    }


    public class DotNetExpressionParser : ExpressionParser<IDotNetParserContext>
    {
        private class Variable
        {
            public readonly string Name;

            public Variable(string name)
            {
                Name = name;
            }
        }

        private class MethodDefinition
        {
            public MethodDefinition(object targetObject, Type type, string name)
            {
                TargetObject = targetObject;
                Name = name;
                Type = type;
            }

            public readonly object TargetObject;
            public readonly Type Type;
            public readonly string Name;
        }

        private static readonly NumberFormatInfo _numberFormat;

        static DotNetExpressionParser()
        {
            _numberFormat = new NumberFormatInfo();

            _numberFormat.NumberDecimalSeparator = ".";
            _numberFormat.NumberGroupSeparator = ",";
            _numberFormat.NumberGroupSizes = new int[] { 3 };
        }

        public DotNetExpressionParser()
        {
            AddTerm(@"""[^""]*""", evalStringLiteral);

            AddPropertyOperator(@"\.", evalDotOperator);


            AddOperator(@"\*|/|%"   , 4, evalOperator);
            AddOperator(@"\+|\-"    , 3, evalOperator);
            AddOperator(@"==|<=|>=|!=|<|>" , 2, evalOperator);
            AddOperator(@"\|\||&&"  , 1 ,evalOperator);

            AddUnaryOperator(@"!" , 5, evalNot);

            AddFunction(@"new\s+[a-zA-Z_][a-zA-Z0-9_]*", evalConstructor);
            AddFunction(@"[a-zA-Z_][a-zA-Z0-9_]*" , evalFunction );

            AddTerm(@"[a-zA-Z_@][a-zA-Z0-9_]*"     , evalVarName);
            AddTerm(@"\-?\d+(?:\.\d+)?" , evalNumber);


            AddTerm(@"'[^']'", evalCharLiteral);

            IgnoreCase = false;

            FunctionNameEvaulator = evalVarName;
            FinalEvaluator = evalVariable;
        }

        private static object evalCharLiteral(IDotNetParserContext customData, string op, object[] terms)
        {
            return ((string)terms[0])[1];
        }

        private static object evalDotOperator(IDotNetParserContext context, string op, object[] terms)
        {
            object obj = terms[0];
            Variable propertyName = (Variable) terms[1];

            if (obj is Variable)
            {
                if (propertyName.Name.StartsWith("@"))
                {
                    int index = GetVariableTableIndex(context, (Variable) obj);

                    switch (propertyName.Name)
                    {
                        case "@oe":
                        case "@oddeven":
                            return ((index % 2) == 0) ? "even" : "odd";
                        case "@OE":
                        case "@OddEven":
                            return ((index % 2) == 0) ? "Even" : "Odd";
                        case "@ODDEVEN":
                            return ((index % 2) == 0) ? "EVEN" : "ODD";
                        case "@n":
                        case "@N":
                        case "@rownum":
                        case "@RowNum":
                        case "@ROWNUM":
                        case "@index":
                        case "@Index":
                        case "@INDEX":
                            return index;
                        default:
                            return null;
                    }
                }
                
                obj = GetVariable(context, (Variable) obj);
            }

            return DotOperator(obj, propertyName);
        }

        private static bool IsInteger(object value)
        {
            return (value is Int32 || value is Int16 || value is Int64 || value is UInt16 || value is UInt32 || value is Byte || value is SByte);
        }

        private static bool IsDouble(object value)
        {
            return (value is double || value is float);
        }

        private static object evalFunction(IDotNetParserContext context, string functionName, object[] arguments)
        {
            if (!(arguments[0] is MethodDefinition))
                throw new Exception("Unexpected function call");

            MethodDefinition function = null;

            List<object> parameters = new List<object>();

            for (int i = 0 ; i< arguments.Length ; i++)
            {
                if (i == 0)
                    function = (MethodDefinition)arguments[0];
                else
                {
                    if (arguments[i] is Variable)
                        parameters.Add(GetVariable(context,(Variable) arguments[i]));
                    else 
                        parameters.Add(arguments[i]);
                }
            }
           

            return CallDotNetMethod(function, parameters.ToArray());
        }

        private static object evalConstructor(IDotNetParserContext context, string functionName, object[] arguments)
        {
            string className = ((Variable)arguments[0]).Name;

            if (!className.StartsWith("new "))
                throw new Exception("Unexpected constructor call");

            className = className.Substring(4);

            Type objectType = (Type)GetVariable(context, new Variable(className));

            List<object> parameters = new List<object>();

            for (int i = 1; i < arguments.Length; i++)
            {
                if (arguments[i] is Variable)
                    parameters.Add(GetVariable(context, (Variable) arguments[i]));
                else
                    parameters.Add(arguments[i]);
            }

            return CallConstructor(objectType, parameters.ToArray());
        }

        private static object evalNot(IDotNetParserContext context, string op, object[] terms)
        {
            object data = terms[0];

            if (data is Variable)
                data = GetVariable(context, (Variable) data);

            if (data == null)
            {
                data = false;
            }
            else if (data is bool)
            {
                data = (bool)data;
            }
            else if (IsInteger(data))
            {
                data = (Convert.ToInt64(data) != 0);
            }
            else if (data is string)
            {
                data = ((string)data).Trim().Length > 0;
            }
            else if (data is decimal)
            {
                data = ((decimal)data) != 0m;
            }
            else if (IsDouble(data))
            {
                data = (Convert.ToDouble(data) != 0.0);
            }
            else if (data is DateTime)
            {
                data = ((DateTime)data) == DateTime.MinValue;
            }
            else
            {
                data = true;
            }

            return !((bool)data);
        }

        private static double ToDouble(object obj)
        {
            if (obj is double)
                return (double)obj;
            else
                return Convert.ToDouble(obj, _numberFormat);
        }

        private static bool ToBool(object value)
        {
            if (value == null)
            {
                return false;
            }
            else if (value is bool)
            {
                return (bool)value;
            }
            else if (IsInteger(value))
            {
                return (Convert.ToInt64(value) != 0);
            }
            else if (value is string)
            {
                return ((string)value).Trim().Length > 0;
            }
            else if (value is decimal)
            {
                return ((decimal)value) != 0m;
            }
            else if (IsDouble(value))
            {
                return (Convert.ToDouble(value) != 0.0);
            }
            else if (value is DateTime)
            {
                return ((DateTime)value) == DateTime.MinValue;
            }
            else
            {
                return true;
            }
        }

        private static object evalVarName(IDotNetParserContext context, string op, object[] terms)
        {
            if ((string) terms[0] == "null")
                return null;

            return new Variable((string) terms[0]);
        }

        private static object evalVariable(IDotNetParserContext context, string op, object[] terms)
        {
            if (terms[0] is Variable)
                return evalVariable(context, (Variable)terms[0]);
            else
                return terms[0];
        }

        private static object evalVariable(IDotNetParserContext context, Variable var)
        {
            return GetVariable(context, var);
        }

        private static object evalIntOperator(string op, object term1, object term2)
        {
            long v1 = Convert.ToInt64(term1);
            long v2 = Convert.ToInt64(term2);
            long result;

            switch (op)
            {
                case "+": result = (v1 + v2); break;
                case "-": result = (v1 - v2); break;
                case "*": result = (v1 * v2); break;
                case "/": result = (v1 / v2); break;
                case "%": result = (v1 % v2); break;
                default: throw new Exception("\"" + op + " operator not supported for integer operands");
            }

            if (result >= Int32.MinValue && result <= Int32.MaxValue)
                return (int) result;
            else 
                return result;
        }

        private static object EvalFloatingPointOperator(string op, object term1, object term2)
        {
            if (term1 is decimal && term2 is decimal)
                return EvalDecimalOperator(op, (decimal)term1, (decimal)term2);

            double v1 = ToDouble(term1);
            double v2 = ToDouble(term2);
            
            switch (op)
            {
                case "+": return (v1 + v2);
                case "-": return (v1 - v2);
                case "*": return (v1 * v2);
                case "/": return (v1 / v2);
            }

            throw new Exception("\"" + op + " operator not supported for floating point operands");
        }

        private static object EvalDecimalOperator(string op, decimal v1, decimal v2)
        {
            switch (op)
            {
                case "+": return (v1 + v2);
                case "-": return (v1 - v2);
                case "*": return (v1 * v2);
                case "/": return (v1 / v2);
            }

            throw new Exception("\"" + op + " operator not supported for decimal operands");
        }

        private static string EvalStringOperator(string op, object v1, object v2)
        {
            
            switch (op)
            {
                case "+": return (v1.ToString() + v2);
            }

            throw new Exception("\"" + op + " operator not supported for string operands");
        }

        private static object EvalBooleanOperator(string op, object term1, object term2)
        {
            bool v1 = ToBool(term1);
            bool v2 = ToBool(term2);

            switch (op)
            {
                case "||": return v1 | v2;
                case "&&": return v1 & v2;
            }

            throw new Exception("\"" + op + " operator not supported for boolean operands");
        }


        private static object evalOperator(IDotNetParserContext context, string op, object[] terms)
        {
            if (terms.Length != 2)
                throw new Exception("Illegal operator \"" + op + "\": " + terms.Length + " operands, but 2 expected" );

            if (terms[0] is Variable)
                terms[0] = GetVariable(context,(Variable) terms[0]);

            if (terms[1] is Variable)
                terms[1] = GetVariable(context,(Variable) terms[1]);

            switch (op)
            {
                case "==": return Equals(terms[0], terms[1]);
                case "!=": return !Equals(terms[0], terms[1]);
            }

            if (op == "<" || op == ">" || op == "<=" || op == ">=")
            {
                if (terms[0] is IComparable && terms[1] is IComparable)
                {
                    int result = ((IComparable)terms[0]).CompareTo(Convert.ChangeType(terms[1],terms[0].GetType()));

                    switch (op)
                    {
                        case "<": return result < 0;
                        case ">": return result > 0;
                        case "<=": return result <= 0;
                        case ">=": return result >= 0;
                    }
                }
                else
                {
                    throw new Exception("values " + terms[0] + " and " + terms[1] + " are not comparable");
                }

            }

            if (IsInteger(terms[0]) && IsInteger(terms[1]))
                return evalIntOperator(op, terms[0], terms[1]);

            if (terms[0] is string || terms[1] is string)
                return EvalStringOperator(op, terms[0], terms[1]);

            if (IsDouble(terms[0]) || IsDouble(terms[1]) || terms[0] is decimal || terms[1] is decimal)
                return EvalFloatingPointOperator(op, terms[0], terms[1]);

            if (terms[0] is bool || terms[1] is bool)
                return EvalBooleanOperator(op, terms[0], terms[1]);

            if (op == "==" || op == ">" || op == "<" || op == ">=" || op == "<=" || op == "!=")
                return false;

            throw new Exception("Operator '" + op + "' cannot be applied to " + terms[0] + " and " + terms[1]);
        }

        private static object evalStringLiteral(object data, string strOp, object[] terms)
        {
            string s = ((string)terms[0]);

            return s.Substring(1, s.Length - 2);
        }

        private static object evalNumber(object data, string strOp, object[] terms)
        {
            string s = (string)terms[0];

            if (s.LastIndexOf('.') >= 0)
            {
                return ToDouble(s);
            }
            else
            {
                long n = Convert.ToInt64(s);

                if (n > Int32.MaxValue || n < Int32.MinValue)
                    return n;
                else 
                    return (int) n;
            }
        }

        private static object DotOperator(object obj, Variable variable)
        {
            string prop = variable.Name;

            bool staticProperty = false;
            Type type;

            if (obj is Type)
            {
                staticProperty = true;

                type = (Type) obj;

                obj = null;
            }
            else
            {
                type = obj.GetType();
            }

            MemberInfo[] memberInfo;
            
            if (staticProperty)
                memberInfo = type.GetMember(prop, BindingFlags.Public|BindingFlags.Static);
            else
                memberInfo = type.GetMember(prop, BindingFlags.Public | BindingFlags.Instance);

            if (memberInfo.Length > 0)
            {
                MemberInfo member = memberInfo[0];

                if (memberInfo.Length > 1) // CoolStorage, ActiveRecord and Dynamic Proxy frameworks sometimes return > 1 member
                {
                    foreach (MemberInfo mi in memberInfo)
                        if (mi.DeclaringType == type)
                            member = mi;
                }

                if (member is MethodInfo)
                {
                    return new MethodDefinition(obj, type, prop);
                }

                if (member is PropertyInfo)
                {
                    return ((PropertyInfo)member).GetValue(obj,null);
                }

                if (member is FieldInfo)
                {
                    return ((FieldInfo)member).GetValue(obj);
                }
            }

            PropertyInfo propInfo = type.GetProperty("Item", new Type[] { typeof(string) });

            if (propInfo != null)
            {
                return propInfo.GetValue(staticProperty ? null:obj, new object[] { prop });
            }

            if (staticProperty)
                throw new Exception("Unknown property '" + prop + "' for type " + type.Name);
            else
                throw new Exception("Unknown property '" + prop + "' for object type " + obj.GetType());
        }

        private static object CallDotNetMethod(MethodDefinition f, object[] parameters)
        {
            Type[] typeList = new Type[parameters.Length];

            for (int i=0;i<parameters.Length;i++)
            {
                typeList[i] = parameters[i] == null ? (Type) Type.Missing : parameters[i].GetType();
            }

            MethodInfo thisIsIt = f.Type.GetMethod(f.Name, typeList);

            if (thisIsIt != null)
                return thisIsIt.Invoke(f.TargetObject, parameters);
            else 
                throw new Exception("Cannot find matching method for " + f.Type.FullName + "." + f.Name);

        }


        private static object CallConstructor(Type type, object[] parameters)
        {
            Type[] typeList = new Type[parameters.Length];

            for (int i = 0; i < parameters.Length; i++)
            {
                typeList[i] = parameters[i] == null ? (Type)Type.Missing : parameters[i].GetType();
            }

            ConstructorInfo constructor = type.GetConstructor(typeList);

            if (constructor != null)
                return constructor.Invoke(parameters);
            else
                throw new Exception("Cannot find matching constructor for " + type.FullName);
        }


        private static object GetVariable(IDotNetParserContext context, Variable variable)
        {
            string name = variable.Name;

            if (context.Exists(name))
                return context.Get(name);

            foreach (NamespaceSpecificiation nameSpace in context.Namespaces)
            {
                Type t;

                if (nameSpace.Assembly != null)
                    t = nameSpace.Assembly.GetType(nameSpace.NamespaceName + "." + name,false);
                else
                    t = Type.GetType(nameSpace + "." + name, false);

                if (t != null)
                    return t;
            }

            return null;

        }

         private static int GetVariableTableIndex(IDotNetParserContext context, Variable variable)
         {
             return context.GetCurrentListIndex(variable.Name);
         }

    }
}
