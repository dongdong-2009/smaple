//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;

namespace Activa.ExpressionParser
{
    internal class Element<T>
	{
        private readonly ElementDefinition<T> _elementDefinition;
		private string            _text;

		internal int    NumTerms = 0;

        internal Element(ElementDefinition<T> elementDefinition, string text)
		{
			_text = text;
			_elementDefinition = elementDefinition;

			switch (elementDefinition.Type)
			{
				case ElementType.UnaryOperator : NumTerms = 1; break;
				case ElementType.Operator      : NumTerms = 2; break;
                case ElementType.PropertyOperator: NumTerms = 2; break;

				default                         : NumTerms = 0; break;
			}
		}

		internal ElementType ElementType
		{
			get { return ElementDefinition.Type; }
		}

		internal int Precedence
		{
			get { return ElementDefinition.Precedence; }
		}

		internal string Text
		{
			get { return _text; }
            set { _text = value; }
		}

        internal ElementDefinition<T> ElementDefinition
		{
			get { return _elementDefinition; }
		}

	    internal bool IsOperator
	    {
	        get { return (ElementType == ElementType.Operator) || (ElementType == ElementType.UnaryOperator) || (ElementType == ExpressionParser.ElementType.PropertyOperator); }
	    }

	    internal bool IsTerm
	    {
	        get { return (ElementType == ElementType.Term); }
	    }

	    internal bool IsUnary
	    {
	        get { return (ElementType == ElementType.UnaryOperator); }
	    }

	    internal bool IsFunction
	    {
	        get { return (ElementType == ElementType.Function); }
	    }

	    internal bool IsLeftParen
	    {
	        get { return (ElementType == ElementType.LeftParen); }
	    }

	    internal bool IsRightParen
	    {
	        get { return (ElementType == ElementType.RightParen); }
	    }

	    public override string ToString()
		{
			return Text;
		}
	}

    internal class ElementStack<T> : Stack<Element<T>>
	{
	}

    internal class ElementQueue<T> : Queue<Element<T>>
	{
        internal ElementQueue<T> Clone()
		{
            ElementQueue<T> queue = new ElementQueue<T>();

            foreach (Element<T> obj in this)
				queue.Enqueue(obj);

			return queue;
		}
	}
}
