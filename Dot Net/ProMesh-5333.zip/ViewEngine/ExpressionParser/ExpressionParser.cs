//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Activa.ExpressionParser
{
	public delegate object ExpressionEvaluator<T>( T customData , string op , object[] terms);

	public class ExpressionParser<T>
	{
		//private ObjectCache<string,Expression> _cache = new ObjectCache<string,Expression>(10);
        private readonly List<ElementDefinition<T>> _elementDefinitions = new List<ElementDefinition<T>>();
	    
		private Regex _regEx = null;
        private bool _ignoreCase = false;

        public bool IgnoreCase
        {
            get { return _ignoreCase; }
            set { _ignoreCase = value; }
        }

		public ExpressionEvaluator<T> FunctionNameEvaulator = null;
        public ExpressionEvaluator<T> FinalEvaluator = null;

//		public int CacheSize
//		{
//			get
//			{
//				return _cache.MaxEntries;
//			}
//			set
//			{
//				if (value <= 0)
//					_cache = null;
//				else
//					_cache = new ObjectCache<string,Expression>(value);
//			}
//		}

		public ExpressionParser()
		{
			_elementDefinitions.Add( new ElementDefinition<T>(ElementType.LeftParen , @"\(") );
			_elementDefinitions.Add( new ElementDefinition<T>(ElementType.RightParen, @"\)") );
		}

		private void AddElementDefinition(ElementDefinition<T> elementDefinition , ExpressionEvaluator<T> evaluator)
		{
			elementDefinition.Evaluator = evaluator;

			_elementDefinitions.Add(elementDefinition);
		}

		public void AddFunction(string pattern , ExpressionEvaluator<T> functionEvaluator)
		{
			pattern += @"(?=\s*\()";

            AddElementDefinition(new ElementDefinition<T>(ElementType.Function, pattern), functionEvaluator);
		}

		public void AddOperator(string pattern , int precedence , ExpressionEvaluator<T> evaluator)
		{
            AddElementDefinition(new ElementDefinition<T>(ElementType.Operator, precedence, pattern), evaluator);
		}

        public void AddPropertyOperator(string pattern , ExpressionEvaluator<T> evaluator)
        {
            AddElementDefinition(new ElementDefinition<T>(ElementType.PropertyOperator, pattern), evaluator);
        }

		public void AddUnaryOperator(string pattern, int precedence , ExpressionEvaluator<T> evaluator)
		{
            AddElementDefinition(new ElementDefinition<T>(ElementType.UnaryOperator, precedence, pattern), evaluator);
		}

		public void AddTerm(string pattern , ExpressionEvaluator<T> evaluator)
		{
            AddElementDefinition(new ElementDefinition<T>(ElementType.Term, pattern), evaluator);
		}

		private string BuildRegex()
		{
			string s = "";

			for (int i = 0 ; i < _elementDefinitions.Count ; i++)
			{
				if(i > 0)
					s += "|";

				s += "(?<" + (i+1) + ">" + _elementDefinitions[i].Pattern + ")";
			}

			return s;
		}


		public virtual Expression<T> Parse(string s)
		{
//			if (_cache != null && _cache.ContainsKey(s))
//				return _cache[s];

            if (_regEx == null)
            {
                RegexOptions regexOptions = RegexOptions.Compiled | RegexOptions.ExplicitCapture;

                if (_ignoreCase)
                    regexOptions |= RegexOptions.IgnoreCase;

                _regEx = new Regex(BuildRegex(), regexOptions);
            }


			int numElements = _elementDefinitions.Count;

            Expression<T> expression = new Expression<T>(this);

			expression.Start();

			foreach(Match match in _regEx.Matches(s))
			{
				int group = -1;

				for(int i=0;i<numElements;i++)
					if(match.Groups[i+1].Success)
					{
						group = i;
						break;
					}

                expression.ApplyElement(new Element<T>(_elementDefinitions[group], match.Value));
			}

			expression.Finish();

//			expression.Evaluator = DefaultEvaluator;

//			if (_cache != null)
//				_cache[s] = expression;

			return expression;
		}

		public virtual object Evaluate(string s , T customData)
		{
            Expression<T> expression = Parse(s);

			return expression.Evaluate(customData);
		}
	}
}
