using System;
using System.Collections;
using System.Collections.Generic;

namespace Activa.ProMesh
{
    public class ControlCollection : IEnumerable<Control>
    {
        private readonly Dictionary<string, Control> _dictionary = new Dictionary<string, Control>(StringComparer.InvariantCultureIgnoreCase);

        public Control this[string name]
        {
            get 
            {
                Control control;

                if (_dictionary.TryGetValue(name, out control))
                    return control;
                else 
                    return null;
            }
            set 
            { 
                _dictionary[name] = value; 
            }
        }

        public void Add(Control control)
        {
            this[control.Name] = control;
        }

        IEnumerator<Control> IEnumerable<Control>.GetEnumerator()
        {
            return _dictionary.Values.GetEnumerator();
        }

        public IEnumerator GetEnumerator()
        {
            return _dictionary.Values.GetEnumerator();
        }
    }
}
