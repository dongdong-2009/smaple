//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Activa.ProMesh
{
	internal class PathReplacer
	{
		private readonly string _fromPath;
		private readonly string _toPath;
	    private readonly bool _onSameDrive;

		public PathReplacer(string fromPath , string toPath)
		{
			if (Path.GetPathRoot(fromPath).ToUpper() != Path.GetPathRoot(toPath).ToUpper())
			    _onSameDrive = false;
            else
			    _onSameDrive = true;

			if (Path.IsPathRooted(fromPath))
			{
				_fromPath = fromPath.Substring(Path.GetPathRoot(fromPath).Length-1);
				_toPath = toPath.Substring(Path.GetPathRoot(toPath).Length-1);
			}
			else
			{
				_fromPath = fromPath;
				_toPath = toPath;
			}
		}

		internal string ReplaceURLs(string inputString)
		{
            if (!_onSameDrive)
                return inputString;

            Regex regex1 = new Regex(@"(?<attr>(href|src|action)\s*=\s*)(?<quote>['""])((?<url>~/.*?)|(?<url>[^""'\s]+\.[a-z0-9]+(\?[^""'\s]*)?)|(?<url>page:[^""'\s]+))\k<quote>", RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);

		    return regex1.Replace(inputString, new MatchEvaluator(ReplaceHREF));
		}

		private static string SetLastChar(string s , string c)
		{
			if (s.EndsWith(c))
				return s;
			else
				return (s + c);
		}

		private static string RemoveLastPart(string path)
		{
			int i = path.LastIndexOf("/");

			if (i >= 0)
				return path.Substring(0,i);
			else
				return path;
		}

		private string ReplaceHREF(Match match)
		{
			string quote = match.Groups["quote"].Value;
			string url = match.Groups["url"].Value;

			if (url.StartsWith("~"))
			{
				if (url.Substring(1).StartsWith("/"))
                    return match.Groups["attr"].Value + quote + Path.Combine(WebAppContext.Request.ApplicationPath, url.Substring(2)) + quote;
				else
                    return match.Groups["attr"].Value + quote + Path.Combine(WebAppContext.Request.ApplicationPath, url.Substring(1)) + quote;
			}

            if (url.StartsWith("$["))
                return match.Value;

			if (url.ToUpper().StartsWith("PAGE:"))
				return match.Groups["attr"].Value + quote + url.Substring(5) + quote;

			if (url.IndexOf(':') >= 0 || url.StartsWith("/") || url.StartsWith("$"))
				return match.Value;

			string toPath = _toPath.Replace('\\','/');
			string fromPath = _fromPath.Replace('\\','/');

			toPath = SetLastChar(toPath, "/");
			fromPath = SetLastChar(fromPath, "/");

			string filePath;

			if (url.StartsWith("/"))
				filePath = url;
			else
				filePath = fromPath + url;

			toPath = SetLastChar(toPath , "/");

			if (!filePath.StartsWith("/") && !filePath.StartsWith("\\") && !Path.IsPathRooted(filePath))
				filePath = toPath + filePath;


			string[] pieces = filePath.Split('/');

			filePath = "";

			foreach(string piece in pieces)
				if (piece.Length > 0)
					if (piece == "..")
						filePath = RemoveLastPart(filePath);
					else
						if (piece != ".")
							filePath += "/" + piece;

			pieces = filePath.Split('/');
			string[] piecesTo = toPath.Split('/');

			int firstMismatch = 0;

			for (int i = 0; i < pieces.Length && i < piecesTo.Length;i++ )
			{
				if (pieces[i].ToUpper() != piecesTo[i].ToUpper())
				{
					firstMismatch = 0;

					for (int j = 0; j < i; j++)
						firstMismatch += pieces[j].Length + 1;

					break;
				}
			}

			if (firstMismatch <= filePath.Length)
				filePath = filePath.Substring(firstMismatch, filePath.Length - firstMismatch);

			int pos = firstMismatch;

			while (pos < toPath.Length)
			{
				if (toPath.Substring(pos, 1) == "/")
					filePath = "../" + filePath;

				pos++;
			}

			return match.Groups["attr"].Value + quote + filePath + quote;
		}
	}
}
