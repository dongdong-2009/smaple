//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;

namespace Activa.ProMesh
{
    /// <summary>
    /// Represents a tree structure where each node can have a value and multiple children
    /// </summary>
    internal class Tree<T> : TreeNode<T>
    {

        /// <summary>
        /// Creates an empty Tree object, with an empty root node (no data)
        /// </summary>
        public Tree()
        {
        }

        /// <summary>
        /// Creates a Tree object, and initializes the data for the root node
        /// </summary>
        /// <param name="rootValue">The object (data) to initialize the root node with</param>
        public Tree(T rootValue)
            : base(rootValue, null)
        {
        }

        /// <summary>
        /// Dumps the contents of the tree structure, by calling ToString() on all data objects in the tree
        /// </summary>
        public void Dump()
        {
            Dump(0);
        }

    }

    /// <summary>
    /// A node in a Tree structure
    /// </summary>
    public class TreeNode<T>
    {
        private readonly TreeNode<T> _parentNode = null;
        private readonly List<TreeNode<T>> _childNodes = new List<TreeNode<T>>();

        internal T _data = default(T);

        public TreeNode()
        {
        }

        public TreeNode(T dataObject, TreeNode<T> parent)
        {
            _data = dataObject;
            _parentNode = parent;
        }

        /// <summary>
        /// Returns the parent node of this node
        /// </summary>
        public TreeNode<T> Parent
        {
            get
            {
                return _parentNode;
            }
        }

        /// <summary>
        /// Returns a collection of TreeNode objects, representing the child nodes of this object
        /// </summary>
        public List<TreeNode<T>> Children
        {
            get
            {
                return _childNodes;
            }
        }

        /// <summary>
        /// Returns true if this node has child nodes
        /// </summary>
        public bool HasChildren()
        {
            return (_childNodes.Count > 0);
        }

        /// <summary>
        /// Returns the root node for the tree
        /// </summary>
        public TreeNode<T> Root
        {
            get
            {
                TreeNode<T> curNode = this;

                while (curNode.Parent != null)
                    curNode = curNode.Parent;

                return curNode;
            }
        }

        /// <summary>
        /// Adds a child node to this tree node
        /// </summary>
        /// <param name="obj">The object for the child node to add</param>
        /// <returns>The new child tree node</returns>
        public TreeNode<T> AddChild(T obj)
        {
            TreeNode<T> newNode = new TreeNode<T>(obj, this);

            _childNodes.Add(newNode);

            return newNode;
        }

        /// <summary>
        /// <value>The object (data) belonging to this node</value>
        /// </summary>
        public T Content
        {
            get { return _data; }
            set { _data = value; }
        }

        public void Dump(int level)
        {
            if (level > 0)
                Console.Write(new String(' ', level * 4));

            if (Equals(Content, default(T)))
                Console.WriteLine("(null)");
            else
                Console.WriteLine(Content.ToString());

            foreach (TreeNode<T> objChild in Children)
            {
                objChild.Dump(level + 1);
            }
        }

    };
}
