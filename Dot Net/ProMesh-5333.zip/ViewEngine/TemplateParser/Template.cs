//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Activa.ExpressionParser.DotNet;

namespace Activa.ProMesh
{
    internal class Template
    {
        private readonly object _staticLock = new object();

        private readonly Tree<TemplateNode> _parsedTemplate;
        private string _pageTitle;
        private static DotNetExpressionParser _expressionParser = null;
        private string _destinationPath;
        private string _fileName;

        internal class ViewDataContext : IDotNetParserContext
        {
            private readonly IList<TableData> _tableList;
            private readonly ViewData _viewData;
            private bool _controlsFirst;

            public ViewDataContext(ViewData viewData, IList<TableData> tableList)
            {
                _tableList = tableList;
                _viewData = viewData;
            }

            public object this[string var]
            {
                get
                {
                    if (_controlsFirst)
                    {
                        Control control = _viewData.Controls[var];

                        if (control != null)
                            return control;
                    }

                    object value;

                    int tableIndex = FindTableForVariable(var, _tableList, out var);

                    if (tableIndex >= 0)
                    {
                        value = TemplateUtil.GetListItem(_tableList[tableIndex].Table, _tableList[tableIndex].Index, var);
                    }
                    else
                    {
                        value = TemplateUtil.GetVar(_viewData.Variables, var);
                    }

                    if (!_controlsFirst && value == null)
                    {
                        value = _viewData.Controls[var];
                    }

                    return value;
                }
            }


            public int GetCurrentListIndex(string name)
            {
                int tableIndex = FindTableForVariable(name, _tableList, out name);

                if (tableIndex >= 0)
                    return _tableList[tableIndex].Index + 1;
                else
                    return 0;

            }

            bool IDotNetParserContext.Exists(string name)
            {
                return this[name] != null;
            }

            object IDotNetParserContext.Get(string name)
            {
                return this[name];
            }

            NamespaceSpecificiation[] IDotNetParserContext.Namespaces
            {
                get { return ViewEngine.Namespaces; }
            }

            public bool ControlsFirst
            {
                get { return _controlsFirst; }
                set { _controlsFirst = value; }
            }
        }

        public Template(string templateFile, string destinationPath)
        {
            lock (_staticLock)
            {
                if (_expressionParser == null)
                    _expressionParser = new DotNetExpressionParser();
            }

            _destinationPath = destinationPath;
            _fileName = templateFile;

            _parsedTemplate = PreParseTemplate(TemplateUtil.ReadTemplateContents(templateFile, destinationPath));
        }

        public Template(Template callingTemplate, string templateName)
        {
            _destinationPath = callingTemplate._destinationPath;
            _fileName = templateName;

            _parsedTemplate = PreParseTemplate(TemplateUtil.ReadTemplateContents(_fileName, _destinationPath));
        }

        public string PageTitle
        {
            get { return _pageTitle; }
        }

        public string Parse(ViewData viewData)
        {
            Tree<string> dataTree = new Tree<string>();

            CreateTreeWithData(viewData, null, _parsedTemplate, dataTree);

            return CreateOutput(dataTree);
        }

        public string ParseHTMLBody(ViewData tplData)
        {
            return TemplateUtil.ExtractBody(Parse(tplData));
        }

        //
        // The template parser uses regular expressions to tokenize the HTML
        // It returns a parse tree which is then cached for later use
        //
        // In the future, a "real" tokenizer should be used, but for now, this works
        //
        private Tree<TemplateNode> PreParseTemplate(string unparsedText)
        {
            Tree<TemplateNode> parseTree = new Tree<TemplateNode>();

            Match matchTitle = Regex.Match(unparsedText, @"<title\s*>(?<title>.*)</title>");

            if (matchTitle.Success)
                _pageTitle = matchTitle.Groups["title"].Value;

            //unparsedText = Regex.Replace(unparsedText, @"(?<headstart>\<head[^\>]*\>)(?<headcontent>.*)</head>","${headstart}\r\n$[_HEADSTART_]${headcontent}$[_JSLIB_]$[_JS_]$[_HEADEND_]\r\n</head>",RegexOptions.Singleline|RegexOptions.IgnoreCase|RegexOptions.Compiled);
            unparsedText = Regex.Replace(unparsedText, @"(\r\n\s*)(?<tag>\<!--\$\(.*?\)--\>)(\s*\r\n)", "${tag}\r\n");

            string[] regexParts = new string[]
                {
                    @"(<!--\s*\$\[(?<tagdir>(ELSE|ENDIF|ENDFOR|IF|RENDER|INCLUDE))\s*(?<tagdirdata>.*?)\s*\]\s*-->)",
                    @"(<!--\s*\$\[\s*FOREACH\s+(?<foreachvar>\S+?)\s+in\s+(?<foreachtable>\S+?)\s*\]\s*-->)",
                    @"(\$\[\[\s*(?<tagfield>.*?)(\:(?<fieldclass>.*?))?(\:(?<fieldclasserror>.*?))?\s*\]\])",
                    @"(\$\[\s*(?<tag>.*?)\s*\])",
                    @"(\$\{\s*(?<taglang>.*?)\s*\})"
                };

            Regex regexp = new Regex(String.Join("|", regexParts), RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);

            TreeNode<TemplateNode> currentNode = parseTree;
            int curPos = 0;

            foreach (Match match in regexp.Matches(unparsedText))
            {
                string tagVar = match.Groups["tag"].Value;
                string tagField = match.Groups["tagfield"].Value;
                string tagLang = match.Groups["taglang"].Value;
                string tagDir = match.Groups["tagdir"].Value.ToUpper();
                string tagDirData = match.Groups["tagdirdata"].Value;
                string foreachname = match.Groups["foreachvar"].Value;
                string foreachtable = match.Groups["foreachtable"].Value;

                int newPos = match.Index;

                if (newPos > curPos)
                    currentNode.AddChild(new TextTemplateNode(unparsedText.Substring(curPos, newPos - curPos))); // Add normal text

                if (tagDir.Length > 0)
                {
                    if (tagDir == "IF")
                        currentNode = currentNode.AddChild(new ConditionalTemplateNode(tagDirData));
                    else if (tagDir == "ENDFOR")
                        currentNode = currentNode.Parent;
                    else if (tagDir == "ENDIF")
                        currentNode = currentNode.Parent;
                    else if (tagDir == "ELSE")
                    {
                        if (!(currentNode.Content is ConditionalTemplateNode))
                            throw new Exception("Misplaced ELSE block in template");

                        string blockName = currentNode.Content.Value;

                        blockName = "!(" + blockName + ")";

                        currentNode = currentNode.Parent;
                        currentNode = currentNode.AddChild(new ConditionalTemplateNode(blockName));
                    }
                    else if (tagDir == "INCLUDE")
                        currentNode.AddChild(new IncludeTemplateNode(tagDirData, false));
                    else if (tagDir == "RENDER")
                        currentNode.AddChild(new IncludeTemplateNode(tagDirData, true));
                }

                if (foreachtable.Length > 0)
                    currentNode = currentNode.AddChild(new TableTemplateNode(foreachtable, foreachname));

                if (tagField.Length > 0)
                    currentNode.AddChild(new ControlTemplateNode(tagField, match.Groups["fieldclass"].Value, match.Groups["fieldclasserror"].Value));

                if (tagLang.Length > 0)
                    currentNode.AddChild(new TranslationTemplateNode(tagLang));

                if (tagVar.Length > 0)
                    currentNode.AddChild(new VarTemplateNode(tagVar));

                curPos = match.Index + match.Length;
            }

            if (curPos < unparsedText.Length - 1)
                currentNode.AddChild(new TextTemplateNode(unparsedText.Substring(curPos)));

            return parseTree;
        }

        private static int TableItemLevel(string key)
        {
            int level = 0;

            for (int i = 0; i < key.Length; i++)
                if (key[i] == '.')
                    level++;
                else
                    break;

            return level;
        }

        private static int FindTableForVariable(string key, IList<TableData> currentTableList, out string newKey)
        {
            if (key.StartsWith("."))
            {
                int level = TableItemLevel(key);

                if (currentTableList.Count < level)
                    throw new Exception("Table variable [" + key + "] used outside table");

                newKey = key.Substring(level);

                return currentTableList.Count - level;
            }


            string var = key;

            if (key.Contains("."))
            {
                var = key.Split('.')[0];
            }


            for (int i = currentTableList.Count - 1; i >= 0; i--)
            {
                if (currentTableList[i].IteratorName != null)
                {
                    if (String.Equals(currentTableList[i].IteratorName, var, StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (key.Length > var.Length)
                            newKey = key.Substring(var.Length + 1);
                        else
                            newKey = "";

                        return i;
                    }
                }
            }

            newKey = key;

            return -1;
        }

        private void CreateTreeWithData(ViewData viewData, List<TableData> currentTableList, TreeNode<TemplateNode> templateTree, TreeNode<string> dataTree)
        {
            if (currentTableList == null)
                currentTableList = new List<TableData>();

            ViewDataContext viewDataContext = new ViewDataContext(viewData, currentTableList);

            bool isTable = (currentTableList.Count > 0 && templateTree.Content is TableTemplateNode);

            int numRows = isTable ? currentTableList[currentTableList.Count - 1].Table.Count : 1;

            for (int rowNum = 0; rowNum < numRows; rowNum++)
            {
                if (isTable)
                    currentTableList[currentTableList.Count - 1].Index = rowNum;

                foreach (TreeNode<TemplateNode> childNode in templateTree.Children)
                {
                    TemplateNode content = childNode.Content;

                    if (content is TextTemplateNode)
                        dataTree.AddChild(content.Value);

                    else if (content is ConditionalTemplateNode)
                    {
                        string expression = "!!(" + content.Value + ")";

                        viewDataContext.ControlsFirst = false;

                        bool showBlock = EvaluateViewDataExpression<bool>(viewDataContext, (ExpressionTemplateNode)content, expression);

                        if (showBlock)
                            CreateTreeWithData(viewData, currentTableList, childNode, dataTree);
                        else
                            dataTree.AddChild("");

                        continue;
                    }

                    else if (content is TableTemplateNode)
                    {
                        TableTemplateNode tableNode = (TableTemplateNode)content;

                        string tableName = tableNode.Value;

                        viewDataContext.ControlsFirst = false;

                        IList subTable = EvaluateViewDataExpression<IList>(viewDataContext, tableNode, tableName);

                        if (subTable != null)
                        {
                            currentTableList.Add(new TableData(subTable, tableNode.IteratorName, -1));

                            CreateTreeWithData(viewData, currentTableList, childNode, dataTree.AddChild(null));
                        }
                    }

                    else if (content is VarTemplateNode)
                    {
                        ExpressionTemplateNode varNode = (ExpressionTemplateNode)content;

                        string varName = varNode.Value;
                        string formatString;

                        varName = ExtractFormatString(varName, out formatString);

                        viewDataContext.ControlsFirst = false;

                        object data = EvaluateViewDataExpression<object>(viewDataContext, varNode, varName);

                        if (data != null)
                        {
                            string stringData;

                            if (data is Control)
                            {
                                stringData = ((Control)data).Render(viewData.View);
                            }
                            else
                            {
                                if (formatString != null)
                                    stringData = String.Format("{0:" + formatString + "}", data);
                                else
                                    stringData = data.ToString();
                            }

                            stringData = viewData.View.ParseTranslations(stringData);

                            dataTree.AddChild(stringData);
                        }
                    }

                    else if (content is ControlTemplateNode)
                    {
                        ControlTemplateNode controlNode = (ControlTemplateNode)content;

                        viewDataContext.ControlsFirst = true;

                        Control control = EvaluateViewDataExpression<Control>(viewDataContext, controlNode, controlNode.Value);

                        if (control != null)
                        {
                            string html = control.Render(viewData.View, controlNode.ClassName, controlNode.ClassNameError);

                            html = viewData.View.ParseTranslations(html);

                            dataTree.AddChild(html);
                        }
                        else
                        {
                            dataTree.AddChild("[?[" + content.Value + "]?]");
                        }
                    }

                    else if (content is TranslationTemplateNode)
                    {
                        dataTree.AddChild(WebAppHelper.GetTranslation(viewData.View.ViewName, content.Value) ?? ("{?{" + content.Value + "}?}"));
                    }

                    else if (content is IncludeTemplateNode)
                    {
                        viewDataContext.ControlsFirst = false;

                        string templateName = EvaluateViewDataExpression<string>(viewDataContext, (IncludeTemplateNode)content, content.Value);

                        string contents;

                        templateName = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(_fileName), templateName));

                        if (((IncludeTemplateNode)content).Render)
                        {
                            Template innerTemplate = new Template(this, templateName);

                            contents = innerTemplate.ParseHTMLBody(viewData);
                        }
                        else
                        {
                            contents = TemplateUtil.ExtractBody(TemplateUtil.ReadTemplateContents(templateName, _destinationPath));
                        }

                        dataTree.AddChild(contents);
                    }

                }

            }

            if (isTable)
                currentTableList.RemoveAt(currentTableList.Count - 1);
        }

        private static T EvaluateViewDataExpression<T>(ViewDataContext viewDataContext, ExpressionTemplateNode varNode, string varName)
        {
            object data;

            if (ViewEngine.IgnoreRenderingExceptions)
            {
                try
                {
                    data = _expressionParser.Evaluate(varName, viewDataContext);
                }
                catch (Exception ex)
                {
                    ViewEngine.Fire_RenderingException(ex);

                    if (typeof(T) == typeof(IList))
                        data = null;
                    else
                        data = "{***ERROR***}";
                }
            }
            else
            {
                data = _expressionParser.Evaluate(varName, viewDataContext);
            }


            return (T)data;
        }


        private static string ExtractFormatString(string varName, out string formatString)
        {
            int colonIndex = varName.IndexOf(':');

            if (colonIndex > 0)
            {
                formatString = varName.Substring(colonIndex + 1);

                return varName.Substring(0, colonIndex);
            }

            formatString = null;

            return varName;
        }

        private static string CreateOutput(TreeNode<string> templateTree)
        {
            StringBuilder stringBuilder = new StringBuilder();

            CreateOutput(templateTree, stringBuilder);

            return stringBuilder.ToString();
        }

        private static void CreateOutput(TreeNode<string> tree, StringBuilder stringBuilder)
        {
            if (tree.Content != null)
                stringBuilder.Append(tree.Content);

            foreach (TreeNode<string> childNode in tree.Children)
                CreateOutput(childNode, stringBuilder);
        }

        private abstract class TemplateNode
        {
            protected TemplateNode(string value)
            {
                Value = value;
            }

            public readonly string Value;
        }

        private class TextTemplateNode : TemplateNode
        {
            public TextTemplateNode(string text) : base(text) { }
        }

        private class ExpressionTemplateNode : TemplateNode
        {
            private bool _isExpression;

            public ExpressionTemplateNode(string name)
                : base(name)
            {
                int colon = name.IndexOf(':');

                if (colon > 0)
                    _isExpression = !Regex.IsMatch(name.Substring(0, colon), @"^[a-zA-Z_\.][a-zA-Z0-9\._]*$", RegexOptions.Singleline);
                else
                    _isExpression = !Regex.IsMatch(name, @"^[a-zA-Z_\.][a-zA-Z0-9\._]*$", RegexOptions.Singleline);
            }

            public bool IsExpression
            {
                get { return _isExpression; }
                protected set { _isExpression = value; }
            }
        }

        private class VarTemplateNode : ExpressionTemplateNode
        {
            public VarTemplateNode(string name)
                : base(name)
            {
            }
        }

        private class ConditionalTemplateNode : ExpressionTemplateNode
        {
            public ConditionalTemplateNode(string blockName)
                : base(blockName)
            {
                IsExpression = true;
            }
        }

        private class TableTemplateNode : ExpressionTemplateNode
        {
            private readonly string _iteratorName;

            public TableTemplateNode(string name)
                : base(name)
            {
            }

            public TableTemplateNode(string name, string iteratorName)
                : this(name)
            {
                _iteratorName = iteratorName;
            }

            public string IteratorName
            {
                get { return _iteratorName; }
            }

        }

        private class ControlTemplateNode : ExpressionTemplateNode
        {
            private readonly string _className = null;
            private readonly string _classNameError = null;

            public ControlTemplateNode(string name, string className, string classNameError)
                : base(name)
            {
                if (className != null && className.Length > 0)
                    _className = className;

                if (classNameError != null && classNameError.Length > 0)
                    _classNameError = classNameError;
            }

            public string ClassName
            {
                get { return _className; }
            }

            public string ClassNameError
            {
                get { return _classNameError; }
            }
        }

        private class TranslationTemplateNode : TemplateNode
        {
            public TranslationTemplateNode(string tag) : base(tag) { }
        }

        private class IncludeTemplateNode : ExpressionTemplateNode
        {
            private readonly bool _render;

            public IncludeTemplateNode(string name, bool render)
                : base(name)
            {
                _render = render;
            }

            public bool Render
            {
                get { return _render; }
            }
        }

        internal class TableData
        {
            public TableData(IList table, string iteratorName, int index)
            {
                Table = table;
                Index = index;
                IteratorName = iteratorName;
            }

            public readonly IList Table;
            public readonly string IteratorName;
            public int Index;
        }
    }

    public class TemplateNotFoundException : Exception
    {
        public string FileName;

        public TemplateNotFoundException(string fileName)
            : base("Template not found: " + Path.GetFileName(fileName))
        {
            FileName = fileName;
        }
    }
}
