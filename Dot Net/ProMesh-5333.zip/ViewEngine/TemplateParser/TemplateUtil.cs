//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Activa.ProMesh
{
	internal static class TemplateUtil
	{
	    internal static object GetVar(IDictionary<string,object> vars, string key)
		{
		    return ProMeshUtil.GetObjectProperty(vars, key);
		}

		internal static object GetListItem(IList list , int index, string property)
		{
			object listItem = list[index];

			object value = property.Length > 0 ? ProMeshUtil.GetObjectProperty(listItem , property) : listItem;

			if (value == null && list is ITypedList)
			{
				PropertyDescriptor propDesc = (list as ITypedList).GetItemProperties(null)[property];

				if (propDesc != null)
					value = propDesc.GetValue(listItem);
			}

			return value;
		}

		internal static string ReadTemplateContents(string templateFileName , string destinationPath)
		{
			string templatePath = Path.GetDirectoryName(templateFileName);

			try
			{
				using (StreamReader stream = new StreamReader(templateFileName, Encoding.GetEncoding("windows-1252")))
				{
				    return ReplaceURLs(stream.ReadToEnd(), templatePath,destinationPath);
				}
			}
			catch
			{
				throw new TemplateNotFoundException(Path.GetFileName(templateFileName));
			}

		}

		internal static string ExtractBody(string s)
		{
			Regex re = new Regex(@"<body[^>]*>(?<body>.+)</body>" , RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);

			Match match = re.Match(s);

			if (match.Success)
				return match.Groups["body"].Value;
			else
				return s;
		}

        internal static string ReplaceURLs(string inputString, string fromPath, string toPath)
        {
            PathReplacer pathReplacer = new PathReplacer(fromPath, toPath);

            return pathReplacer.ReplaceURLs(inputString);
        }


	}
}
