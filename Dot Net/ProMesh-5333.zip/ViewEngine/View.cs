//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace Activa.ProMesh
{
    public class View
    {
        private string _viewName;
        private string _layoutName;
        private Template _layoutTemplate = null;
        private Template _viewTemplate = null;
        private readonly ViewData _viewData;
        private readonly Dictionary<string,string> _registeredJavascriptKeys = new Dictionary<string, string>();
        
        private readonly List<string> _javaScriptLibFragments = new List<string>();
        private readonly List<string> _javaScriptFragments = new List<string>();
        private readonly List<string> _javaScriptStartupFragments = new List<string>();
        private readonly List<string> _javaScriptLibIncludes = new List<string>();
        private readonly List<string> _javaScriptIncludes = new List<string>();

        private int _nextControlIndex = 1;

        public View()
        {
            LayoutName = WebAppConfig.DefaultLayout;

            _viewData = new ViewData(this);
        }

        public string ViewName
        {
            get { return _viewName; }
            internal set { _viewName = value; }
        }

        public string LayoutName
        {
            get { return _layoutName; }
            internal set { _layoutName = value; }
        }

        internal ViewData ViewData
        {
            get { return _viewData;  }
        }

        internal Template ViewTemplate
        {
            get
            {
                if (_viewTemplate == null)
                    _viewTemplate = WebAppHelper.GetTemplate(_viewName);

                return _viewTemplate;
            }
        }

        internal Template LayoutTemplate
        {
            get
            {
                if (_layoutTemplate == null)
                    _layoutTemplate = WebAppHelper.GetTemplate(_layoutName);

                return _layoutTemplate;
            }
        }

        public int NextControlIndex
        {
            get { return _nextControlIndex++; }
        }

        public void RegisterJavascriptFromResource(string key, bool library, Assembly assembly, string resourceName)
        {
            byte[] resourceData = ProMeshUtil.GetResourceData(assembly, resourceName);

            string javaScript = Encoding.UTF8.GetString(resourceData);

            if (!_registeredJavascriptKeys.ContainsKey(key))
            {
                if (library)
                    _javaScriptLibFragments.Add(javaScript + "\r\n");
                else
                    _javaScriptFragments.Add(javaScript + "\r\n");

                _registeredJavascriptKeys.Add(key, javaScript);
            }
        }

        public void RegisterJavascript(string key, bool library, string javaScript)
        {
            if (!_registeredJavascriptKeys.ContainsKey(key))
            {
                if (library)
                    _javaScriptLibFragments.Add(javaScript + "\r\n");
                else
                    _javaScriptFragments.Add(javaScript + "\r\n");
                
                _registeredJavascriptKeys.Add(key, javaScript);
            }
        }

        public void RegisterJavascriptIncludeFromResource(string key, bool library, Assembly assembly, string resourceName)
        {
            if (!_registeredJavascriptKeys.ContainsKey(key))
            {
                string javaScriptUrl = "~/_js_/" + assembly.GetName().Name + "/" + resourceName + '.' + WebAppConfig.PageExtension;

                if (library)
                    _javaScriptLibIncludes.Add(javaScriptUrl);
                else
                    _javaScriptIncludes.Add(javaScriptUrl);

                _registeredJavascriptKeys.Add(key, javaScriptUrl);
            }
        }

        public void RegisterJavascriptInclude(string key, bool library, string javaScriptUrl)
        {
            if (!_registeredJavascriptKeys.ContainsKey(key))
            {
                if (library)
                    _javaScriptLibIncludes.Add(javaScriptUrl);
                else
                    _javaScriptIncludes.Add(javaScriptUrl);

                _registeredJavascriptKeys.Add(key, javaScriptUrl);
            }
        }

        public void RegisterStartupJavascript(string key, string javaScript)
        {
            if (!_registeredJavascriptKeys.ContainsKey(key))
            {
                _javaScriptStartupFragments.Add(javaScript + "\r\n");

                _registeredJavascriptKeys.Add(key, javaScript);
            }
        }

        internal string Render()
        {
            foreach (MethodInfo method in WebAppContext.AjaxMethods.Values)
            {
                string url = ProMeshUtil.TranslateAbsolutePath("~/" + method.DeclaringType.Name.Replace("_","/") + '.' + WebAppConfig.PageExtension + '/' + method.Name);

                RegisterJavaScriptMethod(method, url);
            }

            List<MethodInfo> ajaxMethods = new List<MethodInfo>();

            foreach (Control control in ViewData.Controls)
            {
                MethodInfo[] methods = control.AjaxMethods;

                foreach (MethodInfo method in methods)
                    if (!ajaxMethods.Contains(method))
                        ajaxMethods.Add(method);
            }

            foreach (MethodInfo method in ajaxMethods)
            {
                string url = ProMeshUtil.TranslateAbsolutePath("~/_ajax_/" + method.DeclaringType.Assembly.GetName().Name + '/' + method.DeclaringType.FullName + '/' + method.Name + '.' + WebAppConfig.PageExtension);

                RegisterJavaScriptMethod(method, url);
            }

            ViewData.Variables["Session"] = WebAppContext.Session;
            ViewData.Variables["_SELF_"] = WebAppContext.Request.RawUrl;

            Template layoutTemplate = LayoutTemplate;
            Template viewTemplate = ViewTemplate;

            if (viewTemplate == null && layoutTemplate == null)
                return "<html><body></body></html>";

            if (layoutTemplate == null)
            {
                return viewTemplate.Parse(ViewData);
            }

            if (viewTemplate != null)
            {
                ViewData.Variables["_VIEW_"] = viewTemplate.ParseHTMLBody(ViewData);
                ViewData.Variables["_TITLE_"] = viewTemplate.PageTitle;
            }

            string html = layoutTemplate.Parse(ViewData);

            int idx = html.IndexOf("</head>",StringComparison.OrdinalIgnoreCase);

            if (idx > 0)
            {
                string head = "";
               
                foreach (string js in _javaScriptLibIncludes)
                    head += "<script language=\"javascript\" type=\"text/javascript\" src=\"" + ProMeshUtil.TranslateAbsolutePath(js) + "\"></script>\r\n";

                if (_javaScriptLibFragments.Count > 0)
                    head += "<script language=\"javascript\" type=\"text/javascript\">\r\n";

                foreach (string js in _javaScriptLibFragments)
                    head += js + "\r\n";

                if (_javaScriptLibFragments.Count > 0)
                    head += "</script>\r\n";

                foreach (string js in _javaScriptIncludes)
                    head += "<script language=\"javascript\" type=\"text/javascript\" src=\"" + ProMeshUtil.TranslateAbsolutePath(js) + "\"></script>\r\n";

                if (_javaScriptFragments.Count > 0)
                    head += "<script language=\"javascript\" type=\"text/javascript\">\r\n";

                foreach (string js in _javaScriptFragments)
                    head += js + "\r\n";

                if (_javaScriptFragments.Count > 0)
                    head += "</script>\r\n";

                if (head.Length > 0)
                    html = html.Insert(idx, head);
            }

            idx = html.LastIndexOf("</body>", StringComparison.OrdinalIgnoreCase);

            if (idx > 0)
            {
                string script = "";

                if (_javaScriptStartupFragments.Count > 0)
                    script += "<script language=\"javascript\" type=\"text/javascript\">\r\n";

                foreach (string js in _javaScriptStartupFragments)
                    script += js + "\r\n";

                if (_javaScriptStartupFragments.Count > 0)
                    script += "</script>\r\n";

                if (script.Length > 0)
                    html = html.Insert(idx, script);
            }

            return html;
        }

        private void RegisterJavaScriptMethod(MethodInfo method, string url)
        {
            string[] stringparameters = Array.ConvertAll<ParameterInfo,string>(method.GetParameters(), delegate(ParameterInfo pi) { return pi.Name; });

            string jsMethod = WebAppConfig.AjaxProvider.GenerateJavascriptMethod(url, method.DeclaringType.FullName, method.Name, stringparameters);

            RegisterJavascript(method.DeclaringType.FullName, true, WebAppConfig.AjaxProvider.GenerateJavascriptClassName(method.DeclaringType.FullName));
            RegisterJavascript(method.DeclaringType.FullName + "." + method.Name, true, jsMethod);
        }

        public string ParseTranslations(string inputString)
        {
            if (inputString.IndexOf("${") >= 0)
            {
                return Regex.Replace(inputString, @"\$\{(?<tag>[^\}]+)\}", delegate(Match match)
                       {
                           return WebAppHelper.GetTranslation(ViewName, match.Groups["tag"].Value) ?? "???";
                       },
                       RegexOptions.Singleline | RegexOptions.Compiled);
            }
            else
            {
                return inputString;
            }
        }
    }
}
