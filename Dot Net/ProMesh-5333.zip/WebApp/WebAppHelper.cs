//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.Caching;

namespace Activa.ProMesh
{
    internal static class WebAppHelper
    {
        private static readonly object _staticLock = new object();
        private static readonly string _etagSignature = DateTime.Now.Ticks.ToString("X16");

        private static string BuildETag(string assemblyName, string resource)
        {
            return assemblyName.GetHashCode().ToString("X8") + resource.GetHashCode().ToString("X8") + ":" + _etagSignature;
        }

        private static void SendResource(string assemblyName, string resourceKey , string contentType)
        {
            string eTag = BuildETag(assemblyName, resourceKey);

            if (WebAppContext.Request.CheckETag(eTag))
            {
                WebAppContext.Response.SetETag(eTag);
                WebAppContext.Response.StatusCode = 304;
            }
            else
            {
                Assembly assembly = Assembly.Load(assemblyName);

                WebAppContext.Response.ContentType = contentType;
                WebAppContext.Response.BinaryWrite(ProMeshUtil.GetResourceData(assembly, resourceKey));
                WebAppContext.Response.SetETag(eTag);
            }
        }

        public static View RunPageController(string pageUrl, string pathInfo)
        {
            View view;

            if (pageUrl.StartsWith("_ajax_/"))
            {
                WebAppContext.Response.ContentType = "application/json";
                WebAppContext.Response.Write(RunAjaxMethod(pageUrl.Substring(7)));

                return null;
            }

            if (pageUrl.StartsWith("_js_/"))
            {
                string[] parts = pageUrl.Substring(5).Split('/');

                SendResource(parts[0], parts[1], "text/javascript");
                
                return null;
            }

            if (pageUrl.StartsWith("_gif_/"))
            {
                string[] parts = pageUrl.Substring(6).Split('/');

                SendResource(parts[0], parts[1], "image/gif");

                return null;
            }

            if (pageUrl.StartsWith("_jpg_/"))
            {
                string[] parts = pageUrl.Substring(6).Split('/');

                SendResource(parts[0], parts[1], "image/jpeg");

                return null;
            }

            PageControllerClass pageControllerClass = WebAppConfig.GetPageControllerClass(pageUrl);

            if (pageControllerClass != null)
            {
                WebAppContext.Response.DisableCaching();

                PageController pageObject = pageControllerClass.CreatePageControllerObject();

                view = pageObject.View;

                if (view.ViewName == null)
                    view.ViewName = pageUrl;

                string methodName = "Run";

                if (pathInfo != null && pathInfo.Length > 0)
                {
                    methodName = pathInfo.Substring(1);
                }

                if (pageControllerClass.Run(pageObject, methodName))
                    return view;
                else
                    return null;
            }
            else
            {
                view = new View();

                view.ViewName = pageUrl;
            }

            return view;
        }


        public static Template GetTemplate(string templateName)
        {
            if (templateName == null)
                return null;

            lock (_staticLock)
            {
                string physicalPagePath = WebAppContext.Server.MapPath(WebAppContext.Request.FilePath.Substring(0,WebAppContext.Request.FilePath.LastIndexOf('/')+1));

                string templateFileName;

                if (Path.IsPathRooted(WebAppConfig.TemplatePath))
                    templateFileName = Path.GetFullPath(Path.Combine(WebAppConfig.TemplatePath, templateName + ".htm"));
                else
                    templateFileName = Path.GetFullPath(Path.Combine(Path.Combine(WebAppContext.Request.PhysicalApplicationPath , WebAppConfig.TemplatePath.Replace('/','\\')),templateName + ".htm"));

                string key = "TPL: " + physicalPagePath + ";" + templateFileName;

                if (!WebAppContext.Offline && WebAppContext.WebCache[key] != null)
                    return (Template)WebAppContext.WebCache[key];

                Template template = new Template(templateFileName, physicalPagePath);

                if (!WebAppContext.Offline)
                    WebAppContext.WebCache.Insert(key , template , new CacheDependency(templateFileName),DateTime.Now.AddHours(1),Cache.NoSlidingExpiration);

                return template;
            }
        }

        public static string GetTranslation(string viewName, string tag)
        {
            if (WebAppConfig.TranslationProvider != null)
                return WebAppConfig.TranslationProvider.GetTranslation(WebAppContext.Session.LanguageCode, viewName, tag);
            else 
                return null;
        }

        internal static string GetClientValue(ClientDataAttribute attribute)
        {
            if (attribute.UseGet && WebAppContext.GetData.Has(attribute.Name))
                return WebAppContext.GetData.Get(attribute.Name);
            else if (attribute.UsePost && WebAppContext.PostData.Has(attribute.Name))
                return WebAppContext.PostData.Get(attribute.Name);

            return null;
        }

        internal static object GetClientValue(ClientDataAttribute attribute, Type type)
        {
            if (attribute.UseGet && WebAppContext.GetData.Has(attribute.Name))
                return WebAppContext.GetData.Get(attribute.Name,type);
            else if (attribute.UsePost && WebAppContext.PostData.Has(attribute.Name))
                return WebAppContext.PostData.Get(attribute.Name,type);

            return null;
        }

        internal static string InsertLanguageInURL(string languageID)
        {
            string urlPath = ProMeshHttpContext.Current.Request.RawUrl;
            string appPath = ProMeshHttpContext.Current.Request.ApplicationPath;

            if (urlPath.StartsWith(appPath))
                urlPath = urlPath.Substring(appPath.Length);

            if (!urlPath.StartsWith("/"))
                urlPath = "/" + urlPath;

            if (!appPath.EndsWith("/"))
                appPath += "/";

            return appPath + languageID + urlPath;
        }

        internal static string GetLanguageFromURL()
        {
            if (!WebAppConfig.UseLanguagePath)
                return "";

            string urlPath = SessionBase.Request.FilePath;
            string appPath = SessionBase.Request.ApplicationPath;

            if (urlPath.StartsWith(appPath))
                urlPath = urlPath.Substring(appPath.Length);

            int idx1 = urlPath.LastIndexOf('/');
			
            if (idx1 > 0)
            {
                int idx2 = urlPath.Substring(0,idx1).LastIndexOf('/');

                if (idx2 >= 0)
                    return urlPath.Substring(idx2+1,idx1-idx2-1).ToUpper();
                else
                    return urlPath.Substring(0,idx1);
            }

            return "";
        }

        internal static SessionBase CreateSessionObject()
        {
            SessionBase newSession = (SessionBase) Activator.CreateInstance(WebAppConfig.SessionType);

            WebAppConfig.Fire_SessionCreated(newSession);

            return newSession;
        }


        internal static object[] CreateParameters(MethodInfo method)
        {
            ParameterInfo[] parameters = method.GetParameters();

            object[] parameterValues = new object[parameters.Length];

            int i = 0;
            foreach (ParameterInfo parameter in parameters)
            {
                ClientDataAttribute[] attributes =
                    (ClientDataAttribute[])parameter.GetCustomAttributes(typeof(ClientDataAttribute), true);

                ClientDataAttribute mapAttribute;

                if (attributes.Length > 0)
                {
                    mapAttribute = attributes[0];
                }
                else
                {
                    mapAttribute = new GetOrPostAttribute(parameter.Name);
                }

                parameterValues[i++] = GetClientValue(mapAttribute , parameter.ParameterType);
            }

            return parameterValues;
        }

        private static string RunAjaxMethod(string pageUrl)
        {
            string[] parts = pageUrl.Split('/');

            if (parts.Length != 3)
            {
                throw new ProMeshException("Unrecognized Ajax URL");
            }

            string assemblyName = parts[0];
            string className = parts[1];
            string methodName = parts[2];

            Type type = Type.GetType(className + ", " + assemblyName);

            if (type == null)
            {
                return AjaxHelper.GenerateJSONError("Unknown class " + className + " in assembly " + assemblyName);
            }

            MethodInfo method = type.GetMethod(methodName);

            if (method == null)
            {
                return AjaxHelper.GenerateJSONError("Unknown method " + methodName + " in class " + className);
            }

            if (!method.IsDefined(typeof(AjaxAttribute), false))
            {
                return AjaxHelper.GenerateJSONError("Method " + methodName + " is not an Ajax method");
            }

            object obj = null;

            if (!method.IsStatic)
                obj = Activator.CreateInstance(type);

            return RunAjaxMethod(method, obj);
        }

        internal static string RunAjaxMethod(MethodInfo method, object obj)
        {
            try
            {
                object result = method.Invoke(method.IsStatic ? null : obj, CreateParameters(method));

                return AjaxHelper.GenerateJSONReturnValue(result);
            }
            catch (Exception ex)
            {
                return AjaxHelper.GenerateJSONError(ex.Message);
            }
        }
    }
}
