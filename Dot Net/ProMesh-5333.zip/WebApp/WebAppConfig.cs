//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;

namespace Activa.ProMesh
{
    public static class WebAppConfig
    {
        private static Type                          _sessionType = typeof(SessionBase);

        private static ITranslationProvider          _translationProvider;
        private static ISessionDataProvider          _sessionDataProvider = new MinimalSessionDataProvider();
        private static ILoggingProvider              _loggingProvider;
        private static IAjaxProvider                 _ajaxProvider = new JQueryAjaxProvider();

        private static Dictionary<string, PageControllerClass> _pageControllerClasses = null;
        private static readonly List<Assembly>                 _registeredAssemblies = new List<Assembly>();
        private static readonly List<ICustomObjectCreator>     _customObjectCreators = new List<ICustomObjectCreator>();

        private static string _templatePath          = "templates";
        private static string _defaultLayout         = "master";
        private static string _defaultLanguage       = "en";
        private static string _pageExtension         = "ashx";
        private static bool   _useLanguagePath       = false;
        private static bool   _forceLanguagePath     = false;

        private static readonly string _version;

        public static event Action<Exception> ExceptionOccurred;
        public static event Action<string> PageNotFound;
        public static event Action<SessionBase> SessionCreated;

        static WebAppConfig()
        {
            _version = Assembly.GetExecutingAssembly().GetName().Version.ToString();

            string applicationClassName = null;

            foreach (string configKey in ConfigurationManager.AppSettings.Keys)
            {
                string configValue = ConfigurationManager.AppSettings[configKey];

                switch (configKey.ToLower())
                {
                    case "promesh.defaultlayout":
                        DefaultLayout = configValue;
                        break;
                    case "promesh.templatepath":
                        TemplatePath = configValue;
                        break;
                    case "promesh.pageextension":
                        PageExtension = configValue.StartsWith(".") ? configValue.Substring(1) : configValue;
                        break;
                    case "promesh.uselanguagepath":
                        UseLanguagePath = (configValue.ToLower() == "true");
                        break;
                    case "promesh.forcelanguagepath":
                        ForceLanguagePath = (configValue.ToLower() == "true");
                        break;
                    case "promesh.defaultlanguage":
                        DefaultLanguage = configValue.ToUpper();
                        break;
                    case "promesh.applicationclass":
                        applicationClassName = configValue;
                        break;
                }
            }

            if (applicationClassName == null)
                throw new Exception("No ProMesh.ApplicationClass defined in web.config");

            Type appType = Type.GetType(applicationClassName, false);

            if (appType == null)
                throw new Exception("Application class {" + applicationClassName + "} could not be loaded");

            MethodInfo initMethod = appType.GetMethod("Init", new Type[0]);

            if (initMethod == null || !initMethod.IsStatic)
                throw new Exception("No \"public static void Init()\" method defined for class " + appType.Name);

            RegisterAssembly(appType.Assembly);

            initMethod.Invoke(null, null);

            LoadControllerClasses();
        }

        public static void Init()
        {
            // This method does nothing, but it will trigger the execution of the static constructor for WebApp
        }

        public static Type SessionType
        {
            get
            {
                return _sessionType;
            }
            set
            {
                if (!typeof(SessionBase).IsAssignableFrom(value))
                    throw new Exception("SessionType should be derived from SessionBase");

                _sessionType = value;
            }
        }

        public static ITranslationProvider TranslationProvider
        {
            get { return _translationProvider; }
            set { _translationProvider = value; }
        }

        public static ISessionDataProvider SessionDataProvider
        {
            get { return _sessionDataProvider; }
            set { _sessionDataProvider = value; }
        }

        public static ILoggingProvider LoggingProvider
        {
            get { return _loggingProvider; }
            set { _loggingProvider = value; }
        }

        public static IAjaxProvider AjaxProvider
        {
            get { return _ajaxProvider; }
            set { _ajaxProvider = value; }
        }

        internal static List<ICustomObjectCreator> CustomObjectCreators
        {
            get { return _customObjectCreators; }
        }

        public static string TemplatePath
        {
            get { return _templatePath; }
            set { _templatePath = value; }
        }

        public static string DefaultLayout
        {
            get { return _defaultLayout; }
            set { _defaultLayout = value; }
        }

        public static string DefaultLanguage
        {
            get { return _defaultLanguage; }
            set { _defaultLanguage = value; }
        }

        public static string PageExtension
        {
            get { return _pageExtension; }
            set { _pageExtension = value; }
        }

        public static bool UseLanguagePath
        {
            get { return _useLanguagePath; }
            set { _useLanguagePath = value; }
        }

        public static bool ForceLanguagePath
        {
            get { return _forceLanguagePath; }
            set { _forceLanguagePath = value; }
        }

        public static string Version
        {
            get { return _version; }
        }


        public static void RegisterAssembly(Assembly assembly)
        {
            // We don't need to load anything, because if the assembly object is here, the assembly is automatically loaded

            if (_registeredAssemblies.Find(delegate(Assembly a) { return a.FullName == assembly.FullName; }) == null)
            {
                _registeredAssemblies.Add(assembly);
            }
        }

 
        public static void RegisterAssembly(string assemblyPath)
        {
            Assembly assembly = Assembly.LoadFrom(assemblyPath);

            RegisterAssembly(assembly);
        }

        internal static PageControllerClass GetPageControllerClass(string url)
        {
            PageControllerClass pageControllerClass;

            if (_pageControllerClasses.TryGetValue(url,out pageControllerClass))
                return pageControllerClass;
            else 
                return null;
        }

        private static void LoadControllerClasses()
        {
            _pageControllerClasses = new Dictionary<string, PageControllerClass>(StringComparer.OrdinalIgnoreCase);

            List<Type> pageTypes = new List<Type>();

            foreach (Assembly assembly in _registeredAssemblies)
            {
                pageTypes.AddRange(ProMeshUtil.FindCompatibleTypes(assembly, typeof (PageController)));
            }

            foreach (Type type in pageTypes)
            {
                string url = type.Name;

                UrlAttribute[] urlAttributes = (UrlAttribute[]) type.GetCustomAttributes(typeof (UrlAttribute), true);

                if (urlAttributes.Length > 0)
                {
                    url = urlAttributes[0].Path;
                }
                else
                {
                    url = url.Replace('_', '/');
                }
				
                _pageControllerClasses.Add(url , new PageControllerClass(type));
            }
        }

        public static void RegisterCustomObjectCreator(ICustomObjectCreator creator)
        {
            _customObjectCreators.Add(creator);
        }

        internal static bool Fire_ExceptionHandler(Exception ex)
        {
            if (ExceptionOccurred != null)
            {
                ExceptionOccurred(ex);

                return true;
            }

            return false;
        }

        internal static bool Fire_PageNotFound(string pageUrl)
        {
            if (PageNotFound != null)
            {
                PageNotFound(pageUrl);

                return true;
            }

            return false;
        }

        internal static bool Fire_SessionCreated(SessionBase session)
        {
            if (SessionCreated != null)
            {
                SessionCreated(session);

                return true;
            }

            return false;
        }
    }
}
