//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Caching;

namespace Activa.ProMesh
{
	public static class WebAppContext
	{
        [ThreadStatic]
        private static PageController _currentPageController;

	    [ThreadStatic] 
        private static Dictionary<string, MethodInfo> _ajaxMethods;

	    private static readonly ClientDataCollection _getParameters = new ClientDataCollection(false);
        private static readonly ClientDataCollection _postParameters = new ClientDataCollection(true);

	    public static SessionBase               Session     { get { return ProMeshHttpContext.Current.SessionObject; } }
        public static ProMeshHttpContext        HttpContext { get { return ProMeshHttpContext.Current;               } }
		public static ProMeshHttpResponse       Response    { get { return ProMeshHttpContext.Current.Response;      } }
		public static ProMeshHttpRequest        Request     { get { return ProMeshHttpContext.Current.Request;       } }
		public static ProMeshHttpServerUtility  Server      { get { return ProMeshHttpContext.Current.Server;        } }
		public static Cache                     WebCache    { get { return ProMeshHttpContext.Current.Cache;         } }
        public static ClientDataCollection      GetData     { get { return _getParameters;                           } }
        public static ClientDataCollection      PostData    { get { return _postParameters;                          } }

	    public static PageController CurrentPageController
	    {
	        get { return _currentPageController; }
            internal set { _currentPageController = value; }
	    }

	    public static bool Offline
	    {
            get { return (ProMeshHttpContext.Current is OfflineHttpContext); }
	    }

        internal static void Reset()
        {
            _ajaxMethods = new Dictionary<string, MethodInfo>();
        }

//        internal static void AddAjaxMethod(string name, MethodInfo method)
//        {
//            _ajaxMethods[method.Name] = method;
//        }

	    internal static Dictionary<string, MethodInfo> AjaxMethods
	    {
	        get { return _ajaxMethods; }
	    }
	}
}
