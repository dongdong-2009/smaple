//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Activa.ProMesh
{
	public static class WikiFormatter
	{
		public static string _classImageComment = "";
		public static string _classTable = "";
		public static string _classBoxTitle = "";

		private static readonly Dictionary<char,string> _charMap = null;
		private static readonly char[] _charList = null;
        private static readonly Dictionary<string, string> _formatterCache = new Dictionary<string, string>(StringComparer.InvariantCulture);

		static WikiFormatter()
		{
			if (_charMap == null)
			{
				_charMap = new Dictionary<char, string>();

				_charMap['\''] = "&rsquo;";
				_charMap['<'] = "&lt;";
				_charMap['>'] = "&gt;";
				_charMap['�'] = "&iexcl;";
				_charMap['�'] = "&cent;";
				_charMap['�'] = "&pound;";
				_charMap['�'] = "&euro;";
				_charMap['�'] = "&yen;";
				_charMap['�'] = "&sect;";
				_charMap['�'] = "&uml;";
				_charMap['�'] = "&ordf;";
				_charMap['�'] = "&laquo;";
				_charMap['�'] = "&not";
				_charMap['�'] = "&shy;";
				_charMap['�'] = "&deg;";
				_charMap['�'] = "&plusmn;";
				_charMap['�'] = "&sup2;";
				_charMap['�'] = "&sup3;";
				_charMap['�'] = "&acute;";
				_charMap['�'] = "&micro;";
				_charMap['�'] = "&para;";
				_charMap['�'] = "&middot;";
				_charMap['�'] = "&cedil;";
				_charMap['�'] = "&sup1;";
				_charMap['�'] = "&ordm;";
				_charMap['�'] = "&raquo;";
				_charMap['�'] = "&frac14;";
				_charMap['�'] = "&frac12;";
				_charMap['�'] = "&frac34;";
				_charMap['�'] = "&iquest;";
				_charMap['�'] = "&Agrave;";
				_charMap['�'] = "&Aacute;";
				_charMap['�'] = "&Acirc;";
				_charMap['�'] = "&Atilde;";
				_charMap['�'] = "&Auml;";
				_charMap['�'] = "&Aring;";
				_charMap['�'] = "&AElig;";
				_charMap['�'] = "&Ccedil;";
				_charMap['�'] = "&Egrave;";
				_charMap['�'] = "&Eacute;";
				_charMap['�'] = "&Ecirc;";
				_charMap['�'] = "&Euml;";
				_charMap['�'] = "&Igrave;";
				_charMap['�'] = "&Iacute;";
				_charMap['�'] = "&Icirc;";
				_charMap['�'] = "&Iuml;";
				_charMap['�'] = "&ETH;";
				_charMap['�'] = "&Ntilde;";
				_charMap['�'] = "&Ograve;";
				_charMap['�'] = "&Oacute;";
				_charMap['�'] = "&Ocirc;";
				_charMap['�'] = "&Otilde;";
				_charMap['�'] = "&Ouml;";
				_charMap['�'] = "&times;";
				_charMap['�'] = "&Oslash;";
				_charMap['�'] = "&Ugrave;";
				_charMap['�'] = "&Uacute;";
				_charMap['�'] = "&Ucirc;";
				_charMap['�'] = "&Uuml;";
				_charMap['�'] = "&Yacute;";
				_charMap['�'] = "&THORN;";
				_charMap['�'] = "&szlig;";
				_charMap['�'] = "&agrave;";
				_charMap['�'] = "&aacute;";
				_charMap['�'] = "&acirc;";
				_charMap['�'] = "&atilde;";
				_charMap['�'] = "&auml;";
				_charMap['�'] = "&aring;";
				_charMap['�'] = "&aelig;";
				_charMap['�'] = "&ccedil;";
				_charMap['�'] = "&egrave;";
				_charMap['�'] = "&eacute;";
				_charMap['�'] = "&ecirc;";
				_charMap['�'] = "&euml;";
				_charMap['�'] = "&igrave;";
				_charMap['�'] = "&iacute;";
				_charMap['�'] = "&icirc;";
				_charMap['�'] = "&iuml;";
				_charMap['�'] = "&eth;";
				_charMap['�'] = "&ntilde;";
				_charMap['�'] = "&ograve;";
				_charMap['�'] = "&oacute;";
				_charMap['�'] = "&ocirc;";
				_charMap['�'] = "&otilde;";
				_charMap['�'] = "&ouml;";
				_charMap['�'] = "&divide;";
				_charMap['�'] = "&oslash;";
				_charMap['�'] = "&ugrave;";
				_charMap['�'] = "&uacute;";
				_charMap['�'] = "&ucirc;";
				_charMap['�'] = "&uuml;";
				_charMap['�'] = "&yacute;";
				_charMap['�'] = "&thorn;";
				_charMap['�'] = "&yuml;";

				_charList = new char[_charMap.Count];

				int i = 0;

				foreach (char c in _charMap.Keys)
					_charList[i++] = c;
			}
		}

		public static string ReplaceSymbols(string inputString)
		{
			if (inputString.IndexOfAny(_charList) < 0)
				return inputString;

			StringBuilder translatedString = new StringBuilder(inputString.Length);

			foreach (char c in inputString)
			{
				string tag;

				if (_charMap.TryGetValue(c, out tag))
					translatedString.Append(tag);
				else
					translatedString.Append(c);
			}

			return translatedString.ToString();
		}


		public static string FormatText(string inputString)
		{
			string cacheKey = inputString;

			lock (_formatterCache)
			{
				if (_formatterCache.ContainsKey(cacheKey))
					return _formatterCache[cacheKey];
			}

			StringBuilder outputString = new StringBuilder();

			inputString = inputString.Replace("\r","");
			inputString = inputString.Replace("<br>","");

			inputString = Regex.Replace(inputString,"<[^>]+>","",RegexOptions.Compiled);

			inputString = ReplaceSymbols(inputString);

			//inputString = Regex.Replace(inputString,"\n\\s*\n\\s*\n","\n\n",RegexOptions.Compiled);

			bool inBulletList = false;
			bool inTable = false;
			bool isFirstTableRow = false;
			char cBullet = '\0';

			int tablePadding = 1;
			bool firstRowIsHeader = false;
			char[] columnAlignments = new char[100];

			foreach (string textLine in inputString.Split('\n'))
			{
				Match match;
				bool doBreak = true;

				string newTextLine = textLine;

				// Bold : *text*
				// Italic : #text#
				// Underline : _text_

				if (newTextLine.IndexOf('*') >= 0)
					newTextLine = Regex.Replace(newTextLine, @"\*(?<text>(?<! )[^\*]+(?<! ))\*", "<b>${text}</b>", RegexOptions.Compiled);

				if (newTextLine.IndexOf('#') >= 0) 
					newTextLine = Regex.Replace(newTextLine, @"\#(?<text>(?<! )[^\#]+(?<! ))\#", "<i>${text}</i>", RegexOptions.Compiled);

				if (newTextLine.IndexOf('_') >= 0) 
					newTextLine = Regex.Replace(newTextLine, @"_(?<text>(?<! )[^_]+(?<! ))_", "<u>${text}</u>", RegexOptions.Compiled);

				if (newTextLine.IndexOf("[[") >= 0) 
					newTextLine = Regex.Replace(newTextLine, @"\[\[(?<text>(?<! )[^\]]+(?<! ))\]\]", "<table width='100%' border=1 cellpadding=2 cellspacing=0" + ((_classBoxTitle.Length == 0) ? ("") : (" class='" + _classBoxTitle + "'")) + "><tr><td>${text}</td></tr></table>", RegexOptions.Compiled);


				// Bulleted lists
				// * item1
				// * item2
				// * item3
				// 
				// or
				// - item1
				// - item2
				// - item3
				// 
				// or (for numbered lists)
				//
				// # item1
				// # item2
				// # item3

				
				match = Regex.Match(newTextLine , @"^\s*(?<bullet>-|\*|\+|#)\s(?<item>.*)",RegexOptions.Compiled);

				if (match.Success)
				{
					cBullet = match.Groups["bullet"].Value[0];

					if (!inBulletList)
					{
						outputString.Append(cBullet == '#' ? "<ol>":"<ul>");

						inBulletList = true;
					}

					newTextLine = "<li>" + match.Groups["item"].Value + "</li>";
					doBreak = false;
				}
				else
				{
					if (inBulletList)
					{
						outputString.Append(cBullet == '#' ? "</ol>":"</ul>");

						if (newTextLine.Trim().Length == 0)
							doBreak = false;
					}

					inBulletList = false;
				}

				// Process tables
				//
				// [TABLE H P3 LCR]
				// |cell1|cell2|cell3|
				// |mergedcell4||cell5|
				// |cell6|mergedcell7||

				if (newTextLine.IndexOf("[TABLE", StringComparison.InvariantCultureIgnoreCase) >= 0)
				{
					match = Regex.Match(newTextLine, @"\[TABLE(\s+(?<option>H|P\d+))*(\s+(?<cols>[LRC]+))*\]", RegexOptions.Compiled | RegexOptions.IgnoreCase);

					if (match.Success)
					{
						firstRowIsHeader = false;

						if (match.Groups["option"].Success)
						{
							foreach (Capture optionCapture in match.Groups["option"].Captures)
							{
								if (optionCapture.Value.ToUpper() == "H")
									firstRowIsHeader = true;

								if (optionCapture.Value.ToUpper().StartsWith("P"))
								{
									tablePadding = ProMeshUtil.ConvertString<int>(optionCapture.Value.Substring(1));
								}
							}
						}

						if (match.Groups["cols"].Success)
						{
							string columnSpecs = match.Groups["cols"].Value.ToUpper();

							int i;

							for (i = 0; i < columnSpecs.Length; i++)
								columnAlignments[i] = columnSpecs[i];

							for (; i < 100; i++)
								columnAlignments[i] = 'L';
						}

						newTextLine = "";
						doBreak = false;
					}
				}

				match = Regex.Match(newTextLine , @"^\|(?<cell>[^\|]*\|)+(?<full>\+)?",RegexOptions.Compiled);

				if (match.Success)
				{
					if (!inTable)
					{
						string strExtend = "";

						if (match.Groups["full"].Success)
							strExtend = " width=\"100%\"";

						if (_classTable != null && _classTable.Length > 0)
							outputString.Append("<table cellspacing=\"0\" cellpadding=\"" + tablePadding + "\" class=\"" + _classTable + "\"" + strExtend + ">");
						else
							outputString.Append("<table cellspacing=\"0\" cellpadding=\"" + tablePadding + "\" border=\"1\"" + strExtend + ">");

						inTable = true;
						isFirstTableRow = true;
					}

					Group g = match.Groups["cell"];

					int span = 1;

					newTextLine = "";

					for (int i = g.Captures.Count - 1 ; i >= 0 ; i--)
					{
						Capture capture = g.Captures[i];

						if (capture.Value.Length == 1)
							span++;
						else
						{
							string column;
							string cellTag = "td";
							string strAlign = "left";

							switch (columnAlignments[i])
							{
								case 'L': strAlign = "left"; break;
								case 'R': strAlign = "right"; break;
								case 'C': strAlign = "center"; break;
							}

							if (isFirstTableRow && firstRowIsHeader)
								cellTag = "th";

							if (span > 1)
								column = "<" + cellTag + " align='" + strAlign + "' colspan='" + span + "'>";
							else
								column = "<" + cellTag + " align='" + strAlign + "'>";
							
							column += capture.Value.Substring(0,capture.Value.Length - 1);
								
							column += "</" + cellTag + ">";

							newTextLine = column + newTextLine;

							span = 1;
						}
					}

					newTextLine = "<tr>" + newTextLine + "</tr>";

					doBreak = false;

					isFirstTableRow = false;
				}
				else
				{
					if (inTable)
					{
						outputString.Append("</table>");

						for (int i = 0 ; i < 100; i++)
							columnAlignments[i] = 'L';

						firstRowIsHeader = false;
						tablePadding = 1;
					}

					inTable = false;
				}


				// [IMG=ImageURL,ImageLinkURL (caption)]
				// [IMG/L=ImageURL,ImageLinkURL (caption)]
				// [IMG/R=ImageURL,ImageLinkURL (caption)]
				//
				// Inserts an image in the text. "ImageURL" is required. ImageLinkURL and caption are optional

				if (newTextLine.IndexOf("[IMG",StringComparison.InvariantCultureIgnoreCase) >= 0)
				{
					match = Regex.Match(newTextLine, @"\[IMG(/(?<align>L|R))?=(?<url>[\w\.\?\&\:/@]+)(,(?<link>[^\s\(]+))?\s*(\((?<comment>.*)\))?\]", RegexOptions.IgnoreCase | RegexOptions.Compiled);

					if (match.Success)
					{
						string strAlign = "";
						string strComment = "";
						string strLink = "";

						if (match.Groups["align"].Success)
							strAlign = match.Groups["align"].Value;

						if (match.Groups["comment"].Success)
							strComment = match.Groups["comment"].Value;

						if (match.Groups["link"].Success)
							strLink = match.Groups["link"].Value;

						string strUrl = match.Groups["url"].Value;

						if (strAlign.ToUpper() == "L")
							strAlign = " align='left'";
						if (strAlign.ToUpper() == "R")
							strAlign = " align='right'";

						if (strComment.Length > 0)
						{
							if (_classImageComment != null && _classImageComment.Length > 0)
								strComment = "<font class='" + _classImageComment + "'>" + strComment + "</font>";

							strComment = "<tr><td" + strAlign + ">" + strComment + "</td></tr>";
						}

						string strImg = "<img border=0 src=\"" + strUrl + "\">";

						if (strLink.Length > 0)
							strImg = "<a href='" + strLink + "'>" + strImg + "</a>";

						string strRepl = "<table border='0' cellpadding='0' cellspacing='0'" + strAlign + ">"
						                 + "<tr><td>" + strImg + "</td></tr>"
						                 + strComment
						                 + "</table>";

						newTextLine = newTextLine.Substring(0, match.Index) + strRepl + newTextLine.Substring(match.Index + match.Length);
					}
				}

				// (c) or (r) becomes relevant symbol

				if (newTextLine.IndexOf('(') >= 0)
				{
					newTextLine = Regex.Replace(newTextLine, @"\((c|C)\)", "&copy;", RegexOptions.Compiled);
					newTextLine = Regex.Replace(newTextLine, @"\((r|R)\)", "&reg;", RegexOptions.Compiled);
				}

				// Named link:  "Link Text"="Link URL"

				if (newTextLine.IndexOf('=') >= 0) 
					newTextLine = Regex.Replace(newTextLine, @"""(?<name>[^""]+)""=""(?<url>[^""]+)""", "<a href=\"${url}\" target=\"_blank\">${name}</a>", RegexOptions.Compiled);

				// Text in form www.xxx.xxx are converted to a link with target "_blank"

				if (newTextLine.IndexOf("www") >= 0)
					newTextLine = Regex.Replace(newTextLine, @"(?<!href=""http://)www\.[\-\w\.\?\&\:/@]+", "<a href=\"http://$&\" target=\"_blank\">$&</a>", RegexOptions.Compiled);


				// E-mail adresses are converted to a mailto: URL link

				if (newTextLine.IndexOf('@') >= 0)
					newTextLine = Regex.Replace(newTextLine, @"[a-zA-Z\._0-9\-]{1,}@[A-Za-z0-9\.\-]+\.[A-Za-z0-9]{2,4}", "<a href=\"mailto:$&\">$&</a>", RegexOptions.Compiled);

				// !Title1
				// !!Title2
				// !!!Title3
				if (newTextLine.StartsWith("!"))
				{
					newTextLine = Regex.Replace(newTextLine, @"^!!!(?<title>.+)", "<h3>${title}</h3>", RegexOptions.Compiled);
					newTextLine = Regex.Replace(newTextLine, @"^!!(?<title>.+)", "<h2>${title}</h2>", RegexOptions.Compiled);
					newTextLine = Regex.Replace(newTextLine, @"^!(?<title>.+)", "<h1>${title}</h1>", RegexOptions.Compiled);
				}

				// --- at the start of a line is converted to a horizontal rule

				if (newTextLine.StartsWith("---"))
				{
					if (Regex.Match(newTextLine, @"^-{3,}").Success)
					{
						newTextLine = Regex.Replace(newTextLine, @"^-{3,}", "<hr>");

						doBreak = false;
					}
				}

				// {color:Text} is used to draw text in the specified color (named colors or HTML colors)

				if (newTextLine.IndexOf('{') >= 0)
					newTextLine = Regex.Replace(newTextLine , @"\{(?<color>[a-z#0-9]+):(?<text>[^\}]+)\}" , "<font color=\"${color}\">${text}</font>",RegexOptions.Compiled);

				outputString.Append(newTextLine);
				
				if (doBreak) 
					outputString.Append("<br>\r\n");
			}

			string finalString = outputString.ToString();

			if (finalString.EndsWith("<br>\r\n"))
				finalString = finalString.Substring(0,finalString.Length-6);

			_formatterCache[cacheKey] = finalString;

			return finalString;
		}
	}
}
