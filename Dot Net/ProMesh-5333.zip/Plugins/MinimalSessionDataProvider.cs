//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;

namespace Activa.ProMesh
{
    internal class MinimalSessionDataProvider : ISessionDataProvider
    {
        private readonly static object _staticLock = new object();
        private readonly Dictionary<int, int> _visitors = new Dictionary<int, int>();
        private static int _sessionId = 0;
        private static int _visitorId = 0;

        static MinimalSessionDataProvider()
        {
            _sessionId = (int)(DateTime.Now - new DateTime(2006, 1, 1)).TotalSeconds;
            _visitorId = (int)(DateTime.Now - new DateTime(2005, 1, 1)).TotalSeconds;
        }
 
        public int CreateSession(string httpReferer, string httpRemoteAddress, string httpUserAgent)
        {
            lock (_staticLock)
                return ++_sessionId;
        }

        public void AssignVisitorToSession(int sessionId, int visitorId)
        {
            _visitors[sessionId] = visitorId;
        }

        public void AssignUserToSession(int sessionId, int userId)
        {
        }

        public int GetVisitorIdForSessionId(int sessionId)
        {
            if (_visitors.ContainsKey(sessionId))
                return _visitors[sessionId];
            else
                return 0;
        }

        public int CreateVisitor()
        {
            lock (_staticLock)
                return ++_visitorId;
        }

        public object GetSessionObject(int sessionId)
        {
            return null;
        }

        public object GetVisitorObject(int visitorId)
        {
            return null;
        }
    }
}
