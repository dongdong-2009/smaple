//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;

namespace Activa.ProMesh
{
    public class ClientDataCollection
    {
        private readonly bool _post;

        public ClientDataCollection(bool post)
        {
            _post = post;
        }

        private NameValueCollection Data
        {
            get
            {
                if (_post)
                    return WebAppContext.Request.Form;
                else
                    return WebAppContext.Request.QueryString;
            }
        }

        public string[] Variables
        {
            get { return Data.AllKeys; }
        }

        public bool Has(string name)
        {
            return Data[name] != null;
        }

        public string Get(string name)
        {
            return Data[name];
        }

        public string Get(string name, string defaultValue)
        {
            return Data[name] ?? defaultValue;
        }

        public object Get(string name, Type t)
        {
            if (typeof(Array).IsAssignableFrom(t))
            {
                ArrayList valueList = (ArrayList)typeof(NameObjectCollectionBase).InvokeMember("BaseGet", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, Data, new object[] { name });

                Type elementType = t.GetElementType();

                Array array = Array.CreateInstance(elementType, valueList.Count);

                for (int i = 0; i < valueList.Count; i++)
                {
                    array.SetValue(ProMeshUtil.ConvertString((string) valueList[i], elementType), i);
                }

                return array;
            }

            return ProMeshUtil.ConvertString(Get(name), t);
        }

        public string this[string name]
        {
            get { return Data[name]; }
        }

        public T Get<T>(string name)
        {
            return Get(name, default(T));
        }

        public T Get<T>(string name, T defaultValue)
        {
            if (!Has(name))
                return defaultValue;

            return (T)Get(name, typeof(T));
        }

    }

 
}
