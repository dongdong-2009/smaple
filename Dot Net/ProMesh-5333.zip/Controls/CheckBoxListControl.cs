//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Web;

namespace Activa.ProMesh
{
    public enum CheckBoxListStyle
    {
        Div,
        Span
    }

    public class CheckBoxListControl<Tkey, Tvalue> : CheckBoxListControl where Tkey : IComparable<Tkey>
    {
        public CheckBoxListControl(string name)
            : base(name, typeof(Tkey), typeof(Tvalue))
        {
        }

        public CheckBoxListControl(string name, CheckBoxListStyle style)
            : base(name, typeof(Tkey), typeof(Tvalue) , style)
        {
        }

        public void Check(Tkey key)
        {
            if (!Values.Contains(key))
                Values.Add(key);
        }

        public void UnCheck(Tkey key)
        {
            if (Values.Contains(key))
                Values.Remove(key);
        }


        public bool IsChecked(Tkey key)
        {
            return Values.Contains(key);
        }
    }

    public class CheckBoxListControl : Control
    {
        public class Item
        {
            public Item()
            {
            }

            public Item(object key, object value)
            {
                Key = key;
                Value = value;
            }

            public object Key;
            public object Value;
        }

        private CheckBoxListStyle _style = CheckBoxListStyle.Span;

        private readonly Type _keyType;
        private readonly Type _valueType;

        public List<object> Values;

        private bool _isBound = false;

        private object _dataSource;

        private string _keyMember;
        private string _valueMember;

        private readonly List<Item> _items = new List<Item>();

        public CheckBoxListControl(string name) : base(name)
        {
            _keyType = typeof(string);
            _valueType = typeof(string);
        }

        public CheckBoxListControl(string name, CheckBoxListStyle style) : this(name)
        {
            _style = style;
        }

        protected internal CheckBoxListControl(string name,Type keyType, Type valueType) : base(name)
        {
            _keyType = keyType;
            _valueType = valueType;
        }

        protected internal CheckBoxListControl(string name,Type keyType, Type valueType, CheckBoxListStyle style) : this(name,keyType,valueType)
        {
            _style = style;
        }

        public static string DefaultCssClass
        {
            set { SetDefaultCssClass<DropdownControl>(value, null); }
        }

        public static string DefaultCssClassError
        {
            set { SetDefaultCssClass<DropdownControl>(null, value); }
        }

        public override object DataSource
        {
            get
            {
                return _dataSource;
            }
            set
            {
                _dataSource = value;

                _isBound = false;
            }
        }

        private void Bind()
        {
            Items.Clear();

            if (_dataSource is ITypedList)
            {
                ITypedList typedList = (ITypedList)_dataSource;
                IList list = (IList)_dataSource;

                PropertyDescriptorCollection props = typedList.GetItemProperties(null);

                PropertyDescriptor propKey = props.Find(KeyMember, true);
                PropertyDescriptor propValue = props.Find(ValueMember, true);

                if (propKey == null)
                    throw new ProMeshException(KeyMember + " property does not exist in datasource " + _dataSource);

                if (propValue == null)
                    throw new ProMeshException(ValueMember + " property does not exist in datasource " + _dataSource);

                foreach (object obj in list)
                {
                    Items.Add(new Item(ProMeshUtil.ConvertType(propKey.GetValue(obj), _keyType), ProMeshUtil.ConvertType(propValue.GetValue(obj), _valueType)));
                }
            }
            else if (_dataSource is NameValueCollection)
            {
                NameValueCollection nv = (NameValueCollection)_dataSource;

                for (int i = 0; i < nv.Count; i++)
                {
                    Items.Add(new Item(ProMeshUtil.ConvertType(nv.Keys[i], _keyType), ProMeshUtil.ConvertType(nv[i], _valueType)));
                }
            }
            else if (_dataSource is ICollection)
            {
                ICollection col = (ICollection)_dataSource;

                foreach (object obj in col)
                {
                    object key;
                    object v;

                    if (KeyMember == null)
                        key = ProMeshUtil.ConvertType(obj, _keyType);
                    else
                        key = ProMeshUtil.ConvertType(ProMeshUtil.GetObjectProperty(obj, KeyMember), _keyType);

                    if (ValueMember == null)
                        v = ProMeshUtil.ConvertType(obj, _valueType);
                    else
                        v = ProMeshUtil.ConvertType(ProMeshUtil.GetObjectProperty(obj, ValueMember), _valueType);

                    Items.Add(new Item(key, v));
                }
            }

            _isBound = true;
        }

        public string KeyMember
        {
            get { return _keyMember; }
            set { _keyMember = value; _isBound = false; }
        }

        public string ValueMember
        {
            get { return _valueMember; }
            set { _valueMember = value; _isBound = false; }
        }

        public List<Item> Items
        {
            get
            {
                if (!_isBound)
                    Bind();

                return _items;
            }
        }

        protected override string GenerateHtml(View view, string className, string classNameError)
        {
            if (!_isBound)
                Bind();

            string s = "<div";

            s = AddIdAttribute(s);
            s = AddClassAttribute(s, className, classNameError);

            s += ">\r\n";

            for (int i = 0; i < Items.Count; i++)
            {
                if (_style == CheckBoxListStyle.Div)
                    s += "<div>";

                if (_style == CheckBoxListStyle.Span)
                    s += "<span>";

                bool isChecked = Values.Contains(Items[i].Key);

                s += "<input ";

                s = AddNameAttribute(s);
                s = AddEnabledAttribute(s);
                s = AddOnChangeAttribute(s);

                s += " type='checkbox' value='" + Items[i].Key + "'" + (isChecked  ? " checked='checked'" : "") + " />" + HttpUtility.HtmlEncode(Items[i].Value.ToString());

                if (_style == CheckBoxListStyle.Div)
                    s += "</div>";

                if (_style == CheckBoxListStyle.Span)
                    s += "</span>";

            }

            s += "</div>";

            return s;

        }

        protected override void HandlePostback(ClientDataCollection postData)
        {
            Array array = Array.CreateInstance(_keyType, 0);

            array = (Array) postData.Get(Name, array.GetType());

            Values.Clear();

            foreach (object obj in array)
                Values.Add(obj);
        }
    }
}
