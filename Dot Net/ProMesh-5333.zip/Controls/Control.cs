//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web;

namespace Activa.ProMesh
{
    public abstract class Control
    {
        private string _id;
        private string _name;
        private bool _error;
        private string _cssClass;
        private string _cssClassError;
        private bool _autoPost;
        private string _onChange;
        private bool _enabled = true;

        private static readonly Dictionary<Type, string> _defaultCssClasses = new Dictionary<Type, string>();
        private static readonly Dictionary<Type, string> _defaultCssClassesError = new Dictionary<Type, string>();
        private static readonly Dictionary<Type, MethodInfo[]> _ajaxMethods = new Dictionary<Type, MethodInfo[]>();

        private static IControlIdProvider _controlIdProvider = new DefaultControlIdGenerator();

        protected Control(string name)
        {
            _name = name;
        }

        public MethodInfo[] AjaxMethods
        {
            get
            {
                Type type = GetType();

                lock (_ajaxMethods)
                {
                    if (!_ajaxMethods.ContainsKey(GetType()))
                    {
                        List<MethodInfo> ajaxMethods = new List<MethodInfo>();

                        foreach (MethodInfo method in type.GetMethods())
                        {
                            if (method.IsDefined(typeof(AjaxAttribute), true))
                                ajaxMethods.Add(method);
                        }


                        _ajaxMethods[type] = ajaxMethods.ToArray();
                    }
                }

                return _ajaxMethods[type];
            }
        }

        public virtual string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public virtual string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public virtual bool Error
        {
            get { return _error; }
            set { _error = value; }
        }

        public string CssClass
        {
            get { return _cssClass; }
            set { _cssClass = value; }
        }

        public string CssClassError
        {
            get { return _cssClassError; }
            set { _cssClassError = value; }
        }

        public bool AutoPost
        {
            get { return _autoPost; }
            set { _autoPost = value; }
        }

        public string OnChange
        {
            get { return _onChange; }
            set { _onChange = value; }
        }

        public bool Enabled
        {
            get { return _enabled; }
            set { _enabled = value; }
        }

        public abstract object DataSource { set; get; }

        protected abstract string GenerateHtml(View view, string className, string classNameError);
        protected abstract void HandlePostback(ClientDataCollection postData);

        public string Render(View view)
        {
            return Render(view, null, null);
        }

        public string Render(View view, string cssClass, string cssClassError)
        {
            Id = ControlIdProvider.GenerateControlId(this, view.NextControlIndex);

            return GenerateHtml(view, cssClass, cssClassError);
        }

        protected string AddIdAttribute(string html)
        {
            if (Id != null && Id.Length > 0)
                html += " id=\"" + HttpUtility.HtmlAttributeEncode(Id) + "\"";

            return html;
        }

        protected string AddNameAttribute(string html)
        {
            if (Name != null && Name.Length > 0)
                html += " name=\"" + HttpUtility.HtmlAttributeEncode(Name) + "\"";

            return html;
        }

        protected string AddOnChangeAttribute(string html)
        {
            string onChange = "";

            if (OnChange != null && OnChange.Length > 0)
                onChange += OnChange;

            if (AutoPost)
            {
                if (onChange.Length > 0)
                    onChange += ";";

                onChange += "this.form.submit()";
            }

            if (onChange.Length > 0)
                html += " onchange=\"" + HttpUtility.HtmlAttributeEncode(onChange) + "\"";

            return html;
        }

        private static string ApplyClassName(string existingClass, string newClass)
        {
            if (newClass == null || newClass.Length < 1)
                return existingClass;

            if (newClass[0] == '+')
                return (existingClass ?? "") + ' ' + newClass.Substring(1);

            return newClass;
        }

        protected string AddClassAttribute(string html, string className, string classNameError)
        {
            string cl = CssClass;
            string cle = CssClassError;

            cl = ApplyClassName(cl, className);

            if (cle == null)
                cle = cl;

            cle = ApplyClassName(cle, classNameError);

            if (cl == null)
                cl = DefaultCssClass;

            if (cle == null)
                cle = DefaultCssClassError;

            if (Error && cle != null)
            {
                if (cle.Length > 0)
                    html += " class=\"" + cle + "\"";
            }
            else
            {
                if (cl != null && cl.Length > 0)
                    html += " class=\"" + cl + "\"";
            }

            return html;
        }

        protected string AddEnabledAttribute(string html)
        {
            if (!Enabled)
                html += " disabled=\"disabled\"";

            return html;
        }


        public void HandlePostBack()
        {
            if (WebAppContext.CurrentPageController.IsPost())
                HandlePostback(WebAppContext.PostData);
        }


        protected static void SetDefaultCssClass<T>(string cssClass, string cssClassError) where T : Control
        {
            if (cssClass != null && cssClass.Length > 0)
                _defaultCssClasses[typeof(T)] = cssClass;

            if (cssClassError != null && cssClassError.Length > 0)
                _defaultCssClassesError[typeof(T)] = cssClassError;
        }

        private string DefaultCssClass
        {
            get
            {
                Type type = GetType();

                while (type != typeof(Control))
                {
                    if (_defaultCssClasses.ContainsKey(type))
                        return _defaultCssClasses[type];

                    type = type.BaseType;
                }

                return null;
            }
        }

        private string DefaultCssClassError
        {
            get
            {
                Type type = GetType();

                while (type != typeof(Control))
                {
                    if (_defaultCssClassesError.ContainsKey(type))
                        return _defaultCssClassesError[type];

                    type = type.BaseType;
                }

                return null;
            }
        }

        public static IControlIdProvider ControlIdProvider
        {
            get { return _controlIdProvider; }
            set { _controlIdProvider = value; }
        }
    }
}
