//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Web;

namespace Activa.ProMesh
{
    public class DropdownControl<Tkey,Tvalue> : DropdownControl where Tkey:IComparable<Tkey>
    {
        public DropdownControl(string name) 
            : base(name, typeof(Tkey), typeof(Tvalue))
        {
        }

        public new Tkey Value
        {
            get { return (Tkey) base.Value; }
            set { base.Value = value; }
        }

        public new Tvalue BlankValue
        {
            get { return (Tvalue) base.BlankValue; }
            set { base.BlankValue = value; }
        }

        public new Tkey BlankKey
        {
            get { return (Tkey) base.BlankKey; }
            set { base.BlankKey = value; }
        }
    }

    public class DropdownControl : Control
    {
        public class Item
        {
            public Item()
            {
            }

            public Item(object key, object value)
            {
                Key = key;
                Value = value;
            }

            public object Key;
            public object Value;
        }

        private readonly Type _keyType;
        private readonly Type _valueType;

        public object Value;

        private bool _showBlank = false;
        private object _blankValue;
        private object _blankKey;

        private bool _isBound = false;

        private object _dataSource;

        private string _keyMember;
        private string _valueMember;

        private readonly List<Item> _items = new List<Item>();

        public DropdownControl(string name) : base(name)
        {
            _keyType = typeof(string);
            _valueType = typeof(string);
        }

        protected internal DropdownControl(string name, Type keyType, Type valueType) : base(name)
        {
            _keyType = keyType;
            _valueType = valueType;
        }

        public static string DefaultCssClass
        {
            set { SetDefaultCssClass<DropdownControl>(value,null); }
        }

        public static string DefaultCssClassError
        {
            set { SetDefaultCssClass<DropdownControl>(null,value); }
        }

        public override object DataSource
        {
            get
            {
                return _dataSource;
            }
            set
            {
                _dataSource = value;

                _isBound = false;
            }
        }

        private void Bind()
        {
            _isBound = true;

            Items.Clear();

            if (_dataSource is ITypedList)
            {
                ITypedList typedList = (ITypedList)_dataSource;
                IList list = (IList)_dataSource;

                PropertyDescriptorCollection props = typedList.GetItemProperties(null);

                PropertyDescriptor propKey = props.Find(KeyMember, true);
                PropertyDescriptor propValue = props.Find(ValueMember, true);

                if (propKey == null)
                    throw new ProMeshException(KeyMember + " property does not exist in datasource " + _dataSource);

                if (propValue == null)
                    throw new ProMeshException(ValueMember + " property does not exist in datasource " + _dataSource);

                foreach (object obj in list)
                {
                    Items.Add(new Item(ProMeshUtil.ConvertType(propKey.GetValue(obj), _keyType), ProMeshUtil.ConvertType(propValue.GetValue(obj), _valueType)));
                }
            }
            else if (_dataSource is NameValueCollection)
            {
                NameValueCollection nv = (NameValueCollection)_dataSource;

                for (int i = 0; i < nv.Count; i++)
                {
                    Items.Add(new Item(ProMeshUtil.ConvertType(nv.Keys[i], _keyType), ProMeshUtil.ConvertType(nv[i], _valueType)));
                }
            }
            else if (_dataSource is ICollection)
            {
                ICollection col = (ICollection)_dataSource;

                foreach (object obj in col)
                {
                    object key;
                    object v;

                    if (KeyMember == null)
                        key = ProMeshUtil.ConvertType(obj, _keyType);
                    else
                        key = ProMeshUtil.ConvertType(ProMeshUtil.GetObjectProperty(obj, KeyMember), _keyType);

                    if (ValueMember == null)
                        v = ProMeshUtil.ConvertType(obj, _valueType);
                    else
                        v = ProMeshUtil.ConvertType(ProMeshUtil.GetObjectProperty(obj, ValueMember), _valueType);

                    Items.Add(new Item(key,v));
                }
            }

            if (_showBlank)
            {
                Items.Insert(0, new Item(_blankKey,_blankValue));
            }
        }

        public string KeyMember
        {
            get { return _keyMember; }
            set { _keyMember = value; _isBound = false; }
        }

        public string ValueMember
        {
            get { return _valueMember; }
            set { _valueMember = value; _isBound = false; }
        }

        public bool ShowBlank
        {
            get { return _showBlank; }
            set { _showBlank = value; _isBound = false; }
        }

        public object BlankValue
        {
            get { return _blankValue; }
            set { _blankValue = value; _isBound = false; }
        }

        public object BlankKey
        {
            get { return _blankKey; }
            set { _blankKey = value; _isBound = false; }
        }

        public List<Item> Items
        {
            get
            {
                if (!_isBound)
                    Bind();

                return _items;
            }
        }

        protected override string GenerateHtml(View view, string className, string classNameError)
        {
            if (!_isBound)
                Bind();

            string s = "<select";

            s = AddIdAttribute(s);
            s = AddNameAttribute(s);
            s = AddClassAttribute(s, className , classNameError);
            s = AddEnabledAttribute(s);
            s = AddOnChangeAttribute(s);

            s += ">\r\n";

            for (int i = 0; i < Items.Count; i++)
            {
                bool isCurrent = Equals(Value, Items[i].Key);

                s += "<option value='" + Items[i].Key + "'" + (isCurrent ? " selected='selected'" : "") + ">" + HttpUtility.HtmlEncode(Items[i].Value.ToString()) + "</option>\r\n";
            }

            s += "</select>";

            return s;

        }

        protected override void HandlePostback(ClientDataCollection postData)
        {
            Value = ProMeshUtil.ConvertString(postData[Name],_keyType);
        }
    }
}
