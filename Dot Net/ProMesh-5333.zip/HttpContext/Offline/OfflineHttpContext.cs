//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Caching;

namespace Activa.ProMesh
{
    public class OfflineHttpContext : ProMeshHttpContext
    {
        private readonly OfflineHttpRequest _request;
        private readonly OfflineHttpResponse _response;
        private readonly OfflineHttpServerUtility _server;
        private readonly OfflineHttpSessionState _session;

        private readonly OfflineWebSession _offlineSession;

        public OfflineHttpContext(OfflineWebSession offlineSession, string method, string url, NameValueCollection postData)
        {
            _offlineSession = offlineSession;

            _request = new OfflineHttpRequest(method, url, postData);
            _session = new OfflineHttpSessionState(offlineSession);
            _server = new OfflineHttpServerUtility(offlineSession);
            _response = new OfflineHttpResponse();
        }

        public override Exception[] AllErors
        {
            get { return new Exception[0]; }
        }

        public override Cache Cache
        {
            get { return null; }
        }

        public override ProMeshHttpRequest Request
        {
            get { return _request; }
        }

        public override ProMeshHttpResponse Response
        {
            get { return _response; }
        }

        public override ProMeshHttpServerUtility Server
        {
            get { return _server; }
        }

        public override ProMeshHttpSessionState Session
        {
            get { return _session; }
        }

        public OfflineWebSession OfflineSession
        {
            get { return _offlineSession;  }
        }
    }
}
