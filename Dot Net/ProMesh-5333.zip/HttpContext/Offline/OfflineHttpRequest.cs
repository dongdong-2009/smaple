//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;

namespace Activa.ProMesh
{
    public class OfflineHttpRequest : ProMeshHttpRequest
    {
        private readonly HttpCookieCollection _cookies;
        private readonly NameValueCollection _form;
        private readonly NameValueCollection _queryString;
        private readonly NameValueCollection _serverVariables;
        private readonly Uri _url;

        private string _filePath;
        private string _pathInfo;
        private string _rawUrl;

        public OfflineHttpRequest(string method, string url, NameValueCollection data)
        {
            _cookies = new HttpCookieCollection();
            _queryString = new NameValueCollection(StringComparer.InvariantCultureIgnoreCase);
            _serverVariables = new NameValueCollection(StringComparer.InvariantCultureIgnoreCase);

            if (data != null)
                _form = data;
            else 
                _form = new NameValueCollection(StringComparer.InvariantCultureIgnoreCase);
        
            ProcessUrl(url);

            _url = new Uri("http://localhost:0" + _rawUrl,UriKind.Absolute);

            _serverVariables["REQUEST_METHOD"] = method.ToUpper();
            _serverVariables["REMOTE_ADDR"] = "127.0.0.1";
            _serverVariables["HTTP_USER_AGENT"] = "ProMesh/Offline";
            _serverVariables["HTTP_REFERER"] = "";
        }

        private static OfflineHttpContext Context
        {
            get { return (OfflineHttpContext) ProMeshHttpContext.Current; }
        }

        public override NameValueCollection ServerVariables
        {
            get { return _serverVariables; }
        }

        public override NameValueCollection Form
        {
            get { return _form; }
        }

        public override HttpCookieCollection Cookies
        {
            get { return _cookies; }
        }

        public override string ApplicationPath
        {
            get { return "/"; }
        }

        public override NameValueCollection QueryString
        {
            get { return _queryString; }
        }

        public override string PhysicalApplicationPath
        {
            get { return Context.OfflineSession.RootPath; }
        }

        public override string RawUrl
        {
            get { return _rawUrl; }
        }

        public override string FilePath
        {
            get { return _filePath; }
        }

        public override string PathInfo
        {
            get { return _pathInfo; }
        }

        public override bool IsLocal
        {
            get { return true; }
        }

        public override HttpBrowserCapabilities Browser
        {
            get { throw new NotSupportedException(); }
        }

        public override Uri Url
        {
            get { return _url; }
        }

        public override Uri UrlReferrer
        {
            get { return null; }
        }

        public override string Path
        {
            get { return FilePath + PathInfo; }
        }

        private void ProcessUrl(string url)
        {
            if (url.StartsWith("~/"))
                url = url.Substring(1);

            if (!url.StartsWith("/"))
                throw new UriFormatException("URL cannot be a relative path");

            _rawUrl = url;

            int q = url.IndexOf('?');
            string queryString = "";

            if (q > 0)
            {
                queryString = url.Substring(q + 1);
                url = url.Substring(0, q);
            }

            q = url.LastIndexOf('.');

            if (q < 0)
                throw new UriFormatException("Illegal URL: " + url);

            q = url.IndexOf('/',q);

            if (q > 0)
            {
                _pathInfo = url.Substring(q);
                _filePath = url.Substring(0, q);
            }
            else
            {
                _pathInfo = "";
                _filePath = url;
            }

            string[] paramPairs = queryString.Split('&');

            foreach (string paramPair in paramPairs)
            {
                int eq = paramPair.IndexOf('=');

                if (eq > 0)
                    _queryString[paramPair.Substring(0, eq)] = paramPair.Substring(eq + 1);
                else
                    _queryString[paramPair] = "";
            }
        }

        public override bool CheckETag(string eTag)
        {
            return false;
        }
    }
}