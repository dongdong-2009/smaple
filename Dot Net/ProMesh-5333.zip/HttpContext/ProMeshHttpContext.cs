//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.Caching;

namespace Activa.ProMesh
{
    public abstract class ProMeshHttpContext
    {
        [ThreadStatic]
        private static ProMeshHttpContext _current;

        private ProMeshPageHandler _handler;
        private SessionBase _session;

        public abstract Exception[] AllErors { get; }
        public abstract Cache Cache { get; }
        public abstract ProMeshHttpRequest Request { get; }
        public abstract ProMeshHttpResponse Response { get; }
        public abstract ProMeshHttpServerUtility Server { get; }
        public abstract ProMeshHttpSessionState Session { get; }

        public static ProMeshHttpContext Current
        {
            get { return _current; }
        }

        internal ProMeshPageHandler Handler
        {
            get { return _handler; }
            set { _handler = value; }
        }

        internal SessionBase SessionObject
        {
            get { return _session; }
            set { _session = value; }
        }

        public static void CreatePageContext(HttpContext httpContext)
        {
            WebAppConfig.Init();

            _current = new OnlineHttpContext(httpContext);

            if (httpContext.Session != null) 
                _current.SessionObject = WebAppHelper.CreateSessionObject();
        }

        public static void CreateSessionContext(HttpContext httpContext)
        {
            WebAppConfig.Init();

            _current = new OnlineHttpContext(httpContext);

            if (httpContext.Session != null)
                _current.SessionObject = WebAppHelper.CreateSessionObject();
        }

        public static void CreatePageContext(OfflineWebSession webSession, string method, string url, NameValueCollection postData )
        {
            WebAppConfig.Init();

            _current = new OfflineHttpContext(webSession, method, url, postData);

            _current.SessionObject = WebAppHelper.CreateSessionObject();
        }

        public static void CreateSessionContext(OfflineWebSession webSession, string method, string url, NameValueCollection postData)
        {
            WebAppConfig.Init();

            _current = new OfflineHttpContext(webSession, method, url, postData);

            _current.SessionObject = WebAppHelper.CreateSessionObject();
        }
    }
}