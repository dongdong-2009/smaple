//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Reflection;

namespace Activa.ProMesh
{
    public class FormField<T> where T:class
    {
        private readonly MemberInfo _memberInfo;
        private readonly FormFieldAttribute _attribute;
        private readonly Control _control;
        private readonly WebForm<T> _webForm;
        private readonly T _dataObject;

        public event FieldValidateHandler Validate;

        internal FormField(WebForm<T> webForm, T dataObject, MemberInfo memberInfo, FormFieldAttribute formFieldAttribute)
        {
            _webForm = webForm;
            _memberInfo = memberInfo;
            _attribute = formFieldAttribute;

            _control = _attribute.CreateControl();

            _dataObject = dataObject;
        }

        public Control Control
        {
            get { return _control; }
        }

        internal MemberInfo MemberInfo
        {
            get { return _memberInfo; }
        }

        public FormFieldAttribute Attribute
        {
            get { return _attribute; }
        }

        public bool Error
        {
            get { return _control.Error; }
            set { _control.Error = value; }
        }

        public bool Enabled
        {
            get { return _control.Enabled; }
            set { _control.Enabled = value; }
        }

        public object DataSource
        {
            set { _control.DataSource = value; }
            get { return _control.DataSource; }
        }

        public WebForm<T> Form
        {
            get { return _webForm; }
        }

        internal void SetPropertyFromControl()
        {
            if (MemberInfo is FieldInfo)
                ((FieldInfo)MemberInfo).SetValue(_dataObject, _attribute.GetControlValue(_control));

            if (MemberInfo is PropertyInfo)
                ((PropertyInfo)MemberInfo).SetValue(_dataObject, _attribute.GetControlValue(_control), null);
        }

        internal void SetControlFromProperty()
        {
            if (MemberInfo is FieldInfo)
                _attribute.SetControlValue(_control, ((FieldInfo)MemberInfo).GetValue(_dataObject));

            if (MemberInfo is PropertyInfo)
                _attribute.SetControlValue(_control, ((PropertyInfo)MemberInfo).GetValue(_dataObject, null));
        }

        internal object GetValue()
        {
            if (_memberInfo is FieldInfo)
                return ((FieldInfo)_memberInfo).GetValue(_dataObject);

            if (_memberInfo is PropertyInfo)
                return ((PropertyInfo)_memberInfo).GetValue(_dataObject, null);

            return null;
        }

        internal bool ValidateField()
        {
            bool valid = _attribute.Validate(Control);

            if (valid)
            {
                if (Validate != null)
                    valid = Validate(_attribute.Name, GetValue());
            }

            return valid;
        }
    }
}