//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;

namespace Activa.ProMesh
{
    public class WebForm : WebForm<object>
    {
        public WebForm()
        {
        }

        public WebForm(object dataObject) : base(dataObject)
        {
            
        }
    }

    public delegate bool FieldValidateHandler<T>(T dataObject, string fieldName, object fieldValue);
    public delegate bool FieldValidateHandler(string fieldName,object fieldValue);

    public class WebForm<T> where T:class
    {
        public event Action<T> Fill;
        public event Action<T> Post;
        public event Action<T> Bound;

        public event Predicate<T> Validate;
        public FieldValidateHandler<T> FieldValidate;

        private bool _wasPosted = false;
        private bool _dataOk = false;
        private bool _bound = false;
        private readonly T _dataObject = null;

        private readonly ValidationErrorList _validationErrors = new ValidationErrorList();

        private FormFieldCollection<T> _fieldList;

        private void GetFields()
        {
            _fieldList = new FormFieldCollection<T>();

            MemberInfo[] classMembers = _dataObject.GetType().GetMembers(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            foreach (MemberInfo memberInfo in classMembers)
            {
                FormFieldAttribute[] fieldAttributes = (FormFieldAttribute[])memberInfo.GetCustomAttributes(typeof(FormFieldAttribute), false);

                if (fieldAttributes.Length != 1)
                    continue;

                FormFieldAttribute fieldAttribute = fieldAttributes[0];

                if (fieldAttribute.Name == null)
                    fieldAttribute.Name = memberInfo.Name;

                fieldAttribute.FieldType = GetFieldType(memberInfo);
                fieldAttribute.FormData = _dataObject;

                if (!fieldAttribute.IsRightType())
                    throw new ProMeshException("Property " + memberInfo.Name + " is not of the correct type");

                _fieldList.Add(memberInfo.Name, new FormField<T>(this,_dataObject, memberInfo, fieldAttribute));
            }
        }

        protected WebForm()
        {
            if (typeof(T).IsAssignableFrom(GetType()))
                _dataObject = (T) (object) this;

            GetFields();
        }

        public WebForm(T dataObject)
        {
            _dataObject = dataObject;

            GetFields();
        }

        public void Bind()
        {
            if (_bound)
                return;

            WebAppContext.CurrentPageController.ViewData["ValidationErrors"] = ValidationErrors;

            foreach (FormField<T> formField in _fieldList)
            {
                WebAppContext.CurrentPageController.Controls[formField.MemberInfo.Name] = formField.Control;

                formField.Control.HandlePostBack();
            }

            if (WebAppContext.CurrentPageController.IsPost())
                HandlePost();
            else
                HandleFill();

            _bound = true;

            if (Bound != null)
                Bound(_dataObject);

            OnBind();
            OnBind(_dataObject);
        }

        private void HandleFill()
        {
            if (Fill != null)
                Fill(_dataObject);

            OnFill();
            OnFill(_dataObject);

            foreach (FormField<T> field in _fieldList)
                field.SetControlFromProperty();
        }

        private void HandlePost()
        {
            _wasPosted = true;
            _dataOk = true;

            // Set fields to correct values

            foreach (FormField<T> field in _fieldList)
            {
                field.SetPropertyFromControl();
            }

            // Validate fields

            foreach (FormField<T> field in _fieldList)
            {
                bool valid = field.ValidateField();

                if (valid)
                {
                    valid = OnValidateField(field.Attribute.Name, field.GetValue());

                    if (valid)
                        valid = OnValidateField(_dataObject, field.Attribute.Name, field.GetValue());
                }

                if (!valid)
                {
                    WebAppContext.CurrentPageController.ViewData[field.Attribute.Name + "_Error"] = true;

                    if (field.Attribute.ValidationErrorMsg != null && field.Attribute.ValidationErrorMsg.Length > 0)
                        ValidationErrors.Add(field.Attribute.ValidationErrorMsg);

                    field.Error = true;

                    _dataOk = false;
                }
                
            }

            // Validate complete form

            if (_dataOk)
                _dataOk = OnValidate();

            if (_dataOk)
                _dataOk = OnValidate(_dataObject);

            if (_dataOk && Validate != null)
                _dataOk = Validate(_dataObject);

            if (_dataOk)
            {
                if (Post != null)
                    Post(_dataObject);

                OnPost();
                OnPost(_dataObject);
            }
        }

        public bool Validated
        {
            get
            {
                if (!_bound)
                    throw new ProMeshException("No Bind() called for " + GetType().Name);

                return _wasPosted && _dataOk;
            }
        }

        public FormFieldCollection<T> Fields
        {
            get
            {
                if (!_bound) 
                    throw new ProMeshException("No Bind() called for " + GetType().Name);

                return _fieldList;
            }
        }

        public ValidationErrorList ValidationErrors
        {
            get { return _validationErrors; }
        }

        protected virtual void OnFill()
        {
        }

        protected virtual void OnFill(T dataObject)
        {
        }

        protected virtual void OnPost()
        {
        }

        protected virtual void OnPost(T dataObject)
        {
        }

        protected virtual void OnBind()
        {
        }

        protected virtual void OnBind(T dataObject)
        {
        }

        protected virtual bool OnValidate()
        {
            return true;
        }

        protected virtual bool OnValidate(T dataObject)
        {
            return true;
        }

        protected virtual bool OnValidateField(string fieldName, object fieldValue)
        {
            return true;
        }

        protected virtual bool OnValidateField(T dataObject, string fieldName, object fieldValue)
        {
            return true;
        }

        private static Type GetFieldType(MemberInfo memberInfo)
        {
            if (memberInfo is FieldInfo)
                return ((FieldInfo)memberInfo).FieldType;

            if (memberInfo is PropertyInfo)
                return ((PropertyInfo)memberInfo).PropertyType;

            return null;
        }

    }
}
