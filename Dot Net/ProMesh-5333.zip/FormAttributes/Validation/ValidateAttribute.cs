using System;
using System.Collections.Generic;

namespace Activa.ProMesh.FormAttributes.Validation
{
    public class ValidateAttribute : ValidationAttribute
    {
        private string _expression;

        public ValidateAttribute(string expression)
        {
            _expression = expression;
        }

        protected internal override bool Validate(object value)
        {
            return true;
        }
    }
}
