using System;
using System.Collections.Generic;

namespace Activa.ProMesh
{
    public class ValidateRangeAttribute : ValidationAttribute
    {
        private object _min;
        private object _max;

        public ValidateRangeAttribute()
        {
        }

        public ValidateRangeAttribute(object min, object max)
        {
            Min = min;
            Max = max;
        }

        public object Min
        {
            get { return _min; }
            set { _min = value; }
        }

        public object Max
        {
            get { return _max; }
            set { _max = value; }
        }

        override protected internal bool Validate(object value)
        {
            return true;
        }
    }
}
