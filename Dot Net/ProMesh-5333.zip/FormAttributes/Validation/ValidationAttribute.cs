using System;

namespace Activa.ProMesh
{
    public abstract class ValidationAttribute : Attribute
    {
        protected internal abstract bool Validate(object value);
    }
}