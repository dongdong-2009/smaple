//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Activa.ProMesh;

namespace Activa.ProMesh
{
	public class FormTextBoxAttribute : FormFieldAttribute
	{
		public int Width = 0;
		public int MinLength = 0;
		public int MaxLength = Int32.MaxValue;
	    public bool Required = false;
	    public string ValidationRegEx = null;
	    public double Min = double.MinValue;
	    public double Max = double.MaxValue;
	    public string FormatString = null;
        public bool AutoComplete = false;

	    protected internal override bool IsRightType()
		{
            Type type = Nullable.GetUnderlyingType(FieldType);

            if (type == null)
                type = FieldType;

            return (
                   type == typeof(string)
                || type == typeof(Int16)
                || type == typeof(Int32)
                || type == typeof(Int64)
                || type == typeof(UInt16)
                || type == typeof(UInt32)
                || type == typeof(UInt64)
                || type == typeof(Double)
                || type == typeof(Single)
                || type == typeof(Decimal)
                );
		}

	    protected internal override bool Validate(Control control)
		{
            string value = ((TextBoxControl)control).Value ?? "";

            if (value.Length == 0)
            {
                if (FieldType == typeof(string) || Nullable.GetUnderlyingType(FieldType) != null)
                    return !Required;
                else 
                    return false;
            }

	        bool valid = (value.Length >= MinLength && value.Length <= MaxLength);

            if (valid && FieldType != typeof(string))
            {
                if (Regex.Match(value, @"^\-?\d+([\.,]\d+)?$").Success)
                {
                    double doubleValue;

                    if (double.TryParse(value.Replace(',','.'), NumberStyles.Any, NumberFormatInfo.InvariantInfo, out doubleValue))
                        valid = (doubleValue >= Min && doubleValue <= Max);
                    else
                        valid = false;
                }
                else
                {
                    
                    valid = false;
                }
            }

	        if (valid && ValidationRegEx != null)
            {
                Regex re = new Regex(ValidationRegEx, RegexOptions.Singleline | RegexOptions.IgnoreCase);

                return re.IsMatch(((TextBoxControl) control).Value);
            }

	        return valid;
		}

	    protected internal override Control CreateControl(string name)
	    {
	        TextBoxControl control = new TextBoxControl(name);

            control.MaxLength = MaxLength;
            control.AutoComplete = AutoComplete;
            control.Size = Width;

            return control;
	    }

	    protected internal override object GetControlValue(Control control)
	    {
            string stringValue = ((TextBoxControl) control).Value;

	        return ProMeshUtil.ConvertString(stringValue.Replace(',','.'), FieldType);
	    }

        protected internal override void SetControlValue(Control control, object value)
        {
            if (FormatString == null)
                ((TextBoxControl) control).Value = (value != null) ? value.ToString() : "";
            else
                ((TextBoxControl) control).Value = (value != null) ? String.Format("{0:" + FormatString + "}",value) : "";
        }
    }
}