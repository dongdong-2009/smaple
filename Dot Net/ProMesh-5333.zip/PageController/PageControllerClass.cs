//=============================================================================
// ProMesh.NET - .NET Web Application Framework 
//
// Copyright (c) 2003-2007 Philippe Leybaert
//
// Permission is hereby granted, free of charge, to any person obtaining a copy 
// of this software and associated documentation files (the "Software"), to deal 
// in the Software without restriction, including without limitation the rights 
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
// copies of the Software, and to permit persons to whom the Software is 
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in 
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;

namespace Activa.ProMesh
{
    internal class PageControllerClass
    {
        private readonly Type _classType;
        private readonly List<MethodInfo> _setupMethods = new List<MethodInfo>();
        private readonly List<MethodInfo> _teardownMethods = new List<MethodInfo>();
        private readonly Dictionary<string, MethodInfo> _publicMethods = new Dictionary<string, MethodInfo>(StringComparer.InvariantCultureIgnoreCase);
        private readonly Dictionary<string, MethodInfo> _ajaxMethods = new Dictionary<string, MethodInfo>();

        public PageControllerClass(Type classType)
        {
            _classType = classType;

            Type currentClassType = _classType;
            Stack<Type> pageTypeStack = new Stack<Type>();

            while (currentClassType != typeof(PageController) && currentClassType != null)
            {
                pageTypeStack.Push(currentClassType);

                currentClassType = currentClassType.BaseType;
            }

            while (pageTypeStack.Count > 0)
            {
                currentClassType = pageTypeStack.Pop();

                MethodInfo[] methods = currentClassType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);

                foreach (MethodInfo methodInfo in methods)
                {
                    if (methodInfo.IsSpecialName)
                        continue;

                    if (methodInfo.IsDefined(typeof (SetupAttribute), true))
                    {
                        _setupMethods.Add(methodInfo);
                    }
                    else if (methodInfo.IsDefined(typeof (TearDownAttribute), true))
                    {
                        _teardownMethods.Add(methodInfo);
                    }
                    else if (methodInfo.IsDefined(typeof(AjaxAttribute), true))
                    {
                        AjaxMethods[methodInfo.Name] = methodInfo;
                    }
                    else
                    {
                        if (_publicMethods.ContainsKey(methodInfo.Name))
                        {
                            if (_publicMethods[methodInfo.Name].IsPrivate && methodInfo.IsPublic)
                                _publicMethods[methodInfo.Name] = methodInfo;
                            else
                                throw new Exception("More than one method " + methodInfo.Name + "() was found with the same visibility");
                        }
                        else
                        {
                            _publicMethods.Add(methodInfo.Name, methodInfo);
                        }
                    }
                }
            }
        }

        internal Dictionary<string, MethodInfo> AjaxMethods
        {
            get { return _ajaxMethods; }
        }

        public PageController CreatePageControllerObject()
        {
            return (PageController) Activator.CreateInstance(_classType);
        }

        public bool Run(PageController pageObject , string methodName)
        {
            foreach (MethodInfo methodInfo in _ajaxMethods.Values)
                WebAppContext.AjaxMethods[methodInfo.Name] = methodInfo;

            if (WebAppContext.AjaxMethods.ContainsKey(methodName))
            {
                MethodInfo method = WebAppContext.AjaxMethods[methodName];

                if (method.IsStatic)
                    pageObject = null;

                WebAppContext.Response.ContentType = "application/json";
                WebAppContext.Response.Write(WebAppHelper.RunAjaxMethod(method, pageObject));

                return false;
            }

            try
            {
                foreach (MethodInfo method in _setupMethods)
                    method.Invoke(pageObject, WebAppHelper.CreateParameters(method));

                if (_publicMethods.ContainsKey(methodName))
                {
                    MethodInfo method = _publicMethods[methodName];

                    method.Invoke(pageObject, WebAppHelper.CreateParameters(method));
                }

                foreach (MethodInfo method in _teardownMethods)
                    method.Invoke(pageObject, WebAppHelper.CreateParameters(method));
            }
            catch (TargetInvocationException ex)
            {
                FieldInfo remoteStackTrace = typeof(Exception).GetField("_remoteStackTraceString", BindingFlags.Instance | BindingFlags.NonPublic);

                remoteStackTrace.SetValue(ex.InnerException,ex.InnerException.StackTrace + "\r\n");

                throw ex.InnerException;
            }

            return true;
        }
    }
}
