using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace TextFileCombiner
{
	/// <summary>
	/// Main form of application.
	/// </summary>
	public class frmCombine : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtContent;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.MainMenu mnuMain;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuSaveAs;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.MenuItem mnuEdit;
		private System.Windows.Forms.MenuItem mnuCopyAll;
		private System.Windows.Forms.MenuItem mnuHelp;
		private System.Windows.Forms.MenuItem mnuAbout;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmCombine()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtContent = new System.Windows.Forms.TextBox();
			this.mnuMain = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuSaveAs = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.mnuEdit = new System.Windows.Forms.MenuItem();
			this.mnuCopyAll = new System.Windows.Forms.MenuItem();
			this.mnuHelp = new System.Windows.Forms.MenuItem();
			this.mnuAbout = new System.Windows.Forms.MenuItem();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.SuspendLayout();
			// 
			// txtContent
			// 
			this.txtContent.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtContent.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtContent.Location = new System.Drawing.Point(0, 0);
			this.txtContent.MaxLength = 0;
			this.txtContent.Multiline = true;
			this.txtContent.Name = "txtContent";
			this.txtContent.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtContent.Size = new System.Drawing.Size(728, 681);
			this.txtContent.TabIndex = 0;
			this.txtContent.Text = "";
			this.txtContent.WordWrap = false;
			// 
			// mnuMain
			// 
			this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuFile,
																					this.mnuEdit,
																					this.mnuHelp});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuSaveAs,
																					this.menuItem3,
																					this.mnuExit});
			this.mnuFile.Text = "&File";
			// 
			// mnuSaveAs
			// 
			this.mnuSaveAs.Index = 0;
			this.mnuSaveAs.Text = "Save &As...";
			this.mnuSaveAs.Click += new System.EventHandler(this.mnuSaveAs_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "-";
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 2;
			this.mnuExit.Text = "E&xit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// mnuEdit
			// 
			this.mnuEdit.Index = 1;
			this.mnuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuCopyAll});
			this.mnuEdit.Text = "&Edit";
			// 
			// mnuCopyAll
			// 
			this.mnuCopyAll.Index = 0;
			this.mnuCopyAll.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
			this.mnuCopyAll.Text = "C&opy All Text To Clipboard";
			this.mnuCopyAll.Click += new System.EventHandler(this.mnuCopyAll_Click);
			// 
			// mnuHelp
			// 
			this.mnuHelp.Index = 2;
			this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuAbout});
			this.mnuHelp.Text = "&Help";
			// 
			// mnuAbout
			// 
			this.mnuAbout.Index = 0;
			this.mnuAbout.Text = "&About";
			this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.DefaultExt = "*.txt";
			this.saveFileDialog1.FileName = "Combined.txt";
			this.saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files(*.*)|*.*";
			// 
			// frmCombine
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 681);
			this.Controls.Add(this.txtContent);
			this.Menu = this.mnuMain;
			this.Name = "frmCombine";
			this.Text = "Text File Combiner";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] sArgs) 
		{
			//create shortcut in Send To folder for 'Text File Combiner' application if it does not exist
			if (!(System.IO.File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.SendTo), "Text File Combiner.lnk"))))
			{
				CreateSendToShortcut();
			}

			// if no filenames are passed - show message
			if (sArgs.Length == 0) 
				MessageBox.Show("No files to combine.\n\n1. Select file(s) to combine in Windows Explorer \n2. Use 'Text File Combiner' option in Send To menu.","Text File Combiner", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			else
			{
				int i = 0;
				StringBuilder sb = new StringBuilder();
				String strFile = "";
				string strErrorFiles = ""; 

				while (i < sArgs.Length)
				{
					TextReader tr = new StreamReader(sArgs[i]);
					strFile = tr.ReadToEnd();
					if (VerifyAscii(strFile)) // file is a text file
					{
						sb.Append(strFile);
						sb.Append("\r\n");
					}
					else // file is not a text file
					{
						strErrorFiles += sArgs[i] + "\r\n";
					}
					i = i + 1;
					tr.Close();
				}
				frmCombine f = new  frmCombine();
				f.txtContent.Text = sb.ToString();
				f.txtContent.Select(0,0);
				if (strErrorFiles != "" )
					MessageBox.Show("Following files could not be loaded:\r\n" + strErrorFiles, "Text File Combiner", MessageBoxButtons.OK, MessageBoxIcon.Warning);

				Application.Run(f);
			}
		}

		//create shortcut in Send To folder 
		private static void CreateSendToShortcut()
		{
			try
			{
				string tmpFileName = Environment.GetEnvironmentVariable("TEMP")+ "\\" + Guid.NewGuid().ToString()+ ".vbs";
				StreamWriter sw = new StreamWriter(tmpFileName);
				sw.WriteLine("set WshShell = CreateObject(\"Wscript.shell\")");
				sw.WriteLine("strSendTo = WshShell.SpecialFolders(\"SendTo\")");
				sw.WriteLine("set oMyShortcut = WshShell.CreateShortcut(strSendTo + \"\\Text File Combiner.lnk\")");	
				sw.WriteLine("oMyShortcut.TargetPath = \"" + Application.ExecutablePath + "\"");
				sw.WriteLine("oMyShortCut.Save");
				sw.Flush();
				sw.Close();
			
				Process p = new Process();
				ProcessStartInfo psi = new ProcessStartInfo(tmpFileName);
				p.StartInfo=psi;
				p.Start();
				p.WaitForExit(); //wait for script to exit
				File.Delete(tmpFileName);
			}
			catch
			{
			}
		}

		//verify file is an ascii text file
		private static bool VerifyAscii(string str)
		{
			string Buffer = str.Length > 2000 ? str.Substring(0,2000) : str; //check first 2000 chars only
																			 //change to complete str if you want to check whole file 

			int BlockSize = 10;
			int Start, Len;
			string Block;
			
			System.Text.RegularExpressions.MatchCollection matchColl;
			System.Text.RegularExpressions.Regex R = new System.Text.RegularExpressions.Regex("[\x01-\x80]");

			for (int i=0;i<(Buffer.Length/BlockSize);i++)
			{
				Start = (i*5);
				Len = (Start+BlockSize>Buffer.Length) ? (Buffer.Length-Start) : BlockSize;
				Block  = Buffer.Substring(Start,Len);
				matchColl = R.Matches(Block);
				if (matchColl.Count<Len)
				{
					return false;
				}
			}
			return true;
		}

		//close the application
		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void mnuAbout_Click(object sender, System.EventArgs e)
		{
			string strMessage = "Text File Combiner v1.0\n\nCopyright � 2007 N. Waheed";
				 MessageBox.Show(strMessage, "About Text File Combiner", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		//save content of TextBox to a file
		private void mnuSaveAs_Click(object sender, System.EventArgs e)
		{
			DialogResult dlgR = saveFileDialog1.ShowDialog();
			if (dlgR != DialogResult.Cancel)
			{
				StreamWriter fSave= new StreamWriter(saveFileDialog1.FileName);
				fSave.WriteLine(txtContent.Text);
				fSave.Flush();				
				fSave.Close(); 
			}
		}

		//copy all text to clipboard
		private void mnuCopyAll_Click(object sender, System.EventArgs e)
		{
			Clipboard.SetDataObject (txtContent.Text, true);
		}
	}
}
