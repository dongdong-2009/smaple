using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.HtmlControls;


namespace FlashWebPart
{
    [Guid("f04fa49d-1342-4c7d-904a-c43ebc942f39")]
    [XmlRoot(Namespace = "FlashWebPart")]
    public class FlashWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        public FlashWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }


        protected int flashWidth = 400;
        protected int flashHeight = 300;
        protected string flashUrl = "";
        
        
        [Browsable(true), 
        Category("Flash Info"),
        DefaultValue(400),
        WebPartStorage(Storage.Shared),
        FriendlyName("Width"), 
        Description("Width of the web part")]
        public int FlashWidth
        {
            get
            {
                return this.flashWidth;
            }
            set
            {
                this.flashWidth = value;
            }
        }

        [Browsable(true),
        Category("Flash Info"),
        DefaultValue(300),
        WebPartStorage(Storage.Shared),
        FriendlyName("Height"), 
        Description("Height of the web part")]
        public int FlashHeight
        {
            get
            {
                return this.flashHeight;
            }
            set
            {
                this.flashHeight = value;
            }
        }

        [Browsable(true),
        Category("Flash Info"),
        DefaultValue(""),
        WebPartStorage(Storage.Shared),
        FriendlyName("URL"), 
        Description("URL of the web part")]
        public string FlashURL
        {
            get
            {
                return this.flashUrl;
            }
            set
            {
                this.flashUrl = value;
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            string outHTML = "<OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" " +
                        "codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0\" " +
                        "WIDTH=" + flashWidth + " HEIGHT=" + flashHeight + "> " +
                        "<PARAM NAME=movie VALUE=\"" + flashUrl + "\"> " +
                        "<PARAM NAME=WMODE VALUE=\"Transparent\">" +
                        "<PARAM NAME=quality VALUE=high> " +
                        "<EMBED src=\"" + flashUrl + 
                        "\" quality=high wmode=\"transparent\" WIDTH=\"" + flashWidth + 
                        "\" HEIGHT=\"" + flashHeight + 
                        "\" TYPE=\"application/x-shockwave-flash\" PLUGINSPAGE=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\"></EMBED> " +
                        "</OBJECT>";

            writer.Write(outHTML);
        }
    }
}
