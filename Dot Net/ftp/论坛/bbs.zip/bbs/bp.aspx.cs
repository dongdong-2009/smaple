using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for bp.
	/// </summary>
	public class bp : System.Web.UI.Page
	{
		protected DataSet ds;
		protected System.Web.UI.WebControls.TextBox touser;
		protected System.Web.UI.WebControls.TextBox title;
		protected System.Web.UI.WebControls.TextBox nr;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.DataGrid inboxnr;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.DataGrid outboxnr;
		protected System.Web.UI.HtmlControls.HtmlGenericControl newbp;
		protected System.Web.UI.HtmlControls.HtmlGenericControl sendsuccess;
		protected System.Web.UI.HtmlControls.HtmlGenericControl inbox;
		protected System.Web.UI.HtmlControls.HtmlGenericControl outbox;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlGenericControl sendtime;
		protected System.Web.UI.HtmlControls.HtmlGenericControl sendnr;
		protected int lys1;
		protected config con=new config();
		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			lys1=inboxnr.Items.Count;
			con.link.Close();
		}

		protected void delone(string delno)
		{
			OleDbCommand command;
	
			string sql="delete from bpmessage where [no]="+delno;
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
		}

		protected void del()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
				}
			}
		}

		protected void Page_Load(Object sender, EventArgs e)
		{
			int bz=0,errorno=0;
			string sql;
			OleDbCommand command;
			OleDbDataReader read;
			OleDbDataAdapter datasel;
			sendsuccess.Visible=false;
			if(Session["user_id"]==null || Session["user_id"]=="")
			{
				newbp.InnerHtml="�Բ���,����û�е�¼";
				bz=1;
				newbp.Visible=true;
				inbox.Visible=false;
				outbox.Visible=false;
				list.Visible=false;
			}
			string type=Request.QueryString["type"];
			con.open();
			if(Request.Form["options"]=="del" && bz!=1)
			{
				del();
			}
			if(type=="new" && bz!=1)
			{
				inbox.Visible=false;
				outbox.Visible=false;
				newbp.Visible=true;
				list.Visible=false;
				if(!Page.IsPostBack)
				{
					touser.Text=Request.QueryString["user_id"];
				}
				bz=1;
			}
			if(type=="inbox" && bz!=1)
			{
				newbp.Visible=false;
				inbox.Visible=true;
				outbox.Visible=false;
				list.Visible=false;
				bz=1;
				sql="select [no],whosend,title,date_time,innew from bpmessage where user_id="+con.rep(Session["user_id"].ToString())+" order by [no] desc";
				command=new OleDbCommand(sql,con.link);
				datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
				inboxnr.DataSource=ds.Tables["type"].DefaultView;
				inboxnr.DataBind();
				lys1=inboxnr.Items.Count;
			}
			if(type=="outbox" && bz!=1)
			{
				newbp.Visible=false;
				inbox.Visible=false;
				outbox.Visible=true;
				list.Visible=false;
				bz=1;
				sql="select [no],user_id,title,date_time,outnew from bpmessage where whosend="+con.rep(Session["user_id"].ToString())+" order by [no] desc";
				command=new OleDbCommand(sql,con.link);
				datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
				outboxnr.DataSource=ds.Tables["type"].DefaultView;
				outboxnr.DataBind();
				lys1=outboxnr.Items.Count;
			}
			if(type=="list" && bz!=1)
			{
				bz=1;
				newbp.Visible=false;
				inbox.Visible=false;
				outbox.Visible=false;
				list.Visible=true;
				sql="select * from bpmessage where [no]="+Request.QueryString["no"];
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					if(Request.QueryString["open"]=="inbox")
						sendtime.InnerHtml="��"+read.GetValue(5).ToString()+","+read.GetValue(4).ToString()+"���㷢������Ϣ";
					else
						sendtime.InnerHtml="��"+read.GetValue(5).ToString()+",�㷢��"+read.GetValue(4).ToString()+"����Ϣ";
					sendnr.InnerHtml="��Ϣ����:"+read.GetValue(2).ToString()+"<br>"+con.texttohtml(read.GetValue(3).ToString());
					read.Close();
					if(Request.QueryString["open"]=="inbox")
					{
						sql="update bpmessage set innew='�Ѷ�',outnew='�ѽ���' where [no]="+Request.QueryString["no"];
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
				}
				else
				{
					read.Close();
					list.InnerHtml="���ݿ����";
				}
			}
			con.link.Close();
			if(bz==0)
				newbp.InnerHtml="�Ƿ�����";
		}
		protected void delall(Object sender, EventArgs e)
		{
			con.open();
			OleDbCommand command;
			string sql="delete from bpmessage where user_id="+con.rep(Session["user_id"].ToString());
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			con.link.Close();
			Response.Redirect("bp.aspx?type=inbox");
		}

		protected void send(Object sender, EventArgs e)
		{
			string user_id;
			int errorno=0,no;
			user_id=touser.Text;
			con.open();
			OleDbCommand command;
			OleDbDataReader read;

			string sql="select user_id from "+con.usertable+" where user_id="+con.rep(user_id);
			//	Response.Write(sql);
			//	Response.End();
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(!read.Read())
			{
				errorno=1;
				newbp.InnerHtml="�޴��û�";
			}
			read.Close();
			if(title.Text=="")
			{
				errorno=1;
				newbp.InnerHtml="�����������д";
			}
			if(errorno==0)
			{
				sql="insert into bpmessage(user_id,title,message,whosend,date_time,innew,outnew) values("+con.rep(touser.Text)+","+con.rep(con.texttohtml(title.Text))+","+con.rep(con.texttohtml(nr.Text))+","+con.rep(Session["user_id"].ToString())+",'"+DateTime.Now+"','δ��','δ����')";
				//		Response.Write(sql);
				//		Response.End();
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sendsuccess.Visible=true;
				newbp.Visible=false;
			}
		}
		public bp()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
