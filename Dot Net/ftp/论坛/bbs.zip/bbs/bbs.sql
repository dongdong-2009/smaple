create table bbsbig(no int IDENTITY (1, 1) NOT NULL,name varchar(80),owner varchar(50),orderno int)
create table bbslitter(no int IDENTITY (1, 1) NOT NULL,bigno int,name varchar(80),owner1 varchar(50),owner2 varchar(50),owner3 varchar(50),mbid int,zhutino int,hfno int,wcno int,zerono int,orderno int,sm varchar(255),par int)
create table message(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),hf int,zhuti varchar(255),nr text,bigno int,litterno int,date_time datetime,bq varchar(500),hits int,ip varchar(30),ise_mail int,isliuyan int,zt int,fs int,allnr text,filename varchar(30),newtime datetime,isjhq int,autoaddimage int,uploadimage varchar(1500),qx int,newuser varchar(50),toporder int,topimage varchar(255),editmessage varchar(100),lock int,mbid int,articletype varchar(10),gftype int)
create table hf_message(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),messageno int,nr text,bigno int,litterno int,date_time datetime,bq varchar(500),ip varchar(30),ise_mail int,isliuyan int,fs int,editmessage varchar(100))
create table bbsset(no int IDENTITY (1, 1) NOT NULL,lys int,logo varchar(255),logolj varchar(255),gonggao varchar(255),gonggaolj varchar(255),refresh int,bigno int,litterno int,html int,ubb int,script int,flash int,img int,zt int,ft int,hf int,whouploadimage int,zjfuploadimage int,uploadimage int,headcolor varchar(10),color1 varchar(10),color2 varchar(10),headforecolor varchar(10),itemforecolor varchar(100),articlepage int,articletype varchar(10),zjftype int,zjfvalue int)
create table online(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),user_name varchar(50),ip varchar(30),date_time datetime,isbp int,litterno varchar(100))
create table bpmessage(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),title varchar(255),message text,whosend varchar(50),date_time datetime,innew varchar(10),outnew varchar(10))
create table bbssq(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),why varchar(255),loves varchar(255),howday int,new int,bt varchar(255),date_time datetime,bigno int,litterno int,http varchar(255),sm varchar(50))
create table fs(no int IDENTITY (1, 1) NOT NULL,litterno int,month char(7),cyf int,zjf int,user_id varchar(50),bigno int)
create table bbsmb(no int IDENTITY (1, 1) NOT NULL,nr text,name varchar(50),mbtype varchar(50))
create table myjoin(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),messageno int)
create table mygz(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),messageno int)
create table mydf(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),messageno int)
create table bbsadmin(user_id varchar(50),oskey varchar(50))
create table ggmessage(no int IDENTITY (1, 1) NOT NULL,user_id varchar(50),html int,zhuti varchar(255),nr text,bigno int,litterno int,date_time datetime,hits int,autoaddimage int,uploadimage varchar(1500))
create table bbssystemset(usertable varchar(50),userdatabase varchar(50),bbsname varchar(50),kyf int,zjkyf int,ftdf int,hfdf int,lldf int,bq1 varchar(255),bq2 varchar(255),delfs int,delcyf int,delhffs int,delhfcyf int,jhfs int,jhcyf int,tgfs int,tgcyf int,changefs int,jshead varchar(255),bbspath varchar(255))
create table jbmanage(no int IDENTITY (1, 1) NOT NULL,name varchar(50),jf int,icon varchar(2000))
select * from jbmanage
insert bbsadmin values('admin','super')
select * from bbsadmin
select * from net_user order by 
drop table hf_message
drop table bbsset
select * from bbsset
drop table bbsbig
drop table bbslitter
drop table message
drop table hf_message
drop table bbsset
drop table online
drop table bpmessage
drop table bbssq
drop table userfs
drop table fs
drop table bbsmb
drop table bbsadmin
drop table myjoin
drop table mygz
drop table mydf

select * from bbsset
select * from fs
insert message values('admin',0,'22','22',1,1,getdate(),'��',0,'130.1.7.100',0,0,1,20,'22','1/1.shtml',getdate(),0,1,' ')
select * from message

select * from net_user
select * from bbsexample
select * from ggmessage

insert ggmessage values('admin',0,'t','ttttttt',1,0,getdate(),0,1,null)
select top 10 * from message order by no desc

drop table net_user

select * from bbsset where litterno<>2
select * from bbslitter
select * from message
update message set articletype='shtml' where articletype is null
select * from message
sp_help

select * from net_user
select * from bbsmb
select * from message

update net_user set password='a' where user_id='a'
select * from net_user

select * from message
select * from bbslitter
select * from mydf
select * from fs
drop table fs

create table test(i int,j int)
insert into test(i) values(1)
select * from bbssystemset
drop table bbssystemset
select * from jbmanage
select * from bbslitter
