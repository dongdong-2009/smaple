using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for list.
	/// </summary>
	public class list : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl listnr;
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			con.databasepath="../"+con.databasepath;
			con.open();
			string no;
			int litterno;
			no=Request.QueryString["no"];
			if(no==null||no=="")
			{
				listnr.InnerHtml="����ѡ��һ������";
				return;
			}
			con.getbbsset("0",no);
			if(con.ztset==2)
			{
				if(Session["hy"]==null)
				{
					listnr.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
					return;
				}
			}
			if(con.ztset==3)
			{
				if(Session["hy"]==null||((int)Session["hy"]!=3&&(int)Session["hy"]!=4&&(int)Session["hy"]!=5))
				{
					listnr.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
					return;
				}
			}
			if(con.ztset==4)
			{
				if(Session["hy"]==null||((int)Session["hy"]!=4&&(int)Session["hy"]!=5))
				{
					listnr.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
					return;
				}
			}
			if(con.ztset==5)
			{
				if(Session["hy"]==null||(int)Session["hy"]!=5)
				{
					listnr.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
					return;
				}
			}
			string sql;
			OleDbCommand command;
			OleDbDataReader read;
			sql="select litterno from message where [no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				litterno=(int)read.GetValue(0);
				read.Close();
//				Response.Write(no);
//				Response.Write(litterno+"");
				listnr.InnerHtml=con.getpage(no,litterno,0);
			}
			else
			{
				read.Close();
				listnr.InnerHtml="�Բ������뿴�����Ӳ�����";
			}
			con.link.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
