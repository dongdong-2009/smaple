using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for listgg.
	/// </summary>
	public class listgg : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label zhuti;
		protected System.Web.UI.HtmlControls.HtmlGenericControl ggnr;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected System.Web.UI.HtmlControls.HtmlGenericControl where;
		protected System.Web.UI.WebControls.Label gguserid;
		protected System.Web.UI.WebControls.Label bbsname;
		config con=new config();
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string sql,litterno,littername="";
			OleDbCommand command;
			OleDbDataReader read;
			litterno=Request.QueryString["litterno"];
			if(litterno==null||litterno=="")
			{
				listall.InnerHtml="����ѡ��һ����Ŀ";
				return;
			}
			con.open();
			sql="select name from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				littername=read.GetValue(0).ToString();
			}
			read.Close();
			sql="select * from ggmessage where litterno="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				gguserid.Text=read["user_id"].ToString();
				if((int)read["html"]==1)
				{
					zhuti.Text=read["zhuti"].ToString();
					ggnr.InnerHtml=read["nr"].ToString();
				}
				else
				{
					zhuti.Text=con.changechr(read["zhuti"].ToString());
					ggnr.InnerHtml=con.changechr(read["nr"].ToString());
				}
//				addfj(read["autoaddimage"].ToString(),read["uploadimage"].ToString());
				if(read["uploadimage"].ToString()!=""&&read["autoaddimage"].ToString()=="1")
					ggnr.InnerHtml+=con.addimagenr(read["uploadimage"].ToString(),0);
			}
			read.Close();
			con.getbbsset("0","0");
			bbsname.Text=con.bbsname;
			con.link.Close();
			if(litterno=="0")
			{
				where.InnerHtml="	&nbsp; &nbsp; <img src='images/system/bar.gif'><img src='images/system/openfold.gif'>&nbsp;������";
			}
			else
			{
				where.InnerHtml="&nbsp; <img src='images/system/bar.gif'><img src='images/system/closedfold.gif'>&nbsp;<a href=\"main.aspx?litterno="+litterno+"\">"+littername+"</a><br>";
				where.InnerHtml+="	&nbsp; &nbsp; <img src='images/system/bar.gif'><img src='images/system/openfold.gif'>&nbsp;������";
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
