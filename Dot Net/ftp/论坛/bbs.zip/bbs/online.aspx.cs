using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for online.
	/// </summary>
	public class online : System.Web.UI.Page
	{
		protected DataSet ds;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e)
		{
			con.open();
			string sql="select * from online";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
			con.link.Close();
		}

		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			con.link.Close();
		}
		public online()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
