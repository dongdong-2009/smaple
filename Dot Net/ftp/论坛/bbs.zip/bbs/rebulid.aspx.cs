using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;
using System.Data.SqlClient;

namespace bbs
{
	/// <summary>
	/// Summary description for rebulid.
	/// </summary>
	public class rebulid : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl success;
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string act=Request.QueryString["act"];
			string articletype;
			if(act=="page")
			{
				if(!con.checksuper())
				{
					success.InnerHtml="�Բ�����û��Ȩ��";
					return;
				}
				con.open();
				con.open1();
				string sql,filename,no,filenr;
				int litterno;
				OleDbCommand command;
				OleDbDataReader read;
				sql="select [no],filename,litterno,articletype from message where articletype<>'aspx' order by newtime desc";
				command=new OleDbCommand(sql,con.link1);
				read=command.ExecuteReader();
				while(read.Read())
				{
					articletype=read["articletype"].ToString();
					filename=read.GetValue(1).ToString();
					no=read.GetValue(0).ToString();
					if(articletype=="html"||articletype=="shtml")
					{
						litterno=(int)read.GetValue(2);
						filenr=con.getpage(no,litterno,0);
						filename=Server.MapPath(filename);
						FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
						StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
						wf.Write(filenr);
						wf.Close();
					}
					if(articletype=="xml")
					{
						con.writexml(Int32.Parse(no));
					}

				}
				read.Close();
				con.link1.Close();
				con.link.Close();
				success.InnerHtml="��������ҳ��ɹ�";
			}
			if(act=="lm")
			{
				if(!con.checksuper())
					return;
				con.open();
				con.getlittervalue();
				con.link.Close();
				success.InnerHtml="����������Ŀ��Ϣ�ɹ�";
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
