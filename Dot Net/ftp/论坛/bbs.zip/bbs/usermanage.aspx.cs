using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for usermanage.
	/// </summary>
	/// 
	public class usermanage : System.Web.UI.Page
	{
		public usermanage()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}
		public DataSet ds;
		public int lys1;
		public config con=new config();
		protected System.Web.UI.WebControls.DataGrid lm;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.WebControls.Label usernum;
		protected System.Web.UI.WebControls.TextBox searchuser;
		protected System.Web.UI.WebControls.DropDownList searchtype;
		protected System.Web.UI.WebControls.DropDownList ordertype;
	

		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			string sql="";
			if(searchtype.SelectedItem.Value=="alluser")
			{
				if(searchuser.Text!="")
				{
					sql="select * from "+con.usertable+" where user_id="+con.rep(searchuser.Text);
				}
				else
				{
					sql="select * from "+con.usertable+"";
				}
			}
			else
			{
				if(searchtype.SelectedItem.Value=="lockuser")
					sql="select * from "+con.usertable+" where canlogin=0";
				if(searchtype.SelectedItem.Value=="super")
					sql="select "+con.usertable+".user_id,"+con.usertable+".user_name,password,ishy,usertype,cyf,zjf,fs,fts,hfs,jhfs,canlogin,del,delhf from bbsadmin,"+con.usertable+" where bbsadmin.user_id="+con.usertable+".user_id and oskey='super'";
				if(searchtype.SelectedItem.Value=="check")
					sql="select "+con.usertable+".user_id,"+con.usertable+".user_name,password,ishy,usertype,cyf,zjf,fs,fts,hfs,jhfs,canlogin,del,delhf from bbsadmin,"+con.usertable+" where bbsadmin.user_id="+con.usertable+".user_id and oskey='check'";
			}
			sql=sql+" order by "+ordertype.SelectedItem.Value;
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");

			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			lys1=((DataGrid)sender).Items.Count;
		}
		protected string returnstr(object cc)
		{
			if(cc.ToString()=="1")
				return "��";
			else
				return "��";
		}
		protected string returnstr1(object cc)
		{
			if(cc.ToString()=="0")
				return "��";
			else
				return "��";
		}

		protected void updateone(string delno,int updatetype)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql,path,filename;

			if(updatetype==11)
			{
				sql="update "+con.usertable+" set canlogin=0 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==12)
			{
				sql="update "+con.usertable+" set canlogin=1 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==13)
			{
				sql="update "+con.usertable+" set ishy=1 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==14)
			{
				sql="update "+con.usertable+" set ishy=0 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==15)
			{
				sql="select * from bbsadmin where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					read.Close();
					sql="update bbsadmin set oskey='super' where user_id="+con.rep(delno);
				}
				else
				{
					read.Close();
					sql="insert into bbsadmin(user_id,oskey) values("+con.rep(delno)+",'super')";
				}
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==16)
			{
				sql="delete from bbsadmin where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==17)
			{
				sql="update "+con.usertable+" set usertype=1 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==18)
			{
				sql="update "+con.usertable+" set usertype=0 where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==19)
			{
				sql="select * from bbsadmin where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					read.Close();
					sql="update bbsadmin set oskey='check' where user_id="+con.rep(delno);
				}
				else
				{
					read.Close();
					sql="insert into bbsadmin(user_id,oskey) values("+con.rep(delno)+",'check'";
				}
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==20)
			{
				sql="delete from bbsadmin where user_id="+con.rep(delno);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
		}
		protected void shenghe(int updatetype)
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					updateone(delno,updatetype);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					updateone(delno,updatetype);
				}
			}
		}

		protected void delone(string delno)
		{
			string sql;
			OleDbCommand command;
			sql="delete from "+con.usertable+" where user_id="+con.rep(delno);
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			sql="update "+con.userdatabase+"sysconfig set type=type-1 where valuename='usernum'";
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
		}

		protected void del()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
				}
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{ 
			if(!con.checksuper())
				Response.Redirect("login.aspx");
			con.open();
			string sql,option;
			option=Request.Form["options"];
			if(option=="sdzh")
			{
				shenghe(11);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="qxsd")
			{
				shenghe(12);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="hy")
			{
				shenghe(13);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="qxhy")
			{
				shenghe(14);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="super")
			{
//				con.open1();
				shenghe(15);
//				con.link1.Close();
				Response.Redirect("usermanage.aspx");
			}
			if(option=="qxsuper")
			{
				shenghe(16);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="cy")
			{
				shenghe(17);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="qxcy")
			{
				shenghe(18);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="check")
			{
//				con.open1();
				shenghe(19);
//				con.link1.Close();
				Response.Redirect("usermanage.aspx");
			}
			if(option=="qxcheck")
			{
				shenghe(20);
				Response.Redirect("usermanage.aspx");
			}
			if(option=="del")
			{
				del();
				Response.Redirect("usermanage.aspx");
			}
			if(!Page.IsPostBack)
			{
				con.open();
				sql="select * from "+con.usertable+" order by user_id";
				OleDbCommand command=new OleDbCommand(sql,con.link);
				OleDbDataAdapter datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
		
				lmnr.DataSource=ds.Tables["type"].DefaultView;
				lmnr.DataBind();
				lys1=lmnr.Items.Count;
				usernum.Text="�û�������"+ds.Tables[0].Rows.Count.ToString();
			}
		}
		protected void search(object sender, EventArgs e)
		{ 
			string sql="";
			if(searchtype.SelectedItem.Value=="alluser")
			{
				if(searchuser.Text!="")
				{
					sql="select * from "+con.usertable+" where user_id="+con.rep(searchuser.Text);
				}
				else
				{
					sql="select * from "+con.usertable+"";
				}
			}
			else
			{
				if(searchtype.SelectedItem.Value=="hyuser")
					sql="select * from "+con.usertable+" where ishy=1";
				if(searchtype.SelectedItem.Value=="memuser")
					sql="select * from "+con.usertable+" where usertype=1";
				if(searchtype.SelectedItem.Value=="lockuser")
					sql="select * from "+con.usertable+" where canlogin=0";
				if(searchtype.SelectedItem.Value=="super")
					sql="select "+con.usertable+".user_id,"+con.usertable+".user_name,password,ishy,usertype,cyf,zjf,fs,fts,hfs,jhfs,canlogin,del,delhf from bbsadmin,"+con.usertable+" where bbsadmin.user_id="+con.usertable+".user_id and oskey='super'";
				if(searchtype.SelectedItem.Value=="check")
					sql="select "+con.usertable+".user_id,"+con.usertable+".user_name,password,ishy,usertype,cyf,zjf,fs,fts,hfs,jhfs,canlogin,del,delhf from bbsadmin,"+con.usertable+" where bbsadmin.user_id="+con.usertable+".user_id and oskey='check'";
			}
			con.open();
//			Response.Write(sql);
//			Response.End();
			sql=sql+" order by "+ordertype.SelectedItem.Value;
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");

			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
			lys1=lmnr.Items.Count;
			con.link.Close();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
