using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Drawing;

namespace bbs
{
	/// <summary>
	/// Summary description for main.
	/// </summary>
	public class main : System.Web.UI.Page
	{
		public DataSet ds;
		public string litterno,head;
		protected System.Web.UI.WebControls.Label typediv;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.WebControls.DataGrid bbstype;
		protected System.Web.UI.WebControls.TextBox searchstr;
		protected System.Web.UI.WebControls.DropDownList searchtype;
		protected System.Web.UI.WebControls.DropDownList typelist;
		protected System.Web.UI.WebControls.CheckBox searchto;
		protected System.Web.UI.WebControls.Label searchto1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl openscript;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listpagecount;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listjhq;
		protected System.Web.UI.HtmlControls.HtmlGenericControl owner;
		protected System.Web.UI.HtmlControls.HtmlGenericControl lj;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden sqlstr;
		protected System.Web.UI.HtmlControls.HtmlInputHidden sqlstr1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden issearch;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected config con=new config();
		protected string color1;
		protected System.Web.UI.WebControls.Label listuserid;
		protected System.Web.UI.WebControls.Label ggdiv;
		protected System.Web.UI.WebControls.Label littername;
		int zt;
		protected System.Web.UI.WebControls.Label listhead;
		protected System.Web.UI.WebControls.Label bbsname;
	
		protected string getimage(string imagestr)
		{
			return imagestr;
			
		}

		protected void checkmessage(string user_id)
		{
			bool newmessage=con.isnewmessage(user_id);
			if(newmessage)
			{
				openscript.InnerHtml="<script language=javascript><!--\nopenScript('bp.aspx?type=inbox',420,320);\n--><"+"/script>";
			}
		}

		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			string sql;
			sql=ViewState["sql"].ToString();
			string ordersql=ViewState["ordersql"].ToString();
			bind(sql,ordersql);
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			int zjl,pagenum;
			zjl=ds.Tables[0].Rows.Count;
			if(zjl/lmnr.PageSize*lmnr.PageSize<zjl)
				pagenum=zjl/lmnr.PageSize+1;
			else
				pagenum=zjl/lmnr.PageSize;
			listpagecount.InnerHtml="["+(lmnr.CurrentPageIndex+1)+"ҳ/"+pagenum+"ҳ/"+zjl+"����]";
			listpagecount.InnerHtml+=listjhq.InnerHtml;
			con.link.Close();
		}
			
		protected void Page_Load(object sender, EventArgs e)
		{ 
/*			TimeSpan tt=new TimeSpan(0,0,0,20,0);
			
			string sql5="delete from online where date_time<'"+(DateTime.Now-tt).ToString()+"'";
						Response.Write(sql5);
						Response.End();
*/
			string sql,sql1;
			OleDbCommand command;
			OleDbDataReader read;
			con.open();
			if(Session["hy"]==null)
				zt=1;
			else
				zt=(int)Session["hy"];
			litterno=Request.QueryString["litterno"];
			if(!Page.IsPostBack)
			{
				searchto.Visible=false;
				searchto1.Visible=false;
				sql1="select [no],name from bbslitter where par<>0 order by par";
				command=new OleDbCommand(sql1,con.link);
				read=command.ExecuteReader();
				typelist.Items.Add("�����");
				while(read.Read())
				{
					typelist.Items.Add(new ListItem(read.GetValue(1).ToString().Trim(),read.GetValue(0).ToString()));
				}
				read.Close();
				for(int i = 0; i < typelist.Items.Count; i++) 
				{
					if (typelist.Items[i].Value == litterno)
					{
						typelist.SelectedIndex = i;
					}
				}
				listpage();
				bbsname.Text=con.bbsname;
				lmnr.PageSize=con.pagesize;
				lmnr.HeaderStyle.BackColor=ColorTranslator.FromHtml(con.headcolor);
				lmnr.HeaderStyle.ForeColor=ColorTranslator.FromHtml(con.headforecolor);
				lmnr.ItemStyle.ForeColor=ColorTranslator.FromHtml(con.itemforecolor);
				lmnr.Columns[0].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[1].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[2].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[3].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[4].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[5].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[6].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);

				if(litterno!=""&&litterno!=null)
				{
					sql="select zhutino,zhutino+hfno as totle,name,[no] from bbslitter where par="+litterno;
					command=new OleDbCommand(sql,con.link);
					OleDbDataAdapter datasel=new OleDbDataAdapter();
					datasel.SelectCommand=command;
					ds=new DataSet();
					datasel.Fill(ds,"type");
					bbstype.DataSource=ds.Tables["type"].DefaultView;
					if(ds.Tables[0].Rows.Count==0)
					{
						bbstype.Visible=false;
					}
					bbstype.DataBind();
				}
				if(litterno==""||litterno==null)
					litterno="0";
				sql="select zhuti,html,date_time from ggmessage where litterno="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					if(read.GetValue(1).ToString()=="1")
					{
						ggdiv.Text="<a href=\"listgg.aspx?litterno="+litterno+"\">"+read.GetValue(0).ToString()+"("+read.GetValue(2).ToString()+")</a>";
					}
					else
					{
						ggdiv.Text="<a href=\"listgg.aspx?litterno="+litterno+"\">"+con.changechr(con.texttohtml(read.GetValue(0).ToString()))+"("+read.GetValue(2).ToString()+")</a>";
					}
				}
				read.Close();

				con.link.Close();
				if(Session["user_id"]!=null)
				{
					listuserid.Text =Session["user_id"].ToString();
				}
				else
				{
					listuserid.Text="����";
				}
			}
//			else
//			{
//				listpage();
//			}
		}
		protected void listpage()
		{ 
			string sql="",ljnr,ordersql="";
			OleDbCommand command;
			OleDbDataReader read;
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			string user_id,opentype;
			int bz=0;
			opentype=Request.QueryString["opentype"];
			user_id=(string)Session["user_id"];
			listjhq.Visible=false;
			color1="#ffffff";
/*			if(Request.Form["options"]=="search")
			{
				searchto.Visible=true;
				searchto1.Visible=true;
			}
			else
			{
				searchto.Visible=false;
				searchto1.Visible=false;
			}

*/			head="";
			if(litterno==null||litterno=="")
			{
				ljnr="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				lj.InnerHtml=head+ljnr;
			}
			else
			{
				lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>";
				lj.InnerHtml+="<a href='write.aspx?litterno="+litterno+"'><img border=\"0\" src=\"img/fb.gif\" style=\"CURSOR: hand\"></a>";
				sql="select name from bbslitter where [no]="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					head=read.GetValue(0).ToString();
					littername.Text=head;
				}
				read.Close();
			}

			if(user_id==null)
				user_id="qzren_bbs_guest";
			else
				checkmessage(user_id);
			if(litterno=="" || litterno==null)
			{
				con.refresh("0","'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
			}
			else
			{
				con.getbbsset(litterno,"0");
				if(con.ztset==2)
				{
					if(Session["hy"]==null)
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==3)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=3&&(int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==4)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==5)
				{
					if(Session["hy"]==null||(int)Session["hy"]!=5)
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				con.refresh(litterno,"'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
				owner.InnerHtml=con.getowner(litterno);
			}
			if(litterno==null||litterno=="")
			{
				listhead.Text="<A href=\"main.aspx?opentype=mywt\"><font color=\"#ffffff\">�ҵ�����</font></a> | <A href=\"main.aspx?opentype=mycy\"><font color=\"#ffffff\">�Ҳ��������</font></a>";
				listhead.Text+=" | <A href=\"main.aspx?opentype=mygz\"><font color=\"#ffffff\">�ҵĹ��İ�</font></a>| <A href=\"main.aspx?opentype=new\"><font color=\"#ffffff\">������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=hot&litterno="+litterno+"\"><font color=\"#ffffff\">�ȵ�����</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=yjj\"><font color=\"#ffffff\">�ѽ������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=wjj\"><font color=\"#ffffff\">δ�������</font></a>";
			}
			else
			{
				listhead.Text="<A href=\"main.aspx?opentype=mywt\"><font color=\"#ffffff\">�ҵ�����</font></a> | <A href=\"main.aspx?opentype=mycy\"><font color=\"#ffffff\">�Ҳ��������</font></a>";
				listhead.Text+=" | <A href=\"main.aspx?opentype=mygz\"><font color=\"#ffffff\">�ҵĹ��İ�</font></a>| <A href=\"main.aspx?opentype=new\"><font color=\"#ffffff\">������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=hot&litterno="+litterno+"\"><font color=\"#ffffff\">�ȵ�����</font></a>";
				if(con.zjftype==1)
				{
					listhead.Text+="| <A href=\"main.aspx?opentype=yjj&litterno="+litterno+"\"><font color=\"#ffffff\">�ѽ������</font></a>";
					listhead.Text+="| <A href=\"main.aspx?opentype=wjj&litterno="+litterno+"\"><font color=\"#ffffff\">δ�������</font></a>";
				}
			}
			listhead.Text+=" | <a href=\"bp.aspx?type=inbox\"><font color=\"#ffffff\">����Ϣ</font></a>";
				if(opentype=="mywt")  //�ҵ�����
				{
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where user_id="+con.rep(user_id);
					bz=1;
					littername.Text="�ҵ�����";
					ordersql=" order by newtime desc";
				}
				if(opentype=="mycy")  //�Ҳ��������
				{
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					sql="select message.[no],message.zhuti,message.date_time,message.bq,message.fs,message.hf,message.hits,message.filename,message.user_id,toporder,topimage from message,myjoin where myjoin.user_id="+con.rep(user_id)+" and myjoin.messageno=message.[no] ";
					bz=1;
					littername.Text="�ҵĲ��������";
					ordersql=" order by newtime desc";
				}
				if(opentype=="mygz")  //�ҵĹ��İ�
				{
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					sql="select message.[no],message.zhuti,message.date_time,message.bq,message.fs,message.hf,message.hits,message.filename,message.user_id,toporder,topimage from message,mygz where mygz.user_id="+con.rep(user_id)+" and mygz.messageno=message.[no] ";
					bz=1;
					littername.Text="�ҵĹ��İ�";
					ordersql=" order by newtime desc";
				}
				if(opentype=="jhq")   //����������
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and isjhq=1 and litterno="+litterno;
					listjhq.InnerHtml=" [<a href=\"main.aspx?litterno="+litterno+"\">��ͨ��</a>]";
					bz=1;
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					littername.Text="����������";
					ordersql=" order by toporder,newtime desc";
				}
				else
				{
					if(litterno!=null&&litterno!="")
					{
						listjhq.InnerHtml=" [<a href=\"main.aspx?opentype=jhq&litterno="+litterno+"\">������</a>]";
						ordersql=" order by toporder,newtime desc";
					}
				}
				if(opentype=="hot")   //�ȵ�����
				{
					if(litterno==null||litterno=="")
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message  where qx<="+zt;
					}
					else
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message  where litterno="+litterno;
					}
					lj.InnerHtml=head+"<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					bz=1;
					littername.Text="�ȵ�����";
					ordersql=" order by hits desc,newtime desc";
				}
				if(opentype=="new")   //������
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt;
					lj.InnerHtml=head+"<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
					bz=1;
					littername.Text="������";
					ordersql=" order by newtime desc";
				}
				if(opentype=="yjj")   //�ѽ��������
				{	
					if(litterno==null||litterno=="")
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and gftype=2";
						ordersql=" order by toporder,newtime desc";
					}
					else
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno+" and qx<="+zt+" and gftype=2 ";
						ordersql=" order by toporder,newtime desc";
					}
					bz=1;
					littername.Text="�ѽ������";
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				}
				if(opentype=="wjj")   //δ�������
				{
					if(litterno==null||litterno=="")
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and  gftype=1";
						ordersql=" order by toporder,newtime desc";
					}
					else
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno+" and qx<="+zt+" and  gftype=1";
						ordersql=" order by toporder,newtime desc";
					}
					bz=1;
					littername.Text="δ�������";
					lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				}
			if(bz==1)
			{
				bind(sql,ordersql);
			}
			else
			{
				if(litterno==null||litterno=="")
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<=zt";
					ordersql=" order by toporder,newtime desc";
				}
				else
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno;
					ordersql=" order by toporder,newtime desc";
				}
				bind(sql,ordersql);
			}
		}
		protected void search(object sender, EventArgs e)
		{
			string ljnr,sql="";
			ljnr="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
			lmnr.CurrentPageIndex=0;
			lj.InnerHtml=head+ljnr;
			if(searchstr.Text==""||searchstr.Text==null)
				sql=ViewState["sql"].ToString();
			else
			{
				if(searchto.Visible&&searchto.Checked)
				{
					if(typelist.SelectedItem.Value=="�����")
					{
						sql=ViewState["sql"]+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
					else
					{
						sql=ViewState["sql"]+" and litterno="+typelist.SelectedItem.Value+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
				}
				else
				{
					if(typelist.SelectedItem.Value=="�����")
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
					else
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and litterno="+typelist.SelectedItem.Value+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
				}
			}
			searchto1.Visible=true;
			searchto.Visible=true;
//			Response.Write(sql);
//			Response.End();
			bind(sql," order by newtime desc");
		}
		protected void bind(string sql,string ordersql)
		{
			OleDbCommand command;
			OleDbDataAdapter datasel;
			command=new OleDbCommand(sql+ordersql,con.link);
			datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			ViewState["sql"]=sql;
			ViewState["ordersql"]=ordersql;
			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
			int zjl,pagenum;
			zjl=ds.Tables[0].Rows.Count;
			if(zjl/lmnr.PageSize*lmnr.PageSize<zjl)
				pagenum=zjl/lmnr.PageSize+1;
			else
				pagenum=zjl/lmnr.PageSize;
			listpagecount.InnerHtml="["+(lmnr.CurrentPageIndex+1)+"ҳ/"+pagenum+"ҳ/"+zjl+"����]";
			listpagecount.InnerHtml+=listjhq.InnerHtml;
		}
		public main()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
