using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;

namespace bbs
{
	/// <summary>
	/// Summary description for gf.
	/// </summary>
	public class gf : System.Web.UI.Page
	{
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string no,hfno,user_id,filename="",ftuser="",hfuser="",fs="0",bigno="",litterno="",filename1="",contentnr;
			con.open();
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			int mon,year;
			string tomonth,articletype="shtml";
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;
			user_id=(string)Session["user_id"];
			no=Request.QueryString["no"];
			hfno=Request.QueryString["hfno"];
			string sql="select user_id,filename,fs,bigno,litterno,articletype from message where [no]="+no+" and gftype=1";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataReader read;
			read=command.ExecuteReader();
			if(read.Read())
			{
				filename1=filename=read["filename"].ToString();
				ftuser=read["user_id"].ToString();
				fs=read["fs"].ToString();
				bigno=read["bigno"].ToString();
				litterno=read["litterno"].ToString();
				articletype=read["articletype"].ToString();
			}
			else
			{
				read.Close();
				con.link.Close();
				Response.Write("���������ڣ������Ѿ�����");
				return;
			}
			read.Close();
			sql="select user_id from hf_message where [no]="+hfno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				hfuser=read["user_id"].ToString();
			}
			read.Close();
			if(ftuser==user_id&&hfuser!=user_id)
			{
				sql="update "+con.usertable+" set zjf=zjf+"+fs+",fs=fs+"+fs+" where user_id="+con.rep(hfuser);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="update hf_message set fs="+fs+" where [no]="+hfno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="update message set gftype=2,bq="+con.rep(con.bq2)+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="select month,user_id from fs where user_id="+con.rep(hfuser)+" and month='"+tomonth+"' and litterno="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					read.Close();
					sql="update fs set zjf=zjf+"+fs+" where user_id="+con.rep(hfuser)+" and month='"+tomonth+"' and litterno="+litterno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
					sql="insert into fs(litterno,[month],cyf,zjf,user_id,bigno) values("+litterno+",'"+tomonth+"',0,"+fs+","+con.rep(hfuser)+","+bigno+")";
//					Response.Write(sql);
//					Response.End();
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}

				sql="insert into mydf(user_id,messageno) values("+con.rep(hfuser)+","+no+")";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				
			}
			else
			{
				Response.Write("�Բ�����û��Ȩ�޸���");
				con.link.Close();
				Response.End();
			}

			if(articletype=="shtml"||articletype=="html")
			{
				contentnr=con.getpage(no,Int32.Parse(litterno),0);
				filename1=filename;
				filename=Server.MapPath(filename);
				FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
				StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
				wf.Write(contentnr);
				wf.Close();
				con.link.Close();
				DateTime newtime=new DateTime(2100,01,01);
				File.SetLastWriteTime(filename,newtime);
			}
			if(articletype=="xml")
			{
				con.writexml(Int32.Parse(no));
			}
			if(filename1.Substring(filename1.Length-4,4)!="aspx")
			{
				string nr;
				nr="<html><head>";
				nr+="<title>������������ҳ��</title>";
				nr+="<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">";
				nr+="<meta http-equiv=\"refresh\" content=\"0;url="+filename1+"\">";
				nr+="</head><body>������������ҳ�棬���Ժ򡣡���</body></html>";
				Response.Write(nr);
			}
			else
				Response.Redirect(filename1);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
