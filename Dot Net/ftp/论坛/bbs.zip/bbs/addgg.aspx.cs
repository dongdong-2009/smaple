using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;
namespace bbs
{
	/// <summary>
	/// Summary description for write.
	/// </summary>
	public class addgg : System.Web.UI.Page
	{
		protected int maxfs;
		protected System.Web.UI.WebControls.Button Button6;
		protected System.Web.UI.WebControls.TextBox zhuti;
		protected System.Web.UI.WebControls.TextBox nr;
		protected System.Web.UI.WebControls.CheckBox autoadd;
		protected System.Web.UI.WebControls.TextBox fj;
		protected System.Web.UI.WebControls.Button Button5;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.CheckBox isemail;
		protected System.Web.UI.WebControls.RequiredFieldValidator testzhuti;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.WebControls.DropDownList removefile;
		protected System.Web.UI.WebControls.Button Button4;
		protected System.Web.UI.HtmlControls.HtmlGenericControl pageerror;
		protected System.Web.UI.HtmlControls.HtmlGenericControl logindiv;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.HtmlControls.HtmlInputText user_idform;
		protected System.Web.UI.HtmlControls.HtmlInputText passwordform;
		protected System.Web.UI.HtmlControls.HtmlGenericControl addwindows;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listupload1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listupload2;
		protected System.Web.UI.HtmlControls.HtmlGenericControl displayfjlink;
		protected System.Web.UI.HtmlControls.HtmlGenericControl fjwindows;
		protected System.Web.UI.HtmlControls.HtmlInputFile upload_file;
		protected System.Web.UI.HtmlControls.HtmlGenericControl photosize;
		protected System.Web.UI.HtmlControls.HtmlGenericControl displayupload;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlInputHidden totlephotosize;
		string user_id;
		protected System.Web.UI.WebControls.RadioButtonList bqselect;
		protected System.Web.UI.WebControls.Label mainwhere;
		protected System.Web.UI.WebControls.CheckBox html;
		protected System.Web.UI.WebControls.CheckBox allgg;
		protected config con=new config();
		public void addonefj(string delno)
		{
			string filename;
			filename=Server.MapPath("uploadimage")+"/"+delno;
			if(File.Exists(filename))
			{
				FileStream file=new FileStream(filename,FileMode.Open);
				removefile.Items.Add(new ListItem(delno,""+file.Length));
				long intfilesize;
				long totlesize;
				totlesize=Int32.Parse(totlephotosize.Value)+file.Length;
				totlephotosize.Value=""+totlesize;
				float filesize=(float)totlesize/1024;
				intfilesize=(int)(filesize*10);
				filesize=(float)intfilesize/10;
				photosize.InnerHtml=""+filesize+"k";
				file.Close();
			}
		}
		public void getfj(int isauto,string fjfilename)
		{
			if(isauto==1)
				autoadd.Checked=true;
			else
				autoadd.Checked=false;

			string nr,delno,gs;
			int i,j,js;
			nr=fjfilename;
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addonefj(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addonefj(delno);
				}
			}
			fj.Text=fjfilename;
		}
		protected void displayfj(Object sender, EventArgs e)
		{
			addwindows.Visible=false;
			fjwindows.Visible=true;
		}
		protected void selectpic(Object sender, EventArgs e)
		{
			if(removefile.SelectedItem.Value!="nodelete")
			{
				displayupload.InnerHtml="<img src=\"uploadimage/"+removefile.SelectedItem.Text+"\">";
			}
		}
		protected void listfj()
		{
			if(removefile.Items.Count>1)
			{
				fj.Text="";
				displayfjlink.InnerHtml="������������ͼƬ";
				for(int i = 1; i < removefile.Items.Count; i++) 
				{
					fj.Text+=removefile.Items[i].Text+",";
					displayfjlink.InnerHtml+=con.bbspath+"uploadimage/"+removefile.Items[i].Text+",";
				}
				fj.Text=fj.Text.Substring(0,fj.Text.Length-1);
				displayfjlink.InnerHtml=displayfjlink.InnerHtml.Substring(0,displayfjlink.InnerHtml.Length-1);
			}
			else
			{
				fj.Text="";
				displayfjlink.InnerHtml="��û������ͼƬ";
			}
		}

		protected void remove(Object sender, EventArgs e)
		{
			int totlesize=0;
			if(removefile.SelectedItem.Value!="nodelete")
			{
				if(removefile.Items.Count==2)
				{
					photosize.InnerHtml="0.0k";
					totlephotosize.Value="0";
				}
				else
				{
					totlesize=Int32.Parse(totlephotosize.Value)-Int32.Parse(removefile.SelectedItem.Value);
					totlephotosize.Value=""+totlesize;
					float filesize=(float)totlesize/1024;
					int intfilesize=(int)(filesize*10);
					filesize=(float)intfilesize/10;
					photosize.InnerHtml=""+filesize+"k";
				}
		
				string removefilename=removefile.SelectedItem.Text;
				string removefilesize=removefile.SelectedItem.Value;
				removefile.Items.Remove(new ListItem(removefilename,removefilesize));
				removefilename=Server.MapPath("uploadimage")+"/"+removefilename;
				File.Delete(removefilename);
				displayupload.InnerHtml="";
			}
		}

		protected void displayadd(Object sender, EventArgs e)
		{
			addwindows.Visible=true;
			fjwindows.Visible=false;
			listfj();
		}

		protected void upload(Object sender, EventArgs e)
		{
			int errorno=0;
	
			if(upload_file.PostedFile==null)
			{
				wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
				errorno=1;
			}
			else
			{
				if(upload_file.PostedFile.FileName.Length<3)
				{
					wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
					errorno=1;
				}
				else
				{
					if(upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3).ToLower()!="gif" && upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3).ToLower()!="jpg" )
					{
						wc.InnerHtml="ͼƬ��ʽֻ���� jpg,gif���ָ�ʽ,���ϴ���ͼƬ��ʽ����";
						errorno=1;
					}
					if(upload_file.PostedFile.ContentLength==0)
					{
						wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
						errorno=1;
					}
					if(upload_file.PostedFile.ContentLength>600000)
					{
						wc.InnerHtml="ͼƬ��С�޶���600K����";
						errorno=1;
					}
				}
			}
			if(errorno==0)
			{
				string path=Server.MapPath("uploadimage");
				string filename=DateTime.Now.ToString();
				filename=filename.Replace(":","");
				filename=filename.Replace("-","");
				filename=filename.Replace(" ","");
				Random r=new Random();
				filename=filename+r.Next(1000);
				filename=filename+"."+upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3);
		
				removefile.Items.Add(new ListItem(filename,""+upload_file.PostedFile.ContentLength));
				displayupload.InnerHtml="<img src=\"uploadimage/"+filename+"\">";
		
				filename=path+"/"+filename;
				upload_file.PostedFile.SaveAs(filename);
				wc.Visible=false;
				int intfilesize;
				int totlesize;
				totlesize=Int32.Parse(totlephotosize.Value)+upload_file.PostedFile.ContentLength;
				totlephotosize.Value=""+totlesize;
				float filesize=(float)totlesize/1024;
				intfilesize=(int)(filesize*10);
				filesize=(float)intfilesize/10;
				photosize.InnerHtml=""+filesize+"k";
			}
			else
			{
				wc.Visible=true;
			}
		}
		protected void Page_Load(object sender, EventArgs e)
		{ 
			string sql,litterno;
			int kyf;
			user_id=(string)Session["user_id"];
			litterno=Request.QueryString["litterno"];
			OleDbCommand command;
			OleDbDataReader read;
			if(litterno=="" || litterno==null)
			{
				pageerror.InnerHtml="����ѡ����Ӧ����Ŀ";
				logindiv.Visible=false;
				list.Visible=false;
				return;
			}
			if(user_id==null || user_id=="")
			{
				//			pageerror.InnerHtml="����δ��¼���������<a href=\"default.aspx\">��¼</a>";
				//			pageerror.Visible=true;
				list.Visible=false;
				pageerror.InnerHtml="���ȵ�¼";
				return;
			}
			con.open();
			if(litterno=="0")
			{
				if(!con.checksuper())
				{
					list.Visible=false;
					pageerror.InnerHtml="��û��Ȩ��";
					return;
				}
			}
			else
			{
				if(!con.checkbz(litterno,"0"))
				{
					list.Visible=false;
					pageerror.InnerHtml="��û��Ȩ��";
					return;
				}
				allgg.Visible=false;
			}
			if(!Page.IsPostBack)
			{
				fjwindows.Visible=false;
				sql="select zhuti,nr,html,autoaddimage,uploadimage from ggmessage where litterno="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					zhuti.Text=read.GetValue(0).ToString();
					nr.Text=read.GetValue(1).ToString();
					//				if(read.GetValue(2).ToString()=="1")
					//				{
					//					autoadd.Checked=true;
					//				}
					//				else
					//				{
					//					autoadd.Checked=false;
					//				}
					getfj((int)read.GetValue(3),read.GetValue(4).ToString());
				}
				read.Close();
			}
			con.link.Close();
		}
		protected void add(object sender, EventArgs e)
		{ 
			con.open();
			string litterno,typeid,sql,bq,ip,filename,sql1,sql2,addlitterno;
			int num,bigno,zt,ishtml,liuyan;
			litterno=Request.QueryString["litterno"];
			OleDbCommand command,command1,command2;
			OleDbDataReader read,read1,read2;
	
			sql="select bigno from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				bigno=(int)read.GetValue(0);
			}
			else
				bigno=1;
			read.Close();
			typeid=Request.QueryString["typeid"];
			if(html.Checked)
				ishtml=1;
			else
				ishtml=0;
			liuyan=0;
			int autoaddimage;
			if(autoadd.Checked==true)
				autoaddimage=1;
			else
				autoaddimage=0;

			sql="select [no] from ggmessage where litterno="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				if(litterno=="0"&&allgg.Checked)
				{
					read.Close();
					con.open1();
					sql="select [no] from bbslitter";
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					while(read.Read())
					{
						addlitterno=read.GetValue(0).ToString();
						sql1="select [no] from ggmessage where litterno="+addlitterno;
						command1=new OleDbCommand(sql1,con.link1);
						read1=command1.ExecuteReader();
						if(read1.Read())
						{
							read1.Close();
						}
						else
						{
							sql1="insert into ggmessage(user_id,html,zhuti,nr,bigno,litterno,date_time,hits,autoaddimage,uploadimage) values("+con.rep(user_id)+","+ishtml+","+con.rep(zhuti.Text)+","+con.rep(nr.Text)+","+bigno+","+addlitterno+",'"+DateTime.Now+"',0,"+autoaddimage+","+con.rep(fj.Text)+")";
							read1.Close();
							command1=new OleDbCommand(sql1,con.link1);
							command1.ExecuteNonQuery();
						}
					}
					read.Close();
					con.link1.Close();
					sql="update ggmessage set user_id="+con.rep(user_id)+",html="+ishtml+",zhuti="+con.rep(zhuti.Text)+",nr="+con.rep(nr.Text)+",date_time='"+DateTime.Now+"',autoaddimage="+autoaddimage+",uploadimage="+con.rep(fj.Text);
				}
				else
				{
					sql="update ggmessage set user_id="+con.rep(user_id)+",html="+ishtml+",zhuti="+con.rep(zhuti.Text)+",nr="+con.rep(nr.Text)+",date_time='"+DateTime.Now+"',autoaddimage="+autoaddimage+",uploadimage="+con.rep(fj.Text)+" where litterno="+litterno;
					read.Close();
				}
			}
			else
			{
				sql="insert into ggmessage(user_id,html,zhuti,nr,bigno,litterno,date_time,hits,autoaddimage,uploadimage) values("+con.rep(user_id)+","+ishtml+","+con.rep(zhuti.Text)+","+con.rep(nr.Text)+","+bigno+","+litterno+",'"+DateTime.Now+"',0,"+autoaddimage+","+con.rep(fj.Text)+")";
				read.Close();
			}
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			con.link.Close();
			if(litterno=="0")
			{
				Response.Redirect("admin.aspx");
			}
			else
			{
				Response.Redirect("adminmain.aspx?litterno="+litterno);
			}
		}
		public addgg()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}


		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
