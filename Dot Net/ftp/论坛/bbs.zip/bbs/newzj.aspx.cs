using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bbs
{
	/// <summary>
	/// Summary description for newzj.
	/// </summary>
	public class newzj : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox zjlt;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected string writecyf="";
		protected config con=new config();
		protected void makepage()
		{
			string nr="",adminnr="",sql;
			if(File.Exists(Server.MapPath("menu.htm")))
				File.Delete(Server.MapPath("menu.htm"));
			if(File.Exists(Server.MapPath("adminmenu.htm")))
				File.Delete(Server.MapPath("adminmenu.htm"));

			OleDbCommand command,command1;
			OleDbDataReader read,read1;
			int no,i=1;
	
			con.open2();
			sql="select name,[no] from bbsbig";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				nr=nr+"<div id=\"KB"+i+"Parent\" class=\"parent\">";
				nr=nr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				nr=nr+"<IMG align=absMiddle ";
				nr=nr+"  border=0 src=\"image/line_01.gif\" width=\"18\" height=\"16\"><IMG align=absMiddle border=0 ";
				nr=nr+"  src=\"image/folder_01.gif\"></a>";
				nr=nr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				nr=nr+read.GetValue(0).ToString()+"</a> </div>";
				nr=nr+"<div id=\"KB"+i+"Child\" class=\"child\">";
		
				adminnr=adminnr+"<div id=\"KB"+i+"Parent\" class=\"parent\">";
				adminnr=adminnr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				adminnr=adminnr+"<IMG align=absMiddle ";
				adminnr=adminnr+"  border=0 src=\"image/line_01.gif\" width=\"18\" height=\"16\"><IMG align=absMiddle border=0 ";
				adminnr=adminnr+"  src=\"image/folder_01.gif\"></a>";
				adminnr=adminnr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				adminnr=adminnr+read.GetValue(0).ToString()+"</a> </div>";
				adminnr=adminnr+"<div id=\"KB"+i+"Child\" class=\"child\">";
		
				sql="select [no],name from bbslitter where bigno="+(int)read.GetValue(1);
				command1=new OleDbCommand(sql,con.link2);
				read1=command1.ExecuteReader();
				while(read1.Read())
				{
					nr=nr+"<IMG align=absMiddle border=0 src=\"image/line_05.gif\"><IMG ";
					nr=nr+"align=absMiddle border=0 src=\"image/dot_01.gif\">";
					nr=nr+"<a href=main.aspx?litterno="+read1.GetValue(0).ToString()+"  target=\"frmright\">"+read1.GetValue(1).ToString()+"</a><br>";

					adminnr=adminnr+"<IMG align=absMiddle border=0 src=\"image/line_05.gif\"><IMG ";
					adminnr=adminnr+"align=absMiddle border=0 src=\"image/dot_01.gif\">";
					adminnr=adminnr+"<a href=adminmain.aspx?litterno="+read1.GetValue(0).ToString()+"  target=\"frmright\">"+read1.GetValue(1).ToString()+"</a><br>";
				}
				nr=nr+"</div>";
				adminnr=adminnr+"</div>";
				read1.Close();
				i++;
			}
			read.Close();
			con.link2.Close();

			FileStream writefile = new FileStream(Server.MapPath("menu.htm"), FileMode.OpenOrCreate, FileAccess.Write); 
			StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(nr);
			wf.Close();
	
			writefile = new FileStream(Server.MapPath("adminmenu.htm"), FileMode.OpenOrCreate, FileAccess.Write); 
			wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(adminnr);
			wf.Close();
		}

		protected void change(Object sender, EventArgs e)
		{
			con.open();
			int litterno;
			string sql="select [no] from bbsbig where [no]=1001";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataReader read=command.ExecuteReader();
			if(read.Read())
			{
				read.Close();
			}
			else
			{
				read.Close();
				sql="insert bbsbig values(1001,'ר����̳',' ')";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}

			sql="select [no] from bbslitter where bigno=1001 and owner1="+con.rep(Session["user_id"].ToString());
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				read.Close();
				wc.InnerHtml="���ר����̳�Ѿ���ͨ";
			}
			else
			{
				read.Close();
				sql="select [no] from bbslitter order by [no] desc";
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
					litterno=(int)read.GetValue(0)+1;
				else
					litterno=1;
				read.Close();
				sql="insert bbslitter values("+litterno+","+1001+","+con.rep(zjlt.Text)+","+con.rep(Session["user_id"].ToString())+",'admin','admin',2,0,0,0,0)";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				wc.InnerHtml="���ӳɹ�";
				makepage();
			}
		}

		protected void Page_Load(Object sender, EventArgs e)
		{
			if(!Page.IsPostBack)       //��һ������,����մ�,����ߵ���Ŀ��,�ӱ��ҳ������
			{
				if(Session["user_id"]==null || Session["user_id"].ToString()=="")
				{
					all.InnerHtml="<div align=center>���ȵ�¼</div>";
				}
				/*		else
						{
							con.open();
							string sql="select zjf from userfs where user_id="+con.rep(Session["user_id"].ToString());
							OleDbCommand command=new OleDbCommand(sql,con.link);
							OleDbDataReader read=command.ExecuteReader();
							if(read.Read())
							{
								if((int)read.GetValue(0)<newlitterneadfs)
									all.InnerHtml="<div align=center>Ҫ��ר����̳,������Ҫ��"+newlitterneadfs+"ר�ҷ�</div>";
							}
							else
							{
								all.InnerHtml="<div align=center>Ҫ��ר����̳,������Ҫ��"+newlitterneadfs+"ר�ҷ�</div>";
							}
							read.Close();
							con.link.Close();
							zjlt.Text=Session["user_id"].ToString()+"����̳";
						}
				*/	}
		}

		public newzj()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}


		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
