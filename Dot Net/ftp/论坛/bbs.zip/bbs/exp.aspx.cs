using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for exp.
	/// </summary>
	public class exp : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		protected System.Web.UI.HtmlControls.HtmlGenericControl erp;
	
		protected config con=new config();
		protected DataSet ds;
		protected string nr;
		protected OleDbDataReader readzj;
		protected void listlitter(int bigno)
		{
			int i=0;
			OleDbCommand command;
			OleDbDataReader read;
			nr+="<table width=\"100%\" border=\"0\" cellspacing=\"2\" cellpadding=\"2\">";
			string sql="select [no],name from bbslitter where bigno="+bigno;
			command=new OleDbCommand(sql,con.link2);
			read=command.ExecuteReader();
			while(read.Read())
			{
				if(i==0)
				{
					nr+="<tr><td width=\"20%\">"+read.GetValue(1).ToString()+"</td><td width=\"10%\"><a href=exp.aspx?type=litter&month=total&litterno="+read.GetValue(0).ToString()+">�ܰ�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=tomonth&litterno="+read.GetValue(0).ToString()+">���°�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=lastmonth&litterno="+read.GetValue(0).ToString()+">���°�</a></td>";
					i=1;
				}
				else
				{
					nr+="<td width=\"20%\">"+read.GetValue(1).ToString()+"</td><td width=\"10%\"><a href=exp.aspx?type=litter&month=total&litterno="+read.GetValue(0).ToString()+">�ܰ�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=tomonth&litterno="+read.GetValue(0).ToString()+">���°�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=lastmonth&litterno="+read.GetValue(0).ToString()+">���°�</a></td></tr>";
					i=0;
				}
			}
			if(i==1)
				nr+="<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
			read.Close();
			nr+="</table>";
		}

		protected void Page_Load(Object sender, EventArgs e)
		{
			string sql="";
			string bigno,typenr="",litterno;
			con.open();
			con.open2();

			int mon,year,i=0;
			string tomonth,lastmonth;
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;
			if(mon==1)
			{
				mon=12;
				year--;
			}
			mon--;
			if(mon<10)
				lastmonth=""+year+"-0"+mon;
			else
				lastmonth=""+year+"-"+mon;

			OleDbCommand command,command1;
			OleDbDataReader read,read1;

			if(Request.QueryString["type"]==null)
			{
				all.InnerHtml="�Ƿ�����";
			}
			else
			{
				if(Request.QueryString["type"].ToString()=="all")
				{
					int gftype=0,gfvalue=0,defaultgftype=0,defaultgfvalue=0;
					sql="select zjftype,zjfvalue from bbsset where litterno=0";
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						gftype=(int)read["zjftype"];
						gfvalue=(int)read["zjfvalue"];
						defaultgftype=(int)read["zjftype"];
						defaultgfvalue=(int)read["zjfvalue"];
					}
					read.Close();

					erp.Visible=false;
					all.Visible=true;
					nr="<table width=\"600\" border=\"0\" cellspacing=\"2\" cellpadding=\"2\">";
					sql="select [no],name from bbslitter";
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					while(read.Read())
					{
						sql="select zjftype,zjfvalue from bbsset where litterno="+read["no"].ToString();
						command1=new OleDbCommand(sql,con.link2);
						read1=command1.ExecuteReader();
						if(read1.Read())
						{
							gftype=(int)read1["zjftype"];
							gfvalue=(int)read1["zjfvalue"];
						}
						else
						{
							gftype=defaultgftype;
							gfvalue=defaultgfvalue;
						}
						read1.Close();
						if(gftype==1&&gfvalue>0)
						{
							i++;
							nr+="  <tr>";
							nr+="<td>";
							nr+=read.GetValue(1).ToString()+"</td><td width=\"10%\"><a href=exp.aspx?type=litter&month=total&litterno="+read.GetValue(0).ToString()+">�ܰ�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=tomonth&litterno="+read.GetValue(0).ToString()+">���°�</a></td><td width=\"10%\"><a href=exp.aspx?type=litter&month=lastmonth&litterno="+read.GetValue(0).ToString()+">���°�</a>";
							//						nr+="<td>"+read.GetValue(1).ToString()+"ר�Ұ� &nbsp;<a href=exp.aspx?type=big&month=total&bigno="+(int)read.GetValue(0)+">�ܰ�</a>&nbsp;<a href=exp.aspx?type=big&month=tomonth&bigno="+(int)read.GetValue(0)+">���°�</a>&nbsp;<a href=exp.aspx?type=big&month=lastmonth&bigno="+(int)read.GetValue(0)+">���°�</a>&nbsp;";
							//						listlitter((int)read.GetValue(0));
							nr+="</td>";
							nr+="</tr>";
						}
						if(i==0)
							all.InnerHtml="��δ��ͨ���ְ�";
						else
							all.InnerHtml=nr;
					}
				}
/*				if(Request.QueryString["type"].ToString()=="big")
				{
					erp.Visible=true;
					all.Visible=false;
					bigno=Request.QueryString["bigno"].ToString();
					if(Request.QueryString["month"].ToString()=="total")
					{
						sql="select name from bbsbig where [no]="+bigno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(�ܰ�)";
						}
						read.Close();
						sql="select top 50 user_id,sum(zjf) as zjftj from fs where bigno="+bigno+" group by user_id order by sum(zjf) desc";
					}
					if(Request.QueryString["month"].ToString()=="tomonth")
					{
						sql="select name from bbsbig where [no]="+bigno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(���°�)";
						}
						read.Close();
						sql="select top 50 user_id,zjf from fs where bigno="+bigno+" and month='"+tomonth+"' order by zjf";
					}
					if(Request.QueryString["month"].ToString()=="lastmonth")
					{
						sql="select name from bbsbig where [no]="+bigno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(���°�)";
						}
						read.Close();
						sql="select top 50 user_id,zjf from fs where bigno="+bigno+" and month='"+lastmonth+"' order by zjf";
					}
					command=new OleDbCommand(sql,con.link);
					readzj=command.ExecuteReader();
					list(typenr);
				}
*/				if(Request.QueryString["type"].ToString()=="litter")
				{
					erp.Visible=true;
					all.Visible=false;
					litterno=Request.QueryString["litterno"].ToString();
					if(Request.QueryString["month"].ToString()=="total")
					{
						sql="select name from bbslitter where [no]="+litterno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(�ܰ�)";
						}
						read.Close();
						sql="select top 50 user_id,sum(zjf) as zjftj from fs where litterno="+litterno+" group by user_id order by sum(zjf) desc";
					}
					if(Request.QueryString["month"].ToString()=="tomonth")
					{
						sql="select name from bbslitter where [no]="+litterno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(���°�)";
						}
						read.Close();
						sql="select top 50 user_id,zjf from fs where litterno="+litterno+" and month='"+tomonth+"' order by zjf desc";
					}
					if(Request.QueryString["month"].ToString()=="lastmonth")
					{
						sql="select name from bbslitter where [no]="+litterno;
						command=new OleDbCommand(sql,con.link2);
						read=command.ExecuteReader();
						if(read.Read())
						{
							typenr=read.GetValue(0).ToString()+"Top50ר�Ұ�(���°�)";
						}
						read.Close();
						sql="select top 50 user_id,zjf from fs where litterno="+litterno+" and month='"+lastmonth+"' order by zjf desc";
					}
					command=new OleDbCommand(sql,con.link);
					readzj=command.ExecuteReader();
					list(typenr);
				}
			}
			con.link2.Close();
			con.link.Close();
		}
		protected void list(string typenr)
		{
			string sql;
			int i=1;
			OleDbCommand command;
			OleDbDataReader read;
			nr=typenr;
			nr+="<table width=\"100%\" border=\"0\" cellspacing=\"2\" cellpadding=\"2\">";
			nr+="<tr><td>����</td><td>��¼��</td><td>�ǳ�</td><td>ר�ҷ�</td><td>�����û�������Ϣ</td></tr>";
			while(readzj.Read())
			{
				nr+="<tr><td>"+i+"</td>";
				nr+="<td>"+readzj.GetValue(0).ToString()+"</td>";
				sql="select user_name from "+con.usertable+" where user_id="+con.rep(readzj.GetValue(0).ToString());
				command=new OleDbCommand(sql,con.link2);
				read=command.ExecuteReader();
				if(read.Read())
				{
					nr+="<td>"+read.GetValue(0).ToString();
				}
				read.Close();
				nr+="<td>"+readzj.GetValue(1).ToString();
				nr+="<td><a href=\"javascript:openScript('bp.aspx?type=new&user_id="+readzj.GetValue(0).ToString()+"',420,320)\">�����û�������Ϣ</a></td></tr>";
				i++;
			}
			readzj.Close();
			erp.InnerHtml=nr;
		}
		public exp()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
