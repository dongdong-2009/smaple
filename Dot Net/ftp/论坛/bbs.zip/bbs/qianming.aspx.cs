using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for qianming.
	/// </summary>
	public class qianming : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlTextArea qm;
		protected System.Web.UI.HtmlControls.HtmlSelect usericon;
		protected System.Web.UI.HtmlControls.HtmlInputText ownimage;
		protected System.Web.UI.HtmlControls.HtmlInputText imagewidth;
		protected System.Web.UI.HtmlControls.HtmlInputText imageheight;
		protected System.Web.UI.WebControls.Label wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl success;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlImage useravatars;
		config con=new config();
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["user_id"]==null||Session["user_id"].ToString()=="")
			{
				success.InnerHtml="���ȵ�¼";
			}
			else
			{
				if(!Page.IsPostBack)
				{
					string sql;
					OleDbCommand command;
					OleDbDataReader read;
					con.open();
					sql="select usericon,systemicon,imagewidth,imageheight,qianming from "+con.usertable+" where user_id="+con.rep(Session["user_id"].ToString());
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						ownimage.Value=read.GetValue(0).ToString();
						imagewidth.Value=read.GetValue(2).ToString();
						imageheight.Value=read.GetValue(3).ToString();
						usericon.Value=read.GetValue(1).ToString();
						qm.Value=read.GetValue(4).ToString();
						useravatars.Src="images/face/"+read.GetValue(1).ToString();
					}
					read.Close();
					con.link.Close();
				}
			}
		}
		protected  void update(object sender, System.EventArgs e)
		{
			if(ownimage.Value!="")
			{
				if(imagewidth.Value==""||imageheight.Value==""||Int32.Parse(imagewidth.Value)>100||Int32.Parse(imagewidth.Value)<20||Int32.Parse(imageheight.Value)>100||Int32.Parse(imageheight.Value)<20)
				{
					wc.Text="<font color=red>���������������</font>";
					return;
				}
			}
			string widthstr,heightstr;
			if(imagewidth.Value=="")
				widthstr="null";
			else
				widthstr=imagewidth.Value;
			if(imageheight.Value=="")
				heightstr="null";
			else
				heightstr=imageheight.Value;

			string sql;
			OleDbCommand command;
			OleDbDataReader read;
			con.open();
			sql="update "+con.usertable+" set usericon="+con.rep(ownimage.Value)+",systemicon='"+usericon.Value+"',imagewidth="+widthstr+",imageheight="+heightstr+",qianming="+con.rep(qm.Value)+" where user_id="+con.rep(Session["user_id"].ToString());
//			Response.Write(sql);
//			Response.End();
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			con.link.Close();
			Response.Redirect("index.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ID = "creato";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
