using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for addmygz.
	/// </summary>
	public class addmygz : System.Web.UI.Page
	{
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e)
		{
			con.open();
			string no=Request.QueryString["no"];
			string sql;
			int num;
			if(Session["user_id"]==null || Session["user_id"].ToString()=="")
			{
				Response.Write("<div align=center>�Բ�������û�е�¼</div>");
				Response.End();
			}
			sql="select [no] from mygz where messageno="+no;
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataReader read=command.ExecuteReader();
			if(read.Read())
			{
				read.Close();
			}
			else
			{
				read.Close();
				sql="insert into mygz(user_id,messageno) values("+con.rep(Session["user_id"].ToString())+","+no+")";
			}
			Response.Write("<div align=center>�ɹ��������Ĺ��İ�</div>");
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			con.link.Close();
		}
		public addmygz()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
