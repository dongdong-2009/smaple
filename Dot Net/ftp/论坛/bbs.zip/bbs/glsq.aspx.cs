using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for glsq.
	/// </summary>
	public class glsq : System.Web.UI.Page
	{
		protected DataSet ds;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected int lys1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected config con=new config();

		protected void ty(string delno)
		{
			con.open();
			OleDbCommand command;
			OleDbDataReader read;
			int no,litterno,sqno,bpno;
			string littername,user_id,ownertype;
			string sql="select new,litterno,bt,user_id,ownertype,[no] from bbssq where [no]="+delno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				if((int)read.GetValue(0)==1)
				{
					littername=read.GetValue(2).ToString();
					user_id=read.GetValue(3).ToString();
					sqno=(int)read.GetValue(5);
					read.Close();
					sql="insert mfbbs.qzren.bbslitter values(1,"+con.rep(littername)+","+con.rep(user_id)+",'admin','admin',1,0,0,0,0)";
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					sql="delete from bbssq where [no]="+sqno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();

					sql="insert  bpmessage values("+con.rep(user_id)+",'���������̳�ѿ�ͨ','��ϲ��,���������̳�ѿ�ͨ, �л����θ�л����֧�֡�\n����������̳�����ӡ�\nhttp://www.games.com.cn/aspx/bbs/mfbbs/\n�����������޸���̳�Ĳ���','admin','"+DateTime.Now+"','δ��','δ����')";
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					con.sendtouser(con.getadmin_mail(),user_id,"���������̳�ѿ�ͨ","��ϲ��,���������̳�ѿ�ͨ, �л����θ�л����֧�֡�\n����������̳�����ӡ�\nhttp://www.games.com.cn/aspx/bbs/mfbbs/\n�����������޸���̳�Ĳ���",0);
				}
				else
				{
					user_id=read.GetValue(3).ToString();
					litterno=(int)read.GetValue(1);
					sqno=(int)read.GetValue(5);
					ownertype=read.GetValue(4).ToString();
					read.Close();

					sql="update bbslitter set "+ownertype+"="+con.rep(user_id)+" where [no]="+litterno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();

					sql="insert into bpmessage(user_id,title,message,whosend,date_time,innew,outnew) values("+con.rep(user_id)+",'������İ����ѳɹ�','��ϲ��,������İ����ѿ�ͨ, �л����θ�л����֧�֡�','admin','"+DateTime.Now+"','δ��','δ����')";
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					con.sendtouser(con.getadmin_mail(),user_id,"������İ����ѳɹ�","��ϲ��,������İ����ѳɹ�, �л����θ�л����֧�֡�",0);
				}
				sql="delete from bbssq where [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			con.link.Close();
			Response.Redirect("glsq.aspx");
		}

		protected void delall(Object sender, EventArgs e)
		{
			con.open();
			OleDbCommand command;
	
			string sql="delete from bbssq";
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			con.link.Close();
			Response.Redirect("glsq.aspx");
		}

		protected void delone(string delno)
		{
			OleDbCommand command;
	
			string sql="delete from bbssq where [no]="+delno;
			command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
		}

		protected void del()
		{
			string nr,delno="0",gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
				}
			}
		}
		protected void tysq()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					ty(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					ty(delno);
				}
			}
		}

		protected void Page_Load(Object sender, EventArgs e)
		{
			if(!con.checksuper())
			{
				list.InnerHtml="�Բ���,��ʹ���й���Ȩ�޵��ʺŵ�¼";
				return;
			}

			con.open();
			if(Request.Form["options"]=="del")
			{
				del();
				Response.Redirect("glsq.aspx");
			}
			if(Request.Form["options"]=="tysq")
			{
				tysq();
				Response.Redirect("glsq.aspx");
			}

			string sql="select bbssq.[no],bbssq.user_id,bbssq.date_time,bbssq.sm,bbssq.litterno,bbslitter.name from bbssq,bbslitter where bbssq.litterno=bbslitter.[no]";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
			con.link.Close();
			lys1=lmnr.Items.Count;
		}

		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			con.link.Close();
			lys1=lmnr.Items.Count;
		}
		public glsq()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
