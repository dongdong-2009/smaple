using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for bbsset.
	/// </summary>
	public class bbsset : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList datebasepagesize;
		protected System.Web.UI.WebControls.DropDownList datebasehtml;
		protected System.Web.UI.WebControls.DropDownList datebaseubb;
		protected System.Web.UI.WebControls.DropDownList datebasescript;
		protected System.Web.UI.WebControls.DropDownList datebaseflash;
		protected System.Web.UI.WebControls.DropDownList datebaseimg;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.DropDownList whouploadimage;
		protected System.Web.UI.WebControls.TextBox zjfuploadimage;
		protected System.Web.UI.WebControls.DropDownList llset;
		protected System.Web.UI.WebControls.DropDownList ftset;
		protected System.Web.UI.WebControls.DropDownList hfset;
		protected System.Web.UI.WebControls.DropDownList uploadimageset;
		protected System.Web.UI.HtmlControls.HtmlGenericControl uploadimage;
		protected System.Web.UI.WebControls.DropDownList type;
		protected System.Web.UI.WebControls.TextBox headcolor;
		protected System.Web.UI.WebControls.TextBox color1;
		protected System.Web.UI.WebControls.TextBox color2;
		protected System.Web.UI.WebControls.TextBox headforecolor;
		protected System.Web.UI.WebControls.TextBox itemforecolor;
		protected System.Web.UI.WebControls.DropDownList pagesize;
		protected System.Web.UI.WebControls.DropDownList pagetype;
		protected System.Web.UI.WebControls.DropDownList zjftype;
		protected System.Web.UI.WebControls.TextBox zjfvalue;
		protected System.Web.UI.WebControls.TextBox owner1;
		protected System.Web.UI.WebControls.TextBox owner2;
		protected System.Web.UI.WebControls.TextBox owner3;
		protected config con=new config();
	
		protected void update(Object sender, EventArgs e)
		{
			string litterno=Request.QueryString["litterno"],litterpagesize;
			if(litterno==null || litterno=="")
				all.InnerHtml="����ѡ��һ�����";
			else
			{
				OleDbCommand command;
				OleDbDataReader read;
				con.open();
				string sql;
//				string sql="select [no] from bbslitter where [no]="+litterno;
//				command=new OleDbCommand(sql,con.link);
//				read=command.ExecuteReader();
//				if(read.Read())
//				{
//					read.Close();
					sql="select litterno from bbsset where litterno="+litterno;
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						sql="update bbsset set lys="+datebasepagesize.SelectedItem.Value+",html="+datebasehtml.SelectedItem.Value+",ubb="+datebaseubb.SelectedItem.Value+",script="+datebasescript.SelectedItem.Value+",flash="+datebaseflash.SelectedItem.Value+",img="+datebaseimg.SelectedItem.Value+",zt="+llset.SelectedItem.Value+",ft="+ftset.SelectedItem.Value+",hf="+hfset.SelectedItem.Value+",whouploadimage="+whouploadimage.SelectedItem.Value+",zjfuploadimage="+zjfuploadimage.Text+",uploadimage="+uploadimageset.SelectedItem.Value+",headcolor="+con.rep(headcolor.Text)+",color1="+con.rep(color1.Text)+",color2="+con.rep(color2.Text)+",headforecolor="+con.rep(headforecolor.Text)+",itemforecolor="+con.rep(itemforecolor.Text)+",articlepage="+pagesize.SelectedItem.Value+",articletype='"+pagetype.SelectedItem.Value+"',zjftype="+zjftype.SelectedItem.Value+",zjfvalue="+zjfvalue.Text+" where litterno="+litterno;
						read.Close();
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						sql="update bbslitter set owner1="+con.rep(owner1.Text)+",owner2="+con.rep(owner2.Text)+",owner3="+con.rep(owner3.Text)+" where [no]="+litterno;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
					else
					{
						sql="insert into bbsset(lys,logo,logolj,gonggao,gonggaolj,refresh,bigno,litterno,html,ubb,script,flash,img,zt,ft,hf,whouploadimage,zjfuploadimage,uploadimage,headcolor,color1,color2,headforecolor,itemforecolor,articlepage,articletype,zjftype,zjfvalue) values("+datebasepagesize.SelectedItem.Value+",null,null,null,null,"+"1200"+",1,"+litterno+","+datebasehtml.SelectedItem.Value+","+datebaseubb.SelectedItem.Value+","+datebasescript.SelectedItem.Value+","+datebaseflash.SelectedItem.Value+","+datebaseimg.SelectedItem.Value+","+llset.SelectedItem.Value+","+ftset.SelectedItem.Value+","+hfset.SelectedItem.Value+","+whouploadimage.SelectedItem.Value+","+zjfuploadimage.Text+","+uploadimageset.SelectedItem.Value+","+con.rep(headcolor.Text)+","+con.rep(color1.Text)+","+con.rep(color2.Text)+","+con.rep(headforecolor.Text)+","+con.rep(itemforecolor.Text)+","+pagesize.SelectedItem.Value+",'"+pagetype.SelectedItem.Value+"',"+zjftype.SelectedItem.Value+","+zjfvalue.Text+")";
//						Response.Write(sql);
//						Response.End();

						read.Close();
						//				all.InnerHtml=sql;
//						Response.Write(sql);
//						Response.End();
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						sql="update bbslitter set owner1="+con.rep(owner1.Text)+",owner2="+con.rep(owner2.Text)+",owner3="+con.rep(owner3.Text)+" where [no]="+litterno;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
//				}
//				else
//				{
//					read.Close();
//				}
				con.link.Close();
			}
		}
		protected void listpage(string litterno)
		{
			OleDbCommand command;
			OleDbDataReader read;
			con.open();
			string sql="select [no],name from bbslitter";
			string litterpagesize;
			if(!Page.IsPostBack)
			{
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				int k=0,j=0;
				type.Items.Add(new ListItem("Ĭ����Ŀ","0"));
				while(read.Read())
				{
					if(read.GetValue(0).ToString()==litterno)
						j=k+1;
					type.Items.Add(new ListItem(read.GetValue(1).ToString(),read.GetValue(0).ToString()));
					k++;
				}
				read.Close();
				type.SelectedIndex=j;
			}
			if(!con.checksuper())
				uploadimage.Visible=false;

//			sql="select [no] from bbslitter where [no]="+litterno;
//			command=new OleDbCommand(sql,con.link);
//			read=command.ExecuteReader();
//			if(read.Read())
//			{
//				read.Close();
			sql="select * from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				owner1.Text=read["owner1"].ToString();
				owner2.Text=read["owner2"].ToString();
				owner3.Text=read["owner3"].ToString();
			}
			read.Close();
			sql="select * from bbsset where litterno="+litterno;

				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					litterpagesize=read.GetValue(1).ToString();
					for(int i = 0; i <datebasepagesize.Items.Count; i++) 
					{
						if (datebasepagesize.Items[i].Value == litterpagesize)
						{
							datebasepagesize.SelectedIndex = i;
						}
					}
//					datebaselogo.Text=read.GetValue(2).ToString().Trim();
//					datebaselogolj.Text=read.GetValue(3).ToString().Trim();
//					datebasegg.Text=read.GetValue(4).ToString().Trim();
//					datebasegglj.Text=read.GetValue(5).ToString().Trim();
					if((int)read.GetValue(9)==1)
						datebasehtml.SelectedIndex=0;
					else
						datebasehtml.SelectedIndex=1;
					if((int)read.GetValue(10)==1)
						datebaseubb.SelectedIndex=0;
					else
						datebaseubb.SelectedIndex=1;
					if((int)read.GetValue(11)==1)
						datebasescript.SelectedIndex=0;
					else
						datebasescript.SelectedIndex=1;
					if((int)read.GetValue(12)==1)
						datebaseflash.SelectedIndex=0;
					else
						datebaseflash.SelectedIndex=1;
					if((int)read.GetValue(13)==1)
						datebaseimg.SelectedIndex=0;
					else
						datebaseimg.SelectedIndex=1;
					if((int)read["zjftype"]==1)
						zjftype.SelectedIndex=0;
					else
						zjftype.SelectedIndex=1;
					zjfvalue.Text=read["zjfvalue"].ToString();
					llset.SelectedIndex=(int)read.GetValue(14)-1;
					ftset.SelectedIndex=(int)read.GetValue(15)-1;
					hfset.SelectedIndex=(int)read.GetValue(16)-1;
					whouploadimage.SelectedIndex=(int)read.GetValue(17)-1;
					if((int)read.GetValue(19)==1)
						uploadimageset.SelectedIndex=1;
					else
						uploadimageset.SelectedIndex=0;
					zjfuploadimage.Text=read.GetValue(18).ToString();
					headcolor.Text=read.GetValue(20).ToString();
					color1.Text=read.GetValue(21).ToString();
					color2.Text=read.GetValue(22).ToString();
					headforecolor.Text=read.GetValue(23).ToString();
					itemforecolor.Text=read.GetValue(24).ToString();
					for(int i = 0; i <pagesize.Items.Count; i++) 
					{
						if (pagesize.Items[i].Value == read["articlepage"].ToString())
						{
							pagesize.SelectedIndex = i;
						}
					}
					for(int i = 0; i <pagetype.Items.Count; i++) 
					{
						if (pagetype.Items[i].Value == read["articletype"].ToString())
						{
							pagetype.SelectedIndex = i;
						}
					}
					read.Close();
				}
				else
				{
					sql="select * from bbsset where litterno=0";
					read.Close();
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						litterpagesize=read.GetValue(1).ToString();
						for(int i = 0; i <datebasepagesize.Items.Count; i++) 
						{
							if (datebasepagesize.Items[i].Value == litterpagesize)
							{
								datebasepagesize.SelectedIndex = i;
							}
						}
						//					datebaselogo.Text=read.GetValue(2).ToString().Trim();
						//					datebaselogolj.Text=read.GetValue(3).ToString().Trim();
						//					datebasegg.Text=read.GetValue(4).ToString().Trim();
						//					datebasegglj.Text=read.GetValue(5).ToString().Trim();
						if((int)read.GetValue(9)==1)
							datebasehtml.SelectedIndex=0;
						else
							datebasehtml.SelectedIndex=1;
						if((int)read.GetValue(10)==1)
							datebaseubb.SelectedIndex=0;
						else
							datebaseubb.SelectedIndex=1;
						if((int)read.GetValue(11)==1)
							datebasescript.SelectedIndex=0;
						else
							datebasescript.SelectedIndex=1;
						if((int)read.GetValue(12)==1)
							datebaseflash.SelectedIndex=0;
						else
							datebaseflash.SelectedIndex=1;
						if((int)read.GetValue(13)==1)
							datebaseimg.SelectedIndex=0;
						else
							datebaseimg.SelectedIndex=1;
						if((int)read["zjftype"]==1)
							zjftype.SelectedIndex=0;
						else
							zjftype.SelectedIndex=1;
						zjfvalue.Text=read["zjfvalue"].ToString();
						llset.SelectedIndex=(int)read.GetValue(14)-1;
						ftset.SelectedIndex=(int)read.GetValue(15)-1;
						hfset.SelectedIndex=(int)read.GetValue(16)-1;
						whouploadimage.SelectedIndex=(int)read.GetValue(17)-1;
						if((int)read.GetValue(19)==1)
							uploadimageset.SelectedIndex=1;
						else
							uploadimageset.SelectedIndex=0;
						zjfuploadimage.Text=read.GetValue(18).ToString();
						headcolor.Text=read.GetValue(20).ToString();
						color1.Text=read.GetValue(21).ToString();
						color2.Text=read.GetValue(22).ToString();
						headforecolor.Text=read.GetValue(23).ToString();
						itemforecolor.Text=read.GetValue(24).ToString();
						for(int i = 0; i <pagesize.Items.Count; i++) 
						{
							if (pagesize.Items[i].Value == read["articlepage"].ToString())
							{
								pagesize.SelectedIndex = i;
							}
						}
						for(int i = 0; i <pagetype.Items.Count; i++) 
						{
							if (pagetype.Items[i].Value == read["articletype"].ToString())
							{
								pagetype.SelectedIndex = i;
							}
						}
					}
					else
					{

						zjfuploadimage.Text="0";
						datebasehtml.SelectedIndex=1;
						datebaseubb.SelectedIndex=0;
						datebasescript.SelectedIndex=1;
						datebaseflash.SelectedIndex=0;
						datebaseimg.SelectedIndex=0;
						llset.SelectedIndex=0;
						ftset.SelectedIndex=0;
						hfset.SelectedIndex=0;
						whouploadimage.SelectedIndex=0;
						uploadimageset.SelectedIndex=0;
						headcolor.Text=con.headcolor;
						color1.Text=con.color1;
						color2.Text=con.color2;
						headforecolor.Text=con.headforecolor;
						itemforecolor.Text=con.itemforecolor;
						zjftype.SelectedIndex=1;
						zjfvalue.Text="0";

					}
					read.Close();
				}
//			}
//			else
//			{
//				read.Close();
//				zjfuploadimage.Text="0";
//			}
			con.link.Close();
		}
		protected void changelitter(Object sender, EventArgs e)
		{
			Response.Redirect("bbsset.aspx?litterno="+type.SelectedItem.Value);
//			listpage(type.SelectedItem.Value);
		}
		protected void Page_Load(Object sender, EventArgs e)
		{
			if(!con.checksuper())
				Response.Redirect("login.aspx");
			if(!Page.IsPostBack)
			{
				string litterno=Request.QueryString["litterno"],litterpagesize;
				if(litterno==null || litterno=="")
					all.InnerHtml="����ѡ��һ�����";
				else
				{
					listpage(litterno);
				}
			}
		}
		public bbsset()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
