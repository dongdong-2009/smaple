using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;

namespace bbs
{
	/// <summary>
	/// Summary description for gltj.
	/// </summary>
	public class gltz : System.Web.UI.Page
	{
		config con=new config();
		string tomonth;
		protected string makefilename(int num)
		{ 
			int dir;
			string path;
			dir=num/1000+1;
			string filename="";
			if(con.articletype!="aspx")
				filename=dir+"/"+num+"."+con.articletype;
			else
				filename="list/list.aspx?no="+num;
			if(num%1000==1)
			{
				path=Server.MapPath(""+dir);
				Directory.CreateDirectory(path);
			}
			return filename;
		}
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			int mon,year;
			//			string tomonth;
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;

			con.open();
			string litterno="",messageno="",filename="",filename1="";
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			if(Session["user_id"]==null)
				Response.Redirect("default.aspx");
			string no=Request.QueryString["messageno"];
			if(no!=null&&no!="")
			{
				if(!con.checkbzorowner("0",no,"0"))
					Response.Redirect("default.aspx");
				else
				{
					con.open1();
					string sql="select user_id,filename,zt,litterno,hf,articletype from message where [no]="+no;
					string user_id,path;
					int zt,thislitter,hfno;
					OleDbCommand command,command1;
					OleDbCommand comread=new OleDbCommand(sql,con.link);
					OleDbDataReader ownerlist=comread.ExecuteReader();
					if(ownerlist.Read())
					{
						con.articletype=ownerlist["articletype"].ToString();
						user_id=ownerlist.GetValue(0).ToString();
						filename=ownerlist.GetValue(1).ToString();
						zt=(int)ownerlist.GetValue(2);
						thislitter=(int)ownerlist.GetValue(3);
						hfno=(int)ownerlist.GetValue(4);
						path=Server.MapPath(filename);
						litterno=ownerlist.GetValue(3).ToString();
						ownerlist.Close();
						sql="delete from message where [no]="+no;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						if(con.articletype!="aspx")
							File.Delete(path);
						sql="update bbslitter set zhutino=zhutino-1,hfno=hfno-"+hfno+" where [no]="+thislitter;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						sql="select user_id from hf_message where messageno="+no;
						command=new OleDbCommand(sql,con.link);
						ownerlist=command.ExecuteReader();
						while(ownerlist.Read())
						{
							sql="update "+con.usertable+" set hfs=hfs-1,cyf=cyf-"+con.hffs+",zjf=zjf-"+ownerlist["fs"].ToString()+" where user_id="+con.rep(ownerlist.GetValue(0).ToString());
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
							sql="update fs set zjf=zjf-"+ownerlist["fs"].ToString()+" where user_id="+con.rep(ownerlist.GetValue(0).ToString())+" and litterno="+ownerlist["litterno"].ToString()+" and month='"+tomonth+"'";
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
						}
						ownerlist.Close();
						sql="delete from hf_message where messageno="+no;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
					else
					{
						ownerlist.Close();
					}
					if(con.returnuser==Session["user_id"].ToString())
					{
						sql="update "+con.usertable+" set cyf=cyf-"+con.fbfs+",fts=fts-1 where user_id="+con.rep(con.returnuser) ;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
					else
					{
						sql="update "+con.usertable+" set fts=fts-1,cyf=cyf-"+con.delcyf+" where user_id="+con.rep(con.returnuser);
						command1=new OleDbCommand(sql,con.link);
						command1.ExecuteNonQuery();
					}
					Response.Redirect("main.aspx?litterno="+litterno);
				}
			}
//			no=Request.QueryString["hfno"];
			no=Request.Form["hfno"];
//			Response.Write(no);
			if(Request.Form["option"]=="yy")
			{

				Response.Redirect("hf.aspx?act=yy&yyno="+no+"&messageno="+Request.Form["messageno"]);
			}
			if(Request.Form["option"]=="delhf")
			{
				if(no!=null&&no!="")
				{
					if(!con.checkbzorowner("0","0",no))
						Response.Redirect("default.aspx");
					else
					{
						string sql="select user_id,litterno,messageno from hf_message where [no]="+no;
						string user_id,path;
						int thislitter;
						OleDbCommand command,command1;
						OleDbCommand comread=new OleDbCommand(sql,con.link);
						OleDbDataReader ownerlist=comread.ExecuteReader();
						if(ownerlist.Read())
						{
							user_id=ownerlist.GetValue(0).ToString();
							thislitter=(int)ownerlist.GetValue(1);
							litterno=ownerlist.GetValue(1).ToString();
							messageno=ownerlist.GetValue(2).ToString();
							ownerlist.Close();
							sql="select articletype,filename from message where [no]="+messageno;
							comread=new OleDbCommand(sql,con.link);
							ownerlist=comread.ExecuteReader();
							ownerlist.Read();
							con.articletype=ownerlist.GetValue(0).ToString();
							filename1=filename=ownerlist.GetValue(1).ToString();
							ownerlist.Close();
							sql="update bbslitter set hfno=hfno-1 where [no]="+thislitter;
							command=new OleDbCommand(sql,con.link);
							command.ExecuteNonQuery();
							sql="update message set hf=hf-1 where [no]="+messageno;
							command=new OleDbCommand(sql,con.link);
							command.ExecuteNonQuery();
							sql="delete from hf_message where [no]="+no;
							command=new OleDbCommand(sql,con.link);
							command.ExecuteNonQuery();
						}
						else
						{
							ownerlist.Close();
						}
						if(con.returnuser==Session["user_id"].ToString())
						{
							sql="update "+con.usertable+" set cyf=cyf-"+con.hffs+",hfs=hfs-1 where user_id="+con.rep(con.returnuser) ;
							command=new OleDbCommand(sql,con.link);
							command.ExecuteNonQuery();
						}
						else
						{
							sql="update "+con.usertable+" set hfs=hfs-1,cyf=cyf-"+con.delhfcyf+" where user_id="+con.rep(con.returnuser);
							command1=new OleDbCommand(sql,con.link);
							command1.ExecuteNonQuery();
						}
						//					Response.Write(litterno);
						//					Response.End();
						if(con.articletype=="shtml"||con.articletype=="html")
						{
							string filenr=con.getpage(messageno,Int32.Parse(litterno),0);
//							filename=makefilename(Int32.Parse(messageno));
//							filename1=filename;
							filename=Server.MapPath(filename);
							FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
							StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
							DateTime newtime=new DateTime(2003,01,01);
							File.SetLastWriteTime(filename,newtime);
							File.SetCreationTime(filename,newtime);
							wf.Write(filenr);
							wf.Close();
							con.link.Close();
						}
						if(con.articletype=="xml")
						{
							con.writexml(Int32.Parse(no));
						}
						Response.Redirect(filename1);
					}
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
