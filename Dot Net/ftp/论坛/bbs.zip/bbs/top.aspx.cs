using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for top.
	/// </summary>
	public class top : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid jf;
		protected System.Web.UI.WebControls.DataGrid ft;
		protected System.Web.UI.HtmlControls.HtmlGenericControl allfs;
	
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			DataSet ds;
			string sql="select top 50 user_id,cyf,fts+hfs as totlejf from "+con.usertable+" order by cyf desc";
			OleDbCommand command;
//			OleDbDataReader read;
			con.open();
			command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			jf.DataSource=ds.Tables["type"].DefaultView;
			jf.DataBind();

			sql="select top 50 user_id,cyf,fts+hfs as totlejf from "+con.usertable+" order by fts+hfs desc";
			command=new OleDbCommand(sql,con.link);
			datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			ft.DataSource=ds.Tables["type"].DefaultView;
			ft.DataBind();
			con.link.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
