using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for xg.
	/// </summary>
	public class xg : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.HtmlControls.HtmlGenericControl success;
		protected System.Web.UI.HtmlControls.HtmlGenericControl xgdiv;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl login;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.HtmlControls.HtmlInputText user_id;
		protected System.Web.UI.HtmlControls.HtmlInputText password;
		protected System.Web.UI.HtmlControls.HtmlInputText password1;
		protected System.Web.UI.HtmlControls.HtmlInputText password2;
		protected System.Web.UI.HtmlControls.HtmlInputText user_name;
		protected System.Web.UI.HtmlControls.HtmlInputText e_mail;
		protected System.Web.UI.HtmlControls.HtmlInputText dh;
		protected System.Web.UI.HtmlControls.HtmlSelect sex;
		protected System.Web.UI.HtmlControls.HtmlInputText oicq;
		protected System.Web.UI.HtmlControls.HtmlInputText dz;
		protected System.Web.UI.HtmlControls.HtmlTextArea jianjie;
		protected System.Web.UI.HtmlControls.HtmlGenericControl zhuceno;
		protected System.Web.UI.HtmlControls.HtmlInputText http;
		protected config con=new config();
	
		protected void Page_Load(object sender, EventArgs e)
		{ 
			if(!Page.IsPostBack)
			{
				xgdiv.Visible=false;
				wc.Visible=false;
			}
		}

		protected void qr(object sender, EventArgs e)
		{ 
			int i=1;
			bool j=false;
			string sql;
			string test;
			if(user_id.Value==""||password.Value=="")
			{
				i=0;
				success.InnerHtml="����ؽ�������д����";
				success.Visible=true;
			}
	
			con.open();
			sql="select * from "+con.usertable+" where user_id="+con.rep(user_id.Value)+" and password="+con.rep(password.Value);
			OleDbCommand command1=new OleDbCommand(sql,con.link);
			OleDbDataReader net_user1;
			net_user1=command1.ExecuteReader();
			j=net_user1.Read();
			if(j)
			{
				password1.Value=net_user1.GetValue(7).ToString().Trim();
				password2.Value=net_user1.GetValue(7).ToString().Trim();
				user_name.Value=net_user1.GetValue(2).ToString().Trim();
				e_mail.Value=net_user1.GetValue(3).ToString().Trim();
				http.Value=net_user1.GetValue(4).ToString().Trim();
				jianjie.Value=net_user1.GetValue(5).ToString().Trim();
				oicq.Value=net_user1.GetValue(6).ToString().Trim();
				if(net_user1.GetValue(8).ToString().Trim()=="��")
					sex.SelectedIndex=0;
				else
					sex.SelectedIndex=1;
				dz.Value=net_user1.GetValue(9).ToString().Trim();
				dh.Value=net_user1.GetValue(11).ToString().Trim();
				net_user1.Close();

				sql="select type from "+con.userdatabase+"sysconfig where valuename='usernum'";
				command1=new OleDbCommand(sql,con.link);
				net_user1=command1.ExecuteReader();
				net_user1.Read();
				zhuceno.InnerHtml="Ŀǰע���û�������"+net_user1.GetValue(0).ToString();
				net_user1.Close();
		
//				zhuceno.InnerHtml="Ŀǰע���û�������"+i.ToString();
				success.Visible=false;
				login.Visible=false;
				xgdiv.Visible=true;
			}
			else
			{
				i=0;
				success.InnerHtml="�û���������";
				success.Visible=true;
			}
			con.link.Close();
		}

		protected void qrxg(object sender,EventArgs e) 
		{ 
			string sql; 
			int i=1;
			if(password1.Value=="")
			{
				i=0;
				success.InnerHtml="�����Ϊ��";
				success.Visible=true;
				return;
			}
			if(password1.Value!=password2.Value)
			{
				i=0;
				success.InnerHtml="�����ȷ�Ͽ��ͬ";
				success.Visible=true;
				return;
			}
			if(i==1)
			{
				con.open();
				sql="update "+con.usertable+" set user_name=";
				sql=sql+con.rep(user_name.Value)+",";
				sql=sql+"e_mail="+con.rep(e_mail.Value)+",";
				sql=sql+"http="+con.rep(http.Value)+",";
				sql=sql+"jianjie="+con.rep(jianjie.Value)+",";
				sql=sql+"oicq="+con.rep(oicq.Value)+",";
				sql=sql+"password="+con.rep(password1.Value)+",";
				sql=sql+" sex="+con.rep(sex.Value);
				sql=sql+",dz="+con.rep(dz.Value);
				sql=sql+",dh="+con.rep(dh.Value);
				sql=sql+" where user_id="+con.rep(user_id.Value);

				OleDbCommand command2=new OleDbCommand(sql,con.link);
				//			success.InnerHtml=sql;	
				//			net_user1.Close();	
				command2.ExecuteNonQuery();
				success.Visible=true;
				con.link.Close();
				success.Visible=false;
				wc.Visible=true;
				xgdiv.Visible=false;
			}
	
		} 
		public xg()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
