using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for jbmanage.
	/// </summary>
	public class jbmanage : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid jb;
		protected System.Web.UI.WebControls.TextBox jf;
		protected System.Web.UI.WebControls.TextBox icon;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.TextBox jbname;
		protected System.Web.UI.WebControls.RequiredFieldValidator testname;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator2;
		protected System.Web.UI.HtmlControls.HtmlGenericControl Message;
		config con=new config();
		protected System.Web.UI.WebControls.RequiredFieldValidator testjf;
		protected System.Web.UI.WebControls.RequiredFieldValidator testicon;
		protected System.Web.UI.HtmlControls.HtmlGenericControl P1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!con.checksuper())
				Response.Redirect("login.aspx");
			if(!IsPostBack)
			{
				con.open();
				BindGrid();
				con.link.Close();
			}
		}
		protected void BindGrid() 
		{
			OleDbDataAdapter myCommand = new OleDbDataAdapter("select * from jbmanage order by jf", con.link);

			DataSet ds = new DataSet();
			myCommand.Fill(ds, "jbmanage");

			jb.DataSource=ds.Tables["jbmanage"].DefaultView;
			jb.DataBind();
		}
		protected void update(object sender, System.EventArgs e)
		{
			string sql;
			con.open();
			sql="insert into jbmanage(name,jf,icon) values("+con.rep(jbname.Text)+","+jf.Text+","+con.rep(icon.Text)+")";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			BindGrid();
			con.link.Close();
		}
		protected void MyDataGrid_Edit(Object sender, DataGridCommandEventArgs e)
		{
			con.open();
			jb.EditItemIndex = (int)e.Item.ItemIndex;
			BindGrid();
			con.link.Close();
			testname.Visible=false;
			testjf.Visible=false;
			testicon.Visible=false;
		}

		protected void MyDataGrid_Cancel(Object sender, DataGridCommandEventArgs e)
		{
			con.open();
			jb.EditItemIndex = -1;
			BindGrid();
			con.link.Close();
			testname.Visible=true;
			testjf.Visible=true;
			testicon.Visible=true;
		}

		protected void MyDataGrid_Update(Object sender, DataGridCommandEventArgs e)
		{
			con.open();
			string sql;
			if(((TextBox)e.Item.Cells[1].Controls[0]).Text==""||((TextBox)e.Item.Cells[2].Controls[0]).Text==""||((TextBox)e.Item.Cells[3].Controls[0]).Text=="")
			{
				Message.InnerHtml="�Բ�����������ݲ���ȷ";
				Message.Style["color"] = "red";
				return;
			}
			sql="update jbmanage set name=";
			sql+=con.rep(((TextBox)e.Item.Cells[1].Controls[0]).Text);
			sql+=",jf="+((TextBox)e.Item.Cells[2].Controls[0]).Text;
			sql+=",icon="+con.rep(((TextBox)e.Item.Cells[3].Controls[0]).Text);
			sql+=" where [no]="+jb.DataKeys[(int)e.Item.ItemIndex];
//			Response.Write(sql);
//			Response.End();
			OleDbCommand command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			jb.EditItemIndex = -1;
			testname.Visible=true;
			testjf.Visible=true;
			testicon.Visible=true;
			BindGrid();
			con.link.Close();
		}



		public jbmanage()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		protected void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Windows Form Designer.
			//
			InitializeComponent();
		}

		/// <summary>
		///    Required method for Designer support - do not modify
		///    the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
	}
}
