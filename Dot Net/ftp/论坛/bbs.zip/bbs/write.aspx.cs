using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;

namespace bbs
{
	/// <summary>
	/// Summary description for write.
	/// </summary>
	public class write : System.Web.UI.Page
	{
		protected int maxfs; 
		protected System.Web.UI.WebControls.Button Button6;
		protected System.Web.UI.WebControls.TextBox zhuti;
		protected System.Web.UI.WebControls.TextBox nr;
		protected System.Web.UI.WebControls.CheckBox autoadd;
		protected System.Web.UI.WebControls.TextBox fj;
		protected System.Web.UI.WebControls.Button Button5;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.CheckBox isemail;
		protected System.Web.UI.WebControls.RequiredFieldValidator testzhuti;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.WebControls.DropDownList removefile;
		protected System.Web.UI.WebControls.Button Button4;
		protected System.Web.UI.HtmlControls.HtmlGenericControl pageerror;
		protected System.Web.UI.HtmlControls.HtmlGenericControl logindiv;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.HtmlControls.HtmlInputText user_idform;
		protected System.Web.UI.HtmlControls.HtmlInputText passwordform;
		protected System.Web.UI.HtmlControls.HtmlGenericControl addwindows;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listupload1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listupload2;
		protected System.Web.UI.HtmlControls.HtmlGenericControl displayfjlink;
		protected System.Web.UI.HtmlControls.HtmlGenericControl fjwindows;
		protected System.Web.UI.HtmlControls.HtmlInputFile upload_file;
		protected System.Web.UI.HtmlControls.HtmlGenericControl photosize;
		protected System.Web.UI.HtmlControls.HtmlGenericControl displayupload;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlInputHidden totlephotosize;
		string user_id;
		protected System.Web.UI.WebControls.RadioButtonList bqselect;
		protected System.Web.UI.WebControls.Label mainwhere;
		protected System.Web.UI.WebControls.Label bbsname;
		protected System.Web.UI.WebControls.DropDownList savepassword;
		protected config con=new config();
		protected void login(Object sender, EventArgs e)
		{
			bool logintrue;
			con.open();
			logintrue=con.checklogin(user_idform.Value,passwordform.Value);
			con.link.Close();
			if(!logintrue)
			{
				pageerror.InnerHtml="�û���������";
				con.link.Close();
				return;
			}
			else
			{
				string savedate=savepassword.SelectedItem.Value;
				if(Int32.Parse(savedate)>0)
				{
					HttpCookie cookie=new HttpCookie("aspx");
					cookie["user_id"]=user_idform.Value;
					cookie["savepassword"]=savedate;
					cookie["password"]=passwordform.Value;;
					cookie.Expires=DateTime.Now.AddDays(Int32.Parse(savedate));
					Response.Cookies.Add(cookie);
				}
				con.link.Close();
				Response.Redirect("write.aspx?litterno="+Request.QueryString["litterno"]);
			}
	
		}
		public void getfj(int isauto,string fjfilename)
		{
			if(isauto==1)
				autoadd.Checked=true;
			else
				autoadd.Checked=false;

			string nr,delno,gs;
			int i,j,js;
			nr=fjfilename;
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addonefj(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addonefj(delno);
				}
			}
			fj.Text=fjfilename;
		}
		public void addonefj(string delno)
		{
			string filename;
			filename=Server.MapPath("uploadimage")+"/"+delno;
			if(File.Exists(filename))
			{
				FileStream file=new FileStream(filename,FileMode.Open);
				removefile.Items.Add(new ListItem(delno,""+file.Length));
				long intfilesize;
				long totlesize;
				totlesize=Int32.Parse(totlephotosize.Value)+file.Length;
				totlephotosize.Value=""+totlesize;
				float filesize=(float)totlesize/1024;
				intfilesize=(int)(filesize*10);
				filesize=(float)intfilesize/10;
				photosize.InnerHtml=""+filesize+"k";
				file.Close();
			}
		}

		protected void displayfj(Object sender, EventArgs e)
		{
			addwindows.Visible=false;
			fjwindows.Visible=true;
		}
		protected void selectpic(Object sender, EventArgs e)
		{
			if(removefile.SelectedItem.Value!="nodelete")
			{
				displayupload.InnerHtml="<img src=\"uploadimage/"+removefile.SelectedItem.Text+"\">";
			}
		}
		protected void listfj()
		{
			if(removefile.Items.Count>1)
			{
				fj.Text="";
				displayfjlink.InnerHtml="������������ͼƬ";
				for(int i = 1; i < removefile.Items.Count; i++) 
				{
					fj.Text+=removefile.Items[i].Text+",";
					displayfjlink.InnerHtml+=con.bbspath+"uploadimage/"+removefile.Items[i].Text+",";
				}
				fj.Text=fj.Text.Substring(0,fj.Text.Length-1);
				displayfjlink.InnerHtml=displayfjlink.InnerHtml.Substring(0,displayfjlink.InnerHtml.Length-1);
			}
			else
			{
				fj.Text="";
				displayfjlink.InnerHtml="��û������ͼƬ";
			}
		}

		protected void remove(Object sender, EventArgs e)
		{
			int totlesize=0;
			if(removefile.SelectedItem.Value!="nodelete")
			{
				if(removefile.Items.Count==2)
				{
					photosize.InnerHtml="0.0k";
					totlephotosize.Value="0";
				}
				else
				{
					totlesize=Int32.Parse(totlephotosize.Value)-Int32.Parse(removefile.SelectedItem.Value);
					totlephotosize.Value=""+totlesize;
					float filesize=(float)totlesize/1024;
					int intfilesize=(int)(filesize*10);
					filesize=(float)intfilesize/10;
					photosize.InnerHtml=""+filesize+"k";
				}
		
				string removefilename=removefile.SelectedItem.Text;
				string removefilesize=removefile.SelectedItem.Value;
				removefile.Items.Remove(new ListItem(removefilename,removefilesize));
				removefilename=Server.MapPath("uploadimage")+"/"+removefilename;
				File.Delete(removefilename);
				displayupload.InnerHtml="";
			}
		}

		protected void displayadd(Object sender, EventArgs e)
		{
			addwindows.Visible=true;
			fjwindows.Visible=false;
			listfj();
		}

		protected void upload(Object sender, EventArgs e)
		{
			int errorno=0;
	
			if(upload_file.PostedFile==null)
			{
				wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
				errorno=1;
			}
			else
			{
				if(upload_file.PostedFile.FileName.Length<3)
				{
					wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
					errorno=1;
				}
				else
				{
					if(upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3).ToLower()!="gif" && upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3).ToLower()!="jpg" )
					{
						wc.InnerHtml="ͼƬ��ʽֻ���� jpg,gif���ָ�ʽ,���ϴ���ͼƬ��ʽ����";
						errorno=1;
					}
					if(upload_file.PostedFile.ContentLength==0)
					{
						wc.InnerHtml="����ѡ��һ��ͼƬ�ٵ�ճ��";
						errorno=1;
					}
					if(upload_file.PostedFile.ContentLength>600000)
					{
						wc.InnerHtml="ͼƬ��С�޶���600K����";
						errorno=1;
					}
				}
			}
			if(errorno==0)
			{
				string path=Server.MapPath("uploadimage");
				string filename=DateTime.Now.ToString();
				filename=filename.Replace(":","");
				filename=filename.Replace("-","");
				filename=filename.Replace(" ","");
				Random r=new Random();
				filename=filename+r.Next(1000);
				filename=filename+"."+upload_file.PostedFile.FileName.Substring(upload_file.PostedFile.FileName.Length-3);
		
				removefile.Items.Add(new ListItem(filename,""+upload_file.PostedFile.ContentLength));
				displayupload.InnerHtml="<img src=\"uploadimage/"+filename+"\">";
		
				filename=path+"/"+filename;
				upload_file.PostedFile.SaveAs(filename);
				wc.Visible=false;
				int intfilesize;
				int totlesize;
				totlesize=Int32.Parse(totlephotosize.Value)+upload_file.PostedFile.ContentLength;
				totlephotosize.Value=""+totlesize;
				float filesize=(float)totlesize/1024;
				intfilesize=(int)(filesize*10);
				filesize=(float)intfilesize/10;
				photosize.InnerHtml=""+filesize+"k";
			}
			else
			{
				wc.Visible=true;
			}
		}
		protected void Page_Load(object sender, EventArgs e)
		{ 
			con.open();
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			string sql,litterno;
			int kyf;
			user_id=(string)Session["user_id"];
			litterno=Request.QueryString["litterno"];
			bbsname.Text=con.bbsname;
			if(litterno=="" || litterno==null)
			{
				pageerror.InnerHtml="���������ȵ���Ӧ����Ŀ��";
				logindiv.Visible=false;
				list.Visible=false;
				return;
			}
			if(user_id==null || user_id=="")
			{
				//			pageerror.InnerHtml="����δ��¼���������<a href=\"default.aspx\">��¼</a>";
				//			pageerror.Visible=true;
				list.Visible=false;
				logindiv.Visible=true;
				return;
			}
			con.getbbsset(litterno,"0");
			OleDbCommand command;
			OleDbDataReader read;
			sql="select name from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mainwhere.Text="<a href=\"main.aspx?litterno="+litterno+"\">"+read.GetValue(0).ToString()+"</a>";
			}
			read.Close();


			if(con.ftset==2)
			{
				if(Session["hy"]==null)
				{
					list.Visible=false;
					logindiv.Visible=false;

					pageerror.InnerHtml="�Բ�����û���ڴ˰淢����Ȩ��";
					return;
				}
			}
			if(con.ftset==3)
			{
				if(Session["hy"]==null||((int)Session["hy"]!=3&&(int)Session["hy"]!=4&&(int)Session["hy"]!=5))
				{
					list.Visible=false;
					logindiv.Visible=false;
					pageerror.InnerHtml="�Բ�����û���ڴ˰淢����Ȩ��";
					return;
				}
			}
			if(con.ftset==4)
			{
				if(Session["hy"]==null||((int)Session["hy"]!=4&&(int)Session["hy"]!=5))
				{
					list.Visible=false;
					logindiv.Visible=false;
					pageerror.InnerHtml="�Բ�����û���ڴ˰淢����Ȩ��";
					return;
				}
			}
			if(con.ftset==5)
			{
				if(Session["hy"]==null||(int)Session["hy"]!=5)
				{
					list.Visible=false;
					logindiv.Visible=false;
					pageerror.InnerHtml="�Բ�����û���ڴ˰淢����Ȩ��";
					return;
				}
			}


			if(!Page.IsPostBack)
			{
				fjwindows.Visible=false;
				list.Visible=true;
				logindiv.Visible=false;
//				user_idform.Visible=false;
//				passwordform.Visible=false;
				int no;
				int zjf=0,canupload=0;
				DateTime today,lastday;
				TimeSpan howday;
				string messageno=Request.QueryString["no"];
				if(messageno!=null&&messageno!="")
				{
					if(!con.checkbzorowner("0",messageno,"0"))
					{
						Response.Redirect("default.aspx");
					}
					else
					{
						sql="select * from message where [no]="+messageno;
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						if(read.Read())
						{
							zhuti.Text=read["zhuti"].ToString();
							nr.Text=read["nr"].ToString();
							getfj((int)read["autoaddimage"],read["uploadimage"].ToString());
							Button2.Text="�޸�";
						}
					}
				}

				if(con.uploadimageset==2)
				{
					if(zjf>=con.zjfuploadimage)
						canupload=1;
					if(con.whouploadimage==1)
						canupload=1;
					if(con.whouploadimage==2&&Session["key"]!=null&&(Session["key"].ToString()=="check1"||Session["key"].ToString()=="check2"||Session["key"].ToString()=="super"))
						canupload=1;
					if(con.whouploadimage==3&&Session["key"]!=null&&(Session["key"].ToString()=="check1"||Session["key"].ToString()=="super"))
						canupload=1;
					if(con.whouploadimage==3&&Session["key"]!=null&&Session["key"].ToString()=="super")
						canupload=1;
				}
				else
				{
					if(zjf>=con.zjfuploadimage)
					{
						if(con.whouploadimage==1)
							canupload=1;
						if(con.whouploadimage==2&&Session["key"]!=null&&(Session["key"].ToString()=="check1"||Session["key"].ToString()=="check2"||Session["key"].ToString()=="super"))
							canupload=1;
						if(con.whouploadimage==3&&Session["key"]!=null&&(Session["key"].ToString()=="check1"||Session["key"].ToString()=="super"))
							canupload=1;
						if(con.whouploadimage==3&&Session["key"]!=null&&Session["key"].ToString()=="super")
							canupload=1;
					}
				}
				if(canupload==0)
				{
					listupload1.Visible=false;
					listupload2.Visible=false;
				}
				con.link.Close();
			}
		}
		protected void add(object sender, EventArgs e)
		{ 
//			con.open();
			string litterno,typeid,sql,bq,ip,filename,mbid="0";
			int num,bigno,zt,email,liuyan,fs=0;
			litterno=Request.QueryString["litterno"];
			OleDbCommand command;
			OleDbDataReader read;
	
			if(user_id==null || user_id=="")
			{
				//			pageerror.InnerHtml="����δ��¼���������<a href=\"default.aspx\">��¼</a>";
				//			pageerror.Visible=true;
				list.Visible=false;
				logindiv.Visible=true;
				return;
			}
			sql="select bigno,mbid from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				bigno=(int)read.GetValue(0);
				mbid=read.GetValue(1).ToString();
			}
			else
				bigno=1;
			read.Close();
			sql="select bigno,mbid from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				bigno=(int)read.GetValue(0);
				mbid=read.GetValue(1).ToString();
			}
			else
				bigno=1;
			read.Close();
			typeid=Request.QueryString["typeid"];
			bq="<img src=\"images/emotion/"+bqselect.SelectedItem.Value+".gif\">";
			if(isemail.Checked)
				email=1;
			else
				email=0;
			liuyan=0;
			int autoaddimage;
			if(autoadd.Checked==true)
				autoaddimage=1;
			else
				autoaddimage=0;
			ip=Request.ServerVariables["REMOTE_ADDR"];
			filename="11";
			string no=Request.QueryString["no"];
			if(no==null||no=="")
			{
				if(con.zjftype==1&&con.zjfvalue>0)
				{
					sql="select fs from "+con.usertable+" where user_id="+con.rep(user_id);
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						fs=(int)read.GetValue(0);
					}
					else
						fs=0;
					read.Close();
					if(fs<con.zjfvalue)
					{
						pageerror.InnerHtml="�Բ������Ŀ��÷��Ѳ����ڴ˰�����";
						con.link.Close();
						return;
					}
					sql="update "+con.usertable+" set fs=fs-"+con.zjfvalue+" where user_id="+con.rep(user_id);
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					
				}

				
				if(con.zjftype==1&&con.zjfvalue>0)
					sql="insert into message(user_id,hf,zhuti,nr,bigno,litterno,date_time,bq,hits,ip,ise_mail,isliuyan,zt,fs,allnr,filename,newtime,isjhq,autoaddimage,uploadimage,qx,newuser,toporder,topimage,editmessage,lock,mbid,articletype,gftype) values("+con.rep(user_id)+",0,"+con.rep(zhuti.Text)+","+con.rep(nr.Text)+","+bigno+","+litterno+",'"+DateTime.Now+"',"+con.rep(con.bq1)+",0,'"+Request.ServerVariables["REMOTE_ADDR"]+"',"+email+","+liuyan+",0,"+con.zjfvalue+","+con.rep(nr.Text)+",'"+filename+"','"+DateTime.Now+"',0,"+autoaddimage+","+con.rep(fj.Text)+","+con.ztset+","+con.rep(user_id)+",2,'"+con.newimage+"',null,0,"+mbid+",'"+con.articletype+"',"+con.zjftype+")";
				else
					sql="insert into message(user_id,hf,zhuti,nr,bigno,litterno,date_time,bq,hits,ip,ise_mail,isliuyan,zt,fs,allnr,filename,newtime,isjhq,autoaddimage,uploadimage,qx,newuser,toporder,topimage,editmessage,lock,mbid,articletype,gftype) values("+con.rep(user_id)+",0,"+con.rep(zhuti.Text)+","+con.rep(nr.Text)+","+bigno+","+litterno+",'"+DateTime.Now+"',"+con.rep(bq)+",0,'"+Request.ServerVariables["REMOTE_ADDR"]+"',"+email+","+liuyan+",0,"+con.zjfvalue+","+con.rep(nr.Text)+",'"+filename+"','"+DateTime.Now+"',0,"+autoaddimage+","+con.rep(fj.Text)+","+con.ztset+","+con.rep(user_id)+",2,'"+con.newimage+"',null,0,"+mbid+",'"+con.articletype+"',"+con.zjftype+")";
//				Response.Write(sql);
//				Response.End();
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="select [no] from message order by [no] desc";
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					num=(int)read.GetValue(0);
				}
				else
					num=1;
				read.Close();
				filename=makefilename(num);
				sql="update message set filename="+con.rep(filename)+" where [no]="+num;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				makepage(num,filename,litterno);

				sql="update "+con.usertable+" set cyf=cyf+"+con.fbfs+",fts=fts+1 where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update bbslitter set zhutino=zhutino+1 where [no]="+litterno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				con.link.Close();
				Response.Redirect(filename);
				wc.InnerHtml=filename;
			}
			else
			{
				if(!con.checkbzorowner("0",no,"0"))
					Response.Redirect("default.aspx");
				filename=makefilename(Int32.Parse(no));
				string editmessage="�����ڣ�"+DateTime.Now+"��"+user_id+"�༭��";
				if(con.zjftype==1&&con.zjfvalue>0)
				{
					sql="update message set zhuti="+con.rep(zhuti.Text)+",nr="+con.rep(nr.Text)+",ip='"+Request.ServerVariables["REMOTE_ADDR"]+"',newtime='"+DateTime.Now+"',autoaddimage="+autoaddimage+",uploadimage="+con.rep(fj.Text)+",newuser="+con.rep(user_id)+",editmessage="+con.rep(editmessage)+" where [no]="+no;
				}
				else
				{
					sql="update message set zhuti="+con.rep(zhuti.Text)+",nr="+con.rep(nr.Text)+",bq="+con.rep(bq)+",ip='"+Request.ServerVariables["REMOTE_ADDR"]+"',newtime='"+DateTime.Now+"',autoaddimage="+autoaddimage+",uploadimage="+con.rep(fj.Text)+",newuser="+con.rep(user_id)+",editmessage="+con.rep(editmessage)+" where [no]="+no;
				}
				//				Response.Write(sql);
//				Response.End();
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				makepage(Int32.Parse(no),filename,litterno);
				Response.Redirect(filename);
			}
//			Response.Write(sql);
//			Response.End();
		}
		protected string makefilename(int num)
		{ 
			int dir;
			string path;
			dir=num/1000+1;
			string filename="";
			if(con.articletype!="aspx")
				filename=dir+"/"+num+"."+con.articletype;
			else
				filename="list/list.aspx?no="+num;
			if(num%1000==1)
			{
				path=Server.MapPath(""+dir);
				Directory.CreateDirectory(path);
			}
			return filename;
		}
		protected void makepage(int num,string filename,string litterno)
		{ 

			if(con.articletype=="shtml"||con.articletype=="html")
			{
				string mbnr="",littername="",sql,filenr="",contentnr;
				int mbid=0;
				contentnr=con.getpage(num.ToString(),Int32.Parse(litterno),0);
				filename=Server.MapPath(filename);

					FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(contentnr);
					wf.Close();
				//				File.SetCreationTime(filename,newtime);
//				File.SetLastAccessTime(filename,newtime);
			}
			if(con.articletype=="xml")
			{
				con.writexml(num);
			}
		}
		public write()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}


		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
