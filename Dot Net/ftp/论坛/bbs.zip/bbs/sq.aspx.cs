using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for sq.
	/// </summary>
	public class sq : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList litter;
		protected System.Web.UI.WebControls.TextBox why;
		protected System.Web.UI.WebControls.TextBox dw;
		protected System.Web.UI.WebControls.TextBox time;
		protected System.Web.UI.WebControls.TextBox http;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl error;
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected config con=new config();
	
		protected void Page_Load(Object sender, EventArgs e)
		{
			if(Session["user_id"]==null || Session["user_id"].ToString()=="")
			{
				error.InnerHtml="���ȵ�¼";
				all.Visible=false;
			}
			else
			{
				if(!Page.IsPostBack)
				{
					con.open();
					string type,sql;
					type=Request.QueryString["type"];
//					if(type=="new")
//						newlist.Checked=true;
//					if(type=="old")
//						oldlist.Checked=true;
					OleDbCommand command;
					OleDbDataReader read;
					sql="select [no],name from bbslitter";
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					int i=0;
					while(read.Read())
					{
						litter.Items.Add(new ListItem(read.GetValue(1).ToString().Trim(),read.GetValue(0).ToString()));
						if(read.GetValue(0).ToString()==Request.QueryString["litterno"])
						{
							litter.SelectedIndex = i;
						}
						i++;
					}
					read.Close();
					con.link.Close();
				}
			}
		}
		protected void add(Object sender, EventArgs e)
		{
			con.open();
			int errorno=0,no;
			string sql,user_id,ownertype;
			OleDbDataReader read;
			OleDbCommand command;
			user_id=Session["user_id"].ToString();
/*
			if(newlist.Checked==true)
			{
				if(littername.Text=="")
				{
					error.InnerHtml+="�����������д<br>";
					errorno=1;
				}
				if(why.Text=="")
				{
					error.InnerHtml+="�������ɱ�����д<br>";
					errorno=1;
				}
				if(littername.Text=="")
				{
					error.InnerHtml+="������ҳ������д";
					errorno=1;
				}
		
				sql="select no from bbssq where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					error.InnerHtml+="���Ѿ��ύ��һ������<br>";
					errorno=1;
				}
				read.Close();
		
				sql="select no from mfbbs.qzren.bbslitter where owner1="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					error.InnerHtml+="���Ѿ�������һ����̳<br>";
					errorno=1;
				}
				read.Close();
		
				if(errorno==0)
				{
					sql="insert bbssq values("+con.rep(user_id)+","+con.rep(why.Text)+","+con.rep(dw.Text)+","+con.rep(time.Text)+",1,"+con.rep(littername.Text)+",'"+DateTime.Now+"','owner1',0,"+con.rep(http.Text)+",'���������̳')";
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					//			error.InnerHtml+=sql;
					all.InnerHtml="����ɹ�,��ȴ�����Ա������ͨ,�����ͨ��,���Զ���Ϣ���ʼ��ķ�ʽ֪ͨ��,��ע�����";
				}
			}
			if(oldlist.Checked==true)
			{
*/				if(why.Text=="")
				{
					error.InnerHtml+="�������ɱ�����д<br>";
					errorno=1;
				}
		
				sql="select [no] from bbssq where user_id="+con.rep(user_id)+" and litterno="+litter.SelectedItem.Value;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					error.InnerHtml+="���Ѿ��ύ��һ������<br>";
					errorno=1;
				}
				read.Close();
		
//				sql="select [no] from bbssq order by [no] desc";
//				command=new OleDbCommand(sql,con.link);
//				read=command.ExecuteReader();
//				if(read.Read())
//				{
//					no=(int)read.GetValue(0)+1;
//				}
//				else
//				{
//					no=1;
//				}
//				read.Close();
				if(errorno==0)
				{
					if(Request.QueryString["ownertype"]==null)
					{
						sql="select owner1 from bbslitter where [no]="+litter.SelectedItem.Value;
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						read.Read();
						ownertype="����������,��ǰ����Ϊ��"+read.GetValue(0).ToString();
						sql="insert into bbssq(user_id,why,loves,howday,new,bt,date_time,ownertype,litterno,http,sm) values("+con.rep(user_id)+","+con.rep(why.Text)+","+con.rep(dw.Text)+","+con.rep(time.Text)+",0,null,'"+DateTime.Now+"','owner1',"+litter.SelectedItem.Value+","+con.rep(http.Text)+","+con.rep(ownertype)+")";
					}
					else
					{
						if(Request.QueryString["ownertype"]=="owner1")
						{
							sql="select owner1 from bbslitter where [no]="+litter.SelectedItem.Value;
							command=new OleDbCommand(sql,con.link);
							read=command.ExecuteReader();
							read.Read();
							ownertype="����������,��ǰ����Ϊ��"+read.GetValue(0).ToString();
							sql="insert into bbssq(user_id,why,loves,howday,new,bt,date_time,ownertype,litterno,http,sm) values("+con.rep(user_id)+","+con.rep(why.Text)+","+con.rep(dw.Text)+","+con.rep(time.Text)+",0,null,'"+DateTime.Now+"','owner1',"+litter.SelectedItem.Value+","+con.rep(http.Text)+","+con.rep(ownertype)+")";
						}
						if(Request.QueryString["ownertype"]=="owner2")
						{
							sql="select owner2 from bbslitter where [no]="+litter.SelectedItem.Value;
							command=new OleDbCommand(sql,con.link);
							read=command.ExecuteReader();
							read.Read();
							ownertype="���븱����,��ǰ����Ϊ��"+read.GetValue(0).ToString();
							sql="insert into bbssq(user_id,why,loves,howday,new,bt,date_time,ownertype,litterno,http,sm) values("+con.rep(user_id)+","+con.rep(why.Text)+","+con.rep(dw.Text)+","+con.rep(time.Text)+",0,null,'"+DateTime.Now+"','owner2',"+litter.SelectedItem.Value+","+con.rep(http.Text)+","+con.rep(ownertype)+")";
						}
						if(Request.QueryString["ownertype"]=="owner3")
						{
							sql="select owner3 from bbslitter where [no]="+litter.SelectedItem.Value;
							command=new OleDbCommand(sql,con.link);
							read=command.ExecuteReader();
							read.Read();
							ownertype="���븱����,��ǰ����Ϊ��"+read.GetValue(0).ToString();
							sql="insert into bbssq(user_id,why,loves,howday,new,bt,date_time,ownertype,litterno,http,sm) values("+con.rep(user_id)+","+con.rep(why.Text)+","+con.rep(dw.Text)+","+con.rep(time.Text)+",0,null,'"+DateTime.Now+"','owner3',"+litter.SelectedItem.Value+","+con.rep(http.Text)+","+con.rep(ownertype)+")";
						}
					}
					read.Close();
//					Response.Write(sql);
//					Response.End();
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					//			error.InnerHtml+=sql;
					error.Visible=false;
					all.InnerHtml="����ɹ�,��ȴ�����Ա������ͨ,�����ͨ��,���Զ���Ϣ���ʼ��ķ�ʽ֪ͨ��,��ע�����";
				}
//			}
		}
		public sq()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
