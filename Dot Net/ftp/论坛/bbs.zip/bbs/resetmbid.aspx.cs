using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for resetmbid.
	/// </summary>
	public class resetmbid : System.Web.UI.Page
	{
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			OleDbCommand command,command1;
			OleDbDataReader read;
			string sql;
			con.open();
			con.open1();
			sql="select [no],mbid from bbslitter";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				sql="update message set mbid="+read.GetValue(1).ToString()+" where litterno="+read.GetValue(0).ToString();
				command=new OleDbCommand(sql,con.link1);
				command.ExecuteNonQuery();
			}
			read.Close();
			sql="select litterno,articletype from bbsset where [no]<>0";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				sql="update message set articletype='"+read.GetValue(1).ToString()+"' where litterno="+read.GetValue(0).ToString();
				command=new OleDbCommand(sql,con.link1);
				command.ExecuteNonQuery();
			}
			read.Close();
			con.link.Close();
			con.link1.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
