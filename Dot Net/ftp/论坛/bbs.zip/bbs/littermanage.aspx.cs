using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for littermanage.
	/// </summary>
	public class littermanage : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList type;
		protected System.Web.UI.WebControls.TextBox name;
		protected System.Web.UI.WebControls.DropDownList mb;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl errornr;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listadd;
		protected System.Web.UI.WebControls.TextBox orderno;
		protected System.Web.UI.WebControls.TextBox sm;
		protected System.Web.UI.WebControls.TextBox Textbox1;
		protected System.Web.UI.WebControls.Label parname;
	
		protected config con=new config();
		protected int checkowner(string checkownerstr)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql;
			int no;
			sql="select user_id from "+con.usertable+" where user_id="+con.rep(checkownerstr);
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
				no=0;
			else
				no=1;
			read.Close();
			return(no);
		}

		protected void add(object sender, EventArgs e)
		{
			string par=Request.QueryString["par"];
			string listtype=Request.QueryString["listtype"];
			int error=0;
			if(name.Text==""||name.Text=="")
			{
				errornr.InnerHtml="����ȷ������";
			}
			else
			{
				string sql,nr="",ownerstr1,ownerstr2,ownerstr3;
				OleDbCommand command;
				con.open();
/*				ownerstr1=owner1.Text;
				if(ownerstr1=="")
					ownerstr1="admin";
				else
				{
					error=checkowner(ownerstr1);
					if(error==1)
						errornr.InnerHtml="�����û�"+ownerstr1+"������";
				}
				ownerstr2=owner2.Text;
				if(ownerstr2=="")
					ownerstr2="admin";
				else
				{
					error=checkowner(ownerstr2);
					if(error==1)
						errornr.InnerHtml="�����û�"+ownerstr1+"������";
				}
				ownerstr3=owner3.Text;
				if(ownerstr3=="")
					ownerstr3="admin";
				else
				{
					error=checkowner(ownerstr3);
					if(error==1)
						errornr.InnerHtml="�����û�"+ownerstr1+"������";
				}
		
*/				if(error==0)
				{
					if(par==null||par=="")
						par="0";
					string bignostr;
//					bignostr=type.SelectedItem.Value;
//					if(par!="0")
//						bignostr="0";

					if(orderno.Text=="")
						sql="insert into bbslitter(bigno,name,owner1,owner2,owner3,mbid,zhutino,hfno,wcno,zerono,orderno,sm,par) values(1,"+con.rep(name.Text)+",'admin','admin','admin',"+mb.SelectedItem.Value+",0,0,0,0,1,"+con.rep(sm.Text)+","+type.SelectedItem.Value+")";
					else
						sql="insert into bbslitter(bigno,name,owner1,owner2,owner3,mbid,zhutino,hfno,wcno,zerono,orderno,sm,par) values(1,"+con.rep(name.Text)+",'admin','admin','admin',"+mb.SelectedItem.Value+",0,0,0,0,"+orderno.Text+","+con.rep(sm.Text)+","+type.SelectedItem.Value+")";
//					Response.Write(sql);
//					Response.End();
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					listpage();
					con.makepage();
					errornr.InnerHtml="�������ɹ�";
				}
				con.makepage();
				con.link.Close();
				Response.Redirect("littermanage.aspx?par="+Request.QueryString["par"]);
			}
		
		}
			
		protected void Page_Load(object sender, EventArgs e)
		{ 
			string par=Request.QueryString["par"];
			string listtype=Request.QueryString["listtype"];
			if(!con.checksuper())
			{
				list.InnerHtml="�Բ���,��ʹ���й���Ȩ�޵��ʺŵ�¼";
				return;
			}
			string no,options,owner;
			string sql;
			OleDbCommand command;
			string bigno;
//			bigno=Request.QueryString["bigno"];
//			if(bigno==null||bigno=="")
//				listadd.Visible=false;
//			else
//				listadd.Visible=true;
			options=Request["changetype"];
			con.open();
			if(options=="del")
			{
				no=Request.QueryString["typeid"];
				sql="delete from bbslitter where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="delete from message where litterno="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="delete from hf_message where litterno="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="delete from bbsset where litterno="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="delete from bbssq where litterno="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
//				con.makepage();
				Response.Redirect("littermanage.aspx?par="+Request.QueryString["par"]);
			}
			if(options=="editname")
			{
				no=Request.Form["typeid"];
				sql="update bbslitter set name="+con.rep(Request.Form["name"])+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
//				con.makepage();
			}
			if(options=="editsm")
			{
				no=Request.Form["typeid"];
				sql="update bbslitter set sm="+con.rep(Request.Form["name"])+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
//				con.makepage();
			}
			if(options=="editowner1")
			{
				owner=Request.Form["owner"];
				if(owner!=""&&owner!=null)
				{
					if(checkowner(owner)==0)
					{
						no=Request.Form["typeid"];
						sql="update bbslitter set owner1="+con.rep(owner)+" where [no]="+no;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
				}
				//		con.link.Close();
				//		Response.Redirect("littermanage.aspx");
			}
			if(options=="editowner2")
			{
				owner=Request.Form["owner"];
				if(owner!=""&&owner!=null)
				{
					if(checkowner(owner)==0)
					{
						no=Request.Form["typeid"];
						sql="update bbslitter set owner2="+con.rep(owner)+" where [no]="+no;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
				}
				//		con.link.Close();
				//		Response.Redirect("littermanage.aspx");
			}
			if(options=="editowner3")
			{
				owner=Request.Form["owner"];
				if(owner!=""&&owner!=null)
				{
					if(checkowner(owner)==0)
					{
						no=Request.Form["typeid"];
						sql="update bbslitter set owner3="+con.rep(owner)+" where [no]="+no;
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
				}
				//		con.link.Close();
				//		Response.Redirect("littermanage.aspx");
			}

			if(options=="editorderno")
			{
				no=Request.Form["typeid"];
				sql="update bbslitter set orderno="+Request.Form["orderno"]+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}

			if(options=="editmb")
			{
				no=Request.Form["typeid"];
				sql="update bbslitter set mbid="+Request.Form["typeselect"]+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				//		Response.Redirect("lm.aspx?bignum="+Request.Form["bignumform"]); 
			}
			if(options=="editbig")
			{
				no=Request.Form["typeid"];
				sql="update bbslitter set par="+Request.Form["typeselect"]+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

//				sql="update message set bigno="+Request.Form["typeselect"]+" where litterno="+no;
//				command=new OleDbCommand(sql,con.link);
//				command.ExecuteNonQuery();
//
//				sql="update hf_message set bigno="+Request.Form["typeselect"]+" where litterno="+no;
//				command=new OleDbCommand(sql,con.link);
//				command.ExecuteNonQuery();

//				sql="update bbsset set bigno="+Request.Form["typeselect"]+" where litterno="+no;
//				command=new OleDbCommand(sql,con.link);
//				command.ExecuteNonQuery();

				//		Response.Redirect("lm.aspx?bignum="+Request.Form["bignumform"]); 
			}

			if(!Page.IsPostBack)
			{
				sql="select name,[no] from bbslitter";
				command=new OleDbCommand(sql,con.link);
				OleDbDataReader read=command.ExecuteReader();
				type.Items.Add(new ListItem("��Ŀ¼","0"));
				int i=0,j=0;
				while(read.Read())
				{
					i++;
					if(read.GetValue(1).ToString()==par)
						j=i;
					type.Items.Add(new ListItem(read.GetValue(0).ToString().Trim(),read.GetValue(1).ToString()));
				}
				type.SelectedIndex=j;
				read.Close();
				listpage();
				con.link.Close();	
			}
	
			//	no=Request.QueryString["no"];
	
		}
		protected void listpage()
		{
			string sql,nr="",mb1="";
			string listtype=Request.QueryString["listtype"];
			OleDbCommand command;
			OleDbDataReader read;
			string bigno,bigno1="";

			if(!Page.IsPostBack)
			{
//				bigno=Request["bigno"];
//				if(bigno==null||bigno=="")
//				{
//					bigno1="0";
//					bigno="";
//				}
//				else
//				{
//					bigno1=bigno;
//					if(bigno=="0")
//						bigno="";
//					else
//						bigno=" where bigno="+bigno;
//				}
				sql="select [no],name from bbsmb";
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				while(read.Read())
				{
					mb.Items.Add(new ListItem(read.GetValue(1).ToString().Trim(),read.GetValue(0).ToString()));
				}
				read.Close();
			}
/*			else
			{
				bigno=type.SelectedItem.Value;
				if(bigno=="0")
				{
					bigno="";
					bigno1="0";
				}
				else
				{
					bigno1=bigno;
					bigno=" where bigno="+bigno;
					listadd.Visible=true;
				}
			}
			*/
			string par;
			par=Request.QueryString["par"];
			bigno="";
			if(par==null||par=="")
				par="0";
			bigno=" where par="+par;
/*
			if(par!=null&&par!="")
			{
				//				if(bigno.Length<5)
				//					bigno=bigno+" where par="+par;
				//				else
				//					bigno=bigno+" and par="+par;
				bigno="where par="+par;
				if(par=="0")
					parname.Text="��Ŀ¼������Ŀ";
				else
				{
					sql="select name from bbslitter where no="+par;
					command=new OleDbCommand(sql,con.link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						parname.Text=read["name"].ToString()+"������Ŀ";
					}
					read.Close();
				}
			}
			else
			{
				par="0";
			}
*/	
			nr="				<table cellSpacing=\"1\" cellPadding=\"0\" width=\"100%\" border=\"1\">";
			nr+="					<tr>";
			nr+="						<td width=\"30\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">ID</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">��Ŀ��</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">��Ŀ˵��</font>";
			nr+="							</div>";
			nr+="						</td>";
/*			nr+="						<td width=\"70\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">������</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"100\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">������</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"100\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">������</font>";
			nr+="							</div>";
			nr+="						</td>";
*/			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">�������</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">ģ��</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"70\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">���</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">����</font>";
			nr+="							</div>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">����</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">����Ŀ</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="						<td width=\"140\" bgColor=\"#304d7c\">";
			nr+="							<div align=\"center\">";
			nr+="								<font color=\"#ffffff\">ɾ��</font>";
			nr+="							</div>";
			nr+="						</td>";
			nr+="					</tr>";
	
			OleDbCommand command1;
			OleDbDataReader ownerlist;
			con.open2();
			if(Request.QueryString["listtype"]=="all")
				sql="select [no],name,owner1,owner2,owner3,bigno,mbid,orderno,sm,par from bbslitter";
			else
				sql="select [no],name,owner1,owner2,owner3,bigno,mbid,orderno,sm,par from bbslitter"+bigno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				nr+="<tr valign=center>";
				nr+="<td align=center>"+read.GetValue(0)+"</td>";
				nr+="<td align=center valign=center>";
				nr+="<form method=\"post\" action=\"littermanage.aspx?par="+par+"&listtype="+listtype+"\" ><input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editname\">";
				nr+="<input type=\"text\" name=\"name\" size=\"14\" value=\""+read.GetValue(1)+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
				nr+="<td align=center valign=center>";
				nr+="<form method=\"post\" action=\"littermanage.aspx?par="+par+"&listtype="+listtype+"\" ><input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editsm\">";
				nr+="<input type=\"text\" name=\"name\" size=\"14\" value=\""+read["sm"].ToString()+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
/*				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editowner1\">";
				nr+="<input type=\"hidden\" name=\"bigno\" value=\""+bigno1+"\">";
				nr+="<input type=\"text\" name=\"owner\" size=\"6\" value=\""+read.GetValue(2)+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editowner2\">";
				nr+="<input type=\"hidden\" name=\"bigno\" value=\""+bigno1+"\">";
				nr+="<input type=\"text\" name=\"owner\" size=\"6\" value=\""+read.GetValue(3)+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"bigno\" value=\""+bigno1+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editowner3\">";
				nr+="<input type=\"text\" name=\"owner\" size=\"6\" value=\""+read.GetValue(4)+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
*/
				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx?par="+par+"&listtype="+listtype+"\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editbig\">";
				sql="select [no],name from bbslitter";
				command1=new OleDbCommand(sql,con.link2);
				ownerlist=command1.ExecuteReader();
				mb1="<select class=\"unnamed2\" name=\"typeselect\" size=\"1\">";
				mb1+="<option value='0' name=mbselect selected>��Ŀ¼</option>";
				while(ownerlist.Read())
				{
					if(read["par"].ToString()==ownerlist.GetValue(0).ToString())
						mb1+="<option value='"+ownerlist.GetValue(0).ToString()+"' name=mbselect selected>"+ownerlist.GetValue(1).ToString()+"</option>";
					else
						mb1+="<option value='"+ownerlist.GetValue(0).ToString()+"' name=mbselect>"+ownerlist.GetValue(1).ToString()+"</option>";
				}
				mb1+="</select>";
				nr+=mb1;
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form></td>";
				ownerlist.Close();

				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx?par="+par+"&listtype="+listtype+"\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editmb\">";
				sql="select [no],name from bbsmb";
				command1=new OleDbCommand(sql,con.link2);
				ownerlist=command1.ExecuteReader();
				mb1="<select class=\"unnamed2\" name=\"typeselect\" size=\"1\">";
				while(ownerlist.Read())
				{
					if(read.GetValue(6).ToString()==ownerlist.GetValue(0).ToString())
						mb1+="<option value='"+ownerlist.GetValue(0).ToString()+"' name=mbselect selected>"+ownerlist.GetValue(1).ToString()+"</option>";
					else
						mb1+="<option value='"+ownerlist.GetValue(0).ToString()+"' name=mbselect>"+ownerlist.GetValue(1).ToString()+"</option>";
				}
				mb1+="</select>";
				nr+=mb1;
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form></td>";
				ownerlist.Close();
				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx?par="+par+"&listtype="+listtype+"\">";
				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editorderno\">";
				nr+="<input type=\"text\" name=\"orderno\" size=\"2\" value=\""+read.GetValue(7)+"\">";
				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
				nr+="</form>";
				nr+="</td>";
//				nr+="<td valign=center><form method=\"post\" action=\"littermanage.aspx\">";
//				nr+="<input type=\"hidden\" name=\"typeid\" value=\""+read.GetValue(0)+"\">";
//				nr+="<input type=\"hidden\" name=\"bigno\" value=\""+bigno1+"\">";
//				nr+="<input type=\"hidden\" name=\"changetype\" value=\"editorderno\">";
//				nr+="<input type=\"text\" name=\"orderno\" size=\"2\" value=\""+read.GetValue(7)+"\">";
//				nr+="<input type=\"submit\" name=\"Submit\" value=\"��\">";
//				nr+="</form>";
//				nr+="</td>";
				nr+="<td align=center><a href=\"bbsset.aspx?litterno="+read.GetValue(0).ToString()+"\">����</a></td>";
				nr+="<td align=center><a href=\"adminmain.aspx?litterno="+read.GetValue(0).ToString()+"\">����</a></td>";
				nr+="<td align=center><a href=\"littermanage.aspx?par="+read.GetValue(0).ToString()+"\">����Ŀ</a></td>";
				nr+="<td align=center><a href=\"littermanage.aspx?par="+par+"&listtype="+listtype+"&changetype=del&typeid="+read.GetValue(0)+"\">ɾ��</a></td>";
				nr+="</tr>";
			}
			listall.InnerHtml=nr;
			read.Close();
		}
		protected void selectbig(object sender, EventArgs e)
		{ 
//			con.open();
//			listpage();
//			con.link.Close();
			Response.Redirect("littermanage.aspx?bigno="+type.SelectedItem.Value);
		}
		public littermanage()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
