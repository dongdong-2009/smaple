using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for send.
	/// </summary>
	public class send : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label listuser;
		protected System.Web.UI.WebControls.TextBox title;
		protected System.Web.UI.WebControls.TextBox nr;
		protected System.Web.UI.WebControls.Button button1;
		protected System.Web.UI.WebControls.Label ly;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e)
		{
			string user_id,sql;
			user_id=Request.QueryString["user_id"];
			if(Session["user_id"]==null||Session["user_id"].ToString()=="")
			{
				wc.InnerHtml="���ȵ�¼";
				listall.InnerHtml="";
				return;
			}
			if(user_id==null||user_id=="")
			{
				listall.InnerHtml="������";
				return;
			}
			ly.Text="<a href=\"bp.aspx?type=new&user_id="+user_id+"\">"+"<font color=#ffffff>��������</font></a>";
			listuser.Text=user_id;
		}
		protected void sendmail(Object sender, EventArgs e)
		{
			string user_id;
			user_id=Request.QueryString["user_id"];
			if(title.Text==""||nr.Text=="")
				wc.InnerHtml="��ѱ���������";
			else
			{
				con.open();
				con.sendtouser(con.getadmin_mail(),user_id,title.Text,nr.Text,0);
				con.link.Close();
				wc.InnerHtml="��ϲ�����ͳɹ�";
				listall.InnerHtml="";
			}
		}	
		public send()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
