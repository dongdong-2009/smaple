using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace bbs
{
	/// <summary>
	/// Summary description for Cdefault.
	/// </summary>
	public class Cdefault : System.Web.UI.Page
	{
		public config con=new config();
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlContainerControl chklogdiv;
		protected System.Web.UI.WebControls.TextBox user_id;
		protected System.Web.UI.HtmlControls.HtmlGenericControl chklog;
		protected System.Web.UI.WebControls.Label bbsname;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.HtmlControls.HtmlForm Form2;
		protected System.Web.UI.WebControls.DropDownList savepassword;
		protected System.Web.UI.WebControls.TextBox password;

		protected void Page_Load(Object sender, EventArgs e)
		{
			bool logintrue;
			string user_id,password;
			if(!Page.IsPostBack)
			{
				user_id=Request.Form["user_id"];
				password=Request.Form["password"];
				bbsname.Text=con.bbsname;
				if(user_id!=null&&password!=null)
				{
					con.open();
					logintrue=con.checklogin(user_id,password);
					con.link.Close();
					if(logintrue)
					{
						Response.Redirect("index.aspx");
					}
					else
					{
						wc.Visible=true;
						wc.InnerHtml="�û���������";
					}
				}
			}
	
		}

		protected void login(Object sender, EventArgs e)
		{
			bool logintrue;
			con.open();
			logintrue=con.checklogin(user_id.Text,password.Text);
			con.link.Close();
			if(logintrue)
			{
				string savedate=savepassword.SelectedItem.Value;
				if(Int32.Parse(savedate)>0)
				{
					HttpCookie cookie=new HttpCookie("aspx");
					cookie["user_id"]=user_id.Text;
					cookie["savepassword"]=savedate;
					cookie["password"]=password.Text;;
					cookie.Expires=DateTime.Now.AddDays(Int32.Parse(savedate));
					Response.Cookies.Add(cookie);
				}
				Response.Redirect("index.aspx");
			}
			else
			{
				wc.Visible=true;
				wc.InnerHtml="�û���������";
			}
	
		}

		public Cdefault()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
