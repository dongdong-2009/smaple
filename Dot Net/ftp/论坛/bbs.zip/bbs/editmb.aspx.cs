using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Text;
namespace bbs
{
	/// <summary>
	/// Summary description for editmb.
	/// </summary>
	public class editmb : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox mbname;
		protected System.Web.UI.WebControls.TextBox mbnr;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.DropDownList mbtype;
		protected config con=new config();
	
		protected void edit(object sender, EventArgs e)
		{ 
			if(!con.checksuper())
				Response.Redirect("login.aspx");
			con.open();
			string user_id,sql,id,filename,xmlnr;
			int no;
			OleDbCommand command;
			OleDbDataReader reader;
			user_id=(String)Session["user"];
			FileStream writefile;
			StreamWriter wf;

			id=Request.QueryString["id"];
			if(id!=null)
			{
				sql="update bbsmb set name="+con.rep(mbname.Text)+",nr="+con.rep(mbnr.Text)+",mbtype='"+mbtype.SelectedItem.Value+"' where [no]="+id;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				if(mbtype.SelectedItem.Value=="xml")
				{
					xmlnr="<?xml version=\"1.0\" encoding=\"gb2312\"?>\r\n<?xml-stylesheet type=\"text/xsl\" href=\"../message"+id+".xsl\"?>\r\n<Message></Message>";
					filename=Server.MapPath("message"+id+".xml");
					writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(xmlnr);
					wf.Close();
					filename=Server.MapPath("message"+id+".xsl");
					writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(mbnr.Text);
					wf.Close();
				}
				wc.InnerHtml="�޸������";
			}
			else
			{
				sql="insert into bbsmb(nr,name,mbtype) values("+con.rep(mbnr.Text)+","+con.rep(mbname.Text)+",'"+mbtype.SelectedItem.Value+"')";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				if(mbtype.SelectedItem.Value=="xml")
				{
					sql="select [no] from bbsmb order by [no] desc";
					command=new OleDbCommand(sql,con.link);
					reader=command.ExecuteReader();
					reader.Read();
					filename=Server.MapPath("message"+reader.GetValue(0).ToString()+".xsl");
					writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(mbnr.Text);
					wf.Close();

					xmlnr="<?xml version=\"1.0\" encoding=\"gb2312\"?>\r\n<?xml-stylesheet type=\"text/xsl\" href=\"../message"+reader["no"].ToString()+".xsl\"?>\r\n<Message></Message>";
					filename=Server.MapPath("message"+reader.GetValue(0).ToString()+".xml");
					writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(xmlnr);
					wf.Close();
				}
				wc.InnerHtml="���ӳɹ�";
			}
			listall.Visible=false;
			con.link.Close();
		}
		protected void Page_Load(object sender, EventArgs e)
		{ 
			con.open();
			string user_id,sql,id;
			OleDbCommand command;
			OleDbDataReader reader;

			id=Request.QueryString["id"];
			if(id!=null)
			{
				if(!Page.IsPostBack)
				{
					sql="select * from bbsmb where [no]="+id;
					command=new OleDbCommand(sql,con.link);
					reader=command.ExecuteReader();
					if(reader.Read())
					{
						mbname.Text=reader.GetValue(2).ToString().Trim();
						mbnr.Text=reader.GetValue(1).ToString().Trim();
						Button1.Text="�޸�";
						for(int i=0;i<mbtype.Items.Count;i++)
						{
							if(mbtype.Items[i].Value==reader.GetValue(3).ToString())
							{
								mbtype.SelectedIndex=i;
							}
						}
					}
					reader.Close();
				}
			}
			con.link.Close();
	
		}
		public editmb()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
