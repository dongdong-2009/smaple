using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// systemset ��ժҪ˵����
	/// </summary>
	public class systemset : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox usertable;
		protected System.Web.UI.WebControls.TextBox userdatabase;
		protected System.Web.UI.WebControls.TextBox bbsname;
		protected System.Web.UI.WebControls.TextBox zjkyf;
		protected System.Web.UI.WebControls.TextBox ftdf;
		protected System.Web.UI.WebControls.TextBox hfdf;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		protected System.Web.UI.WebControls.TextBox kyf;
		protected System.Web.UI.WebControls.TextBox lldf;
		protected System.Web.UI.WebControls.TextBox bq1;
		protected System.Web.UI.WebControls.TextBox bq2;
		protected System.Web.UI.WebControls.TextBox delfs;
		protected System.Web.UI.WebControls.TextBox delcyf;
		protected System.Web.UI.WebControls.TextBox delhffs;
		protected System.Web.UI.WebControls.TextBox delhfcyf;
		protected System.Web.UI.WebControls.TextBox jhfs;
		protected System.Web.UI.WebControls.TextBox jhcyf;
		protected System.Web.UI.WebControls.TextBox tgfs;
		protected System.Web.UI.WebControls.TextBox tgcyf;
		protected System.Web.UI.WebControls.TextBox changefs;
		protected System.Web.UI.WebControls.TextBox jshead;
		protected System.Web.UI.WebControls.TextBox bbspath;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.TextBox deluser;
		config con=new config();
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!con.checksuper())
				Response.Redirect("admin.aspx");
			if(!Page.IsPostBack)
			{
				OleDbCommand command;
				OleDbDataReader read;
				string sql;
				sql="select * from bbssystemset";
				con.open();
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					usertable.Text=read["usertable"].ToString();
					userdatabase.Text=read["userdatabase"].ToString();
					bbsname.Text=read["bbsname"].ToString();
					zjkyf.Text=read["zjkyf"].ToString();
					ftdf.Text=read["ftdf"].ToString();
					hfdf.Text=read["hfdf"].ToString();
					kyf.Text=read["kyf"].ToString();
					lldf.Text=read["lldf"].ToString();
					bq1.Text=read["bq1"].ToString();
					bq2.Text=read["bq2"].ToString();
					delfs.Text=read["delfs"].ToString();
					delcyf.Text=read["delcyf"].ToString();
					delhffs.Text=read["delhffs"].ToString();
					delhfcyf.Text=read["delhfcyf"].ToString();
					jhfs.Text=read["jhfs"].ToString();
					jhcyf.Text=read["jhcyf"].ToString();
					tgfs.Text=read["tgfs"].ToString();
					tgcyf.Text=read["tgcyf"].ToString();
					changefs.Text=read["changefs"].ToString();
					jshead.Text=read["jshead"].ToString();
					bbspath.Text=read["bbspath"].ToString();
					deluser.Text=read["deluser"].ToString();
				}
				else
				{
					usertable.Text=con.usertable;
					userdatabase.Text=con.userdatabase;
					bbsname.Text=con.bbsname;
					zjkyf.Text=con.dayfs.ToString();
					ftdf.Text=con.fbfs.ToString();
					hfdf.Text=con.hffs.ToString();
					kyf.Text=con.defaultfs.ToString();
					lldf.Text=con.llfs.ToString();
					bq1.Text=con.bq1;
					bq2.Text=con.bq2;
					delfs.Text=con.delfs.ToString();
					delcyf.Text=con.delcyf.ToString();
					delhffs.Text=con.delhffs.ToString();
					delhfcyf.Text=con.delhfcyf.ToString();
					jhfs.Text=con.jhfs.ToString();
					jhcyf.Text=con.jhcyf.ToString();
					tgfs.Text=con.tg1addfs.ToString();
					tgcyf.Text=con.tg1addcyf.ToString();
					changefs.Text=con.changecyftofs.ToString();
					jshead.Text=con.jshead;
					bbspath.Text=con.bbspath;
					deluser.Text=con.deluser.ToString();
				}
			}
		}
		protected void update(object sender, System.EventArgs e)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql;
			sql="select * from bbssystemset";
			con.open();
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				read.Close();
				sql="update bbssystemset set ";
				sql=sql+"usertable="+con.rep(usertable.Text)+",";
				sql=sql+"userdatabase="+con.rep(userdatabase.Text)+",";
				sql=sql+"bbsname="+con.rep(bbsname.Text)+",";
				sql=sql+"zjkyf="+zjkyf.Text+",";
				sql=sql+"ftdf="+ftdf.Text+",";
				sql=sql+"hfdf="+hfdf.Text+",";
				sql=sql+"kyf="+kyf.Text+",";
				sql=sql+"lldf="+lldf.Text+",";
				sql=sql+"bq1="+con.rep(bq1.Text)+",";
				sql=sql+"bq2="+con.rep(bq2.Text)+",";
				sql=sql+"delfs="+delfs.Text+",";
				sql=sql+"delcyf="+delcyf.Text+",";
				sql=sql+"delhffs="+delhffs.Text+",";
				sql=sql+"delhfcyf="+delhfcyf.Text+",";
				sql=sql+"jhfs="+jhfs.Text+",";
				sql=sql+"jhcyf="+jhcyf.Text+",";
				sql=sql+"tgfs="+tgfs.Text+",";
				sql=sql+"tgcyf="+tgcyf.Text+",";
				sql=sql+"changefs="+changefs.Text+",";
				sql=sql+"jshead="+con.rep(jshead.Text)+",";
				sql=sql+"bbspath="+con.rep(bbspath.Text)+",";
				sql=sql+"deluser="+deluser.Text;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			else
			{
				read.Close();
				sql="insert into bbssystemset(usertable,userdatabase,bbsname,zjkyf,ftdf,hfdf,kyf,lldf,bq1,bq2,delfs,delcyf,delhffs,delhfcyf,jhfs,jhcyf,tgfs,tgcyf,changefs,jshead,bbspath,deluser) values(";
				sql=sql+con.rep(usertable.Text)+",";
				sql=sql+con.rep(userdatabase.Text)+",";
				sql=sql+con.rep(bbsname.Text)+",";
				sql=sql+zjkyf.Text+",";
				sql=sql+ftdf.Text+",";
				sql=sql+hfdf.Text+",";
				sql=sql+kyf.Text+",";
				sql=sql+lldf.Text+",";
				sql=sql+con.rep(bq1.Text)+",";
				sql=sql+con.rep(bq2.Text)+",";
				sql=sql+delfs.Text+",";
				sql=sql+delcyf.Text+",";
				sql=sql+delhffs.Text+",";
				sql=sql+delhfcyf.Text+",";
				sql=sql+jhfs.Text+",";
				sql=sql+jhcyf.Text+",";
				sql=sql+tgfs.Text+",";
				sql=sql+tgcyf.Text+",";
				sql=sql+changefs.Text+",";
				sql=sql+con.rep(jshead.Text)+",";
				sql=sql+con.rep(bbspath.Text)+",";
				sql=sql+deluser.Text;
				sql=sql+")";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			con.link.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN���õ����� ASP.NET Web ���������������ġ�
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
