using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for mb.
	/// </summary>
	public class mb : System.Web.UI.Page
	{
		protected DataSet ds;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden typeid;
		protected config con=new config();
		protected void Page_Load(object sender, EventArgs e)
		{ 
			if(!con.checksuper())
			{
				list.InnerHtml="�Բ���,��ʹ���й���Ȩ�޵��ʺŵ�¼";
				return;
			}
			con.open();
			string user_id,sql,delid;
			OleDbCommand command;
			OleDbDataReader reader;
	
			delid=Request.QueryString["delid"];
			if(delid!=null)
			{
				sql="delete from bbsmb where [no]="+delid;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}

			sql="select [no],name from bbsmb";
			command=new OleDbCommand(sql,con.link);
			OleDbDataAdapter datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
		}
		public mb()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
