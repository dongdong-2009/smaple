using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for plss.
	/// </summary>
	public class plss : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox delnr;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.DropDownList deltype;
		protected System.Web.UI.HtmlControls.HtmlGenericControl sm;
		protected System.Web.UI.HtmlControls.HtmlGenericControl all;
		config con=new config();
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string litterno=Request.QueryString["litterno"];
			if(!Page.IsPostBack)
			{
				if(litterno==null||litterno=="")
				{
					if(!con.checksuper())
					{
						all.InnerHtml="�Բ�����û��Ȩ��";
						return;
					}
				}
				else
				{
					con.open();
					if(!con.checkbz(litterno,"0"))
					{
						all.InnerHtml="�Բ�����û��Ȩ��";
						return;
					}
					con.link.Close();
				}
			}

				// Put user code to initialize the page here
		}
		protected void del(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			OleDbCommand command,command1;
			OleDbDataReader read;
			string sql;
			string litterno=Request.QueryString["litterno"];
			if(delnr.Text=="")
			{
				sm.InnerHtml="������ؼ���";
				return;
			}
			if(litterno==null||litterno=="")
			{
				if(!con.checksuper())
				{
					all.InnerHtml="�Բ�����û��Ȩ��";
					return;
				}
				else
				{
					con.open();
					if(deltype.SelectedItem.Value=="user_id")
					{
						sql="delete from message where user_id="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						sql="delete from message where user_id="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
					if(deltype.SelectedItem.Value=="zhuti")
					{
						con.open1();
						sql="select [no] from message where zhuti="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						while(read.Read())
						{
							sql="delete from hf_message where no="+read["no"].ToString();
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
						}
						read.Close();
						sql="delete from message where zhuti="+con.rep(delnr.Text);
						command1=new OleDbCommand(sql,con.link1);
						command1.ExecuteNonQuery();
						con.link1.Close();
					}
					if(deltype.SelectedItem.Value=="nr")
					{
						con.open1();
						sql="select [no] from message where nr="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						while(read.Read())
						{
							sql="delete from hf_message where no="+read["no"].ToString();
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
						}
						read.Close();
						sql="delete from message where nr="+con.rep(delnr.Text);
						command1=new OleDbCommand(sql,con.link1);
						command1.ExecuteNonQuery();
						con.link1.Close();
					}
					con.getlittervalue();
					con.link.Close();
				}
			}
			else
			{
				if(!con.checkbz(litterno,"0"))
				{
					all.InnerHtml="�Բ�����û��Ȩ��";
					return;
				}
				else
				{
					con.open();
					if(deltype.SelectedItem.Value=="user_id")
					{
						sql="delete from message where litterno="+litterno+" and user_id="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
						sql="delete from message where litterno="+litterno+" and user_id="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						command.ExecuteNonQuery();
					}
					if(deltype.SelectedItem.Value=="zhuti")
					{
						con.open1();
						sql="select [no] from message where litterno="+litterno+" and zhuti="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						while(read.Read())
						{
							sql="delete from hf_message where litterno="+litterno+" and where no="+read["no"].ToString();
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
						}
						read.Close();
						sql="delete from message where zhuti="+con.rep(delnr.Text);
						command1=new OleDbCommand(sql,con.link1);
						command1.ExecuteNonQuery();
						con.link1.Close();
					}
					if(deltype.SelectedItem.Value=="nr")
					{
						con.open1();
						sql="select [no] from message where litterno="+litterno+" and nr="+con.rep(delnr.Text);
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						while(read.Read())
						{
							sql="delete from hf_message where litterno="+litterno+" and no="+read["no"].ToString();
							command1=new OleDbCommand(sql,con.link1);
							command1.ExecuteNonQuery();
						}
						read.Close();
						sql="delete from message where nr="+con.rep(delnr.Text);
						command1=new OleDbCommand(sql,con.link1);
						command1.ExecuteNonQuery();
						con.link1.Close();
					}
					con.getlittervalue();
					con.link.Close();
				}
			}
			sm.InnerHtml="ɾ���ɹ�";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
