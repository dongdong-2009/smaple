using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bbs
{
	/// <summary>
	/// Summary description for gl.
	/// </summary>
	public class gl : System.Web.UI.Page
	{
		string you_user_id;
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e)
		{
			string no,filename="",owner1,owner2,owner3,owner="",options,listnr="",sql;
			int litterno=0,bigno=0,mbid=0,rightzf=0;
			no=Request.QueryString["no"];
			if(no=="" || no==null)
				Response.Redirect("error.aspx?nr=�Ƿ�����");
			if(!con.checksuper())
				Response.Redirect("admin.aspx");
			con.open();
			OleDbCommand command;
			OleDbDataReader read;

			sql="select litterno,bigno,filename,user_id,fs from message where [no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				litterno=(int)read.GetValue(0);
				bigno=(int)read.GetValue(1);
				filename=(string)read.GetValue(2);
				owner=(string)read.GetValue(3);
				rightzf=(int)read.GetValue(4);
			}
			else
			{
				con.link.Close();
				Response.Redirect("error.aspx?nr=�Ƿ�����");
			}
			read.Close();
	
			if(Request.QueryString["move"]=="1")
			{
				sql="select bigno from bbslitter where [no]="+Request.QueryString["litterno"];
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				int tobigno=0;
				if(read.Read())
				{
					tobigno=(int)read.GetValue(0);
				}
				read.Close();
				sql="select zt from message where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				int messagebz=0;
				if(read.Read())
				{
					messagebz=(int)read.GetValue(0);
				}
				read.Close();
				if(messagebz==3)
				{
					sql="update bbslitter set zhutino=zhutino-1,zerono=zerono-1 where [no]="+litterno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					sql="update bbslitter set zhutino=zhutino+1,zerono=zerono+1 where [no]="+Request.QueryString["litterno"];
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					sql="update message set litterno="+Request.QueryString["litterno"]+",bigno="+tobigno+",zt=1 where [no]="+no;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					sql="update bbslitter set zhutino=zhutino-1 where [no]="+litterno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					sql="update bbslitter set zhutino=zhutino+1 where [no]="+Request.QueryString["litterno"];
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
					sql="update message set litterno="+Request.QueryString["litterno"]+",bigno="+tobigno+" where [no]="+no;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				litterno=Int32.Parse(Request.QueryString["litterno"]);
				makefile(no);
				//		Response.Redirect(filename);
			}
	

			you_user_id=(string)Session["user_id"];
			if(you_user_id=="" || you_user_id==null)
				Response.Redirect(filename);

			sql="select owner1,owner2,owner3,mbid from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				owner1=read.GetValue(0).ToString();
				owner2=read.GetValue(1).ToString();
				owner3=read.GetValue(2).ToString();
				mbid=(int)read.GetValue(3);
				if(con.ismanage==0)
				{
					if(you_user_id!=owner)
						Response.Redirect(filename);
				}		
				if(con.ismanage==1)
				{
					if(you_user_id!=owner && you_user_id!="admin")
						Response.Redirect(filename);
				}		
				if(con.ismanage==2)
				{
					if(you_user_id!=owner && you_user_id!=owner1 && you_user_id!="admin")
						Response.Redirect(filename);
				}		
				if(con.ismanage==3)
				{
					if(you_user_id!=owner && you_user_id!=owner1 && you_user_id!=owner2 && you_user_id!=owner3 && you_user_id!="admin")
						Response.Redirect(filename);
				}		
			}
			else
			{
				con.link.Close();
				Response.Redirect("error.aspx?nr=���ݿ����");
			}
			read.Close();
			options=Request.Form["options"];
			if(options=="gf")
				gf(no,rightzf,filename);
			int jfsuccess=1;
			if(options=="jf" && Request.Form["tzjf"]!=null && Request.Form["tzjf"]!="")
				jfsuccess=jf(no);
			if(jfsuccess==0)
			{
				Response.Write("<div align=center>���ķ��ѳ��������ܸ�������</div>");
			}
			else
			{
				listnr=con.getpage(no,litterno,1);
				Response.Write(listnr);
			}
			con.link.Close();
		}

		protected void gf(string no,int rightzf,string filename)
		{ 
			int zf=0,fs,hfno,litterno=0,isyou,fsno=0,bigno=0;
			string onefs,sql,user_id="",ip,getcookie;
			OleDbCommand command,command1;
			OleDbDataReader read,read1;
			int mon,year;
			string tomonth;
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;
			sql="select [no],user_id,ip,litterno,bigno from hf_message where messageno="+no+" and user_id<>"+con.rep(you_user_id);
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				isyou=0;
				hfno=(int)read.GetValue(0);
				onefs=Request.Form["gl"+hfno];
				ip=(string)read.GetValue(2);
				zf+=Int32.Parse(onefs);
				litterno=(int)read.GetValue(3);
				bigno=(int)read.GetValue(4);
			}
			read.Close();
			if(zf!=rightzf)
			{
				Response.Write("<div align=\"center\">���ֺͲ�����"+rightzf+"</div>");
				Response.End();
			}
			read=command.ExecuteReader();
			con.open2();
			while(read.Read())
			{
				onefs=Request.Form["gl"+(int)read.GetValue(0)];
				user_id=(string)read.GetValue(1);
				fs=Int32.Parse(onefs);
				if(fs>0)
				{
					sql="update "+con.usertable+" set zjf=zjf+"+fs+" where user_id="+con.rep(user_id);
					command1=new OleDbCommand(sql,con.link2);
					command1.ExecuteNonQuery();

					sql="update hf_message set fs="+fs+" where [no]="+(int)read.GetValue(0);
					command1=new OleDbCommand(sql,con.link2);
					command1.ExecuteNonQuery();

					sql="select month,user_id from fs where user_id="+con.rep(user_id)+" and month='"+tomonth+"' and litterno="+litterno;
					command=new OleDbCommand(sql,con.link2);
					read1=command.ExecuteReader();
					if(read1.Read())
					{
						read1.Close();
						sql="update fs set zjf=zjf+"+fs+" where user_id="+con.rep(user_id)+" and month='"+tomonth+"' and litterno="+litterno;
						command1=new OleDbCommand(sql,con.link2);
						command1.ExecuteNonQuery();
					}
					else
					{
						read1.Close();
						sql="insert fs values("+litterno+",'"+tomonth+"',0,"+fs+","+con.rep(user_id)+","+bigno+")";
						command1=new OleDbCommand(sql,con.link2);
						command1.ExecuteNonQuery();
					}

					sql="insert mydf values("+con.rep(user_id)+","+no+")";
					command1=new OleDbCommand(sql,con.link2);
					command1.ExecuteNonQuery();
				}
			}
			sql="update message set zt=2,bq="+con.rep(con.bq2)+" where [no]="+no;
			command1=new OleDbCommand(sql,con.link2);
			command1.ExecuteNonQuery();
			con.link2.Close();
			read.Close();
			makefile(no);
			Response.Redirect(filename);
		}
		protected int jf(string no)
		{ 
			int success;
			string sql;
			OleDbCommand command;
			OleDbDataReader read;
			sql="select fs from message where [no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			int kyf,maxfs=0,fs=0;
			if(read.Read())
			{
				fs=(int)read.GetValue(0);
			}
			read.Close();
			sql="select fs,cyf from "+con.usertable+" where user_id="+con.rep(Session["user_id"].ToString());
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				kyf=(int)read.GetValue(0);
				maxfs=con.ftmrf+(int)read.GetValue(1)/con.ftmrfrate;
				maxfs=maxfs-fs;
				if(maxfs>kyf)
					maxfs=kyf;
				if(maxfs<0)
					maxfs=0;
			}
			read.Close();
			if(Int32.Parse(Request.Form["tzjf"])>maxfs)
			{
				return(0);
			}
			else
			{
				sql="update "+con.usertable+" set fs=fs-"+Request.Form["tzjf"]+" where user_id="+con.rep(Session["user_id"].ToString());
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update message set fs=fs+"+Request.Form["tzjf"]+" where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				makefile(no);
				return(1);
			}
		}


		protected void makefile(string no)
		{ 
			string filename="",sql,contentnr;
			int mbid=0,litterno=0;
			OleDbCommand command;
			OleDbDataReader read;
			sql="select bbslitter.mbid,bbslitter.[no],message.filename from bbslitter,message where bbslitter.[no]=message.litterno and message.[no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbid=(int)read.GetValue(0);
				litterno=(int)read.GetValue(1);
				filename=(string)read.GetValue(2);
			}
			read.Close();

			contentnr=con.getpage(no,litterno,0);
			filename=Server.MapPath(filename);
			FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
			StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(contentnr);
			wf.Close();
		}
		public gl()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
