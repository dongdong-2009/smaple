using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for listuser.
	/// </summary>
	public class listuser : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label dlcs;
		protected System.Web.UI.WebControls.Label sex;
		protected System.Web.UI.WebControls.Label fts;
		protected System.Web.UI.WebControls.Label hfs;
		protected System.Web.UI.WebControls.Label http;
		protected System.Web.UI.WebControls.Label zjf;
		protected System.Web.UI.WebControls.Label cyf;
		protected System.Web.UI.WebControls.Label jianjie;
		protected System.Web.UI.WebControls.Label send;
		protected System.Web.UI.WebControls.Label ly;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected System.Web.UI.WebControls.Label jhfs;
		protected System.Web.UI.WebControls.Label del;
		protected System.Web.UI.WebControls.Label delhf;
		protected System.Web.UI.WebControls.Label ishy;
		protected System.Web.UI.WebControls.Label usertype;
		protected System.Web.UI.WebControls.Label lockuser;
		protected System.Web.UI.WebControls.Label zcrq;
		protected System.Web.UI.WebControls.Label lastdl;
		protected System.Web.UI.WebControls.Label kyf;
	
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e)
		{
			string user_id,sql;
			user_id=Request.QueryString["user_id"];
			if(user_id==null||user_id=="")
			{
				listall.InnerHtml="������";
				return;
			}
			con.open();
			OleDbCommand command;
			OleDbDataReader read;
			sql="select * from "+con.usertable+" where user_id="+con.rep(user_id);
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				dlcs.Text="<font color=red>"+read["dlcs"].ToString()+"</font>";
				if(read["sex"].ToString()=="��")
					sex.Text="���";
				else
					sex.Text="����";
				http.Text=read["http"].ToString();
				fts.Text=read["fts"].ToString();
				hfs.Text=read["hfs"].ToString();
				zjf.Text=read["zjf"].ToString();
				cyf.Text=read["cyf"].ToString();
				jhfs.Text=read["jhfs"].ToString();
				del.Text=read["del"].ToString();
				delhf.Text=read["delhf"].ToString();
				kyf.Text=read["fs"].ToString();
				if(read["ishy"].ToString()=="1")
					ishy.Text="��";
				else
					ishy.Text="��";
				if(read["usertype"].ToString()=="1")
					usertype.Text="��";
				else
					usertype.Text="��";
				if(read["canlogin"].ToString()=="1")
					lockuser.Text="�";
				else
					lockuser.Text="����";
//				jhfs.Text=read["jhff"].ToString();
				jianjie.Text=con.texttohtml(read["jianjie"].ToString());
				zcrq.Text=read["date_time"].ToString();
				lastdl.Text=read["dateandtime"].ToString();
				send.Text="<a href=\"send.aspx?user_id="+user_id+"\">"+"<font color=#ffffff>�������ʼ�</font></a>";
				ly.Text="<a href=\"bp.aspx?type=new&user_id="+user_id+"\">"+"<font color=#ffffff>��������</font></a>";
			}
			else
			{
				listall.InnerHtml="������";
				return;
			}
		}
		public listuser()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
