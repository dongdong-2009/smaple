using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for js.
	/// </summary>
	public class js : System.Web.UI.Page
	{
		config con=new config();
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string sql,no,listtype,litterno,nr="";
			litterno=Request.QueryString["litterno"];
			no=Request.QueryString["no"];
			listtype=Request.QueryString["listtype"];
			if(listtype!="hits")
				listtype="date_time";
			if(litterno!=null&&litterno!="")
				litterno=" where litterno="+litterno+" and qx=1";
			else
				litterno=" where qx=1";
			con.open();
			con.getbbsset("0","0");
			sql="select top "+no+" zhuti,filename from message "+litterno+" order by "+listtype+" desc";
			OleDbCommand command;
			OleDbDataReader read;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				nr+=con.jshead+"<a href=\""+con.bbspath+read.GetValue(1).ToString()+"\">"+read.GetValue(0).ToString()+"</a><br>";
			}
			read.Close();
			con.link.Close();
			nr=nr="document.write('"+nr+"');";
			Response.Write(nr);
			con.link.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
