using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace bbs
{
	/// <summary>
	/// Summary description for login.
	/// </summary>
	public class login : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox user_id;
		protected System.Web.UI.WebControls.TextBox password;
		protected System.Web.UI.WebControls.Button ȷ��;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl loginform;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.Label bbsname;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.HtmlControls.HtmlGenericControl chklog;
		protected System.Web.UI.HtmlControls.HtmlForm Form2;
	
		protected config con=new config();
		protected void loginclick(object sender, EventArgs e)
		{ 
			con.open();
			if(con.checklogin(user_id.Text,password.Text))
			{
				con.link.Close();
				if(Session["key"]==null||(Session["key"].ToString()!="super" && Session["key"].ToString()!="check1" && Session["key"].ToString()!="check2"))
					Response.Redirect("login.aspx");
				else
					Response.Redirect("admin.aspx");
			}
			else
			{
				wc.Visible=true;
				wc.InnerHtml="�û���������";
			}
			con.link.Close();
		}

		public login()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}
		protected void Page_Load(object sender, EventArgs e)
		{ 
			bbsname.Text=con.bbsname;
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
