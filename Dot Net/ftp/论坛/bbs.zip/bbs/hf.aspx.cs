using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bbs
{
	/// <summary>
	/// Summary description for hf.
	/// </summary>
	public class hf : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox Content;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl success;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.HtmlControls.HtmlInputText user_idform;
		protected System.Web.UI.HtmlControls.HtmlInputText passwordform;
		protected System.Web.UI.HtmlControls.HtmlInputHidden newsid;
		protected System.Web.UI.WebControls.DropDownList savepassword;
		protected System.Web.UI.WebControls.Label loginsm;
		protected System.Web.UI.HtmlControls.HtmlGenericControl logindiv;
	
		protected config con=new config();

		protected void login(Object sender, EventArgs e)
		{
			bool logintrue;
			string hfno=Request.QueryString["no"];
			string yyno=Request.QueryString["yyno"];
/*			if(yyno!=null&&yyno!="")
			{
				con.open();
				write(Content.Text,newsid.Value);
				con.link.Close();
			}
			else
			{
*/				if(hfno==null||hfno=="")
				{
					con.open();
					if((string)Session["user_id"]==null||(string)Session["user_id"]=="")
					{
						logintrue=con.checklogin(user_idform.Value,passwordform.Value);
						if(logintrue)
						{
							//				con.getbbsset("0",newsid.Value);
							string savedate=savepassword.SelectedItem.Value;
							if(Int32.Parse(savedate)>0)
							{
								HttpCookie cookie=new HttpCookie("aspx");
								cookie["user_id"]=user_idform.Value;
								cookie["savepassword"]=savedate;
								cookie["password"]=passwordform.Value;;
								cookie.Expires=DateTime.Now.AddDays(Int32.Parse(savedate));
								Response.Cookies.Add(cookie);
							}
							write(Content.Text,newsid.Value);
						}
						else
							success.InnerHtml="��¼ʧ��";
					}
					else
					{
						write(Content.Text,newsid.Value);
					}
					con.link.Close();
				}
				else
				{
					con.open();
					write(Content.Text,newsid.Value);
					con.link.Close();
				}
//			}
	
		}
		protected void write(string hfnr,string no)
		{
			string user_id,sql,allnr="",filename="",articletype="shtml",filename1="";
			int litterno=0,num,bigno=0,hf=0,mbid,locktype=0;
//			hfnr=con.changechr(hfnr);
			user_id=(string)Session["user_id"];
			if(user_id==null||user_id=="")
			{
				logindiv.Visible=true;
				return;
			}
			OleDbCommand command;
			OleDbDataReader read;
			sql="select litterno,allnr,bigno,filename,hf,articletype,lock from message where [no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				litterno=(int)read.GetValue(0);
				bigno=(int)read.GetValue(2);
				allnr=read.GetValue(1).ToString();
				filename1=filename=read.GetValue(3).ToString();
				hf=(int)read.GetValue(4);
				articletype=read["articletype"].ToString();
				locktype=(int)read["lock"];
			}
			read.Close();

			string hfno=Request.QueryString["no"];
			if(hfno!=null&&hfno!="")
			{
				string editmessage="�����ڣ�"+DateTime.Now+"��"+user_id+"�༭��";
				sql="update hf_message set nr="+con.rep(hfnr)+",editmessage="+con.rep(editmessage)+" where [no]="+hfno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			else
			{
				if(locktype==1)
				{
//					Content.Text=Request.Form["Content"];
//					newsid.Value=Request.Form["id"];
//					success.InnerHtml="�Բ��𣬴����ѱ�����";
					Response.Write("�Բ��𣬴����ѱ�����");
					Response.End();
					return;
				}
				con.getbbsset(litterno+"","0");
				if(con.hfset==2)
				{
					if(Session["hy"]==null)
					{
						Content.Text=Request.Form["Content"];
						newsid.Value=Request.Form["id"];
						success.InnerHtml="�Բ�����û���ڴ˰�ظ���Ȩ��";
						return;
					}
				}
				if(con.hfset==3)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=3&&(int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						Content.Text=Request.Form["Content"];
						newsid.Value=Request.Form["id"];
						success.InnerHtml="�Բ�����û���ڴ˰�ظ���Ȩ��";
						return;
					}
				}
				if(con.hfset==4)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						Content.Text=Request.Form["Content"];
						newsid.Value=Request.Form["id"];
						success.InnerHtml="�Բ�����û���ڴ˰�ظ���Ȩ��";
						return;
					}
				}
				if(con.hfset==5)
				{
					if(Session["hy"]==null||(int)Session["hy"]!=5)
					{
						Content.Text=Request.Form["Content"];
						newsid.Value=Request.Form["id"];
						success.InnerHtml="�Բ�����û���ڴ˰�ظ���Ȩ��";
						return;
					}
				}

				sql="select hf,isjhq,toporder from message where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					if((int)read.GetValue(1)!=1&&(int)read.GetValue(2)!=1&&(int)read.GetValue(0)>=9)
					{
						sql="update message set hf=hf+1,newtime='"+DateTime.Now+"',allnr="+con.rep(allnr+"\n"+hfnr)+",newuser="+con.rep(user_id)+",topimage="+con.rep(con.hotimage)+" where [no]="+no;
					}
					else
					{
						sql="update message set hf=hf+1,newtime='"+DateTime.Now+"',allnr="+con.rep(allnr+"\n"+hfnr)+",newuser="+con.rep(user_id)+" where [no]="+no;
					}
					read.Close();
				}
				else
				{
					sql="update message set hf=hf+1,newtime='"+DateTime.Now+"',allnr="+con.rep(allnr+"\n"+hfnr)+",newuser="+con.rep(user_id)+" where [no]="+no;
					read.Close();
				}

				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update bbslitter set hfno=hfno+1 where [no]="+litterno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update "+con.usertable+" set cyf=cyf+"+con.hffs+",hfs=hfs+1 where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="insert into hf_message(user_id,messageno,nr,bigno,litterno,date_time,bq,ip,ise_mail,isliuyan,fs,editmessage) values("+con.rep(user_id)+","+no+","+con.rep(hfnr)+","+bigno+","+litterno+",'"+DateTime.Now+"',0,'"+Request.ServerVariables["REMOTE_ADDR"]+"',0,0,0,null)";
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="select [no] from myjoin where user_id="+con.rep(user_id)+" and messageno="+no;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					read.Close();
				}
				else
				{
					read.Close();
					sql="insert into myjoin(user_id,messageno) values("+con.rep(user_id)+","+no+")";
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
			}
	
			if(articletype=="shtml"||articletype=="html")
			{
				StreamReader reader;
				string readdate="",readline,hfdate="";
//				filename1=filename;
				filename=Server.MapPath(filename);
	
				sql="select mbid from bbslitter where [no]="+no;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					mbid=(int)read.GetValue(0);
				}
				read.Close();

				hfdate=con.getpage(no,litterno,0);
				
					FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(hfdate);
					wf.Close();
				con.link.Close();
				//				File(filename,newtime);
			}
			if(articletype=="xml")
			{
				con.writexml(Int32.Parse(no));
			}
//			Response.Write(filename1);
//			Response.End();
			Response.Redirect(filename1);
		}
		protected void Page_Load(Object sender, EventArgs e)
		{
			con.open();
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			if(!Page.IsPostBack)
			{
				string hfno=Request.QueryString["no"],sql,yyno,messageno,yyact;
				OleDbCommand command;
				OleDbDataReader read;
				yyno=Request.QueryString["yyno"];
				messageno=Request.QueryString["messageno"];
				if(hfno==null||hfno=="")
				{
//					Response.Write(Request.Form["id"]);
//					Response.End();
					if(messageno!=null&&messageno!="")
					{
						con.getbbsset("0",messageno);
					}
					else
					{
						con.getbbsset("0",Request.Form["id"]);
					}
				}
				if(Session["user_id"]==null || Session["user_id"].ToString()=="")
				{
					yyact=Request.QueryString["act"];
					if(yyact!="yy")
					{
						if(hfno==null||hfno=="")
						{
							Content.Text=Request.Form["Content"];
							newsid.Value=Request.Form["id"];
						}
						else
						{
							sql="select nr,messageno from hf_message where [no]="+hfno;
							command=new OleDbCommand(sql,con.link);
							read=command.ExecuteReader();
							if(read.Read())
							{
								Content.Text=read.GetValue(0).ToString();
								newsid.Value=read.GetValue(1).ToString();
							}
							read.Close();
							//						write(Request.Form["Content"],Request.Form["id"]);
						}
					}
					else
					{
						messageno=Request.QueryString["messageno"];
						yyno=Request.QueryString["yyno"];
						if(yyno!="0")
						{
							sql="select nr,user_id,messageno from hf_message where [no]="+yyno;
						}
						else
						{
							sql="select nr,user_id,[no] from message where [no]="+messageno;
						}
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						if(read.Read())
						{
							Content.Text="[quote]ԭ���ߣ�"+read.GetValue(1).ToString()+"\n[b]"+read.GetValue(0).ToString()+"[/b][/quote]";
							newsid.Value=read.GetValue(2).ToString();
						}
						read.Close();
					}
				}
				else
				{
					yyact=Request.QueryString["act"];
					if(yyact!="yy")
					{
						if(hfno==null||hfno=="")
						{
							write(Request.Form["Content"],Request.Form["id"]);
						}
						else
						{
							if(!con.checkbzorowner("0","0",hfno))
							{
								Response.Redirect("default.aspx");
								con.link.Close();
							}
							else
							{
								logindiv.Visible=false;
								loginsm.Visible=false;
								sql="select nr,messageno from hf_message where [no]="+hfno;
								command=new OleDbCommand(sql,con.link);
								read=command.ExecuteReader();
								if(read.Read())
								{
									Content.Text=read.GetValue(0).ToString();
									newsid.Value=read.GetValue(1).ToString();
								}
								read.Close();
							}
						}
					}
					else
					{
						logindiv.Visible=false;
						loginsm.Visible=false;
						messageno=Request.QueryString["messageno"];
						yyno=Request.QueryString["yyno"];
						if(yyno!="0")
						{
							sql="select nr,user_id,messageno from hf_message where [no]="+yyno;
						}
						else
						{
							sql="select nr,user_id,[no] from message where [no]="+messageno;
						}
//						Response.Write(sql);
//						Response.End();
						command=new OleDbCommand(sql,con.link);
						read=command.ExecuteReader();
						if(read.Read())
						{
							Content.Text="[quote]ԭ���ߣ�"+read.GetValue(1).ToString()+"\n[b]"+read.GetValue(0).ToString()+"[/b][/quote]";
							newsid.Value=read.GetValue(2).ToString();
						}
						read.Close();
					}
				}
			}
			con.link.Close();
		}
		public hf()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
