using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for hits.
	/// </summary>
	public class hits : System.Web.UI.Page
	{
		protected config con=new config();
		protected void Page_Load(Object sender, EventArgs e) 
		{
			con.open();
			string sql,user_id,litterno;
			sql="update message set hits=hits+1 where [no]="+Request.QueryString["no"];
			OleDbDataReader read;
			OleDbCommand command=new OleDbCommand(sql,con.link);
			command.ExecuteNonQuery();
			user_id=(string)Session["user_id"];
			if(user_id !="" && user_id!= null)
			{
				sql="update "+con.usertable+" set cyf=cyf+"+con.llfs+" where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
	
			sql="select litterno from message where [no]="+Request.QueryString["no"];
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				litterno=read.GetValue(0).ToString();
				read.Close();
				con.refresh(litterno,"'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
				con.link.Close();
			}
			Response.Write(" ");
		}
		public hits()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}


		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
