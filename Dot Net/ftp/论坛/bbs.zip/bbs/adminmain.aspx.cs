using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace bbs
{
	/// <summary>
	/// Summary description for adminmain.
	/// </summary>
	/// 
	public class adminmain : System.Web.UI.Page
	{
		protected config con=new config();
		protected DataSet ds;
		protected string litterno,head;
		protected System.Web.UI.WebControls.Label typediv;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.WebControls.TextBox searchstr;
		protected System.Web.UI.WebControls.DropDownList searchtype;
		protected System.Web.UI.WebControls.DropDownList typelist;
		protected System.Web.UI.WebControls.CheckBox searchto;
		protected System.Web.UI.WebControls.Label searchto1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl openscript;
		protected System.Web.UI.WebControls.Label listhead;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listpagecount;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listjhq;
		protected System.Web.UI.HtmlControls.HtmlGenericControl owner;
		protected System.Web.UI.HtmlControls.HtmlGenericControl lj;
		protected System.Web.UI.WebControls.Label ggdiv;
		protected System.Web.UI.HtmlControls.HtmlForm form1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden sqlstr;
		protected System.Web.UI.HtmlControls.HtmlInputHidden sqlstr1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden issearch;
		protected System.Web.UI.HtmlControls.HtmlInputHidden typeid;
		protected System.Web.UI.HtmlControls.HtmlGenericControl bbsset;
		protected System.Web.UI.WebControls.DropDownList moveto;
		protected System.Web.UI.WebControls.Label listuserid;
		protected System.Web.UI.WebControls.Label littername;
		protected System.Web.UI.HtmlControls.HtmlGenericControl listall;
		protected string color1;
		protected int lys1;
		int zt;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label bbsname;
		protected System.Web.UI.HtmlControls.HtmlAnchor homepage;
		protected System.Web.UI.WebControls.Button Button1;
		string tomonth;
		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			string sql;
			sql=ViewState["sql"].ToString();
			string ordersql=ViewState["ordersql"].ToString();
			bind(sql,ordersql);
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			int zjl,pagenum;
			zjl=ds.Tables[0].Rows.Count;
			if(zjl/lmnr.PageSize*lmnr.PageSize<zjl)
				pagenum=zjl/lmnr.PageSize+1;
			else
				pagenum=zjl/lmnr.PageSize;
			listpagecount.InnerHtml="["+(lmnr.CurrentPageIndex+1)+"ҳ/"+pagenum+"ҳ/"+zjl+"����]";
			listpagecount.InnerHtml+=listjhq.InnerHtml;
			con.link.Close();
		}
		protected void checkmessage(string user_id)
		{
			bool newmessage=con.isnewmessage(user_id);
			if(newmessage)
			{
				openscript.InnerHtml="<script language=javascript><!--\nopenScript('bp.aspx?type=inbox',420,320);\n--><"+"/script>";
			}
		}

		protected void delone(string delno)
		{
			OleDbCommand command,command1;
			string sql,path,filename,user_id,articletype;
			int zt,thislitter,hfno,jianfs=0,jiancyf=0;

			if(!con.checkbz("0",delno))
			{
				//		listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
				return;
			}
	
			sql="select user_id,filename,zt,litterno,hf,articletype from message where [no]="+delno;
			OleDbCommand comread=new OleDbCommand(sql,con.link);
			OleDbDataReader ownerlist=comread.ExecuteReader();
			if(ownerlist.Read())
			{
				user_id=ownerlist.GetValue(0).ToString();
				filename=ownerlist.GetValue(1).ToString();
				zt=(int)ownerlist.GetValue(2);
				thislitter=(int)ownerlist.GetValue(3);
				hfno=(int)ownerlist.GetValue(4);
				articletype=ownerlist["articletype"].ToString();
				sql="delete from message where [no]="+delno;
				ownerlist.Close();
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
		
				ownerlist.Close();
				if(articletype!="aspx")
				{
					path=Server.MapPath(filename);
					File.Delete(path);
				}

				sql="update "+con.usertable+" set fs=fs-"+con.delfs+",cyf=cyf-"+con.delcyf+",del=del+1,fts=fts-1 where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update bbslitter set zhutino=zhutino-1,hfno=hfno-"+hfno+" where [no]="+thislitter;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
//				sql="update "+con.usertable+" set fs=0 where fs<0 and user_id="+con.rep(user_id);
//				command=new OleDbCommand(sql,con.link);
//				command.ExecuteNonQuery();
//				sql="update "+con.usertable+" set cyf=0 where cyf<0 and user_id="+con.rep(user_id);
//				command=new OleDbCommand(sql,con.link);
//				command.ExecuteNonQuery();
		
				sql="select del from "+con.usertable+" where user_id="+con.rep(user_id);
				comread=new OleDbCommand(sql,con.link);
				ownerlist=comread.ExecuteReader();
				if(ownerlist.Read())
				{
					hfno=(int)ownerlist.GetValue(0);
					if(hfno>=con.deluser)
						con.del_user(user_id);
				}
				ownerlist.Close();
				sql="select user_id,fs,litterno from hf_message where messageno="+delno;
				command=new OleDbCommand(sql,con.link);
				ownerlist=command.ExecuteReader();
				while(ownerlist.Read())
				{
					sql="update "+con.usertable+" set hfs=hfs-1,cyf=cyf-"+con.hffs+",fs=fs-"+ownerlist["fs"].ToString()+" where user_id="+con.rep(ownerlist.GetValue(0).ToString());
					command1=new OleDbCommand(sql,con.link1);
					command1.ExecuteNonQuery();

					sql="update fs set zjf=zjf-"+ownerlist["fs"].ToString()+" where user_id="+con.rep(ownerlist.GetValue(0).ToString())+" and litterno="+ownerlist["litterno"].ToString()+" and month='"+tomonth+"'";
					command1=new OleDbCommand(sql,con.link1);
					command1.ExecuteNonQuery();
				}
				ownerlist.Close();
				sql="delete from hf_message where messageno="+delno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			else
			{
				ownerlist.Close();
			}
			//	ownerlist.Close();
		}

		protected void makeone(string delno)
		{
			OleDbCommand command;
			string sql,filename,user_id,filenr,no,articletype;
			int litterno;
			if(!con.checkbz("0",delno))
			{
				//		listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
				return;
			}
	
			sql="select [no],filename,litterno,articletype from message where [no]="+delno;
			OleDbCommand comread=new OleDbCommand(sql,con.link);
			OleDbDataReader read=comread.ExecuteReader();
			if(read.Read())
			{
				filename=read.GetValue(1).ToString();
				no=read.GetValue(0).ToString();
				litterno=(int)read.GetValue(2);
				articletype=read["articletype"].ToString();
				read.Close();
				if(articletype=="shtml"||articletype=="html")
				{
					filenr=con.getpage(no,litterno,0);
					filename=Server.MapPath(filename);
		
					FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
					StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
					wf.Write(filenr);
					wf.Close();
				}
				if(articletype=="xml")
				{
					con.writexml(Int32.Parse(no));
				}
			}
			else
			{
				read.Close();
			}
		}


		protected void addone(string delno)
		{
			if(!con.checkbz("0",delno))
			{
				listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
				return;
			}

			OleDbCommand command;
			string sql,path,filename,user_id;
			int zt,thislitter,hfno,jianfs=0,jiancyf=0;
	
			sql="select user_id,filename,zt,litterno,hf from message where isjhq=0 and [no]="+delno;
			OleDbCommand comread=new OleDbCommand(sql,con.link);
			OleDbDataReader ownerlist=comread.ExecuteReader();
			if(ownerlist.Read())
			{
				user_id=ownerlist.GetValue(0).ToString();
				zt=(int)ownerlist.GetValue(2);
				thislitter=(int)ownerlist.GetValue(3);
				hfno=(int)ownerlist.GetValue(4);
		
				ownerlist.Close();
				sql="update message set isjhq=1,topimage="+con.rep(con.jhimage)+" where [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();

				sql="update "+con.usertable+" set fs=fs+"+con.jhfs+",cyf=cyf+"+con.jhcyf+",jhfs=jhfs+1 where user_id="+con.rep(user_id);
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			else
			{
				ownerlist.Close();
			}
			//	ownerlist.Close();
		}

		protected void addjhq()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					addone(delno);
				}
			}
		}
			
		protected void del()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					delone(delno);
				}
			}
		}
		protected void makefile()
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					makeone(delno);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					makeone(delno);
				}
			}
		}
		protected void updateone(string delno,int updatetype)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql,path,filename,user_id,filenr,no,imagestr,articletype;
			int litterno,thislitter,hfno=0,jianfs=0,jiancyf=0,sd;
			if(!con.checkbz("0",delno))
			{
				//		listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
				return;
			}

			if(updatetype==1)
			{
				sql="select [no],filename,litterno,articletype from message where [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					filename=read.GetValue(1).ToString();
					no=read.GetValue(0).ToString();
					litterno=(int)read.GetValue(2);
					articletype=read["articletype"].ToString();
					read.Close();
					if(articletype=="shtml"||articletype=="html")
					{
						filenr=con.getpage(no,litterno,0);
						filename=Server.MapPath(filename);
		
						FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
						StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
						wf.Write(filenr);
						wf.Close();
					}
					if(articletype=="xml")
					{
						con.writexml(Int32.Parse(no));
					}
				}
				else
				{
					read.Close();
				}
			}
			if(updatetype==2)
			{
				sql="select user_id,filename,zt,litterno,hf,lock,topimage from message where isjhq=0 and [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					user_id=read.GetValue(0).ToString();
					thislitter=(int)read.GetValue(3);
					hfno=(int)read.GetValue(4);
					sd=(int)read["lock"];
					imagestr=read["topimage"].ToString();
					read.Close();
					if(sd==0)
					{
						imagestr=con.jhimage;
					}
					sql="update message set isjhq=1,topimage="+con.rep(imagestr)+" where [no]="+delno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();

					sql="update "+con.usertable+" set fs=fs+"+con.jhfs+",cyf=cyf+"+con.jhcyf+",jhfs=jhfs+1 where user_id="+con.rep(user_id);
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
				}
			}
			if(updatetype==3)
			{
				sql="select user_id,filename,zt,litterno,hf,toporder,lock,topimage from message where isjhq=1 and [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					user_id=read.GetValue(0).ToString();
					thislitter=(int)read.GetValue(3);
					hfno=(int)read.GetValue(4);
					sd=(int)read["lock"];
					imagestr=read["topimage"].ToString();
					if((int)read["lock"]==0)
					{
						if((int)read.GetValue(5)==1)
						{
							imagestr=con.topimage;
						}
						else
						{
							if(hfno>=10)
							{
								imagestr=con.hotimage;
							}
							else
							{
								imagestr=con.newimage;
							}
						}
					}
					read.Close();
					sql="update message set isjhq=0,topimage="+con.rep(imagestr)+" where [no]="+delno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();

					sql="update "+con.usertable+" set fs=fs-"+con.jhfs+",cyf=cyf-"+con.jhcyf+",jhfs=jhfs-1 where user_id="+con.rep(user_id);
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
				}
			}
			if(updatetype==4)
			{
				sql="select user_id,filename,zt,litterno,hf,isjhq,lock,topimage from message where toporder=2 and [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					hfno=(int)read.GetValue(4);
					imagestr=read["topimage"].ToString();
					if((int)read.GetValue(5)==0&&(int)read["lock"]==0)
					{
						imagestr=con.topimage;
					}
					sql="update message set toporder=1,topimage="+con.rep(imagestr)+" where [no]="+delno;
					read.Close();
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
				}
			}
			if(updatetype==5)
			{
				sql="select user_id,filename,zt,litterno,hf,isjhq,lock,topimage from message where toporder=1 and [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					hfno=(int)read.GetValue(4);
					imagestr=read["topimage"].ToString();
					if((int)read.GetValue(5)==0&&(int)read["lock"]==0)
					{
						if(hfno>=10)
						{
							imagestr=con.hotimage;
						}
						else
						{
							imagestr=con.newimage;
						}
					}
					read.Close();
					sql="update message set toporder=2,topimage="+con.rep(imagestr)+" where [no]="+delno;
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
				}
			}
			if(updatetype==6)
			{
//				litterno=Request.QueryString["litterno"];
				sql="select bigno from bbslitter where [no]="+Request.QueryString["litterno"];
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				int tobigno=0;
				if(read.Read())
				{
					tobigno=(int)read.GetValue(0);
				}
				read.Close();
				sql="select hf from message where [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					hfno=(int)read.GetValue(0);
				}
				read.Close();
				sql="update bbslitter set zhutino=zhutino-1,hfno=hfno-"+hfno+" where [no]="+Request.QueryString["litterno"];
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update bbslitter set zhutino=zhutino+1,hfno=hfno+"+hfno+" where [no]="+Request.Form["moveto"];
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update message set litterno="+Request.Form["moveto"]+",bigno="+tobigno+" where [no]="+delno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				sql="update hf_message set litterno="+Request.Form["moveto"]+",bigno="+tobigno+" where messageno="+delno;
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
				litterno=Int32.Parse(Request.QueryString["litterno"]);
				makefile(delno);
			}
			if(updatetype==7)
			{
				sql="update message set topimage="+con.rep(con.sdimage)+",lock=1 where [no]="+delno;
//				read.Close();
				command=new OleDbCommand(sql,con.link);
				command.ExecuteNonQuery();
			}
			if(updatetype==8)
			{
				sql="select user_id,filename,zt,litterno,hf,isjhq,lock,topimage,toporder from message where [no]="+delno+" and lock=1";
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					hfno=(int)read.GetValue(4);
					imagestr=read["topimage"].ToString();
					if((int)read["isjhq"]==1)
					{
						imagestr=con.jhimage;
					}
					else
					{
						if((int)read["toporder"]==1)
						{
							imagestr=con.topimage;
						}
						else
						{
							if(hfno>10)
							{
								imagestr=con.hotimage;
							}
							else
							{
								imagestr=con.newimage;
							}
						}
					}
					sql="update message set topimage="+con.rep(imagestr)+",lock=0 where [no]="+delno;
					read.Close();
					command=new OleDbCommand(sql,con.link);
					command.ExecuteNonQuery();
				}
				else
				{
					read.Close();
				}

			}
		}
		protected void makefile(string no)
		{ 
			string filename="",sql,contentnr;
			int mbid=0,litterno=0;
			OleDbCommand command;
			OleDbDataReader read;
			sql="select bbslitter.mbid,bbslitter.[no],message.filename from bbslitter,message where bbslitter.[no]=message.litterno and message.[no]="+no;
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbid=(int)read.GetValue(0);
				litterno=(int)read.GetValue(1);
				filename=(string)read.GetValue(2);
			}
			read.Close();

			contentnr=con.getpage(no,litterno,0);
			filename=Server.MapPath(filename);
			FileStream writefile = new FileStream(filename, FileMode.Create, FileAccess.Write); 
			StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(contentnr);
			wf.Close();
		}

		protected void shenghe(int updatetype)
		{
			string nr,delno,gs;
			int i,j,js;
			nr=Request.Form["chk"];
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					updateone(delno,updatetype);
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					updateone(delno,updatetype);
				}
			}
		}


		protected void Page_Load(object sender, EventArgs e)
		{ 
			int mon,year;
//			string tomonth;
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;

			con.open();
			string user_id,sql="",option,opentype;
			int bz=0;
			litterno=Request.QueryString["litterno"];
			option=Request.Form["options"];
			bbsset.InnerHtml="<a href=\"addgg.aspx?litterno="+litterno+"\">������></a><a href=\"bbsset.aspx?litterno="+litterno+"\">�����������</a>&nbsp;";

			zt=6;
			if(Session["key"]==null||(Session["key"].ToString()!="super"&&Session["key"].ToString()!="check1"&&Session["key"].ToString()!="check2")||Session["user_id"]==null||Session["user_id"].ToString().Trim()=="")
			{
	
				listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
				return;
			}

			if(option=="del")
			{
				con.open1();
				del();
				con.link1.Close();
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="makefile")
			{
				shenghe(1);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="addjhq")
			{
				shenghe(2);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="movejhq")
			{
				shenghe(3);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="top")
			{
				shenghe(4);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="movetop")
			{
				shenghe(5);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="moveto")
			{
				shenghe(6);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="lock")
			{
				shenghe(7);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}
			if(option=="unlock")
			{
				shenghe(8);
				if(Request.QueryString["litterno"]==null)
					Response.Redirect("adminmain.aspx");
				else
					Response.Redirect("adminmain.aspx?litterno="+Request.QueryString["litterno"]);
			}

			opentype=Request.QueryString["opentype"];
			user_id=(string)Session["user_id"];
			OleDbCommand command;
			OleDbDataReader read;
			listjhq.Visible=false;

			head="";
			if(litterno==null||litterno=="")
			{
			}
			else
			{
				if(!con.checkbz(litterno,"0"))
				{
					listall.InnerHtml="�Բ���,��û��Ȩ�޹���";
					return;
				}
				sql="select name from bbslitter where [no]="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					head=read.GetValue(0).ToString();
					littername.Text=head;
				}
				read.Close();
			}

			if(litterno=="" || litterno==null)
				con.refresh("0","'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
			else
			{
				con.getbbsset(litterno,"0");
				con.refresh(litterno,"'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
				owner.InnerHtml=con.getowner(litterno);
			}
			if(!Page.IsPostBack)
			{
					searchtype.Items.Add(new ListItem("����","zhuti"));
					searchtype.Items.Add(new ListItem("����","nr"));
					searchtype.Items.Add(new ListItem("����","user_id"));
					string sql1="select [no],name from bbslitter where par<>0 order by bigno";
					command=new OleDbCommand(sql1,con.link);
					read=command.ExecuteReader();
					typelist.Items.Add("�����");
					while(read.Read())
					{
						typelist.Items.Add(new ListItem(read.GetValue(1).ToString().Trim(),read.GetValue(0).ToString()));
						moveto.Items.Add(new ListItem(read.GetValue(1).ToString().Trim(),read.GetValue(0).ToString()));
					}
					read.Close();
				listpage();
				lmnr.PageSize=con.pagesize;
				lmnr.HeaderStyle.BackColor=ColorTranslator.FromHtml(con.headcolor);
				lmnr.HeaderStyle.ForeColor=ColorTranslator.FromHtml(con.headforecolor);
				lmnr.ItemStyle.ForeColor=ColorTranslator.FromHtml(con.itemforecolor);
				lmnr.Columns[0].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[1].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[2].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[3].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[4].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);
				lmnr.Columns[5].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color2);
				lmnr.Columns[6].ItemStyle.BorderColor=ColorTranslator.FromHtml(con.color1);

//				lmnr.DataSource=ds.Tables["type"].DefaultView;
//				lmnr.DataBind();
				lys1=lmnr.Items.Count;
				int zjl,pagenum;
				zjl=ds.Tables[0].Rows.Count;
				if(zjl/lmnr.PageSize*lmnr.PageSize<zjl)
					pagenum=zjl/lmnr.PageSize+1;
				else
					pagenum=zjl/lmnr.PageSize;
				listpagecount.InnerHtml="["+(lmnr.CurrentPageIndex+1)+"ҳ/"+pagenum+"ҳ/"+zjl+"����]";
				listpagecount.InnerHtml+=listjhq.InnerHtml;
				if(litterno==""||litterno==null)
					litterno="0";
				sql="select zhuti,html,date_time from ggmessage where litterno="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					if(read.GetValue(1).ToString()=="1")
					{
						ggdiv.Text="<a href=\"listgg.aspx?litterno="+litterno+"\">"+read.GetValue(0).ToString()+"("+read.GetValue(2).ToString()+")</a>";
					}
					else
					{
						ggdiv.Text="<a href=\"listgg.aspx?litterno="+litterno+"\">"+con.changechr(con.texttohtml(read.GetValue(0).ToString()))+"("+read.GetValue(2).ToString()+")</a>";
					}
				}
				else
				{
					//				ggdiv.InnerHtml=="";
				}
				read.Close();
				con.link.Close();
				if(Session["user_id"]!=null)
				{
					listuserid.Text =Session["user_id"].ToString();
				}
				else
				{
					listuserid.Text="����";
				}
			}
		}
		protected void listpage()
		{ 
			string sql="",ljnr;
			OleDbCommand command;
			OleDbDataReader read;
			string ordersql;
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			string user_id,opentype;
			int bz=0;
			bbsname.Text=con.bbsname;
			opentype=Request.QueryString["opentype"];
			user_id=(string)Session["user_id"];
			listjhq.Visible=false;
			color1="#ffffff";
			if(Request.Form["options"]=="search")
			{
				searchto.Visible=true;
				searchto1.Visible=true;
			}
			else
			{
				searchto.Visible=false;
				searchto1.Visible=false;
			}

			head="";
/*			if(litterno==null||litterno=="")
			{
				ljnr="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				lj.InnerHtml=head+ljnr;
			}
			else
			{
				lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>";
				lj.InnerHtml+="<a href='write.aspx?litterno="+litterno+"'><img border=\"0\" src=\"img/fb.gif\" style=\"CURSOR: hand\"></a>";
				sql="select name from bbslitter where [no]="+litterno;
				command=new OleDbCommand(sql,con.link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					head=read.GetValue(0).ToString();
					littername.Text=head;
				}
				read.Close();
			}

*/			if(user_id==null)
				user_id="qzren_bbs_guest";
			else
				checkmessage(user_id);
			if(litterno=="" || litterno==null)
			{
				con.refresh("0","'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
			}
			else
			{
				con.getbbsset(litterno,"0");
				if(con.ztset==2)
				{
					if(Session["hy"]==null)
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==3)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=3&&(int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==4)
				{
					if(Session["hy"]==null||((int)Session["hy"]!=4&&(int)Session["hy"]!=5))
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				if(con.ztset==5)
				{
					if(Session["hy"]==null||(int)Session["hy"]!=5)
					{
						listall.InnerHtml="�Բ�����û��Ȩ�޿��˰�";
						return;
					}
				}
				con.refresh(litterno,"'"+Request.ServerVariables["REMOTE_ADDR"]+"'");
				owner.InnerHtml=con.getowner(litterno);
				sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno;
			}
/*			if(litterno==null||litterno=="")
			{
				listhead.Text="<A href=\"main.aspx?opentype=mywt\"><font color=\"#000000\">�ҵ�����</font></a> | <A href=\"main.aspx?opentype=mycy\"><font color=\"#000000\">�Ҳ��������</font></a>";
				listhead.Text+=" | <A href=\"main.aspx?opentype=mygz\"><font color=\"#000000\">�ҵĹ��İ�</font></a>| <A href=\"main.aspx?opentype=new\"><font color=\"#000000\">������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=hot&litterno="+litterno+"\"><font color=\"#000000\">�ȵ�����</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=yjj\"><font color=\"#000000\">�ѽ������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=wjj\"><font color=\"#000000\">δ�������</font></a>";
			}
			else
			{
				listhead.Text="<A href=\"main.aspx?opentype=mywt\"><font color=\"#000000\">�ҵ�����</font></a> | <A href=\"main.aspx?opentype=mycy\"><font color=\"#000000\">�Ҳ��������</font></a>";
				listhead.Text+=" | <A href=\"main.aspx?opentype=mygz\"><font color=\"#000000\">�ҵĹ��İ�</font></a>| <A href=\"main.aspx?opentype=new\"><font color=\"#000000\">������</font></a>";
				listhead.Text+="| <A href=\"main.aspx?opentype=hot&litterno="+litterno+"\"><font color=\"#000000\">�ȵ�����</font></a>";
				if(con.zjftype==1)
				{
					listhead.Text+="| <A href=\"main.aspx?opentype=yjj&litterno="+litterno+"\"><font color=\"#000000\">�ѽ������</font></a>";
					listhead.Text+="| <A href=\"main.aspx?opentype=wjj&litterno="+litterno+"\"><font color=\"#000000\">δ�������</font></a>";
				}
			}
			listhead.Text+=" | <a href=\"bp.aspx?type=inbox\"><font color=\"#000000\">����Ϣ</font></a>";
			if(opentype=="mywt")  //�ҵ�����
			{
				lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where user_id="+con.rep(user_id)+" order by toporder, newtime desc";
				bz=1;
				littername.Text="�ҵ�����";
			}
			if(opentype=="mycy")  //�Ҳ��������
			{
				lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				sql="select message.[no],message.zhuti,message.date_time,message.bq,message.fs,message.hf,message.hits,message.filename,message.user_id,toporder,topimage from message,myjoin where myjoin.user_id="+con.rep(user_id)+" and myjoin.messageno=message.[no] order by toporder, message.newtime desc";
				bz=1;
				littername.Text="�ҵĲ��������";
			}
			if(opentype=="mygz")  //�ҵĹ��İ�
			{
				lj.InnerHtml="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				sql="select message.[no],message.zhuti,message.date_time,message.bq,message.fs,message.hf,message.hits,message.filename,message.user_id,toporder,topimage from message,mygz where mygz.user_id="+con.rep(user_id)+" and mygz.messageno=message.[no] order by toporder, message.newtime desc";
				bz=1;
				littername.Text="�ҵĹ��İ�";
			}
*/			if(opentype=="jhq")   //����������
			{
				sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and isjhq=1 and litterno="+litterno;
				listjhq.InnerHtml=" [<a href=\"adminmain.aspx?litterno="+litterno+"\">��ͨ��</a>]";
				bz=1;
//				lj.InnerHtml=head+"����������<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				littername.Text="����������";
			}
			else
			{
				if(litterno!=null&&litterno!="")
				{
					listjhq.InnerHtml=" [<a href=\"adminmain.aspx?opentype=jhq&litterno="+litterno+"\">������</a>]";
				}
			}
/*			if(opentype=="hot")   //�ȵ�����
			{
				sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message  where qx<="+zt+" order by hits desc,newtime desc";
				lj.InnerHtml=head+"<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				bz=1;
				littername.Text="�ȵ�����";
			}
			if(opentype=="new")   //������
			{
				sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+"  order by newtime desc";
				lj.InnerHtml=head+"<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				bz=1;
				littername.Text="������";
			}
			if(opentype=="yjj")   //�ѽ��������
			{	
				if(litterno==null||litterno=="")
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and gftype=2 order by toporder, newtime desc";
					lj.InnerHtml=head+"�ѽ������<img border=\"0\" onclick=\"location.reload();\" src=\"img/shua.gif\" style=\"CURSOR: hand\">;&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				}
				else
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno+" and qx<="+zt+" and gftype=2 order by toporder, newtime desc";
					lj.InnerHtml=head+"�ѽ������<img border=\"0\" onclick=\"location.reload();\" src=\"img/shua.gif\" style=\"CURSOR: hand\">;&nbsp;&nbsp;";
				}
				bz=1;
			}
			if(opentype=="wjj")   //δ�������
			{
				if(litterno==null||litterno=="")
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and  gftype=1 order by toporder, newtime desc";
					lj.InnerHtml=head+"<img border=\"0\" onclick=\"location.reload();\" src=\"img/shua.gif\" style=\"CURSOR: hand\">;&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
				}
				else
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno+" and qx<="+zt+" and  gftype=1 order by toporder, newtime desc";
					lj.InnerHtml=head+"<img border=\"0\" onclick=\"location.reload();\" src=\"img/shua.gif\" style=\"CURSOR: hand\">;&nbsp;&nbsp;";
				}
				bz=1;
			}
*/
//			if(bz==1)
//			{
				bind(sql," order by toporder,newtime desc");
/*			}
			else
			{
				if(litterno==null||litterno=="")
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<=zt order by newtime desc";
				}
				else
				{
					sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where litterno="+litterno+" order by toporder,newtime desc";
				}
				bind(sql);
			}
*/		}
		protected void search(object sender, EventArgs e)
		{
			string ljnr,sql="";
//			ljnr="<a href=\"javascript:location.reload()\">ˢ��</a>&nbsp;&nbsp;<FONT color=red>�������Ƚ����������̳</FONT>";
//			lj.InnerHtml=head+ljnr;
			if(searchstr.Text==""||searchstr.Text==null)
				sql=ViewState["sql"].ToString();
			else
			{
				if(searchto.Visible&&searchto.Checked)
				{
					if(typelist.SelectedItem.Value=="�����")
					{
						sql=ViewState["sql"]+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
					else
					{
						sql=ViewState["sql"]+" and litterno="+typelist.SelectedItem.Value+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
				}
				else
				{
					if(typelist.SelectedItem.Value=="�����")
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
					else
					{
						sql="select [no],zhuti,date_time,bq,fs,hf,hits,filename,user_id,toporder,topimage from message where qx<="+zt+" and litterno="+typelist.SelectedItem.Value+" and "+searchtype.SelectedItem.Value+" like "+con.rep1(searchstr.Text);
					}
				}
			}
			searchto1.Visible=true;
			searchto.Visible=true;
			//			Response.Write(sql);
			//			Response.End();
			bind(sql," order by toporder,newtime desc");
		}
		protected void bind(string sql,string ordersql)
		{
			OleDbCommand command;
			OleDbDataAdapter datasel;
			command=new OleDbCommand(sql+ordersql,con.link);
			datasel=new OleDbDataAdapter();
			datasel.SelectCommand=command;
			ds=new DataSet();
			datasel.Fill(ds,"type");
			ViewState["sql"]=sql;
			ViewState["ordersql"]=ordersql;
			lmnr.DataSource=ds.Tables["type"].DefaultView;
			lmnr.DataBind();
			int zjl,pagenum;
			zjl=ds.Tables[0].Rows.Count;
			if(zjl/lmnr.PageSize*lmnr.PageSize<zjl)
				pagenum=zjl/lmnr.PageSize+1;
			else
				pagenum=zjl/lmnr.PageSize;
			listpagecount.InnerHtml="["+(lmnr.CurrentPageIndex+1)+"ҳ/"+pagenum+"ҳ/"+zjl+"����]";
			listpagecount.InnerHtml+=listjhq.InnerHtml;
			lys1=lmnr.Items.Count;
		}
		public adminmain()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
