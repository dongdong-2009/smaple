using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.IO;
using System.Web.Mail;
using System.Text;
using System.Xml;

namespace bbs
{
	/// <summary>
	/// Summary description for config.
	/// </summary>
	public class config : System.Web.UI.Page
	{
//		ls ls=new ls();
		public string databasepath="database/db.aspx";
		public string usertable="net_user";
		public string userdatabase="";
//		public string usertable="netgame.dbo.net_user";
//		public string userdatabase="netgame.dbo.";
		public string bbsname=".net����������";
//		public string bbsname="box����������";
//		public string bbsname="����δ��������";
//		public string bbsname="�л�����������";
		public int defaultfs=500;  //��ʼ���÷�
		public int dayfs=10;   //ÿ�����ӵķ���
		public int hffs=5;    //ÿ�ظ�һ�����ӵĲ��ڷ�
		public int fbfs=10;    //ÿ��һ�����ӵĲ��ڷ�
		public int llfs=0;    //ÿ���һ�����ӵĲ��ڷ�
		public int ftmrf=20;  //����ʱ��Ĭ�Ϸ�
		public int ftmrfrate=20;  //��������= ftmrf+�����/ftmrfrate
		public int cookiecheck=0; //�ӷ�ʱcookie����
		public int ipcheck=0;    //�ӷ�ʱIP����
		public string bq1="<B><FONT color=red>��</FONT></B>";     //δ����������
		public string bq2="<B><FONT color=green>��</FONT></B>";     //�ѽ���������
		public string bq3="<FONT face=Wingdings color=darkgray>r</FONT>";     //��ˮ������
		public int isubb=1;     //����ʹ��ubb����
		public int ishtml=0;     //����ʹ��html����
		public int isscript=0;   //�������� script(���������ʹ��html,��ѡ��ʧЧ
		public int isflash=1;   //����ʹ�� flash
		public int isimg=1;   //������ͼ
		public int delfs=100;  //��ɾһ���۳��Ŀ��÷���
		public int delcyf=300;  //��ɾһ���۳��Ĳ������
		public int delhffs=10;   //��ɾһ�ظ��۳��ķ���
		public int delhfcyf=30;  //��ɾһ�ظ��۳��Ĳ����
		public int deluser=99999;    //��ɾ deluser ������ע�����ʺŲ�ɾ������������,�������ʹ�ô˹��ܾ;�������ֵ���,����ҪԽ��
		public int jhfs=100;    //���ӱ����뾫�������ӵķ���
		public int jhcyf=20;    //���ӱ����뾫�������ӵĲ����
		public int maxftf=500;  //��������
		public int ismanage=0;  //�Ƿ���������,0Ϊֻ�������Ѹ���,1Ϊ����,admin,2Ϊ����,admin,������,3Ϊ����,admin,��������
		public int refreshtime=1200;    //����refreshtime��û�����κζ�������Ϊ��������
		public int newlitterneadfs=2000;  //����ר�ҷ�newlitterneedfs��������Կ�ר�Ұ�
		public int tg1addfs=25;             //ԭ���������Ͷ�����ӵĿ��÷�
		public int tg1addcyf=25;			 //ԭ���������Ͷ�����ӵĲ����
		public int tg1addzjf=0;			//ԭ���������Ͷ�����ӵ�ר�ҷ�
		public int tg2addfs=5;				//ת����Ͷ�����ӵĿ��÷�
		public int tg2addcyf=5;			//ת����Ͷ�����ӵĲ����
		public int tg2addzjf=0;			//ת����Ͷ�����ӵ�ר�ҷ�
		public int changecyftofs=5; 		//���������÷ֵĶһ�����  x:1
		public int changezjftofs=5;		//ר�ҷ�����÷ֵĶһ�����  1:x
		public int pagesize=20;            //ÿҳ��ʾ������
		public string headcolor="#225BB3";  //���ⱳ��ɫ
		public string color1="#D6E3FF";     //���񱳾�ɫ1
		public string color2="#ECF2FF";     //���񱳾�ɫ2
		public string headforecolor="#ffffff";  //��������ɫ
		public string itemforecolor="#000000";  //��������ɫ
		public int articlepage=9999;       //���ӷ�ҳ
		public string articletype="shtml"; //��������
		public string jshead="��";         //js��ʾ������ǰ���ͷ
//		public string bbspath="http://www.boxbbs.com/bbs/";
		public string bbspath="http://www.aspx.net.cn/bbs/";
		
		public string logo="";
		public string logolj="";
		public string gg="��ӭ�������ǵ���ҳ";
		public string gglj="http://www.games.com.cn";
		public int whouploadimage=2;       //����ͼƬ   1Ϊ����,2Ϊ����������,3Ϊ��������,4Ϊ����Ա����
		public int zjfuploadimage=200;       //�趨����ר�ҷ����Ͽ�������ͼƬ
		public int uploadimageset=2;       //1Ϊ����������������Ĺ�ϵ,2Ϊ��Ĺ�ϵ
		public int ztset=1;                //���Ȩ��
		public int ftset=1;                //����Ȩ��
		public int hfset=1;                //�ظ�Ȩ��
		public string returnuser; 
		public int zjftype=0;              //�Ƿ���ְ�        
		public int zjfvalue=0;             //���ְ�ÿ���ķ�ֵ

		public int no1=3000;   //����1

		public string name0="������·";

		public string star0="";

		public string topimage="<img src=\"images/istop.gif\" border=\"0\">";             //�ö�ͼƬ
		public string newimage="<img src=\"images/folder.gif\" border=\"0\">";            //��ͨ��
		public string hotimage="<img src=\"images/hotfolder.gif\" border=\"0\">";         //�ȵ���
		public string jhimage="<img src=\"images/isbest.gif\" border=\"0\">";             //������
		public string sdimage="<img src=\"images/lockfolder.gif\" border=\"0\">";         //������

		public string texttohtml(string chr)
		{
			if(chr==null)
				return "";
			chr=chr.Replace("<","&lt");
			chr=chr.Replace(">","&gt");
			chr=chr.Replace("\n","<br>");
			return(chr);	
		}
		public void writexml(int no)
		{
			string sql="select * from message where [no]="+no,filename,bigname,littername,litterno,userjb,userstar;
			int cyf=0;
			OleDbCommand command,command1;
			OleDbDataReader read,read1;
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			XmlElement hf;
			open3();
			if(read.Read())
			{
				litterno=read["litterno"].ToString();
				XmlDocument doc = new XmlDocument();
				XmlTextReader reader = new XmlTextReader(Server.MapPath(".") + "\\message"+read["mbid"]+".xml");
				doc.Load(reader);
				XmlElement message;
				XmlNode root = doc.DocumentElement;
				filename =read["filename"].ToString();
				message = doc.CreateElement("www.aspx.net.cn_filename");           //�ļ���
				message.InnerText = filename ;
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_zhuti");              //����
				message.InnerText = read["zhuti"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_bigno");              //�������
				message.InnerText = read["bigno"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_litterno");              //С�����
				message.InnerText = read["litterno"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_no");                 //���
				message.InnerText = read["no"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_user_id");            //������
				message.InnerText = read["user_id"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_hfno");                 //�ظ���
				root.AppendChild(message);
				message.InnerText = read["hf"].ToString();
				message = doc.CreateElement("www.aspx.net.cn_nr");                 //����
				message.InnerXml = "<![CDATA["+changechr(read["nr"].ToString())+"]]>";
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_posttime");           //����ʱ��
				message.InnerText = read["date_time"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_bq");                 //����
				message.InnerXml = "<![CDATA["+changechr(read["bq"].ToString())+"]]>";
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_hits");                 //�����
				message.InnerText = read["hits"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_ip");                 //IP
				message.InnerText = read["ip"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_updatetime");                 //������ʱ��
				message.InnerText = read["newtime"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_gftype");                 //����״̬
				message.InnerText = read["gftype"].ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_fs");                 //���ӷ�ֵ
				message.InnerText = read["fs"].ToString();
				root.AppendChild(message);
				sql="select * from "+usertable+" where user_id="+rep(read["user_id"].ToString());
				read.Close();
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					cyf=(int)read["cyf"];
					userjb=name0;
					userstar=star0;
					message = doc.CreateElement("www.aspx.net.cn_user_name");                 //����
					message.InnerText = read["user_name"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_e_mail");                 //email
					message.InnerText = read["e_mail"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_http");                 //��ҳ
					message.InnerText = read["http"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_jianjie");                 //���
					message.InnerText = read["jianjie"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_oicq");                 //oicq
					message.InnerText = read["oicq"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_sex");                 //�Ա�
					message.InnerText = read["sex"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_dz");                 //��ַ
					message.InnerText = read["dz"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_dh");                 //�绰
					message.InnerText = read["dh"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_zctime");                 //ע������
					message.InnerText = read["date_time"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_lasttime");                 //����¼����
					message.InnerText = read["dateandtime"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_userfs");                 //�û����÷�
					message.InnerText = read["fs"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_cyf");                 //�����
					message.InnerText = read["cyf"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_zjf");                 //ר�ҷ�
					message.InnerText = read["zjf"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_dlcs");                 //��¼����
					message.InnerText = read["dlcs"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_fts");                 //������
					message.InnerText = read["fts"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_hfs");                 //�ظ���
					message.InnerText = read["hfs"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_del");                 //��ɾ����
					message.InnerText = read["del"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_delhf");                 //��ɾ�ظ���
					message.InnerText = read["delhf"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_jhfs");                 //���ӱ����뾫�����õ��ķ���
					message.InnerText = read["jhfs"].ToString();
					root.AppendChild(message);
//					message = doc.CreateElement("www.aspx.net.cn_user");                 //�÷�
//					message.InnerXml = read["fs"].ToString();
//					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_qianming");                 //ǩ��
					message.InnerXml = "<![CDATA["+changechr(read["qianming"].ToString())+"]]>";
					root.AppendChild(message);

					message = doc.CreateElement("www.aspx.net.cn_icon");                 //ͷ��
					if(read["usericon"].ToString()=="")
						message.InnerXml="<![CDATA[<img src=\""+bbspath+"images/face/"+read["systemicon"].ToString()+"\">]]>";
					else
						message.InnerXml="<![CDATA[<img src=\""+read["usericon"].ToString()+"\" width=\""+read["imagewidth"].ToString()+"\" height=\""+read["imageheight"].ToString()+"\">]]>";
					root.AppendChild(message);
				}
				read.Close();
				sql="select top 1 *  from jbmanage where jf<="+cyf+" order by jf desc";
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					message = doc.CreateElement("www.aspx.net.cn_userjb");                 //����
					message.InnerText = read["name"].ToString();
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_star");                 //����
					message.InnerXml="<![CDATA["+read["icon"].ToString()+"]]>";
					root.AppendChild(message);
				}
				else
				{
					message = doc.CreateElement("www.aspx.net.cn_userjb");                 //����
					message.InnerText = name0;
					root.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_star");                 //����
					message.InnerXml="<![CDATA["+star0+"]]>";
					root.AppendChild(message);
				}
				read.Close();

				sql="select bbslitter.name,bbsbig.name from bbslitter,bbsbig where bbslitter.[no]="+litterno+" and bbslitter.bigno=bbsbig.[no]";
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				read.Read();
				message = doc.CreateElement("www.aspx.net.cn_bigname");                 //����������
				message.InnerText = read.GetValue(1).ToString();
				root.AppendChild(message);
				message = doc.CreateElement("www.aspx.net.cn_littername");                 //����С����
				message.InnerText = read.GetValue(0).ToString();
				root.AppendChild(message);
				read.Close();

				sql="select * from hf_message where messageno="+no+" order by date_time";
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				while(read.Read())
				{
					hf = doc.CreateElement("www.aspx.net.cn_hf");
					root.AppendChild(hf);
					message = doc.CreateElement("www.aspx.net.cn_no");                 //���
					message.InnerText = read["no"].ToString();
					hf.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_user_id");                 //������
					message.InnerText = read["user_id"].ToString();
					hf.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_nr");                 //����
					message.InnerXml ="<![CDATA["+read["nr"].ToString()+"]]>";
					hf.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_posttime");                 //����ʱ��
					message.InnerText = read["date_time"].ToString();
					hf.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_ip");                 //IP
					message.InnerText = read["ip"].ToString();
					hf.AppendChild(message);
					message = doc.CreateElement("www.aspx.net.cn_df");                 //�÷�
					message.InnerText = read["fs"].ToString();
					hf.AppendChild(message);
					//					XmlTextWriter xmlWriter = new XmlTextWriter(Server.MapPath(filename),null);
//					xmlWriter.Formatting = Formatting.Indented;
//					xmlWriter.Formatting = Formatting.None;
//					doc.Save(xmlWriter);
//					xmlWriter.Close();
					sql="select * from "+usertable+" where user_id="+rep(read["user_id"].ToString());
//					read.Close();
					command1=new OleDbCommand(sql,link3);
					read1=command1.ExecuteReader();
					if(read1.Read())
					{
						cyf=(int)read1["cyf"];
						userjb=name0;
						userstar=star0;
						message = doc.CreateElement("www.aspx.net.cn_user_name");                 //����
						message.InnerText = read1["user_name"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_e_mail");                 //email
						message.InnerText = read1["e_mail"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_http");                 //��ҳ
						message.InnerText = read1["http"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_jianjie");                 //���
						message.InnerText = read1["jianjie"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_oicq");                 //oicq
						message.InnerText = read1["oicq"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_sex");                 //�Ա�
						message.InnerText = read1["sex"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_dz");                 //��ַ
						message.InnerText = read1["dz"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_dh");                 //�绰
						message.InnerText = read1["dh"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_zcdate");                 //ע������
						message.InnerText = read1["date_time"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_lastdate");                 //����¼����
						message.InnerText = read1["dateandtime"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_fs");                 //���÷�
						message.InnerText = read1["fs"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_cyf");                 //�����
						message.InnerText = read1["cyf"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_zjf");                 //ר�ҷ�
						message.InnerText = read1["zjf"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_dlcs");                 //��¼����
						message.InnerText = read1["dlcs"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_fts");                 //������
						message.InnerText = read1["fts"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_hfs");                 //�ظ���
						message.InnerText = read1["hfs"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_del");                 //��ɾ����
						message.InnerText = read1["del"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_delhf");                 //��ɾ�ظ���
						message.InnerText = read1["delhf"].ToString();
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_jhfs");                 //���ӱ����뾫�����õ��ķ���
						message.InnerText = read1["jhfs"].ToString();
						hf.AppendChild(message);
						
/*						message = doc.CreateElement("www.aspx.net.cn_userjb");                 //����
						message.InnerText = userjb;
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_star");                 //��
						message.InnerXml = "<![CDATA["+userstar+"]]>";
						hf.AppendChild(message);

*/						message = doc.CreateElement("www.aspx.net.cn_qianming");                 //ǩ��
						message.InnerXml = "<![CDATA["+changechr(read1["qianming"].ToString())+"]]>";
						hf.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_icon");                 //ͷ��
						if(read1["usericon"].ToString()=="")
							message.InnerXml="<![CDATA[<img src=\""+bbspath+"images/face/"+read1["systemicon"].ToString()+"\">]]>";
						else
							message.InnerXml="<![CDATA[<img src=\""+read1["usericon"].ToString()+"\" width=\""+read1["imagewidth"].ToString()+"\" height=\""+read1["imageheight"].ToString()+"\">]]>";
						hf.AppendChild(message);
						hf.AppendChild(message);
					}
					read1.Close();
					sql="select top 1 *  from jbmanage where jf<="+cyf+" order by jf desc";
					command1=new OleDbCommand(sql,link3);
					read1=command1.ExecuteReader();
					if(read1.Read())
					{
						message = doc.CreateElement("www.aspx.net.cn_userjb");                 //����
						message.InnerText = read1["name"].ToString();
						root.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_star");                 //����
						message.InnerXml="<![CDATA["+read1["icon"].ToString()+"]]>";
						root.AppendChild(message);
					}
					else
					{
						message = doc.CreateElement("www.aspx.net.cn_userjb");                 //����
						message.InnerText = name0;
						root.AppendChild(message);
						message = doc.CreateElement("www.aspx.net.cn_star");                 //����
						message.InnerXml="<![CDATA["+star0+"]]>";
						root.AppendChild(message);
					}
					read1.Close();
				}
				read.Close();
				XmlTextWriter xmlWriter = new XmlTextWriter(Server.MapPath(filename),null);
				xmlWriter.Formatting = Formatting.Indented;
				doc.Save(xmlWriter);
				xmlWriter.Close();
				reader.Close();
			}
			link3.Close();

		}
		public string changechr(string chr)
		{
			if(chr==null)
				return "";
			if(ishtml==0)
			{
				chr=chr.Replace("<","&lt");
				chr=chr.Replace(">","&gt");
				chr=chr.Replace("\n","<br>");
			}
			else
			{
				if(isscript==0)
				{
					chr = Regex.Replace(chr,@"<script(?<x>[^\>]*)>(?<y>[^\>]*)\</script\>",@"&lt;script$1&gt;$2&lt;/script&gt;",RegexOptions.IgnoreCase);
				}
			}
			if( isubb == 1)
			{
				chr = Regex.Replace(chr,@"\[url=(?<x>[^\]]*)\](?<y>[^\]]*)\[/url\]",@"<a href=$1 target=_blank>$2</a>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[url\](?<x>[^\]]*)\[/url\]",@"<a href=$1 target=_blank>$1</a>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[email=(?<x>[^\]]*)\](?<y>[^\]]*)\[/email\]",@"<a href=$1>$2</a>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[email\](?<x>[^\]]*)\[/email\]",@"<a href=$1>$1</a>",RegexOptions.IgnoreCase);

				if(isflash==1)
				{
					chr = Regex.Replace(chr,@"\[flash](?<x>[^\]]*)\[/flash]",@"<OBJECT codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=4,0,2,0 classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 width=500 height=400><PARAM NAME=movie VALUE=""$1""><PARAM NAME=quality VALUE=high><embed src=""$1"" quality=high pluginspage='http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash' type='application/x-shockwave-flash' width=500 height=400>$1</embed></OBJECT>",RegexOptions.IgnoreCase);
				}
				if(isimg==1)
				{
					chr = Regex.Replace(chr,@"\[img](?<x>[^\]]*)\[/img]",@"<IMG SRC=""$1"" border=0>",RegexOptions.IgnoreCase);
				}
				chr = Regex.Replace(chr,@"\[color=(?<x>[^\]]*)\](?<y>[^\]]*)\[/color\]",@"<font color=$1>$2</font>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[face=(?<x>[^\]]*)\](?<y>[^\]]*)\[/face\]",@"<font face=$1>$2</font>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[size=1\](?<x>[^\]]*)\[/size\]",@"<font size=1>$1</font>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[size=2\](?<x>[^\]]*)\[/size\]",@"<font size=2>$1</font>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[size=3\](?<x>[^\]]*)\[/size\]",@"<font size=3>$1</font>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[size=4\](?<x>[^\]]*)\[/size\]",@"<font size=4>$1</font>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[align=(?<x>[^\]]*)\](?<y>[^\]]*)\[/align\]",@"<align=$1>$2</align>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[fly](?<x>[^\]]*)\[/fly]",@"<marquee width=90% behavior=alternate scrollamount=3>$1</marquee>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[move](?<x>[^\]]*)\[/move]",@"<marquee scrollamount=3>$1</marquee>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[glow=(?<x>[^\]]*),(?<y>[^\]]*),(?<z>[^\]]*)\](?<w>[^\]]*)\[/glow\]",@"<table width=$1 style='filter:glow(color=$2, strength=$3)'>$4</table>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[shadow=(?<x>[^\]]*),(?<y>[^\]]*),(?<z>[^\]]*)\](?<w>[^\]]*)\[/shadow\]",@"<table width=$1 style='filter:shadow(color=$2, strength=$3)'>$4</table>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[b\](?<x>[^\]]*)\[/b\]",@"<b>$1</b>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[i\](?<x>[^\]]*)\[/i\]",@"<i>$1</i>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[u\](?<x>[^\]]*)\[/u\]",@"<u>$1</u>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[code\](?<x>[^\]]*)\[/code\]",@"<pre id=code><font size=1 face='Verdana, Arial' id=code>$1</font id=code></pre id=code>",RegexOptions.IgnoreCase);

				chr = Regex.Replace(chr,@"\[list\](?<x>[^\]]*)\[/list\]",@"<ul>$1</ul>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[list=1\](?<x>[^\]]*)\[/list\]",@"<ol type=1>$1</ol id=1>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[list=a\](?<x>[^\]]*)\[/list\]",@"<ol type=a>$1</ol id=a>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[\*\](?<x>[^\]]*)\[/\*\]",@"<li>$1</li>",RegexOptions.IgnoreCase);
				chr = Regex.Replace(chr,@"\[quote](?<x>.*)\[/quote]",@"<center>���� ���������� ����<table border='1' width='80%' cellpadding='10' cellspacing='0' ><tr><td>$1</td></tr></table></center>",RegexOptions.IgnoreCase);
			}
			return(chr);

		}
		public void getlittervalue()
		{
			string sql;
			int thislitter,hfno,zhutino,wcno,zerono;
	
			sql="select [no] from bbslitter";
			OleDbCommand comread=new OleDbCommand(sql,link);
			OleDbDataReader ownerlist=comread.ExecuteReader();

			OleDbCommand command;
			OleDbDataReader read;
			open2();
			while(ownerlist.Read())
			{
				thislitter=(int)ownerlist.GetValue(0);
				sql="select count(*) from message where litterno="+thislitter;
				command=new OleDbCommand(sql,link2);
				read=command.ExecuteReader();
				read.Read();
				zhutino=(int)read.GetValue(0);
				read.Close();

				sql="select count(*) from message where zt=2 and litterno="+thislitter;
				command=new OleDbCommand(sql,link2);
				read=command.ExecuteReader();
				read.Read();
				wcno=(int)read.GetValue(0);
				read.Close();

				sql="select count(*) from message where zt=3 and litterno="+thislitter;
				command=new OleDbCommand(sql,link2);
				read=command.ExecuteReader();
				read.Read();
				zerono=(int)read.GetValue(0);
				read.Close();
		
				sql="select count(*) from hf_message where litterno="+thislitter;
				command=new OleDbCommand(sql,link2);
				read=command.ExecuteReader();
				read.Read();
				hfno=(int)read.GetValue(0);
				read.Close();
				sql="update bbslitter set zhutino="+zhutino+",hfno="+hfno+",wcno="+wcno+",zerono="+zerono+" where [no]="+ownerlist.GetValue(0);
				command=new OleDbCommand(sql,link2);
				command.ExecuteNonQuery();
			}
			link2.Close();
		}

		public void refresh(string where,string ip)
		{
			string sql;
			int num;
			OleDbCommand command;
			OleDbDataReader read;
			if(where=="0")
				where="���������";
			else
			{
				sql="select name from bbslitter where [no]="+where;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
					where=read.GetValue(0).ToString();
				else
					where="δ֪";
				read.Close();
			}
	
			if(Session["user_id"]==null || Session["user_id"].ToString()=="")
			{
				if(Session["guestno"]==null || Session["guestno"].ToString()=="")
				{
					sql="insert into online(user_id,user_name,ip,date_time,isbp,litterno) values('����','����',"+ip+",'"+DateTime.Now+"',1,"+rep(where)+")";
					command=new OleDbCommand(sql,link);
					command.ExecuteNonQuery();
					sql="select top 1 [no] from online order by [no] desc";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						num=(int)read.GetValue(0)+1;
					}
					else
					{
						num=1;
					}
					Session["guestno"]=""+num;
					read.Close();
				}
				else
				{
					sql="update online set date_time='"+DateTime.Now+"',litterno="+rep(where)+" where [no]="+Session["guestno"].ToString();
					command=new OleDbCommand(sql,link);
					command.ExecuteNonQuery();
				}
			}
			else
			{
				sql="select [no] from online where user_id="+rep(Session["user_id"].ToString());
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					read.Close();
					sql="update online set date_time='"+DateTime.Now+"',litterno="+rep(where)+"where user_name='��Ա' and user_id="+rep(Session["user_id"].ToString());
					command=new OleDbCommand(sql,link);
					command.ExecuteNonQuery();
				}
				else
				{
					sql="insert into online(user_id,user_name,ip,date_time,isbp,litterno) values("+rep(Session["user_id"].ToString())+",'��Ա',"+ip+",'"+DateTime.Now+"',1,"+rep(where)+")";
					read.Close();
					command=new OleDbCommand(sql,link);
					command.ExecuteNonQuery();
				}
			}
			TimeSpan tt=new TimeSpan(0,0,0,refreshtime,0);
			
//			sql="delete from online where date_time<'"+(DateTime.Now-tt).ToString()+"'";
			sql="delete from online where date_time<#"+(DateTime.Now-tt).ToString()+"#";
			//			Response.Write(sql);
//			Response.End();
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
		}
		public bool isnewmessage(string user_id)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql;
			int messageno;
			sql="select count(no) from bpmessage where user_id="+rep(user_id)+" and innew='δ��'";
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			read.Read();
			messageno=(int)read.GetValue(0);
			read.Close();
			if(messageno>0)
				return(true);
			else
				return(false);
		}
		public string getowner(string litterno)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql,owner="����:";
			sql="select owner1,owner2,owner3 from bbslitter where [no]="+litterno;
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				if(read.GetValue(0).ToString()=="admin" || read.GetValue(0).ToString().Trim()=="")
					owner+="<a href=sq.aspx?type=old&ownertype=owner1&litterno="+litterno+" target=_blank>��Ҫ����</a>&nbsp;";
				else
					owner+="<a href=\"javascript:openScript('bp.aspx?type=new&user_id="+read.GetValue(0).ToString()+"',420,320)\">"+read.GetValue(0).ToString()+"</a>&nbsp;";
				if(read.GetValue(1).ToString()=="admin" || read.GetValue(0).ToString().Trim()=="")
					owner+="<a href=sq.aspx?type=old&ownertype=owner2&litterno="+litterno+" target=_blank>��Ҫ����</a>&nbsp;";
				else
					owner+="<a href=\"javascript:openScript('bp.aspx?type=new&user_id="+read.GetValue(1).ToString()+"',420,320)\">"+read.GetValue(1).ToString()+"</a>&nbsp;";
				if(read.GetValue(2).ToString()=="admin" || read.GetValue(0).ToString().Trim()=="")
					owner+="<a href=sq.aspx?type=old&ownertype=owner3&litterno="+litterno+" target=_blank>��Ҫ����</a>";
				else
					owner+="<a href=\"javascript:openScript('bp.aspx?type=new&user_id="+read.GetValue(2).ToString()+"',420,320)\">"+read.GetValue(2).ToString()+"</a>";
				read.Close();
				return(owner);
			}
			else
			{
				read.Close();
				return("");
			}
		}
		public void del_user(string deluserid)
		{
			OleDbCommand command;
			string sql;
			sql="delete from "+usertable+" where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from message where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from hf_message where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from jhq where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from online where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from bpmessage where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			sql="delete from fs where user_id="+rep(deluserid);
			command=new OleDbCommand(sql,link);
			command.ExecuteNonQuery();
			getlittervalue();
		}

		public void getbbsset(string litterno,string messageno)
		{
			OleDbCommand command;
			OleDbDataReader read;
			string sql;
			sql="select * from bbssystemset";
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				usertable=read["usertable"].ToString();
				userdatabase=read["usertable"].ToString();
				bbsname=read["bbsname"].ToString();
				defaultfs=(int)read["kyf"];  
				dayfs=(int)read["zjkyf"];
				hffs=(int)read["hfdf"];
				fbfs=(int)read["ftdf"];
				llfs=(int)read["lldf"];
				bq1=read["bq1"].ToString();
				bq2=read["bq2"].ToString();
				delfs=(int)read["delfs"];
				delcyf=(int)read["delcyf"];
				delhffs=(int)read["delhffs"];
				delhfcyf=(int)read["delhfcyf"];
				deluser=(int)read["deluser"];
				jhfs=(int)read["jhfs"];
				jhcyf=(int)read["jhcyf"];
				tg1addfs=(int)read["tgfs"];
				tg1addcyf=(int)read["tgcyf"];
				changecyftofs=(int)read["changefs"];
				jshead=read["jshead"].ToString();
				bbspath=read["bbspath"].ToString();
			}
			read.Close();
			if(messageno!="0")
			{
				sql="select litterno from message where [no]="+messageno;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					litterno=read.GetValue(0).ToString();
				}
				read.Close();
			}
			if(litterno!=null && litterno!="" && litterno!="0" )
			{
				sql="select lys,logo,logolj,gonggao,gonggaolj,html,ubb,script,flash,img,zt,ft,hf,whouploadimage,zjfuploadimage,uploadimage,headcolor,color1,color2,headforecolor,itemforecolor,articlepage,articletype,zjftype,zjfvalue from bbsset where litterno="+litterno;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					pagesize=(int)read.GetValue(0);
					logo=read.GetValue(1).ToString();
					logolj=read.GetValue(2).ToString();
					gg=read.GetValue(3).ToString();
					gglj=read.GetValue(4).ToString();
					ishtml=(int)read.GetValue(5);
					isubb=(int)read.GetValue(6);
					isscript=(int)read.GetValue(7);
					isflash=(int)read.GetValue(8);
					isimg=(int)read.GetValue(9);
					ztset=(int)read.GetValue(10);
					ftset=(int)read.GetValue(11);
					hfset=(int)read.GetValue(12);
					whouploadimage=(int)read.GetValue(13);
					zjfuploadimage=(int)read.GetValue(14);
					uploadimageset=(int)read.GetValue(15);
					headcolor=read.GetValue(16).ToString();
					color1=read.GetValue(17).ToString();
					color2=read.GetValue(18).ToString();
					headforecolor=read.GetValue(19).ToString();
					itemforecolor=read.GetValue(20).ToString();
					articletype=read["articletype"].ToString();
					articlepage=(int)read["articlepage"];
					zjftype=(int)read["zjftype"];
					zjfvalue=(int)read["zjfvalue"];
					read.Close();
				}
				else
				{
					read.Close();
					sql="select lys,logo,logolj,gonggao,gonggaolj,html,ubb,script,flash,img,zt,ft,hf,whouploadimage,zjfuploadimage,uploadimage,headcolor,color1,color2,headforecolor,itemforecolor,articletype,articlepage,zjftype,zjfvalue from bbsset where litterno=0";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						pagesize=(int)read.GetValue(0);
						logo=read.GetValue(1).ToString();
						logolj=read.GetValue(2).ToString();
						gg=read.GetValue(3).ToString();
						gglj=read.GetValue(4).ToString();
						ishtml=(int)read.GetValue(5);
						isubb=(int)read.GetValue(6);
						isscript=(int)read.GetValue(7);
						isflash=(int)read.GetValue(8);
						isimg=(int)read.GetValue(9);
						ztset=(int)read.GetValue(10);
						ftset=(int)read.GetValue(11);
						hfset=(int)read.GetValue(12);
						whouploadimage=(int)read.GetValue(13);
						zjfuploadimage=(int)read.GetValue(14);
						uploadimageset=(int)read.GetValue(15);
						headcolor=read.GetValue(16).ToString();
						color1=read.GetValue(17).ToString();
						color2=read.GetValue(18).ToString();
						headforecolor=read.GetValue(19).ToString();
						itemforecolor=read.GetValue(20).ToString();
						articletype=read["articletype"].ToString();
						articlepage=(int)read["articlepage"];
						zjftype=(int)read["zjftype"];
						zjfvalue=(int)read["zjfvalue"];
						read.Close();
					}
					else
					{
						read.Close();
					}
				}
			}
		}
		public bool checklogin(string checkuser,string checkpassword)
		{
			string sql,addfs;
			OleDbCommand command;
			OleDbDataReader read;
			DateTime lastday;
			TimeSpan howday;
			if(checkuser==""||checkuser==null||checkpassword==""||checkpassword==null)
				return false;
			sql="select user_id,dateandtime,ishy,usertype from "+usertable+" where user_id="+rep(checkuser)+" and password="+rep(checkpassword)+" and canlogin=1";
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				lastday=(DateTime)read.GetValue(1);
				howday=DateTime.Now-lastday;
				if(howday.Days>0)
					addfs=(dayfs*howday.Days).ToString();
				else
					addfs="0";
				Session["hy"]=2;
				if((int)read.GetValue(2)==1)
					Session["hy"]=3;
				if((int)read.GetValue(3)==1)
					Session["hy"]=4;
				read.Close();
				if(addfs=="0")
					sql="update "+usertable+" set dlcs=dlcs+1 where user_id="+rep(checkuser);
				else
					sql="update "+usertable+" set fs=fs+"+addfs+",dlcs=dlcs+1,dateandtime='"+DateTime.Now+"' where user_id="+rep(checkuser);
				command=new OleDbCommand(sql,link);
				command.ExecuteNonQuery();

				Session["user_id"]=checkuser;
				Session["password"]=checkpassword;
		
				sql="select [no] from bbslitter where owner3="+rep(checkuser)+" or owner2="+rep(checkuser);
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					Session["key"]="check2";
				}
				read.Close();

				sql="select [no] from bbslitter where owner1="+rep(checkuser);
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					Session["key"]="check1";
				}
				read.Close();

				sql="select user_id from bbsadmin where user_id="+rep(checkuser);
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					Session["hy"]=5;
					Session["key"]="super";
				}
				read.Close();
				return true;
			}
			else
			{
				read.Close();
				return false;
			}
		}
		public string addimagenr(string nr,int gl)
		{
			string delno,gs,returnstring="";
			int i,j,js;
			gs=",";
			if(nr!="")
			{
				j=nr.IndexOf(gs,0);
				i=1-gs.Length;
				js=0;
				while(j>0)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					if(gl==1)
						returnstring+="<img src=\"uploadimage/"+delno+"\">";
					else
						returnstring+="<img src=\"../uploadimage/"+delno+"\">";
					i=j+1;
					j=nr.IndexOf(gs,j+1);
				}
				j=nr.Length;
				if(j-i>=1)
				{
					delno=nr.Substring(i+gs.Length-1,j-i-gs.Length+1);
					if(gl==1)
						returnstring+="<img src=\"uploadimage/"+delno+"\">";
					else
						returnstring+="<img src=\"../uploadimage/"+delno+"\">";
				}
			}
			js=0;
			return(returnstring);
		}

		public string getpage(string no,int litterno,int gl)
		{ 
//			if(articletype=="shtml"||articletype=="html"||articletype=="aspx")
//			{
				string you_user_id,ml,qianming,usericon,userjb,userstar,hfs;
				string zjftype="0",zjfvalue="0",articleuser="";
				you_user_id=(string)Session["user_id"];
				string mbnr="",littername="",sql,filenr="",contentnr,ip,zz="",linemb,nr="",linenr="";
				int zt=0,isyou,hfno,hfbegin,hfend,cyf=0;
				if(gl==1)
					ml="";
				else
					ml="../";
				OleDbCommand command;
				OleDbDataReader read;
				OleDbCommand command1;
				OleDbDataReader read1;
				sql="select bbsmb.nr from message,bbsmb where message.mbid=bbsmb.[no] and message.[no]="+no;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					mbnr=read.GetValue(0).ToString();
				}
				read.Close();

				sql="select name from bbslitter where [no]="+litterno;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
//					mbnr=read.GetValue(0).ToString();
					littername=read.GetValue(0).ToString();
				}
				read.Close();

				//			mbnr=mbnr.Replace("\r","");
				//			mbnr=mbnr.Replace("\n","");
				open2();

				sql="select user_id,isjhq,zhuti,nr,fs,hf,date_time,zt,autoaddimage,uploadimage,editmessage,gftype from message where [no]="+no;
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					zjftype=read["gftype"].ToString();
					zjfvalue=read["fs"].ToString();
					zz=read.GetValue(0).ToString();
					articleuser=read.GetValue(0).ToString();
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_title",read.GetValue(2).ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_zz","<a href=\""+ml+"listuser.aspx?user_id="+read.GetValue(0).ToString()+"\" target=\"_blank\">"+read.GetValue(0).ToString()+"</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_bp","<a href=\"javascript:openScript('"+ml+"bp.aspx?type=new&user_id="+zz+"',420,320)\">����Ϣ</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_mail","<a href=\"javascript:openScript('"+ml+"send.aspx?user_id="+zz+"',420,320)\">�ʼ�</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_littername",littername);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_hfs",read.GetValue(5).ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_datetime",read.GetValue(6).ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_no",no);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_edit","<a href=\""+ml+"write.aspx?litterno="+litterno+"&no="+no+"\">�༭</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_del","<a href=\""+ml+"del.aspx?type=del&messageno="+no+"\">ɾ��</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_yy","<a href=\""+ml+"hf.aspx?act=yy&yyno=0&messageno="+no+"\">����</a>");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_litterno",litterno+"");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_message",read["editmessage"].ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_bbsname",bbsname);

					contentnr=changechr(read.GetValue(3).ToString())+"\n";
					if((int)read.GetValue(8)==1&&read.GetValue(9)!=null&&read.GetValue(9).ToString().Trim()!="")
						contentnr+=addimagenr(read.GetValue(9).ToString().Trim(),gl);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_nr",contentnr);
					zt=(int)read.GetValue(7);
				}
/*				if(gl==1)
				{
					if(zt!=2)
					{
						sql="select name,[no] from bbslitter";
						command1=new OleDbCommand(sql,link2);
						read1=command1.ExecuteReader();
						filenr="<select name=\"move\" size=\"1\" onchange=\"location=this.options[this.selectedIndex].value\">";
						while(read1.Read())
						{
							if((int)read1.GetValue(1)==litterno)
								filenr+="<option value=\"gl.aspx?no="+no+"&litterno="+read1.GetValue(1).ToString()+"&move=1\" selected>"+read1.GetValue(0).ToString()+"</option>";
							else
								filenr+="<option value=\"gl.aspx?no="+no+"&litterno="+read1.GetValue(1).ToString()+"&move=1\">"+read1.GetValue(0).ToString()+"</option>";
						}
						filenr+="</select>";
						mbnr=mbnr.Replace("www.aspx.net.cn_bbs_move",filenr);
						read1.Close();
					}
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_move","");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_form_begin","<form action='gl.aspx?no="+no+"' method='post' name='form1'>");

					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_form_end","<input type=\"hidden\" name=\"options\" value=\"\"></from>");
			
					mbnr=mbnr.Replace("www.aspx.net.cn_gl_begin","");
					mbnr=mbnr.Replace("www.aspx.net.cn_gl_end","");
				}
				else
				{
					mbnr=Regex.Replace(mbnr,@"www.aspx.net.cn_gl_begin([^\]]*)www.aspx.net.cn_gl_end",@"");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_form_begin","");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_form_end","");
				}
*/				read.Close();
				sql="select usericon,imagewidth,imageheight,qianming,systemicon,cyf,date_time,fts,hfs from "+usertable+" where user_id="+rep(zz);
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					qianming=read.GetValue(3).ToString();
					//				qianming=texttohtml(qianming);
					qianming=changechr(qianming);
					if(read.GetValue(0).ToString()=="")
						usericon="<img src=\""+ml+"images/face/"+read.GetValue(4).ToString()+"\">";
					else
						usericon="<img src=\""+read.GetValue(0).ToString()+"\" width=\""+read.GetValue(1).ToString()+"\" height=\""+read.GetValue(2).ToString()+"\">";
					cyf=(int)read.GetValue(5);
					userjb=name0;
					userstar=star0;
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_usericon",usericon);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_qianming",qianming);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_userfs",cyf+"");
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_fts",read.GetValue(7).ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_user_hfs",read.GetValue(8).ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_user_datetime",read.GetValue(6).ToString());
				}
				read.Close();
				sql="select top 1 * from jbmanage where jf<="+cyf+" order by jf desc";
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				if(read.Read())
				{
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_username",read["name"].ToString());
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_star",read["icon"].ToString());
				}
				else
				{
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_username",name0);
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_star",star0);
				}
				read.Close();

				sql="select user_id,date_time,nr,fs,[no],IP,editmessage,[no] from hf_message where messageno="+no+" order by date_time";
				command=new OleDbCommand(sql,link);
				read=command.ExecuteReader();
				hfbegin=mbnr.IndexOf("www.aspx.net.cn_hf_begin",0);
				hfend=mbnr.IndexOf("www.aspx.net.cn_hf_end",0);
				linemb=mbnr.Substring(hfbegin,hfend-hfbegin);
				nr="";
				while(read.Read())
				{
					zz=read.GetValue(0).ToString();
					linenr=linemb;
					linenr=linenr.Replace("www.aspx.net.cn_hf_userid","<a href=\""+ml+"listuser.aspx?user_id="+zz+"\">"+zz+"</a>");

					linenr=linenr.Replace("www.aspx.net.cn_hf_datetime",read.GetValue(1).ToString());
					linenr=linenr.Replace("www.aspx.net.cn_hf_bp","<a href=\"javascript:openScript('"+ml+"bp.aspx?type=new&user_id="+zz+"',420,320)\">����Ϣ</a>");
					linenr=linenr.Replace("www.aspx.net.cn_hf_mail","<a href=\"javascript:openScript('"+ml+"send.aspx?user_id="+zz+"',420,320)\">�ʼ�</a>");
					linenr=linenr.Replace("www.aspx.net.cn_hf_hf",changechr(read.GetValue(2).ToString()));
					linenr=linenr.Replace("www.aspx.net.cn_hf_edit","<a href=\""+ml+"hf.aspx?no="+read.GetValue(4).ToString()+"\">�༭</a>");
					linenr=linenr.Replace("www.aspx.net.cn_hf_del","<a href=\""+ml+"del.aspx?act=delhf&hfno="+read["no"].ToString()+"\">ɾ��</a>");
					linenr=linenr.Replace("www.aspx.net.cn_hf_yy","<a href=\""+ml+"hf.aspx?act=yy&messageno="+no+"&yyno="+read["no"].ToString()+"\">����</a>");
					linenr=linenr.Replace("www.aspx.net.cn_hf_message",read["editmessage"].ToString());
					if(zjftype=="1"&&articleuser!=zz)
						linenr=linenr.Replace("www.aspx.net.cn_hf_thank","<a href=\"../gf.aspx?no="+no+"&hfno="+read["no"].ToString()+"\">̫���ˣ����Ļش������ҵ�����</a>");
					else
					{
						if(zjftype=="2"&&(int)read["fs"]>0)
						{
							linenr=linenr.Replace("www.aspx.net.cn_hf_thank","<font color=red>������"+read["fs"].ToString()+"</font>");
						}
						else
						{
							linenr=linenr.Replace("www.aspx.net.cn_hf_thank","");
						}
					}

					sql="select usericon,imagewidth,imageheight,qianming,systemicon,cyf,date_time,fts,hfs from "+usertable+" where user_id="+rep(zz);
					command1=new OleDbCommand(sql,link2);
					read1=command1.ExecuteReader();
					if(read1.Read())
					{
						qianming=read1.GetValue(3).ToString();
						//					qianming=texttohtml(qianming);
						qianming=changechr(qianming);
						if(read1.GetValue(0).ToString()=="")
							usericon="<img src=\""+ml+"images/face/"+read1.GetValue(4).ToString()+"\">";
						else
							usericon="<img src=\""+read1.GetValue(0).ToString()+"\" width=\""+read1.GetValue(1).ToString()+"\" height=\""+read1.GetValue(2).ToString()+"\">";
						cyf=(int)read1.GetValue(5);
						userjb=name0;
						userstar=star0;
						//					hfs=((int)read1.GetValue(7)+(int)read1.GetValue(8))+"";
						linenr=linenr.Replace("www.aspx.net.cn_hf_usericon",usericon);
						linenr=linenr.Replace("www.aspx.net.cn_hf_qianming",qianming);
						linenr=linenr.Replace("www.aspx.net.cn_hf_userfs",cyf+"");
//						linenr=linenr.Replace("www.aspx.net.cn_hf_username",userjb);
//						linenr=linenr.Replace("www.aspx.net.cn_hf_star",userstar);
						linenr=linenr.Replace("www.aspx.net.cn_hf_fts",read1.GetValue(7).ToString());
						linenr=linenr.Replace("www.aspx.net.cn_hf_user_hfs",read1.GetValue(8).ToString());
						linenr=linenr.Replace("www.aspx.net.cn_hf_user_datetime",read1.GetValue(6).ToString());
					}
					read1.Close();
					sql="select top 1 *  from jbmanage where jf<="+cyf+" order by jf desc";
					command1=new OleDbCommand(sql,link2);
					read1=command1.ExecuteReader();
					if(read1.Read())
					{
						linenr=linenr.Replace("www.aspx.net.cn_hf_username",read1["name"].ToString());
						linenr=linenr.Replace("www.aspx.net.cn_hf_star",read1["icon"].ToString());
					}
					else
					{
						linenr=linenr.Replace("www.aspx.net.cn_hf_username",name0);
						linenr=linenr.Replace("www.aspx.net.cn_hf_star",star0);
					}
					nr=nr+linenr;
					read1.Close();
				}
				read.Close();
				nr=mbnr.Substring(0,hfbegin)+nr+mbnr.Substring(hfend);
				nr=nr.Replace("www.aspx.net.cn_hf_begin","");
				nr=nr.Replace("www.aspx.net.cn_hf_end","");
				link2.Close();

				nr=nr.Replace("www.aspx.net.cn_bbs_hits","<script language=\"javascript\" src=\""+ml+"hits.aspx?no="+no+"\"><"+"/script>");
				return nr;
//			}
//			if(articletype=="xml")
//			{
//				return "";
//			}
//			return "";
		}
		public bool checkbz(string litterno,string message)
		{ 
			string sql,user_id;
			OleDbCommand command;
			OleDbDataReader read;
			user_id=Session["user_id"].ToString();
			if(litterno!="0")
			{
				if(Session["key"]!=null&&Session["key"].ToString()=="super")
					return true;
				if(user_id=="")
					return false;
				else
				{
					sql="select [no] from bbslitter where [no]="+litterno+" and (owner1="+rep(user_id)+" or owner2="+rep(user_id)+" or owner3="+rep(user_id)+")";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						read.Close();
						return true;
					}
					else
					{
						read.Close();
						return false;
					}
				}
			}
			if(message!="0")
			{
				if(Session["key"]!=null&&Session["key"].ToString()=="super")
					return true;
				if(user_id=="")
					return false;
				else
				{
					sql="select bbslitter.[no] from message,bbslitter where message.[no]="+message+" and message.litterno=bbslitter.[no] and (owner1="+rep(user_id)+" or owner2="+rep(user_id)+" or owner3="+rep(user_id)+")";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						read.Close();
						return true;
					}
					else
					{
						read.Close();
						return false;
					}
				}
			}
			return false;
		}
		public bool checksuper()
		{
			if(Session["key"]==null)
				return false;
			if(Session["key"].ToString()!="super")
				return false;
			else 
				return true;
		}
		public void makepage()
		{
			string nr="",adminnr="",sql;
			if(File.Exists(Server.MapPath("menu.htm")))
				File.Delete(Server.MapPath("menu.htm"));
			if(File.Exists(Server.MapPath("adminmenu.htm")))
				File.Delete(Server.MapPath("adminmenu.htm"));

			OleDbCommand command,command1;
			OleDbDataReader read,read1;
			int i=1;
	
			open2();
			sql="select name,[no] from bbsbig";
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			while(read.Read())
			{
				nr=nr+"<div id=\"KB"+i+"Parent\" class=\"parent\">";
				nr=nr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				nr=nr+"<IMG align=absMiddle ";
				nr=nr+"  border=0 src=\"img/i_option.gif\"></a>";
				nr=nr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				nr=nr+read.GetValue(0).ToString()+"</a> </div>";
				nr=nr+"<div id=\"KB"+i+"Child\" class=\"child\">";
		
				adminnr=adminnr+"<div id=\"KB"+i+"Parent\" class=\"parent\">";
				adminnr=adminnr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				adminnr=adminnr+"<IMG align=absMiddle ";
				adminnr=adminnr+"  border=0 src=\"img/i_option.gif\"></a>";
				adminnr=adminnr+ "<a href=\"#\" onClick=\"expandIt('KB"+i+"'); return false\"> ";
				adminnr=adminnr+read.GetValue(0).ToString()+"</a> </div>";
				adminnr=adminnr+"<div id=\"KB"+i+"Child\" class=\"child\">";
		
				sql="select [no],name from bbslitter where bigno="+(int)read.GetValue(1);
				command1=new OleDbCommand(sql,link2);
				read1=command1.ExecuteReader();
				while(read1.Read())
				{
					nr=nr+"&nbsp;&nbsp;<IMG align=absMiddle border=0 src=\"img/filebox.gif\">";
					nr=nr+"<a href=adminmain.aspx?litterno="+read1.GetValue(0).ToString()+"  target=\"frmright\">"+read1.GetValue(1).ToString()+"</a><br>";

					adminnr=adminnr+"&nbsp;&nbsp;<IMG align=absMiddle border=0 src=\"img/filebox.gif\">";
					adminnr=adminnr+"<a href=adminadminmain.aspx?litterno="+read1.GetValue(0).ToString()+"  target=\"frmright\">"+read1.GetValue(1).ToString()+"</a><br>";
				}
				nr=nr+"</div>";
				adminnr=adminnr+"</div>";
				read1.Close();
				i++;
			}
			read.Close();
			link2.Close();

			FileStream writefile = new FileStream(Server.MapPath("menu.htm"), FileMode.OpenOrCreate, FileAccess.Write); 
			StreamWriter wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(nr);
			wf.Close();
	
			writefile = new FileStream(Server.MapPath("adminmenu.htm"), FileMode.OpenOrCreate, FileAccess.Write); 
			wf= new StreamWriter(writefile,Encoding.Default); 
			wf.Write(adminnr);
			wf.Close();
		}

		public OleDbConnection link;
		public OleDbConnection link1;
		public OleDbConnection link2;
		public OleDbConnection link3;
		public string newsaddress="http://www/news/news1/";
		public void open()
		{ 
			string linkstr="provider=Microsoft.jet.OLEDB.4.0;data Source="+Server.MapPath(databasepath)+";";
//			link=new OleDbConnection(ls.linkstring);
			link=new OleDbConnection(linkstr);
			link.Open();
		}
		public void open1()
		{ 
			string linkstr="provider=Microsoft.jet.OLEDB.4.0;data Source="+Server.MapPath(databasepath)+";";
			link1=new OleDbConnection(linkstr);
			link1.Open();
		}
		public void open2()
		{ 
			string linkstr="provider=Microsoft.jet.OLEDB.4.0;data Source="+Server.MapPath(databasepath)+";";
			link2=new OleDbConnection(linkstr);
			link2.Open();
		}
		public void open3()
		{ 
			string linkstr="provider=Microsoft.jet.OLEDB.4.0;data Source="+Server.MapPath(databasepath)+";";
			link3=new OleDbConnection(linkstr);
			link3.Open();
		}
		public string rep(string cc)
		{
			if(cc==null)
				return "null";
			cc=cc.Trim();
			if(cc=="")
				return "null";
			else
				cc=cc.Replace("'","''");
			cc="'"+cc+"'";
			return cc;
		}
		public string rep1(string cc)
		{
			if(cc==null)
				cc="";
			cc=cc.Trim();
			if(cc=="")
				cc=" ";
			else
				cc=cc.Replace("'","''");
			cc="'%"+cc+"%'";
			return cc;
		}
		public void sendmail(string from,string to,string zhuti,string nr,int html)
		{ 
			MailMessage mail;
			mail=new MailMessage();
	
			mail.From=from;
			mail.To=to;
			mail.Subject=zhuti;
			mail.Body=nr;
			if(html==1)
				mail.BodyFormat=MailFormat.Html;
			SmtpMail.Send(mail);
		}

		public void sendtouser(string from,string user_id,string zhuti,string nr,int html)
		{
			OleDbDataReader read;
			OleDbCommand command;
			string sql="select e_mail from "+usertable+" where user_id="+rep(user_id);
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				MailMessage mail;
				mail=new MailMessage();
		
				mail.From=from;
				mail.To=read.GetValue(0).ToString();
				mail.Subject=zhuti;
				mail.Body=nr;
				if(html==1)
					mail.BodyFormat=MailFormat.Html;
				try
				{
					SmtpMail.Send(mail);
				}
				catch
				{
				}
			}
			read.Close();
		}
		public string getadmin_mail()
		{
			OleDbDataReader read;
			OleDbCommand command;
			string sql="select e_mail from "+usertable+" where user_id='admin'";
			string adminmail="";
			command=new OleDbCommand(sql,link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				adminmail=read.GetValue(0).ToString();
			}
			read.Close();
			return(adminmail);
		}
		public bool checkbzorowner(string litterno,string message,string hfno)
		{ 
			string sql,user_id,owner="";
			OleDbCommand command;
			OleDbDataReader read;
			user_id=Session["user_id"].ToString();
			if(litterno!="0")
			{
				if(Session["key"]!=null&&Session["key"].ToString()=="super")
					return true;
				if(user_id=="")
					return false;
				else
				{
					sql="select [no] from bbslitter where [no]="+litterno+" and (owner1="+rep(user_id)+" or owner2="+rep(user_id)+" or owner3="+rep(user_id)+")";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						read.Close();
						return true;
					}
					else
					{
						read.Close();
						return false;
					}
				}
			}
			if(message!="0")
			{
				if(Session["key"]!=null&&Session["key"].ToString()=="super")
				{
					sql="select user_id,litterno from message where [no]="+message;
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					read.Read();
					returnuser=read.GetValue(0).ToString();
					read.Close();
					return true;
				}
				if(user_id=="")
					return false;
				else
				{
					sql="select user_id,litterno from message where [no]="+message;
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						owner=read.GetValue(0).ToString();
						litterno=read.GetValue(1).ToString();
						returnuser=owner;
					}
					read.Close();
					if(owner==user_id)
					{
						return true;
					}
					sql="select [no] from bbslitter where [no]="+litterno+" and (owner1="+rep(user_id)+" or owner2="+rep(user_id)+" or owner3="+rep(user_id)+")";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						read.Close();
						return true;
					}
					else
					{
						read.Close();
						return false;
					}
				}
			}
			if(hfno!="0")
			{
				if(Session["key"]!=null&&Session["key"].ToString()=="super")
				{
					sql="select user_id,litterno from hf_message where [no]="+hfno;
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						owner=read.GetValue(0).ToString();
						litterno=read.GetValue(1).ToString();
						returnuser=owner;
					}
					read.Close();
					return true;
				}
				if(user_id=="")
					return false;
				else
				{
					sql="select user_id,litterno from hf_message where [no]="+hfno;
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						owner=read.GetValue(0).ToString();
						litterno=read.GetValue(1).ToString();
						returnuser=owner;
					}
					read.Close();
					if(owner==user_id)
						return true;
					sql="select [no] from bbslitter where [no]="+litterno+" and (owner1="+rep(user_id)+" or owner2="+rep(user_id)+" or owner3="+rep(user_id)+")";
					command=new OleDbCommand(sql,link);
					read=command.ExecuteReader();
					if(read.Read())
					{
						read.Close();
						return true;
					}
					else
					{
						read.Close();
						return false;
					}
				}
			}
			return false;
		}

		public void z(string test)
		{
			Response.Write(test);
			Response.End();
		}
		public config()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
