using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for topexp.
	/// </summary>
	public class topexp : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid zjf;
		protected System.Web.UI.WebControls.DataGrid cyf;
		protected System.Web.UI.WebControls.DataGrid lmnr;
		protected System.Web.UI.HtmlControls.HtmlGenericControl allfs;
		protected System.Web.UI.HtmlControls.HtmlGenericControl monthfs;
		protected System.Web.UI.HtmlControls.HtmlForm online;
		protected config con=new config();
		protected System.Web.UI.WebControls.DataGrid ft;
		DataSet ds;
		protected void Page_Load(Object sender, EventArgs e)
		{
			con.open();
			string sql;
			int mon,year;

			string tomonth;
			mon=DateTime.Now.Month;
			year=DateTime.Now.Year;
			if(mon<10)
				tomonth=""+year+"-0"+mon;
			else
				tomonth=""+year+"-"+mon;
	
			if(Request.QueryString["month"]==null)
			{
				monthfs.Visible=false;
				allfs.Visible=true;

				sql="select top 50 user_id,user_name,zjf,cyf,fts+hfs as totleft from "+con.usertable+" order by zjf desc,cyf desc";
				OleDbCommand command=new OleDbCommand(sql,con.link);
				OleDbDataAdapter datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
//				Response.Write(sql);
//				Response.End();
				zjf.DataSource=ds.Tables["type"].DefaultView;
				zjf.DataBind();

				sql="select top 50 user_id,user_name,zjf,cyf,fts+hfs as totleft from "+con.usertable+" order by cyf desc,zjf desc";
				command=new OleDbCommand(sql,con.link);
				datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
				cyf.DataSource=ds.Tables["type"].DefaultView;
				cyf.DataBind();

				sql="select top 50 user_id,user_name,zjf,cyf,fts+hfs as totleft from "+con.usertable+" order by fts+hfs desc,zjf desc";
				command=new OleDbCommand(sql,con.link);
				datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
				ft.DataSource=ds.Tables["type"].DefaultView;
				ft.DataBind();
			}
			else
			{
				sql="select top 50 fs.user_id,"+con.usertable+".user_name,fs.zjf from fs,"+con.usertable+" where fs.user_id="+con.usertable+".user_id and month='"+Request.QueryString["month"]+"' order by fs.zjf desc";
				monthfs.Visible=true;
				allfs.Visible=false;

				OleDbCommand command=new OleDbCommand(sql,con.link);
				OleDbDataAdapter datasel=new OleDbDataAdapter();
				datasel.SelectCommand=command;
				ds=new DataSet();
				datasel.Fill(ds,"type");
				lmnr.DataSource=ds.Tables["type"].DefaultView;
				lmnr.DataBind();
			}
			con.link.Close();
		}

		protected void changepage(object sender,DataGridPageChangedEventArgs e)
		{ 
			con.open();
			((DataGrid)sender).DataSource=ds.Tables["type"].DefaultView;
			((DataGrid)sender).CurrentPageIndex = e.NewPageIndex;
			((DataGrid)sender).DataBind();
			con.link.Close();
		}
		public topexp()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
