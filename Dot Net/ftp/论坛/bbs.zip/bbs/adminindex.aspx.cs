using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for index.
	/// </summary>
	public class adminindex : System.Web.UI.Page
	{
		protected string listall;
		protected System.Web.UI.HtmlControls.HtmlGenericControl openscript;
		protected System.Web.UI.WebControls.Label loginsuccess;
		protected string indexhead;
		protected string indexend;
		protected System.Web.UI.HtmlControls.HtmlForm indexform;
		protected System.Web.UI.WebControls.DropDownList savepassword;
		config con=new config();
		protected void checkmessage(string user_id)
		{
			bool newmessage=con.isnewmessage(user_id);
			if(newmessage)
			{
				openscript.InnerHtml="<script language=javascript><!--\nopenScript('bp.aspx?type=inbox',420,320);\n--><"+"/script>";
			}
		}
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			string welcomeuser;
			con.open();
			HttpCookie cookie=Request.Cookies["aspx"];
			if(Session["user_id"]==null&&cookie!=null&&cookie["user_id"]!=null&&cookie["user_id"]!="")
			{
				if(con.checklogin(cookie["user_id"],cookie["password"]))
				{
					Session["user_id"]=cookie["user_id"]; 
				}
				else
				{
					Session["user_id"]=null;
				}
				cookie.Expires=DateTime.Now.AddDays(Int32.Parse(cookie["savepassword"]));
				Response.Cookies.Add(cookie);
			}
			if(Session["user_id"]!=null)
			{
				welcomeuser=Session["user_id"].ToString(); 
			}
			else
			{
				welcomeuser="����";
			}
			string user_id=(string)Session["user_id"];

			OleDbCommand command,command1,command2;
			OleDbDataReader read,read1,read2;
			int i=1,j,k,totlezhuti=0,totlehf=0;
			string nr="",owner1,owner2,owner3,sql,mbnr="",biglinemb,litterlinemb,templine,tablenr;
		
			con.open2();
			con.open3();
			if(user_id!=null)
				checkmessage(user_id);
			sql="select nr from bbsmb where name='��ҳģ��'";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbnr=read.GetValue(0).ToString();
			}
			read.Close();
			mbnr=mbnr.Replace("www.aspx.net.cn_bbs_welcome",welcomeuser);
			sql="select zhuti,html,date_time from ggmessage where litterno=0";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				if(read.GetValue(1).ToString()=="1")
				{
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_gg",read.GetValue(0).ToString()+"("+read.GetValue(2).ToString()+")");
				}
				else
				{
					mbnr=mbnr.Replace("www.aspx.net.cn_bbs_gg",con.changechr(con.texttohtml(read.GetValue(0).ToString()))+"("+read.GetValue(2).ToString()+")");
				}
			}
			else
			{
				mbnr=mbnr.Replace("www.aspx.net.cn_bbs_gg","");
			}
			read.Close();

			sql="select type from "+con.userdatabase+"sysconfig where valuename='usernum'";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbnr=mbnr.Replace("www.aspx.net.cn_user_no",read.GetValue(0).ToString());
			}
			read.Close();
			sql="select top 1 user_id from "+con.usertable+" order by no desc";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbnr=mbnr.Replace("www.aspx.net.cn_bbs_newuser",read.GetValue(0).ToString());
			}
			read.Close();
			sql="select count(*) from online";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				mbnr=mbnr.Replace("www.aspx.net.cn_bbs_online",read.GetValue(0).ToString());
			}
			read.Close();

			j=mbnr.IndexOf("www.aspx.net.cn_bbs_begin",0);
			indexhead=mbnr.Substring(0,j);
			k=mbnr.IndexOf("www.aspx.net.cn_bbs_end",0);
			indexend=mbnr.Substring(k+23);
			i=mbnr.IndexOf("www.aspx.net.cn_litter_end",0);
			tablenr=mbnr.Substring(i+26,k-i-26);
			mbnr=mbnr.Substring(j+25,k-j-25);

			j=mbnr.IndexOf("www.aspx.net.cn_big_begin",0);
			k=mbnr.IndexOf("www.aspx.net.cn_big_end",0);
			biglinemb=mbnr.Substring(j+25,k-j-25);
			j=mbnr.IndexOf("www.aspx.net.cn_litter_begin",0);
			k=mbnr.IndexOf("www.aspx.net.cn_litter_end",0);
			litterlinemb=mbnr.Substring(j+28,k-j-28);
			sql="select name,[no] from bbslitter where par=0 order by orderno";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			

			while(read.Read())
			{
				templine=biglinemb;
				templine=templine.Replace("www.aspx.net.cn_big_name",read.GetValue(0).ToString());
				nr=nr+templine;
				sql="select [no],name,owner1,owner2,owner3,zhutino,zhutino+hfno,sm from bbslitter where par="+read.GetValue(1).ToString()+" order by orderno";
				command1=new OleDbCommand(sql,con.link2);
				read1=command1.ExecuteReader();
				while(read1.Read())
				{
					//					totlezhuti+=(int)read1.GetValue(5);
					//					totlehf+=(int)read1.GetValue(6);
					templine=litterlinemb;
					owner1=read1.GetValue(2).ToString();
					owner2=read1.GetValue(3).ToString();
					owner3=read1.GetValue(4).ToString();
					if(owner1=="admin"||owner1==null||owner1=="")
						owner1="";
					else
						owner1="<a href=\"listuser.aspx?user_id="+owner1+"\">"+owner1+"</a><br>";
					if(owner2=="admin"||owner2==null||owner2=="")
						owner2="";
					else
						owner2="<a href=\"listuser.aspx?user_id="+owner2+"\">"+owner2+"</a><br>";
					if(owner3=="admin"||owner3==null||owner3=="")
						owner3="";
					else
						owner3="<a href=\"listuser.aspx?user_id="+owner3+"\">"+owner3+"</a><br>";

					templine=templine.Replace("www.aspx.net.cn_litter_owner",owner1+owner2+owner3);
					templine=templine.Replace("www.aspx.net.cn_litter_name",read1.GetValue(1).ToString());
					templine=templine.Replace("www.aspx.net.cn_litter_no",read1.GetValue(0).ToString());
					templine=templine.Replace("www.aspx.net.cn_litter_zhuti",read1.GetValue(5).ToString());
					templine=templine.Replace("www.aspx.net.cn_litter_hf",read1.GetValue(6).ToString());
					templine=templine.Replace("www.aspx.net.cn_litter_sm",read1["sm"].ToString());
					sql="select top 1 zhuti,newtime,newuser,filename from message where litterno="+read1.GetValue(0).ToString()+" order by newtime desc";
					command2=new OleDbCommand(sql,con.link3);
					read2=command2.ExecuteReader();
					if(read2.Read())
					{
						templine=templine.Replace("www.aspx.net.cn_new_zhuti","<a href=\""+read2.GetValue(3).ToString()+"\">"+con.changechr(con.texttohtml(read2.GetValue(0).ToString()))+"</a>");
						templine=templine.Replace("www.aspx.net.cn_new_datetime",read2.GetValue(1).ToString());
						templine=templine.Replace("www.aspx.net.cn_new_zz","<a href=\"listuser.aspx?user_id="+read2.GetValue(2).ToString()+"\">"+read2.GetValue(2).ToString()+"</a>");
					}
					else
					{
						templine=templine.Replace("www.aspx.net.cn_new_zhuti","");
						templine=templine.Replace("www.aspx.net.cn_new_datetime","");
						templine=templine.Replace("www.aspx.net.cn_new_zz","");
					}
					read2.Close();
					nr=nr+templine;
				}
				read1.Close();
			}
			read.Close();
			sql="select sum(zhutino),sum(hfno+zhutino) from bbslitter";
			command=new OleDbCommand(sql,con.link);
			read=command.ExecuteReader();
			if(read.Read())
			{
				totlezhuti=Int32.Parse(read.GetValue(0).ToString());
				totlehf=Int32.Parse(read.GetValue(1).ToString());
				//				Response.Write(read.GetValue(0).ToString()+"<br>"+read.GetValue(1).ToString());
				//				Response.End();
			}
			con.link2.Close();
			con.link3.Close();
			indexhead=indexhead.Replace("www.aspx.net.cn_bbs_totlezhuti",totlezhuti+"");
			indexhead=indexhead.Replace("www.aspx.net.cn_bbs_totleno",totlezhuti+totlehf+"");

			listall=nr+tablenr;
			listall=listall.Replace("main.aspx","adminmain.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
