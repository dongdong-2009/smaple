using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace bbs
{
	/// <summary>
	/// Summary description for reg.
	/// </summary>
	public class reg : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator2;
		protected System.Web.UI.WebControls.RequiredFieldValidator Requiredfieldvalidator3;
		protected System.Web.UI.WebControls.CompareValidator Comparevalidator1;
		protected System.Web.UI.WebControls.RegularExpressionValidator Regularexpressionvalidator1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl wc;
		protected System.Web.UI.HtmlControls.HtmlGenericControl list;
		protected System.Web.UI.HtmlControls.HtmlInputText user_id;
		protected System.Web.UI.HtmlControls.HtmlInputText password1;
		protected System.Web.UI.HtmlControls.HtmlInputText password2;
		protected System.Web.UI.HtmlControls.HtmlInputText user_name;
		protected System.Web.UI.HtmlControls.HtmlInputText http;
		protected System.Web.UI.HtmlControls.HtmlInputText e_mail;
		protected System.Web.UI.HtmlControls.HtmlInputText dh;
		protected System.Web.UI.HtmlControls.HtmlSelect select;
		protected System.Web.UI.HtmlControls.HtmlInputText oicq;
		protected System.Web.UI.HtmlControls.HtmlInputText dz;
		protected System.Web.UI.HtmlControls.HtmlTextArea jieshao;
		protected System.Web.UI.HtmlControls.HtmlGenericControl zhuceno;
		protected config con=new config();
	
		protected void Page_Load(object sender, EventArgs e)
		{ 
			con.open();
			string sql,usernum;
			sql="select type from "+con.userdatabase+"sysconfig where valuename='usernum'";
			OleDbCommand command=new OleDbCommand(sql,con.link);
			OleDbDataReader net_user;
			net_user=command.ExecuteReader();
			net_user.Read();
			usernum=net_user.GetValue(0).ToString();
			zhuceno.InnerHtml="Ŀǰע���û�������"+usernum;
			net_user.Close();
			con.link.Close();

			wc.Visible=false;
		}

		protected void qr(object sender, EventArgs e)
		{ 
			int i;
			int j;
			j=0;
			string userid,sql,adduser="";
			i=1;
			string insertstr;
			adduser=Request.QueryString["user_id"];
			if(adduser==null||adduser=="")
				adduser="null";
			else
				adduser=con.rep(adduser);
			con.open();
			if(user_id.Value==""||e_mail.Value==""||password1.Value=="")
			{
				i=0;
				wc.InnerHtml="����ؽ�������д����";
			}
			if(password1.Value!=password2.Value)
			{
				i=0;
				wc.InnerHtml="�����ȷ�Ͽ��һ��";
			}
			userid=con.rep(user_id.Value);
			sql="select * from "+con.usertable+" where user_id="+con.rep(user_id.Value);
			OleDbCommand command1=new OleDbCommand(sql,con.link);
			OleDbDataReader net_user1;
			net_user1=command1.ExecuteReader();
			if(net_user1.Read())
			{
				i=0;
				wc.InnerHtml="���д��û����뻻һ����¼��";
			}
			if(i==0)
				list.Visible=true;
			else
			{
				wc.InnerHtml="<p>&nbsp;</p><p>&nbsp;</p><p><b><font size=6><font color=#FF0000>��ϲ��ע��ɹ�����</font></font></b></p><p>&nbsp;</p><p><font color=#000080>���ס��ĵ�¼��������</font></p><p>&nbsp;</p><p></p><p><font color=\"#000080\"><a href=\"index.aspx\">��̳��ҳ</a>&nbsp;<a href=\"default.aspx\">��¼��̳</a>&nbsp;</font></p>";
				list.Visible=false;
				insertstr="insert into "+con.usertable+"(user_id,user_name,e_mail,http,jianjie,oicq,[password],sex,dz,dh,date_time,dateandtime,fs,adduser) values("+con.rep(user_id.Value);
				insertstr=insertstr+","+con.rep(user_name.Value);
				insertstr=insertstr+","+con.rep(e_mail.Value);
				insertstr=insertstr+","+con.rep(http.Value);
				insertstr=insertstr+","+con.rep(jieshao.Value);
				insertstr=insertstr+","+con.rep(oicq.Value);
				insertstr=insertstr+","+con.rep(password1.Value);
				insertstr=insertstr+","+con.rep(select.Value.Trim());
				insertstr=insertstr+","+con.rep(dz.Value);
				insertstr=insertstr+","+con.rep(dh.Value);
				insertstr=insertstr+",'"+DateTime.Now+"'";
				insertstr=insertstr+",'"+DateTime.Now+"'";
				insertstr=insertstr+","+con.defaultfs;
				insertstr=insertstr+","+adduser;
				insertstr=insertstr+")";
				net_user1.Close();	
//				Response.Write(insertstr);
//				Response.End();
				OleDbCommand command2=new OleDbCommand(insertstr,con.link);
				command2.ExecuteNonQuery();
				sql="update "+con.userdatabase+"sysconfig set type=type+1 where valuename='usernum'";
				command2=new OleDbCommand(sql,con.link);
				command2.ExecuteNonQuery();
			}
	
			wc.Visible=true;
			con.link.Close();
		}
		public reg()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
