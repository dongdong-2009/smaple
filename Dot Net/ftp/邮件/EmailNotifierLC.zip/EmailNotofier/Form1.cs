using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text;


namespace EmailNotofier
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.TextBox txtPopServer;
		private System.Windows.Forms.TextBox txtPopPort;
		private System.Windows.Forms.TextBox txtUserName;
		private System.Windows.Forms.TextBox txtPassword;
		private System.ComponentModel.IContainer components;
		NetworkStream netStream;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtTimer;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btnHide;
		EmailNotify emailnot;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			timer1.Interval=Int32.Parse(txtTimer.Text);
			this.Opacity=0;
			this.WindowState=FormWindowState.Minimized;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.txtPopServer = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtPopPort = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtUserName = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.label5 = new System.Windows.Forms.Label();
			this.txtTimer = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.btnHide = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtPopServer
			// 
			this.txtPopServer.Location = new System.Drawing.Point(120, 24);
			this.txtPopServer.Name = "txtPopServer";
			this.txtPopServer.TabIndex = 0;
			this.txtPopServer.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 24);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Email Server";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.TabIndex = 2;
			this.label2.Text = "Server Port";
			// 
			// txtPopPort
			// 
			this.txtPopPort.Location = new System.Drawing.Point(120, 48);
			this.txtPopPort.Name = "txtPopPort";
			this.txtPopPort.TabIndex = 3;
			this.txtPopPort.Text = "110";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "UserName";
			// 
			// txtUserName
			// 
			this.txtUserName.Location = new System.Drawing.Point(120, 72);
			this.txtUserName.Name = "txtUserName";
			this.txtUserName.TabIndex = 5;
			this.txtUserName.Text = "";
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(120, 96);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.PasswordChar = '*';
			this.txtPassword.TabIndex = 6;
			this.txtPassword.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 96);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 7;
			this.label4.Text = "Password";
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button1.Location = new System.Drawing.Point(192, 192);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 24);
			this.button1.TabIndex = 8;
			this.button1.Text = "Email Check";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenu = this.contextMenu1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "Email Notifier";
			this.notifyIcon1.Visible = true;
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem1,
																						 this.menuItem2});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Configure";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Check Email";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 300000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 120);
			this.label5.Name = "label5";
			this.label5.TabIndex = 9;
			this.label5.Text = "Timer Interval";
			// 
			// txtTimer
			// 
			this.txtTimer.Location = new System.Drawing.Point(120, 120);
			this.txtTimer.Name = "txtTimer";
			this.txtTimer.TabIndex = 10;
			this.txtTimer.Text = "300000";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(232, 128);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(40, 16);
			this.label6.TabIndex = 11;
			this.label6.Text = "(5 min)";
			// 
			// btnHide
			// 
			this.btnHide.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnHide.Location = new System.Drawing.Point(104, 192);
			this.btnHide.Name = "btnHide";
			this.btnHide.TabIndex = 12;
			this.btnHide.Text = "Hide";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 221);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnHide,
																		  this.label6,
																		  this.txtTimer,
																		  this.label5,
																		  this.button1,
																		  this.label4,
																		  this.txtPassword,
																		  this.txtUserName,
																		  this.label3,
																		  this.txtPopPort,
																		  this.label2,
																		  this.label1,
																		  this.txtPopServer});
			this.Name = "Form1";
			this.ShowInTaskbar = false;
			this.Text = "Email Notifier";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			EmailCheck();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			EmailCheck();			
		}

		private void EmailCheck()
		{
			TcpClient tcpClient = new TcpClient();
			try
			{
				tcpClient.Connect(txtPopServer.Text,Int32.Parse(txtPopPort.Text));
			}
			catch
			{
				MessageBox.Show("Cannot connect to target host "+txtPopServer.Text +" and port "+txtPopPort.Text);
			}
			
			///get the response of pop3 mail server
			netStream = tcpClient.GetStream();
			if(netStream == null)
			{
				throw new Exception("GetStream is null");
			}

			string returnMsg=ReadFromNetStream(ref netStream);
			
			checkForError(returnMsg);

			///send username information
			WriteToNetStream(ref netStream, "USER " + this.txtUserName.Text);

			returnMsg=ReadFromNetStream(ref netStream);
			checkForError(returnMsg);

			///send password information
			WriteToNetStream(ref netStream, "PASS " + this.txtPassword.Text);

			returnMsg=ReadFromNetStream(ref netStream);
			checkForError(returnMsg);
			
			Stat();

			netStream.Close();
			tcpClient.Close();
			
		}
		public void Stat()
		{
			
			WriteToNetStream(ref netStream, "STAT");

			string returnMsg=ReadFromNetStream(ref netStream);
			checkForError(returnMsg);
			
			///split the information of total message and total size
			string[] TotalStat= returnMsg.Split(new char[] {' '});
			
			int count=Int32.Parse(TotalStat[1]);
			int totalSize=Int32.Parse(TotalStat[2]);
				emailnot= new EmailNotify(count);
			
				
                emailnot.Show();
			
		}
		private void WriteToNetStream(ref NetworkStream NetStream, string Command)
		{
			string stringToSend = Command + "\r\n";

			Byte[] arrayToSend = Encoding.ASCII.GetBytes(stringToSend.ToCharArray());
			NetStream.Write(arrayToSend, 0, arrayToSend.Length);
		}

		/// <summary>
		/// this function reads from  Network Stream
		/// </summary>
		/// <param name="NetStream"></param>
		/// <returns></returns>
		private String ReadFromNetStream(ref NetworkStream NetStream)
		{
			StringBuilder strReceived= new StringBuilder();
			StreamReader sr= new StreamReader(NetStream);
			String strLine = sr.ReadLine();

			while(strLine==null || strLine.Length==0)
			{
				strLine = sr.ReadLine();
			}
			strReceived.Append(strLine);

			if(sr.Peek()!=-1)
			{
				while ((strLine=sr.ReadLine())!=null) 
				{	
					strReceived.Append(strLine);
				}
			}
			return strReceived.ToString();
		}
		/// <summary>
		/// this function checks the error in the stream;
		/// </summary>
		/// <param name="s"></param>
		private void checkForError(String strMessage)
		{
			if (strMessage.IndexOf("+OK") == -1)
				throw new Exception("ERROR - . Recieved: " + strMessage);
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			EmailCheck();
		}

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			this.Opacity=100;
			this.WindowState=FormWindowState.Normal;
		}

		private void btnHide_Click(object sender, System.EventArgs e)
		{
			this.Opacity=0;
			this.WindowState=FormWindowState.Minimized;
		}
	}
}
