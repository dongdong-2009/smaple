﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace IPNBSSDK_CSharp
{
    public partial class FormDemo : Form
    {
        #region 窗体事件

        private StatusCallBack callback;

        private delegate void SetTextCallback(string txt);

        public FormDemo()
        {
            InitializeComponent();

            // 设置默认IP
            try
            {
                this.tbServerIP.Text = GetLocalIPAddress();
            }
            catch
            {
                this.tbServerIP.Text = "192.168.1.100";
            }

            // 设置回调
            callback = new StatusCallBack(OnStatusCallBack);
            NativeMethod.IPNBSSDK_SetStatusCallBack(callback, this.Handle);

            this.rtbOutput.DoubleClick += new EventHandler(rtbOutput_DoubleClick);
            this.cbPhone.CheckedChanged += new EventHandler(cbPhone_CheckedChanged);
        }

        public string GetLocalIPAddress()
        {
            System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(@"\d{0,3}\.\d{0,3}\.\d{0,3}\.\d{0,3}");

            string localIP = string.Empty;
            System.Net.IPHostEntry entry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
            foreach (System.Net.IPAddress ipAddress in entry.AddressList)
            {
                string ipStr = ipAddress.ToString();
                if (reg.IsMatch(ipStr))
                {
                    localIP = ipStr;
                    break;
                }
            }
            return localIP;
        }

        void cbPhone_CheckedChanged(object sender, EventArgs e)
        {
            this.tbPhoneNumber.Enabled = this.cbPhone.Checked;
        }

        void rtbOutput_DoubleClick(object sender, EventArgs e)
        {
            // 清除文本
            this.rtbOutput.Clear();
        }

        private void SetStateText(string txt)
        {
            if (this.rtbOutput.InvokeRequired)
            {
                SetTextCallback callback = new SetTextCallback(SetStateText);
                Invoke(callback, new object[] { txt });
            }
            else
            {
                this.rtbOutput.AppendText(txt + "\r\n");
                this.rtbOutput.SelectionStart = this.rtbOutput.TextLength;
                this.rtbOutput.ScrollToCaret();
            }
        }

        #endregion

        #region 设置及回调

        private void OnStatusCallBack(IntPtr dwInstance, IntPtr wParam, IntPtr lParam)
        {
            // 消息回调            
            IPNBSSDK_STATE state = (IPNBSSDK_STATE)wParam.ToInt32();
            DGRAMHEADER_STATUS lpDgramHeader = (DGRAMHEADER_STATUS)Marshal.PtrToStructure(lParam, typeof(DGRAMHEADER_STATUS));
            string strState = string.Empty;
            ushort wDialogFromID = 0;
            ushort wDialogToID = 0;
            ushort wTermFromID = (ushort)(lpDgramHeader.ucParam1 | (lpDgramHeader.ucParam2 << 8));
            ushort wTaskNo = (ushort)(lpDgramHeader.ucParam3 | (lpDgramHeader.ucParam4 << 8));

            if (wParam == IntPtr.Zero && lpDgramHeader.ucParam1 == 0)
            {
                strState += "与服务器断开连接\r\n";
                SetStateText(strState);
                return;
            }

            if (wParam == IntPtr.Zero && lpDgramHeader.ucParam1 == 1)
            {
                strState += "连接服务器成功\r\n";
                SetStateText(strState);
                return;
            }

            if (lpDgramHeader.ucFunction == 0xD1)
            {
                // V2.2(2011-5-9)之前的服务器版本
                // wDialogFromID = lpDgramHeader.ucParam3;
                // wDialogToID = lpDgramHeader.ucParam4;

                // V2.2(2011-5-9)及之后的服务器版本
                byte[] pID = new byte[4];
                IntPtr intptr = new IntPtr(lParam.ToInt32() + Marshal.SizeOf(lpDgramHeader));
                Marshal.Copy(intptr, pID, 0, 4);
                wDialogFromID = (ushort)(pID[0] | (pID[1] << 8));
                wDialogToID = (ushort)(pID[2] | (pID[3] << 8));
            }

            switch (state)
            {
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_NULL:
                    strState = string.Format("终端{0} 空闲", wTermFromID);
                    if (lpDgramHeader.ucParam3 == 0)
                        strState += (" 未登录");
                    else
                        strState += (" 登录");
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_TALKING:
                    strState = string.Format("终端{0} 通话中\r\n", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_LIVE_PLAY:
                    strState = string.Format("终端{0} 实时采播", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_TERMER_RING:
                    strState = string.Format("终端{0} 定时打铃", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_TERMER_PROGRAMS:
                    strState = string.Format("终端{0} 定时节目", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_SERVER_FIRE_ALARM:
                    strState = string.Format("终端{0} 服务器消防报警", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_CALL:
                    {
                        byte ucPanelIndex2 = lpDgramHeader.ucAttachData2[49];
                        byte ucPanelIndex1 = lpDgramHeader.ucParam5;
                        string sSrcPanel = string.Empty;
                        string sDstPanel = string.Empty;
                        if (ucPanelIndex1 != 255)
                            sSrcPanel = string.Format("(面板序号{0})", ucPanelIndex1 + 1);
                        if (ucPanelIndex2 != 255)
                            sDstPanel = string.Format("(面板序号{0})", ucPanelIndex2 + 1);

                        if (lpDgramHeader.ucAttachData2[48] == 0x01)
                            strState = string.Format("终端{0} 监听 终端{1}\r\n", wDialogFromID, wDialogToID);
                        else
                            strState = string.Format("终端{0}{1} 呼叫 终端{2}{3}\r\n", wDialogFromID, sSrcPanel, wDialogToID, sDstPanel);
                    }
                    //strState = string.Format("终端{0}(面板序号{1}) 呼叫 终端{2}", wDialogFromID, lpDgramHeader.ucParam5 + 1, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_BEGIN:
                    {
                        byte ucPanelIndex2 = lpDgramHeader.ucAttachData2[49];
                        byte ucPanelIndex1 = lpDgramHeader.ucAttachData2[47];
                        string sSrcPanel = string.Empty;
                        string sDstPanel = string.Empty;
                        if (ucPanelIndex1 != 255)
                            sSrcPanel = string.Format("(面板序号{0})", ucPanelIndex1 + 1);
                        if (ucPanelIndex2 != 255)
                            sDstPanel = string.Format("(面板序号{0})", ucPanelIndex2 + 1);

                        if (lpDgramHeader.ucAttachData2[48] == 0x01)
                            strState = string.Format("终端{0} 与 终端{1} 开始监听\r\n", wDialogFromID, wDialogToID);
                        else
                            strState = string.Format("终端{0}{1} 与 终端{2}{3} 开始对讲\r\n", wDialogFromID, sSrcPanel, wDialogToID, sDstPanel);
                    }
                    //strState = string.Format("终端{0} 与 终端{1} 开始对讲", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_END:
                    {
                        byte ucPanelIndex2 = lpDgramHeader.ucAttachData2[49];
                        byte ucPanelIndex1 = lpDgramHeader.ucAttachData2[47];
                        string sSrcPanel = string.Empty;
                        string sDstPanel = string.Empty;
                        if (ucPanelIndex1 != 255)
                            sSrcPanel = string.Format("(面板序号{0})", ucPanelIndex1 + 1);
                        if (ucPanelIndex2 != 255)
                            sDstPanel = string.Format("(面板序号{0})", ucPanelIndex2 + 1);

                        if (lpDgramHeader.ucAttachData2[48] == 0x01)
                            strState = string.Format("终端{0} 与 终端{1} 停止监听\r\n", wDialogFromID, wDialogToID);
                        else
                            strState = string.Format("终端{0}{1} 与 终端{2}{3} 停止对讲\r\n", wDialogFromID, sSrcPanel, wDialogToID, sDstPanel);
                    }
                    //strState = string.Format("终端{0} 与 终端{1} 停止对讲", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_REJECT:
                    {
                        byte ucPanelIndex2 = lpDgramHeader.ucAttachData2[49];
                        byte ucPanelIndex1 = lpDgramHeader.ucAttachData2[47];
                        string sSrcPanel = string.Empty;
                        string sDstPanel = string.Empty;
                        if (ucPanelIndex1 != 255)
                            sSrcPanel = string.Format("(面板序号{0})", ucPanelIndex1 + 1);
                        if (ucPanelIndex2 != 255)
                            sDstPanel = string.Format("(面板序号{0})", ucPanelIndex2 + 1);

                        strState = string.Format("终端{0}{1} 拒绝 终端{2}{3} 呼叫\r\n", wDialogFromID, sSrcPanel, wDialogToID, sDstPanel);
                    }
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_OFFLINE:
                    strState = string.Format("终端{0} 呼叫 终端{1} 目标不在线 \r\n", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_OFFLINE2:
                    strState = string.Format("终端{0} 呼叫 终端{1} 目标不可达 \r\n", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_BUSY:
                    strState = string.Format("终端{0} 呼叫 终端{1} 目标正忙 \r\n", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_SLEEP:
                    strState = string.Format("终端{0} 呼叫 终端{1} 无人接听 \r\n", wDialogFromID, wDialogToID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM1:
                    strState = string.Format("终端{0} 端口1报警", wDialogFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM2:
                    strState = string.Format("终端{0} 端口2报警", wDialogFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM_EX:
                    strState = string.Format("终端{0} 扩展端口{1}报警", wDialogFromID, lpDgramHeader.ucParam3);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_NULL:
                    strState = string.Format("{0}号任务 : 空闲", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_TERMER_RING_BEGIN:
                    strState = string.Format("{0}号任务 : 定时打铃 : 执行", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_TERMER_RING_END:
                    strState = string.Format("{0}号任务 : 定时打铃 : 停止", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_FIRE_ALARM_BEGIN:
                    strState = string.Format("{0}号任务 : 消防报警 : 执行", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_FIRE_ALARM_END:
                    strState = string.Format("{0}号任务 : 消防报警 : 停止", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_IP:
                    if (lpDgramHeader.ucParam1 == 0)
                        strState = "查询IP结果 : 失败";
                    else
                        strState = string.Format("查询IP结果 : 成功 {0}.{1}.{2}.{3}", lpDgramHeader.ucParam2,
                                        lpDgramHeader.ucParam3, lpDgramHeader.ucParam4, lpDgramHeader.ucParam5);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ID:
                    if (lpDgramHeader.ucParam1 == 0)
                        strState = "查询ID结果 : 失败";
                    else
                        strState = string.Format("查询ID结果 : 成功 {0}",
                            lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_COUNT:
                    strState = string.Format("查询终端数量结果 : {0}",
                            lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_PORT_STATE:
                    {
                        if (lpDgramHeader.ucParam1 == 0)
                        {
                            if (lpDgramHeader.ucParam4 == 0x80)
                                strState = string.Format("终端 {0} 状态 :防拆报警\r\n", lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                            else if (lpDgramHeader.ucParam4 == 0x90)
                                strState = string.Format("终端 {0} 状态 :防拆报警解除\r\n", lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                        }
                        else
                        {
                            strState = string.Format("查询终端 {0} {1}端口 {2} 状态 : {3}",
                                lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8),
                                (lpDgramHeader.ucParam1 & 0x80) == 0 ? "输入" : "输出",
                                lpDgramHeader.ucParam1 & 0x7F,
                                lpDgramHeader.ucParam4 == 0 ? "断开" : "闭合");
                        }
                    }
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_SD_PLAY_STATE:
                    strState = string.Format("终端 {0} SD卡 {1}",
                        lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8),
                        lpDgramHeader.ucParam1 == 0 ? ("停止") : ("播放"));
                    break;
            }

            if (lpDgramHeader.ucFunction == 0xD2 && lpDgramHeader.ucAttachData1[0] != '\0')
            {
                string strTemp = string.Format("\r\n终端名称 :{0}\r\n", Encoding.Default.GetString(lpDgramHeader.ucAttachData1).TrimEnd(new char[] { '\0' }));
                strState += strTemp;
                strTemp = string.Format("IP地址 : {0}.{1}.{2}.{3}\r\n", lpDgramHeader.ucAttachData2[0],
                    lpDgramHeader.ucAttachData2[1], lpDgramHeader.ucAttachData2[2], lpDgramHeader.ucAttachData2[3]);
                strState += strTemp;
                strTemp = string.Format("音量 : {0}", lpDgramHeader.ucAttachData2[4]);
                strState += strTemp;
            }

            if (lpDgramHeader.ucFunction == 0xD2)
            {
                uint dwPanel = BitConverter.ToUInt32(lpDgramHeader.ucAttachData2, 5);
                ushort wMemberPanelState = (ushort)(dwPanel & 0xFFFF);
                if (wMemberPanelState == (ushort)~(dwPanel >> 16))
                {
                    string strPanel = string.Empty;
                    string strPanelAll = string.Empty;
                    for (int j = 0; j < 16; j++)
                    {
                        if (((dwPanel >> j) & 0x01) == 0x01)
                        {
                            strPanel = string.Format(" {0}", j + 1);
                            strPanelAll = strPanelAll + strPanel;
                            //	strTemp += strTemp2; 
                            //	nCount++;
                            //	nPanelCount++;
                        }
                    }

                    string strTemp = string.Format("面板 :{0}\r\n", strPanelAll);
                    strState += strTemp;
                }
            }

            if (lpDgramHeader.ucFunction == 0xD1 && lpDgramHeader.ucParam2 == 0x30)
            {
                // 接收到创建对讲录音文件消息
                IntPtr intptr = Marshal.AllocHGlobal(32);
                Marshal.Copy(lpDgramHeader.ucAttachData1, 0, intptr, 32);
                CREATE_FILE_INFO pCreateFileInfo = (CREATE_FILE_INFO)Marshal.PtrToStructure(intptr, typeof(CREATE_FILE_INFO));
                string pchFilePath = Encoding.Default.GetString(lpDgramHeader.ucAttachData1, 32, 18).TrimEnd(new char[] { '\0' });
                string strTemp = string.Format("创建录音文件(终端{0}): {1}", pCreateFileInfo.wTermID, pCreateFileInfo);
                strState += strTemp;
            }

            SetStateText(strState);
        }

        private void btnSetConfig_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_SetServerIP(this.tbServerIP.Text)
                && NativeMethod.IPNBSSDK_SetServerPort(ushort.Parse(this.tbServerPort.Text))
                && NativeMethod.IPNBSSDK_SetStatePort(ushort.Parse(this.tbStatePort.Text)))
                this.tsLabelResult.Text = "设置成功";
            else
                this.tsLabelResult.Text = "设置失败";
        }

        private void btnTcpConnect_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_TCPConnect(this.tbServerIP.Text, ushort.Parse(this.tbServerPort.Text)))
                this.tsLabelResult.Text = "TCP连接成功";
            else
                this.tsLabelResult.Text = "TCP连接失败";
        }

        private void btnTcpClose_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_TCPClose())
                this.tsLabelResult.Text = "TCP断开成功";
            else
                this.tsLabelResult.Text = "TCP断开失败";
        }

        #endregion

        #region 呼叫

        private void btnCall_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlCall(ushort.Parse(this.tbCallFromId.Text), ushort.Parse(this.tbCallToId.Text)))
                this.tsLabelResult.Text = "呼叫成功";
            else
                this.tsLabelResult.Text = "呼叫失败";
        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlAnswer(ushort.Parse(this.tbCallFromId.Text)))
                this.tsLabelResult.Text = "接听成功";
            else
                this.tsLabelResult.Text = "接听失败";
        }

        private void btnHang_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlHang(ushort.Parse(this.tbCallFromId.Text)))
                this.tsLabelResult.Text = "挂断成功";
            else
                this.tsLabelResult.Text = "挂断失败";
        }

        private void btnCallEx_Click(object sender, EventArgs e)
        {
            if (this.cbPhone.Checked)
            {
                if (NativeMethod.IPNBSSDK_CtrlCallPhone(ushort.Parse(this.tbCallExFromId.Text), ushort.Parse(this.tbCallExToId.Text),
                    byte.Parse(this.tbCallExAreaId.Text), this.tbPhoneNumber.Text))
                    this.tsLabelResult.Text = "呼叫成功";
                else
                    this.tsLabelResult.Text = "呼叫失败";
            }
            else
            {
                if (NativeMethod.IPNBSSDK_CtrlCallEx(ushort.Parse(this.tbCallExFromId.Text), ushort.Parse(this.tbCallExToId.Text),
                    byte.Parse(this.tbCallExAreaId.Text)))
                    this.tsLabelResult.Text = "呼叫成功";
                else
                    this.tsLabelResult.Text = "呼叫失败";
            }
        }

        private void btnAnswerEx_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlAnswerEx(ushort.Parse(this.tbCallExFromId.Text)))
                this.tsLabelResult.Text = "接听成功";
            else
                this.tsLabelResult.Text = "接听失败";
        }

        private void btnHangEx_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlHangEx(ushort.Parse(this.tbCallExFromId.Text)))
                this.tsLabelResult.Text = "挂断成功";
            else
                this.tsLabelResult.Text = "挂断失败";
        }

        #endregion

        #region 采播

        private void btnStartBroadcast_Click(object sender, EventArgs e)
        {
            string[] tmps = this.tbBroadcastToId.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<ushort> toIdList = new List<ushort>();
            ushort id;
            foreach (string tmp in tmps)
            {
                if (ushort.TryParse(tmp, out id))
                    toIdList.Add(id);
            }

            if (this.cbIsGroupBoardcast.Checked)
            {
                if (NativeMethod.IPNBSSDK_CtrlBroadcastGroup(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, true))
                    this.tsLabelResult.Text = "开始分区采播成功";
                else
                    this.tsLabelResult.Text = "开始分区采播失败";
            }
            else
            {
                if (NativeMethod.IPNBSSDK_CtrlBroadcast_CSharp(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, true))
                    this.tsLabelResult.Text = "开始采播成功";
                else
                    this.tsLabelResult.Text = "开始采播失败";
            }
        }

        private void btnBroadcastStop_Click(object sender, EventArgs e)
        {
            string[] tmps = this.tbBroadcastToId.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<ushort> toIdList = new List<ushort>();
            ushort id;
            foreach (string tmp in tmps)
            {
                if (ushort.TryParse(tmp, out id))
                    toIdList.Add(id);
            }

            if (this.cbIsGroupBoardcast.Checked)
            {
                if (NativeMethod.IPNBSSDK_CtrlBroadcastGroup(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, false))
                    this.tsLabelResult.Text = "停止分区采播成功";
                else
                    this.tsLabelResult.Text = "停止分区采播失败";
            }
            else
            {
                if (NativeMethod.IPNBSSDK_CtrlBroadcast_CSharp(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, false))
                    this.tsLabelResult.Text = "停止采播成功";
                else
                    this.tsLabelResult.Text = "停止采播失败";
            }
        }

        private void btn8AreaBroadcastStart_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlBroadcastSingle(ushort.Parse(this.tbBroadcastFromId.Text), ushort.Parse(this.tb8AreaTerminalId.Text),
                byte.Parse(this.tb8AreaNumber.Text), true))
                this.tsLabelResult.Text = "开始【8分区】采播成功";
            else
                this.tsLabelResult.Text = "开始【8分区】采播失败";
        }

        private void btn8AreaBroadcastStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlBroadcastSingle(ushort.Parse(this.tbBroadcastFromId.Text), ushort.Parse(this.tb8AreaTerminalId.Text),
                byte.Parse(this.tb8AreaNumber.Text), false))
                this.tsLabelResult.Text = "停止【8分区】采播成功";
            else
                this.tsLabelResult.Text = "停止【8分区】采播失败";
        }

        #endregion

        #region 监听、IO控制、SD卡播放

        private void btnSpyStart_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlMonitor(ushort.Parse(this.tbSpyFromId.Text), ushort.Parse(this.tbSpyToId.Text), true))
                this.tsLabelResult.Text = "开始监听成功";
            else
                this.tsLabelResult.Text = "开始监听失败";
        }

        private void btnSpyStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlMonitor(ushort.Parse(this.tbSpyFromId.Text), ushort.Parse(this.tbSpyToId.Text), false))
                this.tsLabelResult.Text = "停止监听成功";
            else
                this.tsLabelResult.Text = "停止监听失败";
        }

        private void btnIOOpen_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlIO(ushort.Parse(this.tbIOControlId.Text), byte.Parse(this.tbIOControlPort.Text), true))
                this.tsLabelResult.Text = "IO口闭合成功";
            else
                this.tsLabelResult.Text = "IO口闭合失败";
        }

        private void btnIOClose_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlIO(ushort.Parse(this.tbIOControlId.Text), byte.Parse(this.tbIOControlPort.Text), false))
                this.tsLabelResult.Text = "IO口断开成功";
            else
                this.tsLabelResult.Text = "IO口断开失败";
        }

        private void btnSDPlay_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSDPlay(ushort.Parse(this.tbSDControlId.Text), true, byte.Parse(this.tbSDFileIndex.Text)))
                this.tsLabelResult.Text = "SD卡文件播放成功";
            else
                this.tsLabelResult.Text = "SD卡文件播放失败";
        }

        private void btnSDStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSDPlay(ushort.Parse(this.tbSDControlId.Text), false, byte.Parse(this.tbSDFileIndex.Text)))
                this.tsLabelResult.Text = "SD卡文件停止成功";
            else
                this.tsLabelResult.Text = "SD卡文件停止失败";
        }

        #endregion

        #region 终端查询

        private void btnSearchTerminalCount_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryTermCount())
                this.tsLabelResult.Text = "查询终端数量成功";
            else
                this.tsLabelResult.Text = "查询终端数量失败";
        }

        private void btnStateSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryState(ushort.Parse(this.tbSearchId.Text)))
                this.tsLabelResult.Text = "查询终端状态成功";
            else
                this.tsLabelResult.Text = "查询终端状态失败";
        }

        private void btnIPSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryIP(ushort.Parse(this.tbSearchId.Text)))
                this.tsLabelResult.Text = "查询终端IP成功";
            else
                this.tsLabelResult.Text = "查询终端IP失败";
        }

        private void btnIdSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryID(this.tbTerminalIP.Text))
                this.tsLabelResult.Text = "查询终端ID成功";
            else
                this.tsLabelResult.Text = "查询终端ID失败";
        }

        private void btnModifyName_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSetName(ushort.Parse(this.tbSearchId.Text), this.tbTerminalName.Text))
                this.tsLabelResult.Text = "设置终端名称成功";
            else
                this.tsLabelResult.Text = "设置终端名称失败";
        }

        private void btnModifyVolume_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSetVolume(ushort.Parse(this.tbSearchId.Text), byte.Parse(this.tbVolume.Text)))
                this.tsLabelResult.Text = "设置终端音量成功";
            else
                this.tsLabelResult.Text = "设置终端音量失败";
        }

        private void btnPortSearch_Click(object sender, EventArgs e)
        {
            byte m_wQueryPort = byte.Parse(this.tbSearchPort.Text);
            if (!this.rbPortIn.Checked)
                m_wQueryPort |= 0x80;
            if (NativeMethod.IPNBSSDK_CtrlQueryPort(ushort.Parse(this.tbSearchId.Text), m_wQueryPort))
                this.tsLabelResult.Text = "查询终端端口状态成功";
            else
                this.tsLabelResult.Text = "查询终端端口状态失败";
        }

        #endregion

        #region 任务

        private void btnStartAlarmTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlFireAlarm(ushort.Parse(this.tbAlarmTaskId.Text), true))
                this.tsLabelResult.Text = "开始报警成功";
            else
                this.tsLabelResult.Text = "开始报警失败";
        }

        private void tbnStopAlarmTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlFireAlarm(ushort.Parse(this.tbAlarmTaskId.Text), false))
                this.tsLabelResult.Text = "停止报警成功";
            else
                this.tsLabelResult.Text = "停止报警失败";
        }

        private void btnStartRingTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlTimerRing(ushort.Parse(this.tbRingTaskId.Text), true))
                this.tsLabelResult.Text = "开始定时打铃成功";
            else
                this.tsLabelResult.Text = "开始定时打铃失败";
        }

        private void btnStopRingTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlTimerRing(ushort.Parse(this.tbRingTaskId.Text), false))
                this.tsLabelResult.Text = "停止定时打铃成功";
            else
                this.tsLabelResult.Text = "停止定时打铃失败";
        }

        #endregion

        #region 多方通话

        private void rbConferenceMode_CheckedChanged(object sender, EventArgs e)
        {
            this.labelMutiCallParam1.Text = "参会人数:";
            this.tbMultiCallParam1.Text = "3";
        }

        private void rbManageMode_CheckedChanged(object sender, EventArgs e)
        {
            this.labelMutiCallParam1.Text = "指挥ID:";
            this.tbMultiCallParam1.Text = "2";
        }

        private void rbAnswerMode_CheckedChanged(object sender, EventArgs e)
        {
            this.labelMutiCallParam1.Text = "指挥ID:";
            this.tbMultiCallParam1.Text = "2";
        }

        private void btnMulitCallStart_Click(object sender, EventArgs e)
        {
            MultiCall(true);
        }

        private void btnMulitCallStop_Click(object sender, EventArgs e)
        {
            MultiCall(false);
        }

        private void MultiCall(bool start)
        {
            ushort id;
            ushort port;
            string ip = this.tbMultiCallTerminalIP.Text;
            if (ushort.TryParse(this.tbMutiCallTerminalId.Text, out id) &&
                ushort.TryParse(this.tbMultiCallTerminalPort.Text, out port) &&
                !string.IsNullOrEmpty(ip))
            {
                NativeMethod.SetMultiCallNetParms(id, ip, port);

                int mode = 0;
                if (this.rbManageMode.Checked)
                    mode = 1;
                else if (this.rbAnswerMode.Checked)
                    mode = 2;
                else
                    mode = 0;

                ushort uTemp;
                List<ushort> terminalList = new List<ushort>();
                string[] strs = this.tbMultiCallTarget.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string str in strs)
                {
                    if (ushort.TryParse(str, out uTemp))
                        terminalList.Add(uTemp);
                }

                if (ushort.TryParse(this.tbMultiCallParam1.Text, out uTemp))
                    NativeMethod.MultiCall(start, mode, uTemp, terminalList);
            }
        }

        private void btnMultiCallState_Click(object sender, EventArgs e)
        {
            ushort id;
            ushort port;
            string ip = this.tbMultiCallTerminalIP.Text;
            if (ushort.TryParse(this.tbMutiCallTerminalId.Text, out id) &&
                ushort.TryParse(this.tbMultiCallTerminalPort.Text, out port) &&
                !string.IsNullOrEmpty(ip))
            {
                NativeMethod.SetMultiCallNetParms(id, ip, port);
                NativeMethod.GetMultiCallStat();
            }
        }

        #endregion
    }
}
