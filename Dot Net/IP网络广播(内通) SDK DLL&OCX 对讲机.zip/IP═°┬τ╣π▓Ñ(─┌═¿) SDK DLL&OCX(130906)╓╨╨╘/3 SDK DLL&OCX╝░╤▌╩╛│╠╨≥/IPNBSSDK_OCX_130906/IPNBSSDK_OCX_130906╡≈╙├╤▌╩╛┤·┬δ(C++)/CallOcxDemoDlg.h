// CallOcxDemoDlg.h : header file
//
//{{AFX_INCLUDES()
#include "ipnbssdk.h"
//}}AFX_INCLUDES

#if !defined(AFX_CALLOCXDEMODLG_H__E06884A6_3639_4B98_81DB_C994DB5527CA__INCLUDED_)
#define AFX_CALLOCXDEMODLG_H__E06884A6_3639_4B98_81DB_C994DB5527CA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TERM_8AREA_TEST

/////////////////////////////////////////////////////////////////////////////
// CCallOcxDemoDlg dialog

class CCallOcxDemoDlg : public CDialog
{
// Construction
public:
	static void CALLBACK OnStatusCallBack(DWORD dwInstance, WPARAM wParam, LPARAM lParam);
	CCallOcxDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCallOcxDemoDlg)
	enum { IDD = IDD_CALLOCXDEMO_DIALOG };
	CEdit	m_editOutput;
	BYTE	m_ucAlarmArea;
	UINT	m_wBCFromID;
	CString	m_strBCToID;
	UINT	m_wIOID;
	BYTE	m_ucIOPort;
	CString	m_strServerIP;
	UINT	m_nServerPort;
	UINT	m_nStatePort;
	CIPNBSSDK	m_IPNBSsdk;
	UINT	m_wMonitorFromID;
	UINT	m_wMonitorToID;
	CString	m_strOutput;
	UINT	m_wQueryStateID;
	UINT	m_wTimerRingID;
	CString	m_strQueryIDSrcIP;
	UINT	m_wQueryIPSrcID;
	UINT	m_wSetNameID;
	CString	m_strSetName;
	UINT	m_wSetVolumeID;
	BYTE	m_ucSetVolume;
	UINT	m_wQueryPortID;
	UINT	m_wQueryPort;
	int		m_nQueryPortIn;
	UINT	m_wSDFileIndex;
	UINT	m_wSDID;
	BYTE	m_ucDialogToPanelPanel;
	UINT	m_wDialogFromID;
	UINT	m_wDialogToID;
	UINT	m_wDialogToPanelFromID;
	UINT	m_wDialogToPanelToID;
	BOOL	m_bCallPhone;
	CString	m_strPhone;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCallOcxDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	VARIANT CreateSafeArray(LPBYTE lpInBuf, DWORD dwBufSize);
	void OnBroadcast(BOOL bStart);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCallOcxDemoDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnSetServerIp();
	afx_msg void OnBtnCall();
	afx_msg void OnBtnSetServerPort();
	afx_msg void OnBtnSetStatePort();
	afx_msg void OnBtnAnswer();
	afx_msg void OnBtnHang();
	afx_msg void OnBtnMinitorStart();
	afx_msg void OnBtnMinitorEnd();
	afx_msg void OnBtnBcStart();
	afx_msg void OnBtnBcEnd();
	afx_msg void OnBtnIoOn();
	afx_msg void OnBtnIoOff();
	afx_msg void OnBtnStartAlarm();
	afx_msg void OnBtnEndAlarm();
	virtual BOOL OnInitDialog();
	afx_msg void OnIPNBSSDKRecvStatus(short wParam, const VARIANT FAR& lParam);
	afx_msg void OnClose();
	afx_msg void OnBtnQueryState();
	afx_msg void OnBtnStartRing();
	afx_msg void OnBtnEndRing();
	afx_msg void OnBtnQueryIP();
	afx_msg void OnBtnQueryID();
	afx_msg void OnBtnQueryTermCount();
	afx_msg void OnBtnSetName();
	afx_msg void OnBtnSetVolume();
	afx_msg void OnBtnQueryPort();
	afx_msg void OnBtnClearStatus();
	afx_msg void OnBtnSdPlay();
	afx_msg void OnBtnSdStop();
	afx_msg void OnBtnDialogToPanelAnswer();
	afx_msg void OnBtnDialogToPanelHang();
	afx_msg void OnBtnDialogToPanelCall();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
#ifdef TERM_8AREA_TEST
	afx_msg void OnBtn8areaStart();
	afx_msg void OnBtn8areaEnd();
#endif
	DECLARE_MESSAGE_MAP()

private:
	void OnRecvStatus(WPARAM wParam, LPARAM lParam);
	VARIANT			m_vaState;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALLOCXDEMODLG_H__E06884A6_3639_4B98_81DB_C994DB5527CA__INCLUDED_)
