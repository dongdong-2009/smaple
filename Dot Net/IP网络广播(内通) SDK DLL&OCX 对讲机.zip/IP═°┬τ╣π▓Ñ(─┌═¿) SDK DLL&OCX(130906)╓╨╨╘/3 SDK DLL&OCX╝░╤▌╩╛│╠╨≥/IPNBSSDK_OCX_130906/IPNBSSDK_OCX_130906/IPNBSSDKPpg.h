#if !defined(AFX_IPNBSSDKPPG_H__9E964E87_919F_4B3A_AC6F_A90C71BD8908__INCLUDED_)
#define AFX_IPNBSSDKPPG_H__9E964E87_919F_4B3A_AC6F_A90C71BD8908__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// IPNBSSDKPpg.h : Declaration of the CIPNBSSDKPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKPropPage : See IPNBSSDKPpg.cpp.cpp for implementation.

class CIPNBSSDKPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CIPNBSSDKPropPage)
	DECLARE_OLECREATE_EX(CIPNBSSDKPropPage)

// Constructor
public:
	CIPNBSSDKPropPage();

// Dialog Data
	//{{AFX_DATA(CIPNBSSDKPropPage)
	enum { IDD = IDD_PROPPAGE_IPNBSSDK };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CIPNBSSDKPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPNBSSDKPPG_H__9E964E87_919F_4B3A_AC6F_A90C71BD8908__INCLUDED)
