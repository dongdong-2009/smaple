//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IPNBSSDK.rc
//

#define IDS_IPNBSSDK               1
#define IDS_IPNBSSDK_PPG           2

#define IDS_IPNBSSDK_PPG_CAPTION   200

#define IDD_PROPPAGE_IPNBSSDK      200

#define IDD_ABOUTBOX_IPNBSSDK      1

#define IDB_IPNBSSDK               1

#define IDI_ABOUTDLL				1

#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#define _APS_NEXT_COMMAND_VALUE         32768
