// IPNBSSDKPpg.cpp : Implementation of the CIPNBSSDKPropPage property page class.

#include "stdafx.h"
#include "IPNBSSDK.h"
#include "IPNBSSDKPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CIPNBSSDKPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CIPNBSSDKPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CIPNBSSDKPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CIPNBSSDKPropPage, "IPNBSSDK.IPNBSSDKPropPage.1",
	0xad72a3ed, 0xc393, 0x40ef, 0xbb, 0xc0, 0xe7, 0xd6, 0xdf, 0xaa, 0xb1, 0x70)


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKPropPage::CIPNBSSDKPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CIPNBSSDKPropPage

BOOL CIPNBSSDKPropPage::CIPNBSSDKPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_IPNBSSDK_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKPropPage::CIPNBSSDKPropPage - Constructor

CIPNBSSDKPropPage::CIPNBSSDKPropPage() :
	COlePropertyPage(IDD, IDS_IPNBSSDK_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CIPNBSSDKPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKPropPage::DoDataExchange - Moves data between page and properties

void CIPNBSSDKPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CIPNBSSDKPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKPropPage message handlers
