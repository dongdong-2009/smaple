#if !defined(AFX_IPNBSSDKCTL_H__C13D598D_8D5C_4BBA_9D28_E12A7E2A14A2__INCLUDED_)
#define AFX_IPNBSSDKCTL_H__C13D598D_8D5C_4BBA_9D28_E12A7E2A14A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// IPNBSSDKCtl.h : Declaration of the CIPNBSSDKCtrl ActiveX Control class.

#include "IPNBSSDK_Face.h"
#include "BSSocket.h"
#include <objsafe.h> 

#define VARIANT_COUNT		20

/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl : See IPNBSSDKCtl.cpp for implementation.

class CIPNBSSDKCtrl : public COleControl
{
	DECLARE_DYNCREATE(CIPNBSSDKCtrl)

// Constructor
public:
	//ȥ����ȫ���� BEGIN
	DECLARE_INTERFACE_MAP()
	BEGIN_INTERFACE_PART(ObjectSafety, IObjectSafety)
	STDMETHOD(GetInterfaceSafetyOptions)(REFIID riid, DWORD __RPC_FAR *pdwSupportedOptions, DWORD __RPC_FAR *pdwEnabledOptions);
	STDMETHOD(SetInterfaceSafetyOptions)(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions);
	END_INTERFACE_PART(ObjectSafety)
	//ȥ����ȫ���� END

	CIPNBSSDKCtrl();
	static void CALLBACK OnStatusCallBack(DWORD dwInstance, WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIPNBSSDKCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CIPNBSSDKCtrl();

	DECLARE_OLECREATE_EX(CIPNBSSDKCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CIPNBSSDKCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CIPNBSSDKCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CIPNBSSDKCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CIPNBSSDKCtrl)
	//}}AFX_MSG
	afx_msg void OnRecvState(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CIPNBSSDKCtrl)
	afx_msg BOOL IPNBSSDKCtrlCall(short wFromID, short wToID);
	afx_msg BOOL IPNBSSDKSetServerIP(LPCTSTR strServerIP);
	afx_msg BOOL IPNBSSDKSetServerPort(short wPort);
	afx_msg BOOL IPNBSSDKSetStatePort(short wPort);
	afx_msg BOOL IPNBSSDKCtrlFireAlarm(short wAlarmArea, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlAnswer(short wFromID);
	afx_msg BOOL IPNBSSDKCtrlHang(short wFromID);
	afx_msg BOOL IPNBSSDKCtrlIO(short wID, short wPort, BOOL bIsOn);
	afx_msg BOOL IPNBSSDKInit();
	afx_msg BOOL IPNBSSDKCtrlMonitor(short wFromID, short wToID, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlBroadcast(short wFromID, const VARIANT FAR& vaToID, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlQueryState(short wID);
	afx_msg BOOL IPNBSSDKCtrlTimerRing(short wNO, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlQueryIP(short wID);
	afx_msg BOOL IPNBSSDKCtrlQueryID(LPCTSTR strTermIP);
	afx_msg BOOL IPNBSSDKCtrlIPCall(LPCTSTR strFromIP, LPCTSTR strToIP);
	afx_msg BOOL IPNBSSDKCtrlIPAnswer(LPCTSTR strFromIP);
	afx_msg BOOL IPNBSSDKCtrlIPHang(LPCTSTR strFromIP);
	afx_msg void IPNBSSDKSetStatusCallBack(long dwCallBack, long dwInstance);
	afx_msg BOOL IPNBSSDKCtrlQueryTermCount();
	afx_msg BOOL IPNBSSDKCtrlSetName(short wID, LPCTSTR strName);
	afx_msg BOOL IPNBSSDKCtrlSetVolume(short wID, short wVolume);
	afx_msg BOOL IPNBSSDKCtrlQueryPort(short wID, short wPort);
	afx_msg BOOL IPNBSSDKCtrlSDPlay(short wID, BOOL bPlay, short wFileIndex);
	afx_msg BOOL IPNBSSDKCtrlVoiceControl(short wID, short wCtrlIn, short wCtrlOut);
	afx_msg BOOL IPNBSSDKCtrlCallEx(short wFromID, short wToID, short ucPanel);
	afx_msg BOOL IPNBSSDKCtrlHangEx(short wFromID);
	afx_msg BOOL IPNBSSDKCtrlAnswerEx(short wFromID);
	afx_msg BOOL IPNBSSDKCtrlBroadcastEx(short wFromID, const VARIANT FAR& vaToID, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlIPCallEx(LPCTSTR strFromIP, LPCTSTR strToIP, short ucPanel);
	afx_msg BOOL IPNBSSDKCtrlIPAnswerEx(LPCTSTR strFromIP);
	afx_msg BOOL IPNBSSDKCtrlIPHangEx(LPCTSTR strFromIP);
	afx_msg BOOL IPNBSSDKCtrlBroadcastSingle(short wFromID, short wToID, short ucArea, BOOL bStart);
	afx_msg BOOL IPNBSSDKCtrlCallPhone(short wFromID, short wToID, short ucPanel, LPCTSTR strPhone);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CIPNBSSDKCtrl)
	void FireIPNBSSDKRecvState(short wParam, const VARIANT FAR& lParam)
		{FireEvent(eventidIPNBSSDKRecvState,EVENT_PARAM(VTS_I2  VTS_VARIANT), wParam, &lParam);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CIPNBSSDKCtrl)
	dispidIPNBSSDKCtrlCall = 1L,
	dispidIPNBSSDKSetServerIP = 2L,
	dispidIPNBSSDKSetServerPort = 3L,
	dispidIPNBSSDKSetStatePort = 4L,
	dispidIPNBSSDKCtrlFireAlarm = 5L,
	dispidIPNBSSDKCtrlAnswer = 6L,
	dispidIPNBSSDKCtrlHang = 7L,
	dispidIPNBSSDKCtrlIO = 8L,
	dispidIPNBSSDKInit = 9L,
	dispidIPNBSSDKCtrlMonitor = 10L,
	dispidIPNBSSDKCtrlBroadcast = 11L,
	dispidIPNBSSDKCtrlQueryState = 12L,
	dispidIPNBSSDKCtrlTimerRing = 13L,
	dispidIPNBSSDKCtrlQueryIP = 14L,
	dispidIPNBSSDKCtrlQueryID = 15L,
	dispidIPNBSSDKCtrlIPCall = 16L,
	dispidIPNBSSDKCtrlIPAnswer = 17L,
	dispidIPNBSSDKCtrlIPHang = 18L,
	dispidIPNBSSDKSetStatusCallBack = 19L,
	dispidIPNBSSDKCtrlQueryTermCount = 20L,
	dispidIPNBSSDKCtrlSetName = 21L,
	dispidIPNBSSDKCtrlSetVolume = 22L,
	dispidIPNBSSDKCtrlQueryPort = 23L,
	dispidIPNBSSDKCtrlSDPlay = 24L,
	dispidIPNBSSDKCtrlVoiceControl = 25L,
	dispidIPNBSSDKCtrlCallEx = 26L,
	dispidIPNBSSDKCtrlHangEx = 27L,
	dispidIPNBSSDKCtrlAnswerEx = 28L,
	dispidIPNBSSDKCtrlBroadcastEx = 29L,
	dispidIPNBSSDKCtrlIPCallEx = 30L,
	dispidIPNBSSDKCtrlIPAnswerEx = 31L,
	dispidIPNBSSDKCtrlIPHangEx = 32L,
	dispidIPNBSSDKCtrlBroadcastSingle = 33L,
	dispidIPNBSSDKCtrlCallPhone = 34L,
	eventidIPNBSSDKRecvState = 1L,
	//}}AFX_DISP_ID
	};
protected:
	VARIANT CreateSafeArray(LPBYTE lpInBuf, DWORD dwBufSize);
	HRESULT VariantEnumToBytes(IDispatch* disp, LPBYTE *ppBytes, DWORD *pdwBytes);
	HRESULT VariantArrayToBytes(const VARIANT *pVariant, LPBYTE *ppBytes, DWORD *pdwBytes);

protected:
	CBSSocket		m_bsSocket;
	VARIANT			m_pvaState[VARIANT_COUNT];
	BYTE			m_ucStatePos;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPNBSSDKCTL_H__C13D598D_8D5C_4BBA_9D28_E12A7E2A14A2__INCLUDED)
