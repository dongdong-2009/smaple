// IPNBSSDKCtl.cpp : Implementation of the CIPNBSSDKCtrl ActiveX Control class.

#include "stdafx.h"
#include "IPNBSSDK.h"
#include "IPNBSSDK_Face.h"
#include "IPNBSSDKCtl.h"
#include "IPNBSSDKPpg.h"
#include <comdef.h>
#include <atlbase.h>
#include <atlconv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CIPNBSSDKCtrl, COleControl)

//ȥ����ȫ���� BEGIN
BEGIN_INTERFACE_MAP(CIPNBSSDKCtrl, COleControl)
INTERFACE_PART(CIPNBSSDKCtrl, IID_IObjectSafety, ObjectSafety)
END_INTERFACE_MAP()
// Implementation of IObjectSafety
STDMETHODIMP CIPNBSSDKCtrl::XObjectSafety::GetInterfaceSafetyOptions(
	REFIID riid,
	DWORD __RPC_FAR *pdwSupportedOptions,
	DWORD __RPC_FAR *pdwEnabledOptions)
{
	METHOD_PROLOGUE_EX(CIPNBSSDKCtrl, ObjectSafety)
	if (!pdwSupportedOptions || !pdwEnabledOptions)
	{
		return E_POINTER;
	}
	*pdwSupportedOptions = INTERFACESAFE_FOR_UNTRUSTED_CALLER | INTERFACESAFE_FOR_UNTRUSTED_DATA;
	*pdwEnabledOptions = 0;
	if (NULL == pThis->GetInterface(&riid))
	{
		TRACE("Requested interface is not supported.\n");
		return E_NOINTERFACE;
	}
	// What interface is being checked out anyhow?
	OLECHAR szGUID[39];
	int i = StringFromGUID2(riid, szGUID, 39);
	if (riid == IID_IDispatch)
	{
		// Client wants to know if object is safe for scripting
		*pdwEnabledOptions = INTERFACESAFE_FOR_UNTRUSTED_CALLER;
		return S_OK;
	}
	else if (riid == IID_IPersistPropertyBag
		|| riid == IID_IPersistStreamInit
		|| riid == IID_IPersistStorage
		|| riid == IID_IPersistMemory)
	{
		// Those are the persistence interfaces COleControl derived controls support
		// as indicated in AFXCTL.H
		// Client wants to know if object is safe for initializing from persistent data
		*pdwEnabledOptions = INTERFACESAFE_FOR_UNTRUSTED_DATA;
		return S_OK;
	}
	else
	{
		// Find out what interface this is, and decide what options to enable
		TRACE("We didn't account for the safety of this interface, and it's one we support...\n");
		return E_NOINTERFACE;
	}
}

STDMETHODIMP CIPNBSSDKCtrl::XObjectSafety::SetInterfaceSafetyOptions(
	REFIID riid,
	DWORD dwOptionSetMask,
	DWORD dwEnabledOptions)
{
	METHOD_PROLOGUE_EX(CIPNBSSDKCtrl, ObjectSafety)
	OLECHAR szGUID[39];
	// What is this interface anyway?
	// We can do a quick lookup in the registry under HKEY_CLASSES_ROOT\Interface
	int i = StringFromGUID2(riid, szGUID, 39);
	if (0 == dwOptionSetMask && 0 == dwEnabledOptions)
	{
		// the control certainly supports NO requests through the specified interface
		// so it"s safe to return S_OK even if the interface isn"t supported.
		return S_OK;
	}
	// Do we support the specified interface?
	if (NULL == pThis->GetInterface(&riid))
	{
		TRACE1("%s is not support.\n", szGUID);
		return E_FAIL;
	}
	if (riid == IID_IDispatch)
	{
		TRACE("Client asking if it's safe to call through IDispatch.\n");
		TRACE("In other words, is the control safe for scripting?\n");
		if (INTERFACESAFE_FOR_UNTRUSTED_CALLER == dwOptionSetMask && INTERFACESAFE_FOR_UNTRUSTED_CALLER == dwEnabledOptions)
		{
			return S_OK;
		}
		else
		{
			return E_FAIL;
		}
	}
	else if (riid == IID_IPersistPropertyBag
		|| riid == IID_IPersistStreamInit
		|| riid == IID_IPersistStorage
		|| riid == IID_IPersistMemory)
	{
		TRACE("Client asking if it's safe to call through IPersist*.\n");
		TRACE("In other words, is the control safe for initializing from persistent data?\n");
		if (INTERFACESAFE_FOR_UNTRUSTED_DATA == dwOptionSetMask && INTERFACESAFE_FOR_UNTRUSTED_DATA == dwEnabledOptions)
		{
			return NOERROR;
		}
		else
		{
			return E_FAIL;
		}
	}
	else
	{
		TRACE1("We didn't account for the safety of %s, and it's one we support...\n", szGUID);
		return E_FAIL;
	}
}

STDMETHODIMP_(ULONG) CIPNBSSDKCtrl::XObjectSafety::AddRef()
{
	METHOD_PROLOGUE_EX_(CIPNBSSDKCtrl, ObjectSafety)
	return (ULONG)pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG) CIPNBSSDKCtrl::XObjectSafety::Release()
{
	METHOD_PROLOGUE_EX_(CIPNBSSDKCtrl, ObjectSafety)
	return (ULONG)pThis->ExternalRelease();
}

STDMETHODIMP CIPNBSSDKCtrl::XObjectSafety::QueryInterface(REFIID iid, LPVOID* ppvObj)
{
	METHOD_PROLOGUE_EX_(CIPNBSSDKCtrl, ObjectSafety)
	return (HRESULT)pThis->ExternalQueryInterface(&iid, ppvObj);
}
//ȥ����ȫ���� END

/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CIPNBSSDKCtrl, COleControl)
	//{{AFX_MSG_MAP(CIPNBSSDKCtrl)
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
	ON_MESSAGE(UM_IPNBSSDK_STATE, OnRecvState)
//	ON_MESSAGE(UM_IPNBSSDK_STATE, OnRecvState)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CIPNBSSDKCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CIPNBSSDKCtrl)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlCall", IPNBSSDKCtrlCall, VT_BOOL, VTS_I2 VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKSetServerIP", IPNBSSDKSetServerIP, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKSetServerPort", IPNBSSDKSetServerPort, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKSetStatePort", IPNBSSDKSetStatePort, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlFireAlarm", IPNBSSDKCtrlFireAlarm, VT_BOOL, VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlAnswer", IPNBSSDKCtrlAnswer, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlHang", IPNBSSDKCtrlHang, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIO", IPNBSSDKCtrlIO, VT_BOOL, VTS_I2 VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKInit", IPNBSSDKInit, VT_BOOL, VTS_NONE)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlMonitor", IPNBSSDKCtrlMonitor, VT_BOOL, VTS_I2 VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlBroadcast", IPNBSSDKCtrlBroadcast, VT_BOOL, VTS_I2 VTS_VARIANT VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlQueryState", IPNBSSDKCtrlQueryState, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlTimerRing", IPNBSSDKCtrlTimerRing, VT_BOOL, VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlQueryIP", IPNBSSDKCtrlQueryIP, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlQueryID", IPNBSSDKCtrlQueryID, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPCall", IPNBSSDKCtrlIPCall, VT_BOOL, VTS_BSTR VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPAnswer", IPNBSSDKCtrlIPAnswer, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPHang", IPNBSSDKCtrlIPHang, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKSetStatusCallBack", IPNBSSDKSetStatusCallBack, VT_EMPTY, VTS_I4 VTS_I4)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlQueryTermCount", IPNBSSDKCtrlQueryTermCount, VT_BOOL, VTS_NONE)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlSetName", IPNBSSDKCtrlSetName, VT_BOOL, VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlSetVolume", IPNBSSDKCtrlSetVolume, VT_BOOL, VTS_I2 VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlQueryPort", IPNBSSDKCtrlQueryPort, VT_BOOL, VTS_I2 VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlSDPlay", IPNBSSDKCtrlSDPlay, VT_BOOL, VTS_I2 VTS_BOOL VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlVoiceControl", IPNBSSDKCtrlVoiceControl, VT_BOOL, VTS_I2 VTS_I2 VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlCallEx", IPNBSSDKCtrlCallEx, VT_BOOL, VTS_I2 VTS_I2 VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlHangEx", IPNBSSDKCtrlHangEx, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlAnswerEx", IPNBSSDKCtrlAnswerEx, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlBroadcastEx", IPNBSSDKCtrlBroadcastEx, VT_BOOL, VTS_I2 VTS_VARIANT VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPCallEx", IPNBSSDKCtrlIPCallEx, VT_BOOL, VTS_BSTR VTS_BSTR VTS_I2)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPAnswerEx", IPNBSSDKCtrlIPAnswerEx, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlIPHangEx", IPNBSSDKCtrlIPHangEx, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlBroadcastSingle", IPNBSSDKCtrlBroadcastSingle, VT_BOOL, VTS_I2 VTS_I2 VTS_I2 VTS_BOOL)
	DISP_FUNCTION(CIPNBSSDKCtrl, "IPNBSSDKCtrlCallPhone", IPNBSSDKCtrlCallPhone, VT_BOOL, VTS_I2 VTS_I2 VTS_I2 VTS_BSTR)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CIPNBSSDKCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CIPNBSSDKCtrl, COleControl)
	//{{AFX_EVENT_MAP(CIPNBSSDKCtrl)
	EVENT_CUSTOM("IPNBSSDKRecvState", FireIPNBSSDKRecvState, VTS_I2  VTS_VARIANT)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CIPNBSSDKCtrl, 1)
	PROPPAGEID(CIPNBSSDKPropPage::guid)
END_PROPPAGEIDS(CIPNBSSDKCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CIPNBSSDKCtrl, "IPNBSSDK.IPNBSSDKCtrl.1",
	0xbcba4f50, 0x29a0, 0x41f7, 0x8d, 0xb7, 0x1d, 0xa9, 0xdb, 0x3, 0xec, 0x66)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CIPNBSSDKCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DIPNBSSDK =
		{ 0xc9c431ee, 0x4603, 0x46fb, { 0xa0, 0xb2, 0x85, 0x2f, 0xd, 0x28, 0xbc, 0x8b } };
const IID BASED_CODE IID_DIPNBSSDKEvents =
		{ 0x3ffa7132, 0x5963, 0x4c83, { 0xae, 0x25, 0xa4, 0x5a, 0x83, 0x4e, 0xe2, 0xd8 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwIPNBSSDKOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CIPNBSSDKCtrl, IDS_IPNBSSDK, _dwIPNBSSDKOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::CIPNBSSDKCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CIPNBSSDKCtrl

BOOL CIPNBSSDKCtrl::CIPNBSSDKCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_IPNBSSDK,
			IDB_IPNBSSDK,
			afxRegApartmentThreading,
			_dwIPNBSSDKOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::CIPNBSSDKCtrl - Constructor

CIPNBSSDKCtrl::CIPNBSSDKCtrl()
{
	InitializeIIDs(&IID_DIPNBSSDK, &IID_DIPNBSSDKEvents);

	// TODO: Initialize your control's instance data here.
	SetInitialSize(1, 1);
	m_ucStatePos = 0;
	for (int i = 0; i < VARIANT_COUNT; i++)
		VariantInit(&m_pvaState[i]);
	m_bsSocket.SetStatusCallBack((DWORD)OnStatusCallBack, (DWORD)this);
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::~CIPNBSSDKCtrl - Destructor

CIPNBSSDKCtrl::~CIPNBSSDKCtrl()
{
	// TODO: Cleanup your control's instance data here.
	m_bsSocket.SetStatusCallBack((DWORD)NULL, (DWORD)this);
	for (int i = 0; i < VARIANT_COUNT; i++)
	{
		if (m_pvaState[i].vt != VT_EMPTY)
			VariantClear(&m_pvaState[i]);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::OnDraw - Drawing function

void CIPNBSSDKCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
//	pdc->TextOut(10, 16, _T("IPNBSSDK"));
//	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::DoPropExchange - Persistence support

void CIPNBSSDKCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::OnResetState - Reset control to default state

void CIPNBSSDKCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl::AboutBox - Display an "About" box to the user

void CIPNBSSDKCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_IPNBSSDK);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKCtrl message handlers

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlCall(short wFromID, short wToID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlCall(wFromID, wToID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKSetServerIP(LPCTSTR strServerIP) 
{
	// TODO: Add your dispatch handler code here
	CString strIP = strServerIP;
	return m_bsSocket.SetServerIP(strIP.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKSetServerPort(short wPort) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.SetServerPort(wPort);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKSetStatePort(short wPort) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.SetStatePort(wPort);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlFireAlarm(short wAlarmArea, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlFireAlarm(wAlarmArea, bStart);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlAnswer(short wFromID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlAnswer(wFromID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlHang(short wFromID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlHang(wFromID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIO(short wID, short wPort, BOOL bIsOn) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlIO(wID, (BYTE)wPort, bIsOn);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlBroadcast(short wFromID, const VARIANT FAR& vaToID, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	BOOL bRet = FALSE;
	LPBYTE lpBuf = NULL;
	DWORD nLen = BROADCAST_TO_ID_LEN;
	HRESULT hr = S_OK;
	BYTE lpToID[BROADCAST_TO_ID_LEN];
	ZeroMemory(lpToID, BROADCAST_TO_ID_LEN);

	if (vaToID.vt == (VT_ARRAY | VT_VARIANT))
	{ 
		//deal with vc array
		long lLbound; 
		long lUbound; 
		_variant_t vOut;
		SAFEARRAY *pSA = NULL;
		lpBuf = new BYTE[BROADCAST_TO_ID_LEN];
		ZeroMemory(lpBuf, BROADCAST_TO_ID_LEN);
		nLen = BROADCAST_TO_ID_LEN;
		pSA = vaToID.parray;
		SafeArrayGetLBound(pSA, 1, &lLbound);
		SafeArrayGetUBound(pSA, 1, &lUbound);
		for (int i = 0; lLbound <= lUbound && i < BROADCAST_TO_ID_LEN; lLbound++, i++)
		{
			SafeArrayGetElement(pSA, &lLbound, &vOut);
			lpBuf[i] = vOut.bVal;
		}
	}
	else if(vaToID.vt == VT_DISPATCH)
	{
		//deal with javascript array
		hr = VariantEnumToBytes(vaToID.pdispVal,&lpBuf, &nLen);
	}
	else
	{
		//deal with vbscript array
		hr = VariantArrayToBytes(&vaToID, &lpBuf, &nLen) ;
	}

	if(S_OK == hr)
	{
		memcpy(lpToID, lpBuf, nLen);
		bRet = m_bsSocket.CtrlBroadcast(wFromID, lpToID, bStart);
	}
	if (lpBuf != NULL)
	{
		delete []lpBuf;
		lpBuf = NULL;
	}

	return bRet;
}

void CIPNBSSDKCtrl::OnRecvState(WPARAM wParam, LPARAM lParam)
{
	BYTE					pucStateData[sizeof (DGRAMHEADER_STATUS) + 4];
	LPDGRAMHEADER_STATUS	lpData = (LPDGRAMHEADER_STATUS)lParam;
	ZeroMemory(&pucStateData, sizeof (DGRAMHEADER_STATUS) + 4);
	DWORD dwStateSize = (lpData->ucFunction == 0xD1) ? sizeof (DGRAMHEADER_STATUS) + 4 : DGRAMHEADER_HEADER_SIZE;
	memcpy(&pucStateData, (LPBYTE)lParam, dwStateSize);
//	dwStateSize = sizeof (DGRAMHEADER_STATUS) + 4;

	//�����¼�
	short wMsgParam = (short)wParam;
	VARIANT varMsgParam;
	varMsgParam = CreateSafeArray((LPBYTE)&pucStateData, dwStateSize);
	FireIPNBSSDKRecvState(wMsgParam, varMsgParam);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKInit() 
{
	// TODO: Add your dispatch handler code here
	BOOL bRet = TRUE;
	if (m_hWnd != NULL)
		m_bsSocket.SetParentWnd(m_hWnd);
	else
		bRet = FALSE;

	return bRet;
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlMonitor(short wFromID, short wToID, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlMonitor(wFromID, wToID, bStart);
}

VARIANT CIPNBSSDKCtrl::CreateSafeArray(LPBYTE lpInBuf, DWORD dwBufSize)
{
	m_ucStatePos = (m_ucStatePos + 1) % VARIANT_COUNT;
	if (m_pvaState[m_ucStatePos].vt != VT_EMPTY)
		VariantClear(&m_pvaState[m_ucStatePos]);
		
    // Create SafeArray
    HRESULT hr = S_OK;
    SAFEARRAY *pSA;
    SAFEARRAYBOUND aDim[1];
    aDim[0].lLbound = 0;
    aDim[0].cElements = dwBufSize;
    pSA = SafeArrayCreate(VT_VARIANT, 1, aDim);
    if (pSA != NULL)
	{
		_variant_t vOut;
		vOut.vt = VT_UI1;
		for (DWORD i = 0; i < dwBufSize; i++)
		{
			vOut.bVal = lpInBuf[i];
			if (hr = SafeArrayPutElement(pSA, (long *)&i, &vOut))
			{
				SafeArrayDestroy(pSA); // does a deep destroy
				break;
			}
		}
		m_pvaState[m_ucStatePos].vt = VT_ARRAY | VT_VARIANT;
		m_pvaState[m_ucStatePos].parray = pSA;
    }
	
	return m_pvaState[m_ucStatePos];
}

HRESULT CIPNBSSDKCtrl::VariantArrayToBytes(const VARIANT *pVariant, LPBYTE *ppBytes, DWORD *pdwBytes)
{
	USES_CONVERSION;
	if (pVariant->vt != (VT_VARIANT | VT_BYREF))
		return E_INVALIDARG;
	if (!(pVariant->pvarVal->vt & VT_ARRAY))
		return E_INVALIDARG;

	SAFEARRAY* pX = NULL;
	if (pVariant->pvarVal->vt & VT_BYREF)
		pX = *(pVariant->pvarVal->pparray);
	else
		pX = pVariant->pvarVal->parray;
	if (::SafeArrayGetDim(pX) != 1)
		return E_INVALIDARG;

	*ppBytes = NULL;
	*pdwBytes = 0;
	VARIANT *pArray = NULL;
	HRESULT hr = E_FAIL;
	_variant_t v;
	hr = SafeArrayAccessData(pX, (void **) &pArray);
	if(SUCCEEDED(hr))
	{
		*pdwBytes = pX->rgsabound->cElements;
		*ppBytes = (LPBYTE)new BYTE[*pdwBytes];
		ZeroMemory(*ppBytes, *pdwBytes);
		for(DWORD i = 0; i < *pdwBytes; i++)
		{
			v = pArray[i];
			v.ChangeType(VT_UI1);
			(*ppBytes)[i] = v.bVal;
		}
		SafeArrayUnaccessData( pX );
	}
	else
		return hr;
	SafeArrayDestroy(pX);

	return S_OK;
}

HRESULT CIPNBSSDKCtrl::VariantEnumToBytes(IDispatch *disp, LPBYTE *ppBytes, DWORD *pdwBytes)
{
	HRESULT hr;
	DISPPARAMS noArgs = {NULL, NULL, 0, 0};
	CComVariant resultV;
	hr = disp->Invoke(DISPID_NEWENUM,
		IID_NULL,
		LOCALE_SYSTEM_DEFAULT,
		DISPATCH_PROPERTYGET,
		&noArgs,
		&resultV,
		NULL,
		NULL);
	if (FAILED(hr) && FAILED(resultV.ChangeType(VT_UNKNOWN)))
		return E_FAIL;
	// Bug 37459, above Invoke succeeds, but returns resultV.vt == VT_EMPTY, resultV->other param unchanged
	if (resultV.vt != VT_UNKNOWN && resultV.vt != VT_DISPATCH)
	{
		return E_FAIL;
	}

	CComQIPtr<IEnumUnknown> pEnum(resultV.punkVal);
	if(!pEnum)
		return E_FAIL;

	// Count the elements
	*pdwBytes = 0;
	hr = S_OK;
	//Get Enum Size
	while(hr == S_OK)
	{
		hr = pEnum->Skip(1);
		if(hr == S_OK)
			(*pdwBytes)++;
	}
	//allocate memory
	*ppBytes = (LPBYTE)new BYTE[*pdwBytes];
	ZeroMemory(*ppBytes, *pdwBytes);
	int nCount = 0;
	CComVariant elemV;
	pEnum->Reset();
	hr = S_OK;
	::MessageBox(NULL, _T("4"), _T("FAILED"), MB_OK);
	while (hr == S_OK)
	{
		// Could switch to use Skip when Cary gets
		// it working.
		hr = pEnum->Next(1, (IUnknown **)&elemV, NULL);
		if (elemV.vt != VT_I4)
			hr = S_FALSE; // correct for dispproxy bug 19307
		else
		{
			int nTmp = elemV.lVal;
			(*ppBytes)[nCount] = (BYTE)nTmp;
		}
		if (hr == S_OK)
			nCount++;
	}
	
	return S_OK;
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlQueryState(short wID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlQueryState(wID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlTimerRing(short wNO, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlTimerRing(wNO, bStart);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlQueryIP(short wID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlQueryIP(wID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlQueryID(LPCTSTR strTermIP) 
{
	// TODO: Add your dispatch handler code here
	CString strIP = strTermIP;
	return m_bsSocket.CtrlQueryID(strIP.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPCall(LPCTSTR strFromIP, LPCTSTR strToIP) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP, strTo = strToIP;
	return m_bsSocket.CtrlIPCall(strFrom.GetBuffer(0), strTo.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPAnswer(LPCTSTR strFromIP) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP;
	return m_bsSocket.CtrlIPAnswer(strFrom.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPHang(LPCTSTR strFromIP) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP;
	return m_bsSocket.CtrlIPHang(strFrom.GetBuffer(0));
}

void CIPNBSSDKCtrl::IPNBSSDKSetStatusCallBack(long dwCallBack, long dwInstance) 
{
	// TODO: Add your dispatch handler code here
	m_bsSocket.SetStatusCallBack(dwCallBack, dwInstance);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlQueryTermCount() 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlQueryTermCount();
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlSetName(short wID, LPCTSTR strName) 
{
	// TODO: Add your dispatch handler code here
	CString		strTemp = strName;
	return m_bsSocket.CtrlSetName(wID, strTemp.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlSetVolume(short wID, short wVolume) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlSetVolume(wID, (BYTE)wVolume);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlQueryPort(short wID, short wPort) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlQueryPort(wID, (BYTE)wPort);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlSDPlay(short wID, BOOL bPlay, short wFileIndex) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlSDPlay(wID, bPlay, (BYTE)wFileIndex);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlVoiceControl(short wID, short wCtrlIn, short wCtrlOut) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlVoiceControl(wID, (BYTE)wCtrlIn, (BYTE)wCtrlOut);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlCallEx(short wFromID, short wToID, short ucPanel) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlCallEx(wFromID, wToID, ucPanel & 0xFF);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlHangEx(short wFromID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlHangEx(wFromID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlAnswerEx(short wFromID) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlAnswerEx(wFromID);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlBroadcastEx(short wFromID, const VARIANT FAR& vaToID, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	BOOL		bRet = FALSE;
	LPBYTE		lpBuf = NULL;
	DWORD		nLen = BROADCAST_TO_ID_LEN_EX;
	HRESULT		hr = S_OK;
	BYTE		lpToID[BROADCAST_TO_ID_LEN_EX];

	ZeroMemory(lpToID, BROADCAST_TO_ID_LEN_EX);
	
	if (vaToID.vt == (VT_ARRAY | VT_VARIANT))
	{ 
		//deal with vc array
		long		lLbound; 
		long		lUbound; 
		_variant_t	vOut;
		SAFEARRAY	*pSA = NULL;

		lpBuf = new BYTE[BROADCAST_TO_ID_LEN_EX];
		ZeroMemory(lpBuf, BROADCAST_TO_ID_LEN_EX);
		nLen = BROADCAST_TO_ID_LEN_EX;
		pSA = vaToID.parray;
		SafeArrayGetLBound(pSA, 1, &lLbound);
		SafeArrayGetUBound(pSA, 1, &lUbound);
		for (int i = 0; lLbound <= lUbound && i < BROADCAST_TO_ID_LEN_EX; lLbound++, i++)
		{
			SafeArrayGetElement(pSA, &lLbound, &vOut);
			lpBuf[i] = vOut.bVal;
		}
	}
	else if(vaToID.vt == VT_DISPATCH)
	{
		//deal with javascript array
		hr = VariantEnumToBytes(vaToID.pdispVal,&lpBuf, &nLen);
	}
	else
	{
		//deal with vbscript array
		hr = VariantArrayToBytes(&vaToID, &lpBuf, &nLen) ;
	}
	
	if(S_OK == hr)
	{
		memcpy(lpToID, lpBuf, nLen);
		bRet = m_bsSocket.CtrlBroadcastEx(wFromID, lpToID, bStart);
	}
	if (lpBuf != NULL)
	{
		delete []lpBuf;
		lpBuf = NULL;
	}
	
	return bRet;
}

void CIPNBSSDKCtrl::OnStatusCallBack(DWORD dwInstance, WPARAM wParam, LPARAM lParam)
{
	CIPNBSSDKCtrl		*pCtrl = (CIPNBSSDKCtrl *)dwInstance;
	pCtrl->OnRecvState(wParam, lParam);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPCallEx(LPCTSTR strFromIP, LPCTSTR strToIP, short ucPanel) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP, strTo = strToIP;
	return m_bsSocket.CtrlIPCallEx(strFrom.GetBuffer(0), strTo.GetBuffer(0), (BYTE)ucPanel);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPAnswerEx(LPCTSTR strFromIP) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP;
	return m_bsSocket.CtrlIPAnswerEx(strFrom.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlIPHangEx(LPCTSTR strFromIP) 
{
	// TODO: Add your dispatch handler code here
	CString strFrom = strFromIP;
	return m_bsSocket.CtrlIPHangEx(strFrom.GetBuffer(0));
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlBroadcastSingle(short wFromID, short wToID, short ucArea, BOOL bStart) 
{
	// TODO: Add your dispatch handler code here
	return m_bsSocket.CtrlBroadcastSingle(wFromID, wToID, (BYTE)ucArea, bStart);
}

BOOL CIPNBSSDKCtrl::IPNBSSDKCtrlCallPhone(short wFromID, short wToID, short ucPanel, LPCTSTR strPhone) 
{
	// TODO: Add your dispatch handler code here
	CString		strTemp = strPhone;
	return m_bsSocket.CtrlCallPhone(wFromID, wToID, ucPanel & 0xFF, strTemp.GetBuffer(0));
}
