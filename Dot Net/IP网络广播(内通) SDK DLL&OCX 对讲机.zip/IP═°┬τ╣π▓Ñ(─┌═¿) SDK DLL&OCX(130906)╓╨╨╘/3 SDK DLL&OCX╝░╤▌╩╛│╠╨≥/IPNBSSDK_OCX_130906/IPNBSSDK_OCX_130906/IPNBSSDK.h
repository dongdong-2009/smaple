#if !defined(AFX_IPNBSSDK_H__807F9948_4FD0_40E8_9574_EA569693EBDC__INCLUDED_)
#define AFX_IPNBSSDK_H__807F9948_4FD0_40E8_9574_EA569693EBDC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// IPNBSSDK.h : main header file for IPNBSSDK.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols
#include "IPNBSSDKCtl.h"

/////////////////////////////////////////////////////////////////////////////
// CIPNBSSDKApp : See IPNBSSDK.cpp for implementation.

class CIPNBSSDKApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();

//	CIPNBSSDKCtrl	m_ctrl;
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPNBSSDK_H__807F9948_4FD0_40E8_9574_EA569693EBDC__INCLUDED)
