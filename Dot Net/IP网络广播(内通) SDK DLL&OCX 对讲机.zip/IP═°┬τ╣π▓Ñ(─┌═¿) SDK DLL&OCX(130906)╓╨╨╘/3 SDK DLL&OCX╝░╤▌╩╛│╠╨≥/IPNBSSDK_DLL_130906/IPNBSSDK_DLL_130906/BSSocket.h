/********************************************************************
	Copyright (C) 2003-2009
	created:	2009/04/09
	filename: 	E:\work\process\fourthtask\DLL\IPNBSSDK\BSSocket.h
	file base:	BSSocket
	file ext:	h
	author:		PanBasan <panbasan163@163.com>
	
	purpose:	����ӿ�ͷ�ļ�
*********************************************************************/
// BSSocket.h: interface for the CBSSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSSOCKET_H__8A219CDD_0AA3_497E_8FCD_F2A47E85AEB7__INCLUDED_)
#define AFX_BSSOCKET_H__8A219CDD_0AA3_497E_8FCD_F2A47E85AEB7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIO_UDP_CONNRESET			_WSAIOW(IOC_VENDOR,12)
#define IP_HEAD_VERSION_4			4
#define SOCKET_NET_BUF_SIZE			1024
#define DGRAMHEADER_MIN_SIZE		52

typedef enum {
	DIALOG_CALL, 
	DIALOG_ANSWER, 
	DIALOG_HANG, 
	DIALOG_CALL_EX, 
	DIALOG_CALL_PHONE, 
	DIALOG_ANSWER_EX, 
	DIALOG_HANG_EX, 
} DIALOG_CTRL;
typedef DWORD  IP4ADDR, *PIP4ADDR, FAR *LPIP4ADDR;

typedef struct tagPSEUDO_HDR{
	IP4ADDR ipSource;
	IP4ADDR ipTarget;
	BYTE    ucZero;
	BYTE    ucProtocol;
	WORD    wLength;
} PSEUDO_HDR, *PPSEUDO_HDR;

#include <pshpack1.h>
typedef struct tagIP_HEAD
{
	union
	{
		BYTE Version;			// �汾
		BYTE HdrLen;			// IHL
	};
	BYTE ServiceType;			// ��������
	WORD TotalLen;				// �ܳ�
	WORD ID;					// ��ʶ
	union
	{
		WORD Flags;				// ��־
		WORD FragOff;			// �ֶ�ƫ��
	};
	BYTE TimeToLive;			// ������
	BYTE Protocol;				// Э��
	WORD HdrChksum;				// ͷУ���
	DWORD SrcAddr;				// Դ��ַ
	DWORD DstAddr;				// Ŀ�ĵ�ַ
	//	DWORD Options;				// ѡ��
} IP_HEAD, *PIP_HEAD;			//size: 24 bytes

typedef struct tagUDP_HEAD
{
	WORD SrcPort;			// Դ�˿�
	WORD DstPort;			// Ŀ�Ķ˿�
	WORD DataLen;			// UDPͷ������������(bytes)
	WORD Chksum;			// У���
} UDP_HEAD, *PUDP_HEAD;		//size: 8 bytes
#include <poppack.h>

typedef void  (WINAPI *PSTATUSCALLBACK)(DWORD dwInstance, WPARAM wParam, LPARAM lParam);

class CBSSocket  
{
public:
	BOOL CtrlCallPhone(WORD wFromID, WORD wToID, BYTE ucPanel, LPTSTR strPhone);
	void SetIsUnicode(BOOL bIsUnicode);
	BOOL CtrlBroadcastSingle(WORD wFromID, WORD wToID, BYTE ucArea, BOOL bStart);
	BOOL CtrlBroadcastEx(WORD wFromID, BYTE *pToID, BOOL bStart);
	BOOL CtrlVoiceControl(WORD wID, BYTE ucCtrlIn, BYTE ucCtrlOut);
	BOOL CtrlSDPlay(WORD wID, BOOL bPlay, BYTE ucFileIndex);
	BOOL CtrlQueryPort(WORD wID, BYTE ucPort);
	BOOL CtrlSetVolume(WORD wID, BYTE ucVolume);
	BOOL CtrlSetName(WORD wID, LPTSTR strName);
	BOOL CtrlQueryTermCount();
	void SetStatusCallBack(DWORD dwCallback, DWORD dwInstance);
	BOOL CtrlQueryID(LPTSTR strTermIP);
	BOOL CtrlQueryIP(WORD wID);
	BOOL CtrlTimerRing(WORD wNO, BOOL bStart);
	BOOL CtrlQueryState(WORD wID);
	BOOL CtrlMonitor(WORD wFromID, WORD wToID, BOOL bStart);
	BOOL CtrlBroadcast(WORD wFromID, BYTE *pToID, BOOL bStart);
	BOOL SetStatePort(WORD wPort);
	BOOL SetServerPort(WORD nPort);
	BOOL CtrlIO(WORD wID, BYTE ucPort, BOOL bIsOn);
	BOOL CtrlHang(WORD wFromID);
	BOOL CtrlAnswer(WORD wFromID);
	BOOL CtrlCall(WORD wFromID, WORD wToID);
	BOOL CtrlHangEx(WORD wFromID);
	BOOL CtrlAnswerEx(WORD wFromID);
	BOOL CtrlCallEx(WORD wFromID, WORD wToID, BYTE ucPanel);
	BOOL CtrlIPHang(LPTSTR strFromIP);
	BOOL CtrlIPAnswer(LPTSTR strFromIP);
	BOOL CtrlIPCall(LPTSTR strFromIP, LPTSTR strToIP);
	BOOL CtrlIPHangEx(LPTSTR strFromIP);
	BOOL CtrlIPAnswerEx(LPTSTR strFromIP);
	BOOL CtrlIPCallEx(LPTSTR strFromIP, LPTSTR strToIP, BYTE ucPanel);
	BOOL CtrlFireAlarm(WORD wAlarmArea, BOOL bStart);
	void SetParentWnd(HWND hWnd);
	BOOL SetServerIP(LPTSTR strServerIP);
	CBSSocket();
	virtual ~CBSSocket();

private:
	BOOL SendTo(char *lpBuf, int nBufLen);

protected:
	BOOL CtrlDialog(DIALOG_CTRL dialogCtrl, WORD wFromID, WORD wToID, BYTE ucPanel, LPTSTR strPhone = NULL);
	BOOL CtrlIPDialog(DIALOG_CTRL dialogCtrl, LPTSTR strFromIP, LPTSTR strToIP, BYTE ucPanel = 0);
	BOOL InitSocket(void);
	BOOL JoinLeaf(SOCKET &socket, LPTSTR strRecvAddr);	//����һ���鲥������
	BOOL InitStateSocket(void);
	BOOL InitCtrlSocket(void);
	BOOL ConvertToAddr(LPTSTR strAddr, SOCKADDR_IN &stAddr);
	int CheckWinsockVersion(void);	//ȷ��WinSock DLL��2.0���ϰ汾,֧���򷵻�0,���򷵻ط�0
	static DWORD WINAPI StateSocketThreadProc(LPVOID lpParameter);

private:
	SOCKET			m_socketCtrl;				// �����׽���
	SOCKET			m_socketState;				//  ״̬�׽���
	SOCKET			m_socketMulti;				// �����鲥���ݵ��׽���
	SOCKADDR_IN		m_addrServer;				// ���ֹ㲥������IP
	SOCKADDR_IN		m_addrHost;					// ����IP
	BOOL			m_bWinsockVersion;			// WinSock DLL�汾�Ƿ���2.0����
	WSAEVENT		m_hStateEvent;				// ����״̬�����¼�
	WSAEVENT		m_hMultiEvent;				// �鲥״̬�����¼�
	HANDLE			m_hThreadExitEvent;			// ״̬�����߳��˳��¼�
	HANDLE			m_hThread;					// ״̬�����߳�
	HWND			m_hParentWnd;				// �����ھ��
	WORD			m_wServerPort;				// ���������ն˿�
	WORD			m_wStatePort;				// ״̬���ն˿�
	BYTE			m_pSendBuf[SOCKET_NET_BUF_SIZE];	//���紫�ͻ�����
	PSTATUSCALLBACK	m_pCallBack;				// ״̬�����Ļص�����
	DWORD			m_dwInstance;				// ״̬�����Ļص�����������ʵ��
	BOOL			m_bIsUnicode;				// Unicode����
};

#endif // !defined(AFX_BSSOCKET_H__8A219CDD_0AA3_497E_8FCD_F2A47E85AEB7__INCLUDED_)
