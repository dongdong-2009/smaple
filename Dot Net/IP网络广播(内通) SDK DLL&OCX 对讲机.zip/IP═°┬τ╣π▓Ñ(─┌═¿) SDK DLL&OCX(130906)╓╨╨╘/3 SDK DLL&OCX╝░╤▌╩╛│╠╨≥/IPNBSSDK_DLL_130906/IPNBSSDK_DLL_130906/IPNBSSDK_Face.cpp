#include "stdafx.h"
#include "IPNBSSDK_Face.h"
#include "BSSocket.h"

CBSSocket g_BSSocket;

void IPNBSSDK_SetParentWnd(HWND hWnd)
{
	g_BSSocket.SetParentWnd(hWnd);
}

BOOL IPNBSSDK_SetServerIP(LPTSTR strServerIP)
{
	return g_BSSocket.SetServerIP(strServerIP);
}

BOOL IPNBSSDK_CtrlCall(WORD wFromID, WORD wToID)
{
	return g_BSSocket.CtrlCall(wFromID, wToID);
}

BOOL IPNBSSDK_CtrlAnswer(WORD wFromID)
{
	return g_BSSocket.CtrlAnswer(wFromID);
}

BOOL IPNBSSDK_CtrlHang(WORD wFromID)
{
	return g_BSSocket.CtrlHang(wFromID);
}

BOOL IPNBSSDK_CtrlCallEx(WORD wFromID, WORD wToID, BYTE ucPanel)
{
	return g_BSSocket.CtrlCallEx(wFromID, wToID, ucPanel);
}

BOOL IPNBSSDK_CtrlAnswerEx(WORD wFromID)
{
	return g_BSSocket.CtrlAnswerEx(wFromID);
}

BOOL IPNBSSDK_CtrlHangEx(WORD wFromID)
{
	return g_BSSocket.CtrlHangEx(wFromID);
}

BOOL IPNBSSDK_CtrlIPCall(LPTSTR strFromIP, LPTSTR strToIP)
{
	return g_BSSocket.CtrlIPCall(strFromIP, strToIP);
}

BOOL IPNBSSDK_CtrlIPAnswer(LPTSTR strFromIP)
{
	return g_BSSocket.CtrlIPAnswer(strFromIP);
}

BOOL IPNBSSDK_CtrlIPHang(LPTSTR strFromIP)
{
	return g_BSSocket.CtrlIPHang(strFromIP);
}

BOOL IPNBSSDK_CtrlIPCallEx(LPTSTR strFromIP, LPTSTR strToIP, BYTE ucPanel)
{
	return g_BSSocket.CtrlIPCallEx(strFromIP, strToIP, ucPanel);
}

BOOL IPNBSSDK_CtrlIPAnswerEx(LPTSTR strFromIP)
{
	return g_BSSocket.CtrlIPAnswerEx(strFromIP);
}

BOOL IPNBSSDK_CtrlIPHangEx(LPTSTR strFromIP)
{
	return g_BSSocket.CtrlIPHangEx(strFromIP);
}

BOOL IPNBSSDK_CtrlIO(WORD wID, BYTE ucPort, BOOL bIsOn)
{
	return g_BSSocket.CtrlIO(wID, ucPort, bIsOn);
}

BOOL IPNBSSDK_SetServerPort(WORD wPort)
{
	return g_BSSocket.SetServerPort(wPort);
}

BOOL IPNBSSDK_SetStatePort(WORD wPort)
{
	return g_BSSocket.SetStatePort(wPort);
}

BOOL IPNBSSDK_CtrlBroadcast(WORD wFromID, BYTE *pToID, BOOL bStart)
{
	return g_BSSocket.CtrlBroadcast(wFromID, pToID, bStart);
}

BOOL IPNBSSDK_CtrlBroadcastEx(WORD wFromID, BYTE *pToID, BOOL bStart)
{
	return g_BSSocket.CtrlBroadcastEx(wFromID, pToID, bStart);
}

BOOL IPNBSSDK_CtrlBroadcastSingle(WORD wFromID, WORD wToID, BYTE ucArea, BOOL bStart)
{
	return g_BSSocket.CtrlBroadcastSingle(wFromID, wToID, ucArea, bStart);
}

BOOL IPNBSSDK_CtrlMonitor(WORD wFromID, WORD wToID, BOOL bStart)
{
	return g_BSSocket.CtrlMonitor(wFromID, wToID, bStart);
}

BOOL IPNBSSDK_CtrlQueryState(WORD wID)
{
	return g_BSSocket.CtrlQueryState(wID);
}

BOOL IPNBSSDK_CtrlQueryTermCount()
{
	return g_BSSocket.CtrlQueryTermCount();
}

BOOL IPNBSSDK_CtrlQueryIP(WORD wID)
{
	return g_BSSocket.CtrlQueryIP(wID);
}

BOOL IPNBSSDK_CtrlQueryID(LPTSTR strFromIP)
{
	return g_BSSocket.CtrlQueryID(strFromIP);
}

BOOL IPNBSSDK_CtrlFireAlarm(WORD wAlarmArea, BOOL bStart)
{
	return g_BSSocket.CtrlFireAlarm(wAlarmArea, bStart);
}

BOOL IPNBSSDK_CtrlTimerRing(WORD wNO, BOOL bStart)
{
	return g_BSSocket.CtrlTimerRing(wNO, bStart);
}

void IPNBSSDK_SetStatusCallBack(DWORD dwCallBack, DWORD dwInstance)
{
	g_BSSocket.SetStatusCallBack(dwCallBack, dwInstance);
}

BOOL IPNBSSDK_CtrlSetName(WORD wID, LPTSTR strName)
{
	return g_BSSocket.CtrlSetName(wID, strName);
}

BOOL IPNBSSDK_CtrlSetVolume(WORD wID, BYTE ucVolume)
{
	return g_BSSocket.CtrlSetVolume(wID, ucVolume);
}

BOOL IPNBSSDK_CtrlQueryPort(WORD wID, BYTE ucPort)
{
	return g_BSSocket.CtrlQueryPort(wID, ucPort);
}

BOOL IPNBSSDK_CtrlSDPlay(WORD wID, BOOL bPlay, BYTE ucFileIndex)
{
	return g_BSSocket.CtrlSDPlay(wID, bPlay, ucFileIndex);
}

BOOL IPNBSSDK_CtrlVoiceControl(WORD wID, BYTE ucCtrlIn, BYTE ucCtrlOut)
{
	return g_BSSocket.CtrlVoiceControl(wID, ucCtrlIn, ucCtrlOut);
}

void IPNBSSDK_SetIsUnicode(BOOL bIsUnicode)
{
	g_BSSocket.SetIsUnicode(bIsUnicode);
}

BOOL IPNBSSDK_CtrlCallPhone(WORD wFromID, WORD wToID, BYTE ucPanel, LPTSTR strPhone)
{
	return g_BSSocket.CtrlCallPhone(wFromID, wToID, ucPanel, strPhone);
}
