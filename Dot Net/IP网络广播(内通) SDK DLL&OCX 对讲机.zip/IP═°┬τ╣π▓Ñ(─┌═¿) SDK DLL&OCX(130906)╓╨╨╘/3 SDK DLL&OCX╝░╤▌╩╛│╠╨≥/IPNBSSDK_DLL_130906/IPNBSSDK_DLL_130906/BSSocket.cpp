/********************************************************************
	Copyright (C) 2003-2009
	created:	2009/04/09
	filename: 	E:\work\process\fourthtask\DLL\IPNBSSDK\BSSocket.cpp
	file base:	BSSocket
	file ext:	cpp
	author:		PanBasan <panbasan163@163.com>
	
	purpose:	����ӿڶ����ļ�
*********************************************************************/
// BSSocket.cpp: implementation of the CBSSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BSSocket.h"
#include "IPNBSSDK_Face.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

int ConvertUnicodeToAnsi(CHAR *obj, WCHAR *source) 
{   
	int nLength = 0;   
    
	nLength = WideCharToMultiByte(CP_ACP, 0, source, -1, NULL, 0, NULL, NULL);   
	WideCharToMultiByte(CP_ACP, 0, source, -1, obj, nLength, NULL, NULL);   
	
	return nLength;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static const IP_HEAD g_xsIPHEAD = {
	(IP_HEAD_VERSION_4 << 4) | (sizeof(IP_HEAD) / sizeof(DWORD)),
		0,
		sizeof(IP_HEAD) + sizeof(UDP_HEAD),
		htons(2009),
		0,
		64,
		IPPROTO_UDP,
		0,
		0,
		0
};

WORD CalcChkSum(WORD wInitChkSum, PBYTE pBuffer, DWORD dwLength, BOOL bAddHigh)
{
	DWORD   dwCount = (dwLength >> 1);
	PWORD   pData = (PWORD)pBuffer;
	DWORD   dwChkSum = wInitChkSum;
	
    while (dwCount-- > 0)
		dwChkSum += *pData++;
	
	if ((dwLength & 0x01) == 0x01)
		dwChkSum += *((PBYTE)pData);
	
	if (bAddHigh)
	{
		while (HIWORD(dwChkSum) != 0)
			dwChkSum = LOWORD(dwChkSum) + HIWORD(dwChkSum);
	}
	
	return LOWORD(dwChkSum);
}

CBSSocket::CBSSocket()
{
	m_bIsUnicode = FALSE;
	m_socketCtrl = INVALID_SOCKET;
	m_socketState = INVALID_SOCKET;
	m_socketMulti = INVALID_SOCKET;
	m_hParentWnd = NULL;
	m_hStateEvent = WSACreateEvent();
	m_hMultiEvent = WSACreateEvent();
	m_hThreadExitEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_wServerPort = BSSOCKET_SERVER_PORT;
	m_wStatePort = BSSOCKET_STATE_PORT;
	DWORD dwThreadID;
	m_hThread = CreateThread(NULL, 0, StateSocketThreadProc, this, 0, &dwThreadID);
	m_pCallBack = NULL;
	m_dwInstance = 0;

	//���WinSock�汾��
	int iRet = CheckWinsockVersion();
	if (iRet != 0)
	{
		TRACE1("WSAStartup() error : %d\n", iRet);
		m_bWinsockVersion = FALSE;
	}
	else
		m_bWinsockVersion = TRUE;
	
	char lpName[128];
	gethostname(lpName, sizeof(lpName));		
	HOSTENT *pHostent = gethostbyname(lpName);
	if (pHostent != NULL)
		m_addrServer.sin_addr = *(in_addr *)pHostent->h_addr_list[0];
	else
		m_addrServer.sin_addr.s_addr = htonl(INADDR_ANY);
	m_addrHost.sin_addr.s_addr = m_addrServer.sin_addr.s_addr;
	m_addrServer.sin_family = AF_INET;
	m_addrServer.sin_port = htons(m_wServerPort);

	InitSocket();
}

CBSSocket::~CBSSocket()
{
	if (m_hThreadExitEvent != NULL)
		SetEvent(m_hThreadExitEvent);
	if (m_hStateEvent != WSA_INVALID_EVENT)
	{
		WSASetEvent(m_hStateEvent);
		WSACloseEvent(m_hStateEvent);
	}
	if (m_hMultiEvent != WSA_INVALID_EVENT)
	{
		WSASetEvent(m_hMultiEvent);
		WSACloseEvent(m_hMultiEvent);
	}
	
	if (m_socketCtrl != INVALID_SOCKET)
		closesocket(m_socketCtrl);
	if (m_socketState != INVALID_SOCKET)
		closesocket(m_socketState);
	if (m_socketMulti != INVALID_SOCKET)
		closesocket(m_socketMulti);
	if (m_hThread)
		CloseHandle(m_hThread);
	WSACleanup();
}

BOOL CBSSocket::InitSocket()
{
	BOOL bSucceed;

	bSucceed = InitStateSocket();
	if (!InitCtrlSocket())
		bSucceed = FALSE;

	return bSucceed;
}

int CBSSocket::CheckWinsockVersion()
{
	WORD wVersionRequested;
	WSADATA wsaData;
	int iErr;
	
	wVersionRequested = MAKEWORD(2, 2);	//�첽I/O�Ͷ�ַ�㲥ֻ����WinSock 2.0���ϰ汾��֧�� 
	iErr = WSAStartup(wVersionRequested, &wsaData); 
	if (iErr == 0) 
	{
		if (!(LOBYTE(wsaData.wVersion) == 2) || !(HIBYTE(wsaData.wVersion) == 2)) 
		{
			WSACleanup(); 
			iErr = WSAVERNOTSUPPORTED; //ȷ��WinSock DLL֧��2.0,WinSock DLL��֧��,ʧ�ܷ���
		}
	}
	
	return iErr; 
}

BOOL CBSSocket::ConvertToAddr(LPTSTR strAddr, SOCKADDR_IN &stAddr)
{
	BOOL		bRet = TRUE;
	int			iRet;
	int			iLen = sizeof(SOCKADDR);
	
	if (m_bIsUnicode)
	{
		CHAR		pAddr[MAX_PATH];
		int			nStrLen = ConvertUnicodeToAnsi(pAddr, (WCHAR *)strAddr);
		pAddr[nStrLen] = '\0';
		iRet = WSAStringToAddress(pAddr, AF_INET, NULL, (LPSOCKADDR)&stAddr, &iLen);
	}
	else
		iRet = WSAStringToAddress(strAddr, AF_INET, NULL, (LPSOCKADDR)&stAddr, &iLen);
	if (iRet != 0)
	{
		TRACE1("WSAStringToAddress() error : %d\n", WSAGetLastError());
		bRet = FALSE;
	}
		
	return bRet;
}

BOOL CBSSocket::InitCtrlSocket()
{
	BOOL bSucceed = m_bWinsockVersion;
	BOOL bFlag;
	int iRet;
	
	if (m_socketCtrl != INVALID_SOCKET)
		closesocket(m_socketCtrl);

	//�����׽���
	if (bSucceed)
	{
		m_socketCtrl = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
		if (m_socketCtrl == INVALID_SOCKET)
		{
			TRACE1("socket() error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
	}
	
	//�����׽���Ϊ�����ö˿ڵ�ַ
	if (bSucceed)
	{
		iRet = setsockopt(m_socketCtrl, SOL_SOCKET, SO_REUSEADDR, (CHAR *)&bFlag, sizeof(bFlag));
		if (iRet == SOCKET_ERROR)
		{
			TRACE1("setsockopt() SO_REUSEADDR error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
	}
	
	//��IP���˿�
	if (bSucceed)
	{
		bFlag = TRUE;
		iRet = setsockopt(m_socketCtrl, IPPROTO_IP, IP_HDRINCL, (CHAR *)&bFlag, sizeof(bFlag));
		if (iRet == SOCKET_ERROR)
		{
			TRACE1("setsockopt(IP_HDRINCL) error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
	}

	return bSucceed;
}

BOOL CBSSocket::InitStateSocket()
{
	BOOL bSucceed = m_bWinsockVersion;
	BOOL bFlag;
	int iRet;

	if (m_socketState != INVALID_SOCKET)
		closesocket(m_socketState);
	if (m_socketMulti != INVALID_SOCKET)
		closesocket(m_socketMulti);
		
	//�����׽���
	if (bSucceed)
	{
		m_socketState = WSASocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, (LPWSAPROTOCOL_INFO)NULL, 0, \
			WSA_FLAG_OVERLAPPED | WSA_FLAG_MULTIPOINT_C_LEAF | WSA_FLAG_MULTIPOINT_D_LEAF);
		if (m_socketState == INVALID_SOCKET)
		{
			TRACE1("WSASocket() error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
	}
	
	//�����׽���Ϊ�����ö˿ڵ�ַ
	if (bSucceed)
	{
		iRet = setsockopt(m_socketState, SOL_SOCKET, SO_REUSEADDR, (CHAR *)&bFlag, sizeof(bFlag));
		if (iRet == SOCKET_ERROR)
		{
			TRACE1("setsockopt() SO_REUSEADDR error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
	}
	
	DWORD dwBytesReturned = 0;
	//���Ŀ��˿ڲ��ɵ���ʱ,socket��ϵͳ�Ͽ�����
	BOOL bNewBehavior = FALSE;
	iRet = WSAIoctl(m_socketState, SIO_UDP_CONNRESET, &bNewBehavior, sizeof(BOOL), NULL, 0, &dwBytesReturned, NULL, NULL);
	if (SOCKET_ERROR == iRet)
		TRACE1("WSAIoctl(SIO_UDP_CONNRESET) error : %d\n", WSAGetLastError());
	
	//��IP���˿�
	if (bSucceed)
	{
		SOCKADDR_IN addrState;
		addrState.sin_addr.s_addr = htonl(INADDR_ANY);
		addrState.sin_family = AF_INET;
		addrState.sin_port = htons(m_wStatePort);
		iRet = bind(m_socketState, (struct sockaddr FAR *)&addrState, sizeof(struct sockaddr)); 
		if (iRet == SOCKET_ERROR)
		{
			TRACE1("bind() error : %d\n", WSAGetLastError());
			bSucceed = FALSE;
		}
		WSAEventSelect(m_socketState, m_hStateEvent, FD_READ);
		//�����鲥��,��������
		if (m_wStatePort != BSSOCKET_MULTI_PORT)
		{
			m_socketMulti = WSASocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, (LPWSAPROTOCOL_INFO)NULL, 0, \
				WSA_FLAG_OVERLAPPED | WSA_FLAG_MULTIPOINT_C_LEAF | WSA_FLAG_MULTIPOINT_D_LEAF);
			if (m_socketMulti == INVALID_SOCKET)
				TRACE1("WSASocket() error : %d\n", WSAGetLastError());
			iRet = setsockopt(m_socketMulti, SOL_SOCKET, SO_REUSEADDR, (CHAR *)&bFlag, sizeof(bFlag));
			if (iRet == SOCKET_ERROR)
				TRACE1("setsockopt() SO_REUSEADDR error : %d\n", WSAGetLastError());
			addrState.sin_port = htons(BSSOCKET_MULTI_PORT);
			iRet = bind(m_socketMulti, (struct sockaddr FAR *)&addrState, sizeof(struct sockaddr)); 
			if (iRet == SOCKET_ERROR)
				TRACE1("bind() error : %d\n", WSAGetLastError());
			JoinLeaf(m_socketMulti, BSSOCKET_STATE_IP);
			WSAEventSelect(m_socketMulti, m_hMultiEvent, FD_READ);
		}
		else
			JoinLeaf(m_socketState, BSSOCKET_STATE_IP);
	}

	return bSucceed;
}

BOOL CBSSocket::JoinLeaf(SOCKET &socket, LPTSTR strRecvAddr)
{
	BOOL bRet = TRUE;
	SOCKADDR_IN recvAddr;

	//���뵽ָ����ַ�㲥�飬ָ��Ϊ��������������������,
	//�� IP multicast �У����ص��׽�����������������׽�����������ͬ
	SOCKET newSock;
	ConvertToAddr(strRecvAddr, recvAddr);
	newSock = WSAJoinLeaf(socket, (PSOCKADDR)&recvAddr, sizeof (SOCKADDR), 
		NULL, NULL, NULL, NULL, JL_BOTH); 
	if (newSock == INVALID_SOCKET) 
	{
		TRACE1("WSAJoinLeaf() error : %d\n", WSAGetLastError());
		bRet = FALSE;
	}
	
	return bRet;
}

BOOL CBSSocket::SetServerIP(LPTSTR strServerIP)
{
	BOOL bRet = TRUE;
	SOCKADDR_IN addrCtrl;
	
	if (ConvertToAddr(strServerIP, addrCtrl))
	{
		bRet = TRUE;
		m_addrServer = addrCtrl;
		m_addrServer.sin_family = AF_INET;
		m_addrServer.sin_port = htons(m_wServerPort);
	}
	else
		bRet = FALSE;

	return bRet;
}

DWORD WINAPI CBSSocket::StateSocketThreadProc(LPVOID lpParameter)
{
	CBSSocket				*pCBSSocket = (CBSSocket *)lpParameter;
	WSANETWORKEVENTS		networkEvents;
	BOOL					bContinue;
	WORD					pRecvData[SOCKET_NET_BUF_SIZE / sizeof (WORD)];//sizeof (DGRAMHEADER_STATUS)
	int						iRecvSize;
	LPDGRAMHEADER_STATUS	lpDgramHeader = (LPDGRAMHEADER_STATUS)pRecvData;
	WPARAM					wParam;
	LPARAM					lParam;
	HANDLE					pWaitEvent[3];
	BOOL					bExit = FALSE;

#if _DEBUG
	static int nThreadCount = 0;
	nThreadCount++;
	TRACE1("\n\nCreate StateSocketThreadProc() count : %d\n", nThreadCount);
#endif

	pWaitEvent[0] = pCBSSocket->m_hThreadExitEvent;
	pWaitEvent[2] = pCBSSocket->m_hMultiEvent;
	pWaitEvent[1] = pCBSSocket->m_hStateEvent;
	while (TRUE)
	{
		iRecvSize = 0;
		switch (::WSAWaitForMultipleEvents(3, pWaitEvent, FALSE, INFINITE, FALSE))
		{
		case WSA_WAIT_EVENT_0:		bExit = TRUE; break;
		case WSA_WAIT_EVENT_0 + 2:
			if (WSAEnumNetworkEvents(pCBSSocket->m_socketMulti, pCBSSocket->m_hMultiEvent, &networkEvents) == 0)
			{
				if (networkEvents.lNetworkEvents == FD_READ)
					iRecvSize = recv(pCBSSocket->m_socketMulti, (char *)pRecvData, SOCKET_NET_BUF_SIZE, 0);
			}
			break;
		case WSA_WAIT_EVENT_0 + 1:
			if (WSAEnumNetworkEvents(pCBSSocket->m_socketState, pCBSSocket->m_hStateEvent, &networkEvents) == 0)
			{
				if (networkEvents.lNetworkEvents == FD_READ)
					iRecvSize = recv(pCBSSocket->m_socketState, (char *)pRecvData, SOCKET_NET_BUF_SIZE, 0);
			}
			break;
		default:			break;
		}
		if (bExit)
			break;

		if (iRecvSize > 0)
		{
			bContinue = FALSE;
			wParam = 0;
			lParam = (LPARAM)lpDgramHeader;
			ZeroMemory((char *)pRecvData + iRecvSize + 1, SOCKET_NET_BUF_SIZE - iRecvSize);
			// SD������״̬,���ܺ�:0xD8
			if (lpDgramHeader->ucFunction == 0xD8)
			{
				bContinue = TRUE;
				wParam = (WPARAM)IPNBSSDK_STATE_SD_PLAY_STATE;
			}
			// ��ѯ�ն��տ�״̬,��־:0x00,0x00,���ܺ�:0xD7
			if (lpDgramHeader->ucFunction == 0xD7)
			{
				bContinue = TRUE;
				wParam = (WPARAM)IPNBSSDK_STATE_PORT_STATE;
			}
			//��ѯ�ն���Ŀ���,��־:0x00,0x00,���ܺ�:0xD6
			else if (lpDgramHeader->ucFunction == 0xD6)
			{
				bContinue = TRUE;
				wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_COUNT;
			}
			//��ѯID���,��־:0x00,0x00,���ܺ�:0xD5
			else if (lpDgramHeader->ucFunction == 0xD5)//pCBSSocket->m_sDgramHeader.wFlag == 0x00 && 
			{
				bContinue = TRUE;
				wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_ID;
			}
			//��ѯIP���,��־:0x00,0x00,���ܺ�:0xD4
			else if (lpDgramHeader->ucFunction == 0xD4)//lpDgramHeader->wFlag == 0x00 && 
			{
				bContinue = TRUE;
				wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_IP;
			}
			//����״̬���,��־:0x00,0x00,���ܺ�:0xD3
			else if (lpDgramHeader->ucFunction == 0xD3)//lpDgramHeader->wFlag == 0x00 && 
			{
				bContinue = TRUE;
				switch (lpDgramHeader->ucParam.ucParam1)
				{
				case 0x00:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_NULL;
					break;
				case 0x03:
					if (lpDgramHeader->ucParam.ucParam2 == 0x01)
						wParam = (WPARAM)IPNBSSDK_STATE_TASK_TERMER_RING_BEGIN;
					else if (lpDgramHeader->ucParam.ucParam2 == 0x00)
						wParam = (WPARAM)IPNBSSDK_STATE_TASK_TERMER_RING_END;
					break;
				case 0x07:
					if (lpDgramHeader->ucParam.ucParam2 == 0x01)
						wParam = (WPARAM)IPNBSSDK_STATE_TASK_FIRE_ALARM_BEGIN;
					else if (lpDgramHeader->ucParam.ucParam2 == 0x00)
						wParam = (WPARAM)IPNBSSDK_STATE_TASK_FIRE_ALARM_END;
					break;
				}
			}
			//�ն�״̬���,��־:0x00,0x00,���ܺ�:0xD2
			else if (lpDgramHeader->ucFunction == 0xD2)//lpDgramHeader->wFlag == 0x00 && 
			{
				bContinue = TRUE;
				switch (lpDgramHeader->ucParam.ucParam4)
				{
				case 0x00:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_NULL;
					break;
				case 0x01:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_LIVE_PLAY;
					break;
				case 0x03:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_TERMER_RING;
					break;
				case 0x04:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_TERMER_PROGRAMS;
					break;
				case 0x07:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_SERVER_FIRE_ALARM;
					break;
				}
			}
			//�ն˶Խ����,��־:0x00,0x00,���ܺ�:0xD1
			else if (lpDgramHeader->ucFunction == 0xD1)//lpDgramHeader->wFlag == 0x00 && 
			{
				bContinue = TRUE;
				switch (lpDgramHeader->ucParam.ucParam2)
				{
				case 0x00:
					wParam = (WPARAM)IPNBSSDK_STATE_DIALOG_CALL;
					break;
				case 0x01:
					if (lpDgramHeader->ucParam.ucParam5 == 0x01)
						wParam = (WPARAM)IPNBSSDK_STATE_DIALOG_BEGIN;
					else if (lpDgramHeader->ucParam.ucParam5 == 0x00)
						wParam = (WPARAM)IPNBSSDK_STATE_DIALOG_END;
					break;
				case 0x02:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_ALARM1;
					break;
				case 0x03:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_ALARM2;
					break;
				case 0x04:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_ALARM3;
					break;
				case 0x09:
				case 0x0A:
				case 0x0B:
				case 0x0C:
				case 0x0D:
				case 0x0E:
				case 0x0F:
				case 0x10:
					wParam = (WPARAM)IPNBSSDK_STATE_TERMINAL_ALARM_EX;
					break;
				}
			}
			if (bContinue)
			{
				if (pCBSSocket->m_pCallBack != NULL)
					pCBSSocket->m_pCallBack(pCBSSocket->m_dwInstance, wParam, lParam);
				else
					::PostMessage(pCBSSocket->m_hParentWnd, UM_IPNBSSDK_STATE, wParam, lParam);
			}
		}
	}
#if _DEBUG
	TRACE1("\n\nEnd StateSocketThreadProc() count : %d\n", nThreadCount);
#endif

	return 0;
}

void CBSSocket::SetParentWnd(HWND hWnd)
{
	m_hParentWnd = hWnd;
}

BOOL CBSSocket::CtrlFireAlarm(WORD wAlarmArea, BOOL bStart)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory((LPVOID)&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCA;
	dgramHeader.ucParam.ucParam1 = bStart ? 1 : 0;
	dgramHeader.ucParam.ucParam2 = BYTE(wAlarmArea & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wAlarmArea & 0xFF00) >> 8);

	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlFireAlarm() error : %d\n", WSAGetLastError());

	return bRet;
}

BOOL CBSSocket::CtrlCall(WORD wFromID, WORD wToID)
{
	return CtrlDialog(DIALOG_CALL, wFromID, wToID, 0);
}

BOOL CBSSocket::CtrlAnswer(WORD wFromID)
{
	return CtrlDialog(DIALOG_ANSWER, wFromID, 0, 0);
}

BOOL CBSSocket::CtrlHang(WORD wFromID)
{
	return CtrlDialog(DIALOG_HANG, wFromID, 0, 0);
}

BOOL CBSSocket::CtrlCallEx(WORD wFromID, WORD wToID, BYTE ucPanel)
{
	return CtrlDialog(DIALOG_CALL_EX, wFromID, wToID, ucPanel);
}

BOOL CBSSocket::CtrlAnswerEx(WORD wFromID)
{
	return CtrlDialog(DIALOG_ANSWER_EX, wFromID, 0, 0);
}

BOOL CBSSocket::CtrlHangEx(WORD wFromID)
{
	return CtrlDialog(DIALOG_HANG_EX, wFromID, 0, 0);
}

BOOL CBSSocket::CtrlIPCall(LPTSTR strFromIP, LPTSTR strToIP)
{
	return CtrlIPDialog(DIALOG_CALL, strFromIP, strToIP);
}

BOOL CBSSocket::CtrlIPAnswer(LPTSTR strFromIP)
{
	return CtrlIPDialog(DIALOG_ANSWER, strFromIP, NULL);
}

BOOL CBSSocket::CtrlIPHang(LPTSTR strFromIP)
{
	return CtrlIPDialog(DIALOG_HANG, strFromIP, NULL);
}

BOOL CBSSocket::CtrlIPCallEx(LPTSTR strFromIP, LPTSTR strToIP, BYTE ucPanel)
{
	return CtrlIPDialog(DIALOG_CALL_EX, strFromIP, strToIP, ucPanel);
}

BOOL CBSSocket::CtrlIPAnswerEx(LPTSTR strFromIP)
{
	return CtrlIPDialog(DIALOG_ANSWER_EX, strFromIP, NULL);
}

BOOL CBSSocket::CtrlIPHangEx(LPTSTR strFromIP)
{
	return CtrlIPDialog(DIALOG_HANG_EX, strFromIP, NULL);
}

BOOL CBSSocket::CtrlDialog(DIALOG_CTRL dialogCtrl, WORD wFromID, WORD wToID, BYTE ucPanel, LPTSTR strPhone)
{
	BOOL				bRet = FALSE;
	BYTE				pBuf[DGRAMHEADER_HEADER_SIZE + 60];
	DGRAMHEADER_STATUS	*pdgramHeader = (DGRAMHEADER_STATUS *)pBuf;
	BYTE				ucLen = DGRAMHEADER_HEADER_SIZE;
	
	CHAR				pPhone[MAX_PATH];
	int					nPhoneLen = 0;

	ZeroMemory(pBuf, sizeof (pBuf));
	pdgramHeader->wFlag = 0xFFFF;
	pdgramHeader->ucFunction = 0xC1;
	switch (dialogCtrl)
	{
	case DIALOG_CALL:
		pdgramHeader->ucParam.ucParam1 = 0x00;
		break;
	case DIALOG_ANSWER:
		pdgramHeader->ucParam.ucParam1 = 0x01;
		break;
	case DIALOG_HANG:
		pdgramHeader->ucParam.ucParam1 = 0x02;
		break;
	case DIALOG_CALL_EX:
		pdgramHeader->ucParam.ucParam1 = 0x03;
		ucLen = DGRAMHEADER_HEADER_SIZE + 1;
		pBuf[DGRAMHEADER_HEADER_SIZE] = ucPanel;
		break;
	case DIALOG_CALL_PHONE:
		if (m_bIsUnicode)
			nPhoneLen = ConvertUnicodeToAnsi(pPhone, (WCHAR *)strPhone);
		else
		{
			strcpy(pPhone, strPhone);
			nPhoneLen = strlen(strPhone);
		}
		nPhoneLen = max(45, nPhoneLen);
		pPhone[nPhoneLen] = '\0';

		pdgramHeader->ucParam.ucParam1 = 0x03;
		ucLen = DGRAMHEADER_HEADER_SIZE + 60;
		pBuf[DGRAMHEADER_HEADER_SIZE] = ucPanel;
		strcpy((CHAR *)&pBuf[DGRAMHEADER_HEADER_SIZE + 14], pPhone);
		*((WORD*)&pBuf[DGRAMHEADER_HEADER_SIZE + 10]) = 0xD1A1;
		*((WORD*)&pBuf[DGRAMHEADER_HEADER_SIZE + 12]) = CalcChkSum(0, &pBuf[DGRAMHEADER_HEADER_SIZE + 14], 46, TRUE);
		break;
	case DIALOG_ANSWER_EX:
		pdgramHeader->ucParam.ucParam1 = 0x04;
		ucLen = DGRAMHEADER_HEADER_SIZE + 1;
		break;
	case DIALOG_HANG_EX:
		pdgramHeader->ucParam.ucParam1 = 0x05;
		ucLen = DGRAMHEADER_HEADER_SIZE + 1;
		break;
	}
	pdgramHeader->ucParam.ucParam2 = BYTE(wFromID & 0xFF);
	pdgramHeader->ucParam.ucParam3 = BYTE((wFromID & 0xFF00) >> 8);
	pdgramHeader->ucParam.ucParam4 = BYTE(wToID & 0xFF);
	pdgramHeader->ucParam.ucParam5 = BYTE((wToID & 0xFF00) >> 8);
	
	if (SendTo((char *)pBuf, ucLen))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlDialog() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlIPDialog(DIALOG_CTRL dialogCtrl, LPTSTR strFromIP, LPTSTR strToIP, BYTE ucPanel/* = 0*/)
{

	BOOL				bRet = FALSE;
	SOCKADDR_IN			addrFrom, addrTo;
	BYTE				pBuf[DGRAMHEADER_HEADER_SIZE + 5];
	DGRAMHEADER_STATUS	*pdgramHeader = (DGRAMHEADER_STATUS *)pBuf;
	PDWORD				pIPParam = (PDWORD)&pdgramHeader->ucParam.ucParam2;
	BOOL				bIPError = FALSE;
	
	ZeroMemory(pBuf, DGRAMHEADER_HEADER_SIZE + 5);
	pdgramHeader->wFlag = 0xFFFF;
	pdgramHeader->ucFunction = 0xC8;
	switch (dialogCtrl)
	{
	case DIALOG_CALL:
		pdgramHeader->ucParam.ucParam1 = 0x00;
		break;
	case DIALOG_ANSWER:
		pdgramHeader->ucParam.ucParam1 = 0x01;
		break;
	case DIALOG_HANG:
		pdgramHeader->ucParam.ucParam1 = 0x02;
		break;
	case DIALOG_CALL_EX:
		pdgramHeader->ucParam.ucParam1 = 0x03;
		pBuf[DGRAMHEADER_HEADER_SIZE + 4] = ucPanel;
		break;
	case DIALOG_ANSWER_EX:
		pdgramHeader->ucParam.ucParam1 = 0x04;
		break;
	case DIALOG_HANG_EX:
		pdgramHeader->ucParam.ucParam1 = 0x05;
		break;
	}
	
	if (ConvertToAddr(strFromIP, addrFrom))
	{
		*pIPParam++ = addrFrom.sin_addr.s_addr;
		if (dialogCtrl == DIALOG_CALL || dialogCtrl == DIALOG_CALL_EX)
		{
			bIPError = !ConvertToAddr(strToIP, addrTo);
			*pIPParam++ = addrTo.sin_addr.s_addr;
		}
		if (!bIPError && SendTo((char *)pBuf, DGRAMHEADER_HEADER_SIZE + 5))
			bRet = TRUE;
		else
			TRACE1("CtrlIPDialog() error : %d\n", WSAGetLastError());
	}
	
	return bRet;
}

BOOL CBSSocket::CtrlIO(WORD wID, BYTE ucPort, BOOL bIsOn)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xC2;
	dgramHeader.ucParam.ucParam2 = wID & 0xFF;
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	dgramHeader.ucParam.ucParam4 = ucPort;
	dgramHeader.ucParam.ucParam5 = bIsOn ? 1 : 0;
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlIO() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::SetServerPort(WORD wPort)
{
	m_wServerPort = wPort;
	m_addrServer.sin_port = htons(m_wServerPort);
	return TRUE;
}

BOOL CBSSocket::SetStatePort(WORD wPort)
{
	m_wStatePort = wPort;
	return InitSocket();
}

BOOL CBSSocket::CtrlBroadcast(WORD wFromID, BYTE *pToID, BOOL bStart)
{
	BOOL bRet = FALSE;
	int nDataSize = DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN;
	DGRAMHEADER_STATUS DgramHeader;
	
	ZeroMemory((char *)&DgramHeader, sizeof (DGRAMHEADER_STATUS));
	DgramHeader.wFlag = 0xFFFF;
	DgramHeader.ucFunction = 0xC3;
	DgramHeader.ucParam.ucParam1 = bStart ? 0x01 : 0x00;
	DgramHeader.ucParam.ucParam2 = BYTE(wFromID & 0xFF);
	DgramHeader.ucParam.ucParam3 = BYTE((wFromID & 0xFF00) >> 8);
	memcpy(DgramHeader.ucAttachData1, pToID, BROADCAST_TO_ID_LEN);
	
	if (SendTo((char *)&DgramHeader, nDataSize))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == nDataSize
		bRet = TRUE;
	else
		TRACE1("CtrlBroadcast() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlMonitor(WORD wFromID, WORD wToID, BOOL bStart)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xC4;
	dgramHeader.ucParam.ucParam1 = bStart ? 1 : 0;
	dgramHeader.ucParam.ucParam2 = BYTE(wFromID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wFromID & 0xFF00) >> 8);
	dgramHeader.ucParam.ucParam4 = BYTE(wToID & 0xFF);
	dgramHeader.ucParam.ucParam5 = BYTE((wToID & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlMointor() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlQueryState(WORD wID)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xC5;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlQueryState() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlTimerRing(WORD wNO, BOOL bStart)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory((LPVOID)&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCB;
	dgramHeader.ucParam.ucParam1 = bStart ? 1 : 0;
	dgramHeader.ucParam.ucParam2 = BYTE(wNO & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wNO & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlTimerRang() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlQueryIP(WORD wID)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xC6;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//		(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
		bRet = TRUE;
	else
		TRACE1("CtrlQueryIP() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlQueryID(LPTSTR strTermIP)
{
	BOOL bRet = FALSE;
	DGRAMHEADER_STATUS dgramHeader;
	SOCKADDR_IN addrCtrl;
	
	if (ConvertToAddr(strTermIP, addrCtrl))
	{
		ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
		dgramHeader.wFlag = 0xFFFF;
		dgramHeader.ucFunction = 0xC7;
		
		dgramHeader.ucParam.ucParam5 = addrCtrl.sin_addr.s_impno;
		dgramHeader.ucParam.ucParam4 = addrCtrl.sin_addr.s_lh;
		dgramHeader.ucParam.ucParam3 = addrCtrl.sin_addr.s_host;
		dgramHeader.ucParam.ucParam2 = addrCtrl.sin_addr.s_net;
		
		if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))//, 0, m_socketCtrl, 
//			(struct sockaddr *)&m_addrServer, sizeof(struct sockaddr))) == DGRAMHEADER_HEADER_SIZE
			bRet = TRUE;
		else
			TRACE1("CtrlQueryID() error : %d\n", WSAGetLastError());
	}
	
	return bRet;
}

BOOL CBSSocket::SendTo(char *lpBuf, int nBufLen)
{
	int				nBytesSend = 0;
	PIP_HEAD		pIPHead = NULL;
	PUDP_HEAD		pUDPHead = NULL;
	PSEUDO_HDR		xsPseudoHdr;
	WSABUF			wbItem;
	int				nRet = SOCKET_ERROR;
	DWORD			dwBytesSend;
		
	nBytesSend = SOCKET_NET_BUF_SIZE - sizeof (IP_HEAD) - sizeof (UDP_HEAD);
	nBufLen = nBufLen > nBytesSend ? nBytesSend : nBufLen;
	nBytesSend = nBufLen + sizeof (IP_HEAD) + sizeof (UDP_HEAD);
	nBytesSend = nBytesSend < DGRAMHEADER_MIN_SIZE ? DGRAMHEADER_MIN_SIZE : nBytesSend;
	ZeroMemory(m_pSendBuf, nBytesSend); 
	memcpy(m_pSendBuf + sizeof (IP_HEAD) + sizeof (UDP_HEAD), lpBuf, nBufLen);
	pIPHead = (PIP_HEAD)m_pSendBuf;
	pUDPHead = (PUDP_HEAD)(m_pSendBuf + sizeof (IP_HEAD));
	pUDPHead->SrcPort = htons(m_wStatePort);
	pUDPHead->DstPort = htons(m_wServerPort);
	pUDPHead->DataLen = htons(nBytesSend - sizeof (IP_HEAD));
	pUDPHead->Chksum = 0;
	
	xsPseudoHdr.wLength = pUDPHead->DataLen;
	xsPseudoHdr.ipSource = m_addrHost.sin_addr.s_addr;
	xsPseudoHdr.ipTarget = m_addrServer.sin_addr.s_addr;
	xsPseudoHdr.ucProtocol = IPPROTO_UDP;
	xsPseudoHdr.ucZero = 0;
	pUDPHead->Chksum = CalcChkSum(0, (PBYTE)pUDPHead, nBufLen + sizeof (UDP_HEAD), TRUE);
	pUDPHead->Chksum = ~CalcChkSum(pUDPHead->Chksum, (PBYTE)&xsPseudoHdr, sizeof(PSEUDO_HDR), TRUE);
	if (pUDPHead->Chksum == 0)
		pUDPHead->Chksum = 0xFFFF;
	
	memcpy(pIPHead, (PVOID)&g_xsIPHEAD, sizeof (IP_HEAD));
	pIPHead->TotalLen = htons(nBytesSend);
	pIPHead->SrcAddr = m_addrHost.sin_addr.s_addr;
	pIPHead->DstAddr = m_addrServer.sin_addr.s_addr;
	pIPHead->HdrChksum = ~CalcChkSum(0, (PBYTE)pIPHead, sizeof(IP_HEAD), TRUE);
	
	wbItem.buf = (char *)m_pSendBuf;
	wbItem.len = nBytesSend;
	nRet = ::WSASendTo(m_socketCtrl, &wbItem, 1, &dwBytesSend, 0, (struct sockaddr *)&m_addrServer, \
		sizeof(struct sockaddr), NULL, NULL);
	if (nRet == SOCKET_ERROR)
		TRACE1("\nCVTSocket::WSASendTo(...) error : %d", ::WSAGetLastError());
	
	return (nRet != SOCKET_ERROR);
}

void CBSSocket::SetStatusCallBack(IN DWORD_PTR dwCallback, DWORD dwInstance)
{
	m_pCallBack = (PSTATUSCALLBACK)dwCallback;
	m_dwInstance = dwInstance;
}

BOOL CBSSocket::CtrlQueryTermCount()
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCC;
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))
		bRet = TRUE;
	else
		TRACE1("CtrlQueryTermCount() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlSetName(WORD wID, LPTSTR strName)
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, sizeof (DGRAMHEADER_STATUS));
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCF;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	
	CHAR		pName[MAX_PATH];
	int			nStrLen = 0;
	if (m_bIsUnicode)
		nStrLen = ConvertUnicodeToAnsi(pName, (WCHAR *)strName);
	else
	{
		strcpy(pName, strName);
		nStrLen = strlen(strName);
	}
	nStrLen = max(49, nStrLen);
	pName[nStrLen] = '\0';
	strcpy((char *)&dgramHeader.ucAttachData1[0], pName);

	if (SendTo((char *)&dgramHeader, sizeof (DGRAMHEADER_STATUS)))
		bRet = TRUE;
	else
		TRACE1("CtrlSetName() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlSetVolume(WORD wID, BYTE ucVolume)
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCE;
	dgramHeader.ucParam.ucParam1 = min(ucVolume, 15);
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))
		bRet = TRUE;
	else
		TRACE1("CtrlSetVolume() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlQueryPort(WORD wID, BYTE ucPort)
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xCD;
	dgramHeader.ucParam.ucParam1 = ucPort;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))
		bRet = TRUE;
	else
		TRACE1("CtrlSetVolume() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlSDPlay(WORD wID, BOOL bPlay, BYTE ucFileIndex)
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xF1;
	dgramHeader.ucParam.ucParam1 = bPlay ? 1 : 0;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	dgramHeader.ucParam.ucParam4 = ucFileIndex;
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))
		bRet = TRUE;
	else
		TRACE1("CtrlSDPlay() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlVoiceControl(WORD wID, BYTE ucCtrlIn, BYTE ucCtrlOut)
{
	BOOL				bRet = FALSE;
	DGRAMHEADER_STATUS	dgramHeader;
	
	ZeroMemory(&dgramHeader, DGRAMHEADER_HEADER_SIZE);
	dgramHeader.wFlag = 0xFFFF;
	dgramHeader.ucFunction = 0xC9;
	dgramHeader.ucParam.ucParam2 = BYTE(wID & 0xFF);
	dgramHeader.ucParam.ucParam3 = BYTE((wID & 0xFF00) >> 8);
	dgramHeader.ucParam.ucParam4 = ucCtrlIn;
	dgramHeader.ucParam.ucParam5 = ucCtrlOut;
	
	if (SendTo((char *)&dgramHeader, DGRAMHEADER_HEADER_SIZE))
		bRet = TRUE;
	else
		TRACE1("CtrlVoiceControl() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlBroadcastEx(WORD wFromID, BYTE *pToID, BOOL bStart)
{
	BOOL		bRet = FALSE;
	int			nDataSize = DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN_EX;
	BYTE		pBuf[DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN_EX];
	DGRAMHEADER_STATUS	*pDgramHeader = (DGRAMHEADER_STATUS *)pBuf;
	
	ZeroMemory((char *)pBuf, DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN_EX);
	pDgramHeader->wFlag = 0xFFFF;
	pDgramHeader->ucFunction = 0xC3;
	pDgramHeader->ucParam.ucParam1 = bStart ? 0x03 : 0x02;
	pDgramHeader->ucParam.ucParam2 = BYTE(wFromID & 0xFF);
	pDgramHeader->ucParam.ucParam3 = BYTE((wFromID & 0xFF00) >> 8);
	memcpy(pDgramHeader->ucAttachData1, pToID, BROADCAST_TO_ID_LEN_EX);
	
	if (SendTo((char *)&pBuf, nDataSize))
		bRet = TRUE;
	else
		TRACE1("CtrlBroadcastEx() error : %d\n", WSAGetLastError());
	
	return bRet;
}

BOOL CBSSocket::CtrlBroadcastSingle(WORD wFromID, WORD wToID, BYTE ucArea, BOOL bStart)
{
	BOOL		bRet = FALSE;
	int			nDataSize = DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN;
	BYTE		pBuf[DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN];
	DGRAMHEADER_STATUS	*pDgramHeader = (DGRAMHEADER_STATUS *)pBuf;
	
	ZeroMemory((char *)pBuf, DGRAMHEADER_HEADER_SIZE + BROADCAST_TO_ID_LEN);
	pDgramHeader->wFlag = 0xFFFF;
	pDgramHeader->ucFunction = 0xC3;
	pDgramHeader->ucParam.ucParam1 = bStart ? 0x05 : 0x04;
	pDgramHeader->ucParam.ucParam2 = BYTE(wFromID & 0xFF);
	pDgramHeader->ucParam.ucParam3 = BYTE((wFromID & 0xFF00) >> 8);
	*((WORD *)(pBuf + DGRAMHEADER_HEADER_SIZE)) = wToID;
	*((BYTE *)(pBuf + DGRAMHEADER_HEADER_SIZE + 2)) = ucArea;
	
	if (SendTo((char *)&pBuf, nDataSize))
		bRet = TRUE;
	else
		TRACE1("CtrlBroadcastSingle() error : %d\n", WSAGetLastError());
	
	return bRet;
}

void CBSSocket::SetIsUnicode(BOOL bIsUnicode)
{
	m_bIsUnicode = bIsUnicode;
}

BOOL CBSSocket::CtrlCallPhone(WORD wFromID, WORD wToID, BYTE ucPanel, LPTSTR strPhone)
{
	return CtrlDialog(DIALOG_CALL_PHONE, wFromID, wToID, ucPanel, strPhone);
}
