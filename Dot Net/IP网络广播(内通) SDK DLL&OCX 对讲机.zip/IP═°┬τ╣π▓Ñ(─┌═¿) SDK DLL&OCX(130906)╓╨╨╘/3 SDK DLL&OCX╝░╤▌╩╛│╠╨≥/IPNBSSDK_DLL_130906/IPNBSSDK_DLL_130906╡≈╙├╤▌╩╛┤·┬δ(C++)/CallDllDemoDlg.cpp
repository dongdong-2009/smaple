// CallDllDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CallDllDemo.h"
#include "CallDllDemoDlg.h"
#include "define.h"

#include "IPNBSSDK_Face.h"
#pragma comment (lib, "IPNBSSDK.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CREATE_FILE_INFO_HEADER_SIZE		32
typedef struct tagCREATE_FILE_INFO	// �����ļ����͸���Ƶ��������Ϣ
{
	WORD		wTermID;
	WORD		wYear;
	WORD		wMonth;
	WORD		wDay;
	WORD		wHour;
	WORD		wMinute;
	WORD		wSecond;
	BYTE		pucReserve[18];		// ����
	CHAR		pchFilePath[1];		// ¼���ļ�����·��(���Ǹ��ַ���,������)
} CREATE_FILE_INFO, *PCREATE_FILE_INFO;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCallDllDemoDlg dialog

CCallDllDemoDlg::CCallDllDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCallDllDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCallDllDemoDlg)
	m_strServerIP = _T("192.168.0.10");
	m_nServerPort = BSSOCKET_SERVER_PORT;
	m_wIOID = 2;
	m_ucIOPort = 1;
	m_nStatePort = BSSOCKET_STATE_PORT;
	m_wBCFromID = 1;
	m_strBCToID = _T("2,3,4");
	m_wMonitorFromID = 1;
	m_wMonitorToID = 2;
	m_strOutput = _T("");
	m_wAlarmArea = 1;
	m_wQueryStateID = 1;
	m_wTimerRingID = 2;
	m_strQueryIDSrcIP = _T("192.168.0.11");
	m_wQueryIPSrcID = 1;
	m_wSetNameID = 1;
	m_strSetName = _T("�ն�1");
	m_wSetVolumeID = 1;
	m_ucSetVolume = 12;
	m_wQueryPortID = 1;
	m_wQueryPort = 1;
	m_nQueryPortIn = 1;
	m_wSDFileIndex = 1;
	m_wSDID = 2;
	m_ucDialogToPanelPanel = 2;
	m_wDialogFromID = 1;
	m_wDialogToID = 2;
	m_wDialogToPanelFromID = 1;
	m_wDialogToPanelToID = 2;
	m_bCallPhone = FALSE;
	m_strPhone = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCallDllDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCallDllDemoDlg)
	DDX_Control(pDX, IDC_EDIT_OUTPUT, m_editOutput);
	DDX_Text(pDX, IDC_EDIT_SERVER_IP, m_strServerIP);
	DDX_Text(pDX, IDC_EDIT_SERVER_PORT, m_nServerPort);
	DDV_MinMaxUInt(pDX, m_nServerPort, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_IO_ID, m_wIOID);
	DDV_MinMaxUInt(pDX, m_wIOID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_IO_PORT, m_ucIOPort);
	DDV_MinMaxByte(pDX, m_ucIOPort, 1, 16);
	DDX_Text(pDX, IDC_EDIT_STATE_PORT, m_nStatePort);
	DDV_MinMaxUInt(pDX, m_nStatePort, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_BC_FROM_ID, m_wBCFromID);
	DDV_MinMaxUInt(pDX, m_wBCFromID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_BC_TO_ID, m_strBCToID);
	DDX_Text(pDX, IDC_EDIT_MINITOR_FROM_ID, m_wMonitorFromID);
	DDV_MinMaxUInt(pDX, m_wMonitorFromID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_MINITOR_TO_ID, m_wMonitorToID);
	DDV_MinMaxUInt(pDX, m_wMonitorToID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_OUTPUT, m_strOutput);
	DDX_Text(pDX, IDC_EDIT_ALARM, m_wAlarmArea);
	DDV_MinMaxUInt(pDX, m_wAlarmArea, 1, 1000);
	DDX_Text(pDX, IDC_EDIT_QUERY_STATE, m_wQueryStateID);
	DDV_MinMaxUInt(pDX, m_wQueryStateID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_TERMER_RING, m_wTimerRingID);
	DDV_MinMaxUInt(pDX, m_wTimerRingID, 1, 1000);
	DDX_Text(pDX, IDC_EDIT_QUERY_ID, m_strQueryIDSrcIP);
	DDX_Text(pDX, IDC_EDIT_QUERY_IP, m_wQueryIPSrcID);
	DDV_MinMaxUInt(pDX, m_wQueryIPSrcID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_SET_NAME_ID, m_wSetNameID);
	DDV_MinMaxUInt(pDX, m_wSetNameID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_SET_NAME_NAME, m_strSetName);
	DDV_MaxChars(pDX, m_strSetName, 49);
	DDX_Text(pDX, IDC_EDIT_SET_VOLUME_ID, m_wSetVolumeID);
	DDV_MinMaxUInt(pDX, m_wSetVolumeID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_SET_VOLUME_VOLUME, m_ucSetVolume);
	DDV_MinMaxByte(pDX, m_ucSetVolume, 0, 15);
	DDX_Text(pDX, IDC_EDIT_QUERY_PORT_ID, m_wQueryPortID);
	DDV_MinMaxUInt(pDX, m_wQueryPortID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_QUERY_PORT_PORT, m_wQueryPort);
	DDV_MinMaxUInt(pDX, m_wQueryPort, 1, 255);
	DDX_Radio(pDX, IDC_RADIO_QUERY_PORT_IN, m_nQueryPortIn);
	DDX_Text(pDX, IDC_EDIT_SD_FILE_INDEX, m_wSDFileIndex);
	DDV_MinMaxUInt(pDX, m_wSDFileIndex, 1, 255);
	DDX_Text(pDX, IDC_EDIT_SD_ID, m_wSDID);
	DDV_MinMaxUInt(pDX, m_wSDID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_DIALOG_TO_PANEL_PANEL, m_ucDialogToPanelPanel);
	DDV_MinMaxByte(pDX, m_ucDialogToPanelPanel, 0, 16);
	DDX_Text(pDX, IDC_EDIT_DIALOG_FROM_ID, m_wDialogFromID);
	DDV_MinMaxUInt(pDX, m_wDialogFromID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_DIALOG_TO_ID, m_wDialogToID);
	DDV_MinMaxUInt(pDX, m_wDialogToID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_DIALOG_TO_PANEL_FROM_ID, m_wDialogToPanelFromID);
	DDV_MinMaxUInt(pDX, m_wDialogToPanelFromID, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_DIALOG_TO_PANEL_TO_ID, m_wDialogToPanelToID);
	DDV_MinMaxUInt(pDX, m_wDialogToPanelToID, 1, 65535);
	DDX_Check(pDX, IDC_CHECK_CALL_PHONE, m_bCallPhone);
	DDX_Text(pDX, IDC_EDIT_DIALOG_TO_PANEL_PHONE, m_strPhone);
	DDV_MaxChars(pDX, m_strPhone, 45);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCallDllDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CCallDllDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_START_ALARM, OnBtnStartAlarm)
	ON_BN_CLICKED(IDC_BTN_END_ALARM, OnBtnEndAlarm)
	ON_BN_CLICKED(IDC_BTN_CALL, OnBtnCall)
	ON_BN_CLICKED(IDC_BTN_ANSWER, OnBtnAnswer)
	ON_BN_CLICKED(IDC_BTN_HANG, OnBtnHang)
	ON_BN_CLICKED(IDC_BTN_IO_ON, OnBtnIoOn)
	ON_BN_CLICKED(IDC_BTN_IO_OFF, OnBtnIoOff)
	ON_BN_CLICKED(IDC_BTN_BC_START, OnBtnBcStart)
	ON_BN_CLICKED(IDC_BTN_BC_END, OnBtnBcEnd)
	ON_BN_CLICKED(IDC_BTN_MINITOR_START, OnBtnMinitorStart)
	ON_BN_CLICKED(IDC_BTN_MINITOR_END, OnBtnMinitorEnd)
	ON_BN_CLICKED(IDC_BTN_QUERY_STATE, OnBtnQueryState)
	ON_BN_CLICKED(IDC_BTN_START_RING, OnBtnStartRing)
	ON_BN_CLICKED(IDC_BTN_END_RING, OnBtnEndRing)
	ON_BN_CLICKED(IDC_BTN_QUERY_IP, OnBtnQueryIP)
	ON_BN_CLICKED(IDC_BTN_QUERY_ID, OnBtnQueryID)
	ON_BN_CLICKED(IDC_BTN_DIALOG_TO_PANEL_ANSWER, OnBtnDialogToPanelAnswer)
	ON_BN_CLICKED(IDC_BTN_DIALOG_TO_PANEL_HANG, OnBtnDialogToPanelHang)
	ON_BN_CLICKED(IDC_BTN_DIALOG_TO_PANEL_CALL, OnBtnDialogToPanelCall)
	ON_BN_CLICKED(IDC_BTN_QUERY_TERM_COUNT, OnBtnQueryTermCount)
	ON_BN_CLICKED(IDC_BTN_SET_NAME, OnBtnSetName)
	ON_BN_CLICKED(IDC_BTN_SET_VOLUME, OnBtnSetVolume)
	ON_BN_CLICKED(IDC_BTN_QUERY_PORT, OnBtnQueryPort)
	ON_BN_CLICKED(IDC_BTN_CLEAR_STATUS, OnBtnClearStatus)
	ON_BN_CLICKED(IDC_BTN_SET, OnBtnSet)
	ON_BN_CLICKED(IDC_BTN_SD_PLAY, OnBtnSdPlay)
	ON_BN_CLICKED(IDC_BTN_SD_STOP, OnBtnSdStop)
	//}}AFX_MSG_MAP
#ifdef TERM_8AREA_TEST
	ON_BN_CLICKED(IDC_BTN_8AREA_START, OnBtn8areaStart)
	ON_BN_CLICKED(IDC_BTN_8AREA_END, OnBtn8areaEnd)
#endif
	ON_MESSAGE(UM_IPNBSSDK_STATE, OnRecvStatus)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCallDllDemoDlg message handlers

BOOL CCallDllDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
//	IPNBSSDK_SetParentWnd(m_hWnd);				// ��Ϣ��ʽ����״̬(δ���ûص���������Ч)
	IPNBSSDK_SetStatusCallBack((DWORD)OnStatusCallBack, (DWORD)this);	// �ص�������ʽ����״̬

	char lpName[128];
	gethostname(lpName, sizeof(lpName));		
	HOSTENT *pHostent = gethostbyname(lpName);
	if (pHostent != NULL)
		m_strServerIP = inet_ntoa(*(in_addr *)pHostent->h_addr_list[0]);
	else
		m_strServerIP = _T("192.168.0.10");
	UpdateData(FALSE);

#ifdef TERM_8AREA_TEST
	GetDlgItem(IDC_EDIT_8AREA_FROM_ID)->SetWindowText(_T("1"));
	GetDlgItem(IDC_EDIT_8AREA_TO_ID)->SetWindowText(_T("2"));
	GetDlgItem(IDC_EDIT_8AREA_AREA)->SetWindowText(_T("7"));
#endif
		
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCallDllDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCallDllDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCallDllDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCallDllDemoDlg::OnRecvStatus(WPARAM wParam, LPARAM lParam)
{
	IPNBSSDK_STATE			state = (IPNBSSDK_STATE)wParam;
	LPDGRAMHEADER_STATUS	lpDgramHeader = (LPDGRAMHEADER_STATUS)lParam;
	CString					strState, strTemp;
	WORD					wDialogFromID = 0,
							wDialogToID = 0,
							wTermFromID = lpDgramHeader->ucParam.ucParam1 | (lpDgramHeader->ucParam.ucParam2 << 8),
							wTaskNo = lpDgramHeader->ucParam.ucParam3 | (lpDgramHeader->ucParam.ucParam4 << 8);

	if (lpDgramHeader->ucFunction == 0xD1)
	{
		// V2.2(2011-5-9)֮ǰ�ķ������汾
//		wDialogFromID = lpDgramHeader->ucParam.ucParam3;
//		wDialogToID = lpDgramHeader->ucParam.ucParam4;

		// V2.2(2011-5-9)��֮��ķ������汾
		PBYTE		pID = &lpDgramHeader->ucAttachData2[49] + 1;
		wDialogFromID = pID[0] | (pID[1] << 8);
		wDialogToID = pID[2] | (pID[3] << 8);
	}

	switch (state)
	{
	case IPNBSSDK_STATE_TERMINAL_NULL:
		strState.Format(_T("�ն�%d ����"), wTermFromID);
		if (lpDgramHeader->ucParam.ucParam3 == 0)
			strState += _T(" δ��¼\r\n");
		else
			strState += _T(" ��¼\r\n");
		break;
	case IPNBSSDK_STATE_TERMINAL_LIVE_PLAY:
		strState.Format(_T("�ն�%d ʵʱ�ɲ�\r\n"), wTermFromID);
		break;
	case IPNBSSDK_STATE_TERMINAL_TERMER_RING:
		strState.Format(_T("�ն�%d ��ʱ����\r\n"), wTermFromID);
		break;
	case IPNBSSDK_STATE_TERMINAL_TERMER_PROGRAMS:
		strState.Format(_T("�ն�%d ��ʱ��Ŀ\r\n"), wTermFromID);
		break;
	case IPNBSSDK_STATE_TERMINAL_SERVER_FIRE_ALARM:
		strState.Format(_T("�ն�%d ��������������\r\n"), wTermFromID);
		break;
	case IPNBSSDK_STATE_DIALOG_CALL:
		strState.Format(_T("�ն�%d(������%d) ���� �ն�%d\r\n"), wDialogFromID, lpDgramHeader->ucParam.ucParam5 + 1, wDialogToID);
		break;
	case IPNBSSDK_STATE_DIALOG_BEGIN:
		strState.Format(_T("�ն�%d �� �ն�%d ��ʼ�Խ�\r\n"), wDialogFromID, wDialogToID);
		break;
	case IPNBSSDK_STATE_DIALOG_END:
		strState.Format(_T("�ն�%d �� �ն�%d ֹͣ�Խ�\r\n"), wDialogFromID, wDialogToID);
		break;
	case IPNBSSDK_STATE_TERMINAL_ALARM1:
		strState.Format(_T("�ն�%d �˿�1����\r\n"), wDialogFromID);
		break;
	case IPNBSSDK_STATE_TERMINAL_ALARM2:
		strState.Format(_T("�ն�%d �˿�2����\r\n"), wDialogFromID);
		break;
	case IPNBSSDK_STATE_TERMINAL_ALARM_EX:
		strState.Format(_T("�ն�%d ��չ�˿�%d����\r\n"), wDialogFromID, lpDgramHeader->ucParam.ucParam3);
		break;
	case IPNBSSDK_STATE_TASK_NULL:
		strState.Format(_T("%d������ : ���� \r\n"), wTaskNo);
		break;
	case IPNBSSDK_STATE_TASK_TERMER_RING_BEGIN:
		strState.Format(_T("%d������ : ��ʱ���� : ִ�� \r\n"), wTaskNo);
		break;
	case IPNBSSDK_STATE_TASK_TERMER_RING_END:
		strState.Format(_T("%d������ : ��ʱ���� : ֹͣ \r\n"), wTaskNo);
		break;
	case IPNBSSDK_STATE_TASK_FIRE_ALARM_BEGIN:
		strState.Format(_T("%d������ : �������� : ִ�� \r\n"), wTaskNo);
		break;
	case IPNBSSDK_STATE_TASK_FIRE_ALARM_END:
		strState.Format(_T("%d������ : �������� : ֹͣ \r\n"), wTaskNo);
		break;
	case IPNBSSDK_STATE_TERMINAL_IP:
		if (lpDgramHeader->ucParam.ucParam1 == 0)
			strState.Format(_T("��ѯIP��� : ʧ�� \r\n"));
		else
			strState.Format(_T("��ѯIP��� : �ɹ� %d.%d.%d.%d \r\n"), lpDgramHeader->ucParam.ucParam2, \
							lpDgramHeader->ucParam.ucParam3, lpDgramHeader->ucParam.ucParam4, lpDgramHeader->ucParam.ucParam5);
		break;
	case IPNBSSDK_STATE_TERMINAL_ID:
		if (lpDgramHeader->ucParam.ucParam1 == 0)
			strState.Format(_T("��ѯID��� : ʧ�� \r\n"));
		else
			strState.Format(_T("��ѯID��� : �ɹ� %d \r\n"), \
				lpDgramHeader->ucParam.ucParam2 | (lpDgramHeader->ucParam.ucParam3 << 8));
		break;
	case IPNBSSDK_STATE_TERMINAL_COUNT:
		strState.Format(_T("��ѯ�ն�������� : %d\r\n"), \
				lpDgramHeader->ucParam.ucParam2 | (lpDgramHeader->ucParam.ucParam3 << 8));
		break;
	case IPNBSSDK_STATE_PORT_STATE:
		if (lpDgramHeader->ucParam.ucParam1 == 0x7E)
		{
			strState.Format(_T("�ն� %d ��������\r\n"), \
				lpDgramHeader->ucParam.ucParam2 | (lpDgramHeader->ucParam.ucParam3 << 8));
		}
		else
		{
			strState.Format(_T("��ѯ�ն� %d %s�˿� %d ״̬ : %s\r\n"), \
				lpDgramHeader->ucParam.ucParam2 | (lpDgramHeader->ucParam.ucParam3 << 8), \
				(lpDgramHeader->ucParam.ucParam1 & 0x80) == 0 ? _T("����") : _T("���"), \
				lpDgramHeader->ucParam.ucParam1 & 0x7F, \
				lpDgramHeader->ucParam.ucParam4 == 0 ? _T("�Ͽ�") : _T("�պ�"));
		}
		break;
	case IPNBSSDK_STATE_SD_PLAY_STATE:
		strState.Format(_T("�ն� %d SD��%s\r\n"), \
			lpDgramHeader->ucParam.ucParam2 | (lpDgramHeader->ucParam.ucParam3 << 8), \
			lpDgramHeader->ucParam.ucParam1 == 0 ? _T("ֹͣ") : _T("����"));
		break;
	}
	if (lpDgramHeader->ucFunction == 0xD2 && lpDgramHeader->ucAttachData1[0] != '\0')
	{
		strTemp.Format(_T("�ն����� : %s\r\n"), &lpDgramHeader->ucAttachData1[0]);
		strState += strTemp;
		strTemp.Format(_T("IP��ַ : %d.%d.%d.%d\r\n"), lpDgramHeader->ucAttachData2[0], \
			lpDgramHeader->ucAttachData2[1], lpDgramHeader->ucAttachData2[2], lpDgramHeader->ucAttachData2[3]);
		strState += strTemp;
		strTemp.Format(_T("���� : %d\r\n"), lpDgramHeader->ucAttachData2[4]);
		strState += strTemp;
	}
	
	if (lpDgramHeader->ucFunction == 0xD1 && lpDgramHeader->ucParam.ucParam2 == 0x30)
	{	// ���յ������Խ�¼���ļ���Ϣ
		PCREATE_FILE_INFO		pCreateFileInfo = (PCREATE_FILE_INFO)lpDgramHeader->ucAttachData1;
		strTemp.Format(_T("����¼���ļ�(�ն�%d):%s\r\n"), pCreateFileInfo->wTermID, pCreateFileInfo->pchFilePath);
		strState += strTemp;
	}

	m_strOutput += strState;
	GetDlgItem(IDC_EDIT_OUTPUT)->SetWindowText(m_strOutput);
	m_editOutput.LineScroll(m_editOutput.GetLineCount());
}

void CCallDllDemoDlg::OnBtnStartAlarm() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlFireAlarm(m_wAlarmArea, TRUE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ����ʧ��"));
}

void CCallDllDemoDlg::OnBtnEndAlarm() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlFireAlarm(m_wAlarmArea, FALSE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ����ʧ��"));
}

void CCallDllDemoDlg::OnBtnCall() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlCall(m_wDialogFromID, m_wDialogToID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("���гɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
}

void CCallDllDemoDlg::OnBtnAnswer() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlAnswer(m_wDialogFromID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
}

void CCallDllDemoDlg::OnBtnHang() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlHang(m_wDialogFromID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�Ҷϳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�Ҷ�ʧ��"));	
}

void CCallDllDemoDlg::OnBtnIoOn() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlIO(m_wIOID, m_ucIOPort, TRUE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("IO�˿ڱպϳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("IO�˿ڱպ�ʧ��"));	
}

void CCallDllDemoDlg::OnBtnIoOff() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlIO(m_wIOID, m_ucIOPort, FALSE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("IO�˿ڶϿ��ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("IO�˿ڶϿ�ʧ��"));	
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	GetDlgItem(IDC_ABOUTDLG_EDITION)->SetWindowText(EDITION_INFO);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCallDllDemoDlg::OnBtnBcStart() 
{
	// TODO: Add your control notification handler code here
	OnBroadcast(TRUE);
}

void CCallDllDemoDlg::OnBroadcast(BOOL bStart)
{
	BYTE		lpBuf[BROADCAST_TO_ID_LEN_EX];
	BYTE		lpID[10];
	int			nBufPos = 0, nIDPos = 0;
	int			nID;
	TCHAR		chID;
	CString		strOut, strID;
	BOOL		bBroadcastEx = FALSE;
	BOOL		bSucceed = FALSE;
	
	UpdateData();
	
	if (bStart)
		strOut.Format(_T("�ն�%d ��ʼ�������ն˲ɲ�:"), m_wBCFromID);
	else
		strOut.Format(_T("�ն�%d ֹͣ�������ն˲ɲ�:"), m_wBCFromID);
	ZeroMemory(lpBuf, BROADCAST_TO_ID_LEN_EX);
	for (int i = 0; i < m_strBCToID.GetLength(); i++)
	{
		chID = m_strBCToID.GetAt(i);
		if (chID >= '0' && chID <= '9')
		{
			if (nIDPos < 6)
				lpID[nIDPos++] = (BYTE)chID;
		}
		else if (chID == ',')
		{
			lpID[nIDPos++] = '\0';
			nIDPos = 0;
			nID = atoi((char *)lpID) - 1;
			if (nID >= 0 && nID < 1000)
			{
				if (nID >= 128)
					bBroadcastEx = TRUE;
				lpBuf[nID / 8] |= 1 << (nID % 8);
				strID.Format(_T("%d,"), nID + 1);
				strOut += strID;
			}
		}
	}
	if (nIDPos != 0)
	{
		lpID[nIDPos++] = '\0';
		nIDPos = 0;
		nID = atoi((char *)lpID) - 1;
		if (nID >= 0 && nID < 1000)
		{
			if (nID >= 128)
				bBroadcastEx = TRUE;
			lpBuf[nID / 8] |= 1 << (nID % 8);
			strID.Format(_T("%d,"), nID + 1);
			strOut += strID;
		}
	}

	if (bBroadcastEx)
		bSucceed = IPNBSSDK_CtrlBroadcastEx(m_wBCFromID, lpBuf, bStart);
	else
		bSucceed = IPNBSSDK_CtrlBroadcast(m_wBCFromID, lpBuf, bStart);
	if (bSucceed)
		strOut += _T("�ɹ�");
	else
		strOut += _T("ʧ��");

	GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(strOut);	
}

void CCallDllDemoDlg::OnBtnBcEnd() 
{
	// TODO: Add your control notification handler code here
	OnBroadcast(FALSE);
}

void CCallDllDemoDlg::OnBtnMinitorStart() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlMonitor(m_wMonitorFromID, m_wMonitorToID, TRUE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ����ʧ��"));	
}

void CCallDllDemoDlg::OnBtnMinitorEnd() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlMonitor(m_wMonitorFromID, m_wMonitorToID, FALSE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ����ʧ��"));	
}

void CCallDllDemoDlg::OnBtnQueryState() 
{
	// TODO: Add your control notification handler code herem_wQueryStateID
	UpdateData();
	if (IPNBSSDK_CtrlQueryState(m_wQueryStateID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�״̬��ѯ�ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�״̬��ѯʧ��"));
}

void CCallDllDemoDlg::OnBtnStartRing() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlTimerRing(m_wTimerRingID, TRUE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ��ʱ����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ��ʱ����ʧ��"));	
}

void CCallDllDemoDlg::OnBtnEndRing() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlTimerRing(m_wTimerRingID, FALSE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ��ʱ����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ��ʱ����ʧ��"));		
}

void CCallDllDemoDlg::OnBtnQueryIP() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlQueryIP(m_wQueryIPSrcID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�IP��ѯ�ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�IP��ѯʧ��"));	
}

void CCallDllDemoDlg::OnBtnQueryID() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlQueryID(m_strQueryIDSrcIP.GetBuffer(0)))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�ID��ѯ�ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�ն�ID��ѯʧ��"));	
}
void CCallDllDemoDlg::OnBtnDialogToPanelAnswer() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlAnswerEx(m_wDialogToPanelFromID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
}

void CCallDllDemoDlg::OnBtnDialogToPanelHang() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlHangEx(m_wDialogToPanelFromID))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�Ҷϳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�Ҷ�ʧ��"));	
}

void CCallDllDemoDlg::OnBtnDialogToPanelCall() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (m_bCallPhone)
	{
		if (IPNBSSDK_CtrlCallPhone(m_wDialogToPanelFromID, m_wDialogToPanelToID, m_ucDialogToPanelPanel, m_strPhone.GetBuffer(0)))
			GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("���гɹ�"));
		else
			GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
	}
	else
	{
		if (IPNBSSDK_CtrlCallEx(m_wDialogToPanelFromID, m_wDialogToPanelToID, m_ucDialogToPanelPanel))
			GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("���гɹ�"));
		else
			GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
	}
}

void CCallDllDemoDlg::OnStatusCallBack(DWORD dwInstance, WPARAM wParam, LPARAM lParam)
{
	CCallDllDemoDlg		*pDlg = (CCallDllDemoDlg *)dwInstance;
	if (pDlg != NULL)
		pDlg->OnRecvStatus(wParam, lParam);
}
void CCallDllDemoDlg::OnBtnQueryTermCount() 
{
	// TODO: Add your control notification handler code here
	CString strText;
	if (IPNBSSDK_CtrlQueryTermCount())
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ѯ�ն������ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ѯ�ն�����ʧ��"));
}

void CCallDllDemoDlg::OnBtnSetName() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlSetName(m_wSetNameID, m_strSetName.GetBuffer(0)))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ն����ֳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ն�����ʧ��"));
}

void CCallDllDemoDlg::OnBtnSetVolume() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlSetVolume(m_wSetVolumeID, m_ucSetVolume))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ն������ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("�����ն�����ʧ��"));
}

void CCallDllDemoDlg::OnBtnQueryPort() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (m_nQueryPortIn != 0)
		m_wQueryPort |= 0x80;
	if (IPNBSSDK_CtrlQueryPort(m_wQueryPortID, m_wQueryPort))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ѯ�ն˶˿�״̬�ɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ѯ�ն˶˿�״̬ʧ��"));
}

void CCallDllDemoDlg::OnBtnClearStatus() 
{
	// TODO: Add your control notification handler code here
	m_strOutput.Empty();
	UpdateData(FALSE);
}

void CCallDllDemoDlg::OnBtnSet() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_SetServerIP(m_strServerIP.GetBuffer(0)) \
		&& IPNBSSDK_SetServerPort(m_nServerPort) \
		&& IPNBSSDK_SetStatePort(m_nStatePort))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("���óɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("����ʧ��"));
}

void CCallDllDemoDlg::OnBtnSdPlay() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlSDPlay(m_wSDID, TRUE, (BYTE)m_wSDFileIndex))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("SD�����ſ��Ʒ��ͳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("SD�����ſ��Ʒ���ʧ��"));
}

void CCallDllDemoDlg::OnBtnSdStop() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if (IPNBSSDK_CtrlSDPlay(m_wSDID, FALSE, (BYTE)m_wSDFileIndex))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("SD��ֹͣ���Ʒ��ͳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("SD��ֹͣ���Ʒ���ʧ��"));
}

#ifdef TERM_8AREA_TEST
void CCallDllDemoDlg::OnBtn8areaStart() 
{
	// TODO: Add your control notification handler code here
	CString		strText;
	WORD		wFromID, wToID;
	BYTE		ucArea;
	int			nTemp;
	GetDlgItem(IDC_EDIT_8AREA_FROM_ID)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	wFromID = min(nTemp, 65535);
	GetDlgItem(IDC_EDIT_8AREA_TO_ID)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	wToID = min(nTemp, 65535);
	GetDlgItem(IDC_EDIT_8AREA_AREA)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	ucArea = min(nTemp, 255);
	if (IPNBSSDK_CtrlBroadcastSingle(wFromID, wToID, ucArea, TRUE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ8�����ն˹㲥�Ŀ��Ʒ��ͳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("��ʼ8�����ն˹㲥�Ŀ��Ʒ���ʧ��"));
}

void CCallDllDemoDlg::OnBtn8areaEnd() 
{
	// TODO: Add your control notification handler code here
	CString		strText;
	WORD		wFromID, wToID;
	BYTE		ucArea;
	int			nTemp;
	GetDlgItem(IDC_EDIT_8AREA_FROM_ID)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	wFromID = min(nTemp, 65535);
	GetDlgItem(IDC_EDIT_8AREA_TO_ID)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	wToID = min(nTemp, 65535);
	GetDlgItem(IDC_EDIT_8AREA_AREA)->GetWindowText(strText);
	nTemp = atoi(strText.GetBuffer(0));
	ucArea = min(nTemp, 255);
	if (IPNBSSDK_CtrlBroadcastSingle(wFromID, wToID, ucArea, FALSE))
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ8�����ն˹㲥�Ŀ��Ʒ��ͳɹ�"));
	else
		GetDlgItem(IDC_STATIC_CTRL_RESULT)->SetWindowText(_T("ֹͣ8�����ն˹㲥�Ŀ��Ʒ���ʧ��"));
}
#endif
