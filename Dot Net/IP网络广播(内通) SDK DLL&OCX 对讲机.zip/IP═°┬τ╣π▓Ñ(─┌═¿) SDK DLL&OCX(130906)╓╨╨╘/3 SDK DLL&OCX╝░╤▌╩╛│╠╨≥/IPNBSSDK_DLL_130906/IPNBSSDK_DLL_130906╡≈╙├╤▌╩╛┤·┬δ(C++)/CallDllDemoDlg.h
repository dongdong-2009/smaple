// CallDllDemoDlg.h : header file
//

#if !defined(AFX_CALLDLLDEMODLG_H__42CAE545_9BFD_41A4_82F2_B71FF4307D57__INCLUDED_)
#define AFX_CALLDLLDEMODLG_H__42CAE545_9BFD_41A4_82F2_B71FF4307D57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IPNBSSDK_Face.h"

#define TERM_8AREA_TEST

/////////////////////////////////////////////////////////////////////////////
// CCallDllDemoDlg dialog

class CCallDllDemoDlg : public CDialog
{
// Construction
public:
	CCallDllDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCallDllDemoDlg)
	enum { IDD = IDD_CALLDLLDEMO_DIALOG };
	CEdit	m_editOutput;
	CString	m_strServerIP;
	UINT	m_nServerPort;
	UINT	m_wIOID;
	BYTE	m_ucIOPort;
	UINT	m_nStatePort;
	UINT	m_wBCFromID;
	CString	m_strBCToID;
	UINT	m_wMonitorFromID;
	UINT	m_wMonitorToID;
	CString	m_strOutput;
	UINT	m_wAlarmArea;
	UINT	m_wQueryStateID;
	UINT	m_wTimerRingID;
	CString	m_strQueryIDSrcIP;
	UINT	m_wQueryIPSrcID;
	UINT	m_wSetNameID;
	CString	m_strSetName;
	UINT	m_wSetVolumeID;
	BYTE	m_ucSetVolume;
	UINT	m_wQueryPortID;
	UINT	m_wQueryPort;
	int		m_nQueryPortIn;
	UINT	m_wSDFileIndex;
	UINT	m_wSDID;
	BYTE	m_ucDialogToPanelPanel;
	UINT	m_wDialogFromID;
	UINT	m_wDialogToID;
	UINT	m_wDialogToPanelFromID;
	UINT	m_wDialogToPanelToID;
	BOOL	m_bCallPhone;
	CString	m_strPhone;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCallDllDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void OnBroadcast(BOOL bStart);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCallDllDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnStartAlarm();
	afx_msg void OnBtnEndAlarm();
	afx_msg void OnBtnCall();
	afx_msg void OnBtnAnswer();
	afx_msg void OnBtnHang();
	afx_msg void OnBtnIoOn();
	afx_msg void OnBtnIoOff();
	afx_msg void OnBtnBcStart();
	afx_msg void OnBtnBcEnd();
	afx_msg void OnBtnMinitorStart();
	afx_msg void OnBtnMinitorEnd();
	afx_msg void OnBtnQueryState();
	afx_msg void OnBtnStartRing();
	afx_msg void OnBtnEndRing();
	afx_msg void OnBtnQueryIP();
	afx_msg void OnBtnQueryID();
	afx_msg void OnBtnDialogToPanelAnswer();
	afx_msg void OnBtnDialogToPanelHang();
	afx_msg void OnBtnDialogToPanelCall();
	afx_msg void OnBtnQueryTermCount();
	afx_msg void OnBtnSetName();
	afx_msg void OnBtnSetVolume();
	afx_msg void OnBtnQueryPort();
	afx_msg void OnBtnClearStatus();
	afx_msg void OnBtnSet();
	afx_msg void OnBtnSdPlay();
	afx_msg void OnBtnSdStop();
	//}}AFX_MSG
#ifdef TERM_8AREA_TEST
	afx_msg void OnBtn8areaStart();
	afx_msg void OnBtn8areaEnd();
#endif
	afx_msg void OnRecvStatus(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

public:
	static void CALLBACK OnStatusCallBack(DWORD dwInstance, WPARAM wParam, LPARAM lParam);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALLDLLDEMODLG_H__42CAE545_9BFD_41A4_82F2_B71FF4307D57__INCLUDED_)
