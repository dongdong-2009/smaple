#ifndef _DEMO_DEFINE_H
#define _DEMO_DEFINE_H

#define EDITION_INFO _T("")//Ver1.8 (2009-05-20)

#endif //_DEMO_DEFINE_H