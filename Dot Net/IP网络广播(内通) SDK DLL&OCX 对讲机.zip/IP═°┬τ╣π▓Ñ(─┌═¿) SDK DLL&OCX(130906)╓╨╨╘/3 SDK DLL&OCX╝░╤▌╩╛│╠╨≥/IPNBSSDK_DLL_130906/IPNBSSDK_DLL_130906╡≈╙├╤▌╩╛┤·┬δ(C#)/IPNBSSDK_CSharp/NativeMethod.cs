﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace IPNBSSDK_CSharp
{
    //服务器状态输出
    public enum IPNBSSDK_STATE
    {
        IPNBSSDK_STATE_TERMINAL_NULL = 1,			// 终端空闲
        IPNBSSDK_STATE_TERMINAL_LIVE_PLAY,			// 终端实时采播
        IPNBSSDK_STATE_TERMINAL_TERMER_RING,		// 终端定时打铃
        IPNBSSDK_STATE_TERMINAL_TERMER_PROGRAMS,	// 终端定时节目
        IPNBSSDK_STATE_TERMINAL_SERVER_FIRE_ALARM,	// 终端接收服务器消防报警
        IPNBSSDK_STATE_DIALOG_CALL,					// 对讲呼叫
        IPNBSSDK_STATE_DIALOG_BEGIN,				// 对讲开始
        IPNBSSDK_STATE_DIALOG_END,					// 对讲结束
        IPNBSSDK_STATE_TERMINAL_ALARM1,				// 终端报警1
        IPNBSSDK_STATE_TERMINAL_ALARM2,				// 终端报警2
        IPNBSSDK_STATE_TASK_NULL,					// 任务空闲
        IPNBSSDK_STATE_TASK_TERMER_RING_BEGIN,		// 任务定时打铃执行
        IPNBSSDK_STATE_TASK_TERMER_RING_END,		// 任务定时打铃停止
        IPNBSSDK_STATE_TASK_FIRE_ALARM_BEGIN,		// 任务消防报警
        IPNBSSDK_STATE_TASK_FIRE_ALARM_END,			// 任务消防报警
        IPNBSSDK_STATE_TERMINAL_IP,					// 由ID号查到的IP地址
        IPNBSSDK_STATE_TERMINAL_ID,					// 由IP地址查到的ID号
        IPNBSSDK_STATE_TERMINAL_COUNT,				// 查询到终端数量
        IPNBSSDK_STATE_PORT_STATE,					// 查询到终端端口状态
        IPNBSSDK_STATE_SD_PLAY_STATE,				// SD卡播放状态
        IPNBSSDK_STATE_TERMINAL_ALARM_EX,			// 终端扩展报警输入
    };

    //组播的数据结构(服务器状态输出)
    [StructLayout(LayoutKind.Sequential)]
    public struct DGRAMHEADER_STATUS
    {
        public ushort wFlag;
        public byte ucFunction;
        public byte ucParam1;
        public byte ucParam2;
        public byte ucParam3;
        public byte ucParam4;
        public byte ucParam5;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
        public byte[] ucAttachData1;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
        public byte[] ucAttachData2;
    }

    // 创建文件后发送给视频联动的消息
    [StructLayout(LayoutKind.Sequential)]
    public struct CREATE_FILE_INFO
    {
        public ushort wTermID;
        public ushort wYear;
        public ushort wMonth;
        public ushort wDay;
        public ushort wHour;
        public ushort wMinute;
        public ushort wSecond; //14
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public byte[] pucReserve;		// 保留
        //CHAR		pchFilePath[1];		// 录音文件名和路径(这是个字符串,不定长)
    };

    public delegate void StatusCallBack(IntPtr dwInstance, IntPtr wParam, IntPtr lParam);

    /// <summary>
    /// 跨平台调用方法
    /// </summary>
    public class NativeMethod
    {
        public const int UM_IPNBSSDK_STATE = (0x0400 + 200);	// 向调用窗口发送接收状态的消息
        public const int DGRAMHEADER_HEADER_SIZE = 8;			// 数据头尺寸(未包括后面的附加数据)
        public const int BSSOCKET_SERVER_PORT = 2048;			// 广播服务器控制接收端口
        public const int BSSOCKET_MULTI_PORT = 2046;			// 调用程序接收组播状态的网络端口
        public const int BSSOCKET_STATE_PORT = 2058;			// 调用程序接收单播状态的网络端口
        public const string BSSOCKET_STATE_IP = "234.0.0.254";	// 调用程序接收状态的组播地址
        public const int BROADCAST_TO_ID_LEN = 16;			    // 终端采播目标终端选择的附带数据长度(128个点)
        public const int BROADCAST_TO_ID_LEN_EX = 125;			// 终端采播目标终端选择的附带数据长度(1000个点)

        [DllImport("IPNBSSDK.dll")]
        public static extern void IPNBSSDK_SetParentWnd(IntPtr hWnd);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_SetServerIP(string strServerIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_SetServerPort(ushort wPort);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_SetStatePort(ushort wPort);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlCall(ushort wFromID, ushort wToID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlAnswer(ushort wFromID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlHang(ushort wFromID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPCall(string strFromIP, string strToIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPAnswer(string strFromIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPHang(string strFromIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPCallEx(string strFromIP, string strToIP, byte ucPanel);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPAnswerEx(string strFromIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIPHangEx(string strFromIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlIO(ushort wID, byte ucPort, bool bIsOn);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlBroadcast(ushort wFromID, IntPtr pToID, bool bStart);
        //pToID 为接收采播的终端(16Bytes,  共128bits,  对应128 个终端,  如:  第一个字节的第一位表示 ID为1 的终端…)

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlMonitor(ushort wFromID, ushort wToID, bool bStart);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlQueryState(ushort wID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlQueryIP(ushort wID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlQueryID(string strTermIP);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlQueryTermCount();

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlFireAlarm(ushort wAlarmArea, bool bStart);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlTimerRing(ushort wNO, bool bStart);

        [DllImport("IPNBSSDK.dll")]
        public static extern void IPNBSSDK_SetStatusCallBack(StatusCallBack dwCallBack, IntPtr dwInstance);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlSetName(ushort wID, string strName);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlSetVolume(ushort wID, byte ucVolume);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlQueryPort(ushort wID, byte ucPort);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlSDPlay(ushort wID, bool bPlay, byte ucFileIndex);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlVoiceControl(ushort wID, byte ucCtrlIn, byte ucCtrlOut);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlCallEx(ushort wFromID, ushort wToID, byte ucPanel);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlAnswerEx(ushort wFromID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlHangEx(ushort wFromID);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlBroadcastEx(ushort wFromID, IntPtr pToID, bool bStart);
        //pToID 为接收采播的终端(125Bytes,  共1000bits,  对应1000个终端,  如:  第一个字节的第一位表示 ID为1 的终端…)

        public static bool IPNBSSDK_CtrlBroadcast_CSharp(ushort wFromID, List<ushort> pToIDList, bool bStart)
        {
            bool bBroadcastEx = false; // 16
            byte[] bytes = new byte[125];
            foreach (ushort nID in pToIDList)
            {
                if (nID >= 0 && nID < 1000)
                {
                    if (nID >= 128)
                        bBroadcastEx = true;
                    bytes[nID / 8] |= (byte)(1 << (nID % 8));
                }
            }

            if (bBroadcastEx)
            {
                IntPtr intptr = Marshal.AllocHGlobal(125);
                Marshal.Copy(bytes, 0, intptr, 125);
                return IPNBSSDK_CtrlBroadcastEx(wFromID, intptr, bStart);
            }
            else
            {
                IntPtr intptr = Marshal.AllocHGlobal(16);
                Marshal.Copy(bytes, 0, intptr, 16);
                return IPNBSSDK_CtrlBroadcast(wFromID, intptr, bStart);
            }
        }

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlBroadcastSingle(ushort wFromID, ushort wToID, byte ucArea, bool bStart);

        [DllImport("IPNBSSDK.dll")]
        public static extern void IPNBSSDK_SetIsUnicode(bool bIsUnicode);

        [DllImport("IPNBSSDK.dll")]
        public static extern bool IPNBSSDK_CtrlCallPhone(ushort wFromID, ushort wToID, byte ucPanel, string strPhone);
    }
}
