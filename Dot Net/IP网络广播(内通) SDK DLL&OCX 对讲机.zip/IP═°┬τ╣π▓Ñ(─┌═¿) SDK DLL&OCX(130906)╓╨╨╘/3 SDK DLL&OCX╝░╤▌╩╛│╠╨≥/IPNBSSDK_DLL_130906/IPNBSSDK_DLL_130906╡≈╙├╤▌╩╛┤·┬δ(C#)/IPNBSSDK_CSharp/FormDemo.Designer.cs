﻿namespace IPNBSSDK_CSharp
{
    partial class FormDemo
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.gbConfig = new System.Windows.Forms.GroupBox();
            this.btnSetConfig = new System.Windows.Forms.Button();
            this.tbStatePort = new System.Windows.Forms.TextBox();
            this.tbServerPort = new System.Windows.Forms.TextBox();
            this.tbServerIP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbOutput = new System.Windows.Forms.GroupBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageControl = new System.Windows.Forms.TabPage();
            this.btn8AreaBroadcastStop = new System.Windows.Forms.Button();
            this.btn8AreaBroadcastStart = new System.Windows.Forms.Button();
            this.tb8AreaNumber = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tb8AreaTerminalId = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btnSDStop = new System.Windows.Forms.Button();
            this.btnSDPlay = new System.Windows.Forms.Button();
            this.tbSDFileIndex = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tbSDControlId = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnIOClose = new System.Windows.Forms.Button();
            this.btnIOOpen = new System.Windows.Forms.Button();
            this.tbIOControlPort = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbIOControlId = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnSpyStop = new System.Windows.Forms.Button();
            this.btnSpyStart = new System.Windows.Forms.Button();
            this.tbSpyToId = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbSpyFromId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnBroadcastStop = new System.Windows.Forms.Button();
            this.btnStartBroadcast = new System.Windows.Forms.Button();
            this.tbBroadcastToId = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbBroadcastFromId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbPhoneNumber = new System.Windows.Forms.TextBox();
            this.cbPhone = new System.Windows.Forms.CheckBox();
            this.tbCallExAreaId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnCallEx = new System.Windows.Forms.Button();
            this.btnHangEx = new System.Windows.Forms.Button();
            this.btnAnswerEx = new System.Windows.Forms.Button();
            this.tbCallExToId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbCallExFromId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnCall = new System.Windows.Forms.Button();
            this.btnHang = new System.Windows.Forms.Button();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.tbCallToId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbCallFromId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPageSearch = new System.Windows.Forms.TabPage();
            this.btnStopRingTask = new System.Windows.Forms.Button();
            this.btnStartRingTask = new System.Windows.Forms.Button();
            this.tbRingTaskId = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tbnStopAlarmTask = new System.Windows.Forms.Button();
            this.btnStartAlarmTask = new System.Windows.Forms.Button();
            this.tbAlarmTaskId = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.rbPortOut = new System.Windows.Forms.RadioButton();
            this.rbPortIn = new System.Windows.Forms.RadioButton();
            this.btnPortSearch = new System.Windows.Forms.Button();
            this.tbSearchPort = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.btnModifyVolume = new System.Windows.Forms.Button();
            this.tbVolume = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.btnModifyName = new System.Windows.Forms.Button();
            this.tbTerminalName = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnSearchTerminalCount = new System.Windows.Forms.Button();
            this.btnIdSearch = new System.Windows.Forms.Button();
            this.tbTerminalIP = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.btnIPSearch = new System.Windows.Forms.Button();
            this.btnStateSearch = new System.Windows.Forms.Button();
            this.tbSearchId = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.statusStripMain = new System.Windows.Forms.StatusStrip();
            this.tsLabelResult = new System.Windows.Forms.ToolStripStatusLabel();
            this.gbConfig.SuspendLayout();
            this.gbOutput.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageControl.SuspendLayout();
            this.tabPageSearch.SuspendLayout();
            this.statusStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbConfig
            // 
            this.gbConfig.Controls.Add(this.btnSetConfig);
            this.gbConfig.Controls.Add(this.tbStatePort);
            this.gbConfig.Controls.Add(this.tbServerPort);
            this.gbConfig.Controls.Add(this.tbServerIP);
            this.gbConfig.Controls.Add(this.label3);
            this.gbConfig.Controls.Add(this.label2);
            this.gbConfig.Controls.Add(this.label1);
            this.gbConfig.Location = new System.Drawing.Point(12, 12);
            this.gbConfig.Name = "gbConfig";
            this.gbConfig.Size = new System.Drawing.Size(188, 128);
            this.gbConfig.TabIndex = 0;
            this.gbConfig.TabStop = false;
            this.gbConfig.Text = "设置";
            // 
            // btnSetConfig
            // 
            this.btnSetConfig.Location = new System.Drawing.Point(106, 97);
            this.btnSetConfig.Name = "btnSetConfig";
            this.btnSetConfig.Size = new System.Drawing.Size(75, 23);
            this.btnSetConfig.TabIndex = 7;
            this.btnSetConfig.Text = "设置";
            this.btnSetConfig.UseVisualStyleBackColor = true;
            this.btnSetConfig.Click += new System.EventHandler(this.btnSetConfig_Click);
            // 
            // tbStatePort
            // 
            this.tbStatePort.Location = new System.Drawing.Point(105, 70);
            this.tbStatePort.Name = "tbStatePort";
            this.tbStatePort.Size = new System.Drawing.Size(76, 21);
            this.tbStatePort.TabIndex = 5;
            this.tbStatePort.Text = "2058";
            // 
            // tbServerPort
            // 
            this.tbServerPort.Location = new System.Drawing.Point(93, 44);
            this.tbServerPort.Name = "tbServerPort";
            this.tbServerPort.Size = new System.Drawing.Size(88, 21);
            this.tbServerPort.TabIndex = 4;
            this.tbServerPort.Text = "2048";
            // 
            // tbServerIP
            // 
            this.tbServerIP.Location = new System.Drawing.Point(81, 18);
            this.tbServerIP.Name = "tbServerIP";
            this.tbServerIP.Size = new System.Drawing.Size(100, 21);
            this.tbServerIP.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "状态接收端口:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "服务器端口:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "服务器IP:";
            // 
            // gbOutput
            // 
            this.gbOutput.Controls.Add(this.rtbOutput);
            this.gbOutput.Location = new System.Drawing.Point(206, 12);
            this.gbOutput.Name = "gbOutput";
            this.gbOutput.Size = new System.Drawing.Size(281, 128);
            this.gbOutput.TabIndex = 8;
            this.gbOutput.TabStop = false;
            this.gbOutput.Text = "状态输出";
            // 
            // rtbOutput
            // 
            this.rtbOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbOutput.Location = new System.Drawing.Point(3, 17);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.Size = new System.Drawing.Size(275, 108);
            this.rtbOutput.TabIndex = 0;
            this.rtbOutput.Text = "";
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageControl);
            this.tabControlMain.Controls.Add(this.tabPageSearch);
            this.tabControlMain.Location = new System.Drawing.Point(12, 146);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(475, 330);
            this.tabControlMain.TabIndex = 10;
            // 
            // tabPageControl
            // 
            this.tabPageControl.Controls.Add(this.btn8AreaBroadcastStop);
            this.tabPageControl.Controls.Add(this.btn8AreaBroadcastStart);
            this.tabPageControl.Controls.Add(this.tb8AreaNumber);
            this.tabPageControl.Controls.Add(this.label30);
            this.tabPageControl.Controls.Add(this.tb8AreaTerminalId);
            this.tabPageControl.Controls.Add(this.label29);
            this.tabPageControl.Controls.Add(this.btnSDStop);
            this.tabPageControl.Controls.Add(this.btnSDPlay);
            this.tabPageControl.Controls.Add(this.tbSDFileIndex);
            this.tabPageControl.Controls.Add(this.label24);
            this.tabPageControl.Controls.Add(this.tbSDControlId);
            this.tabPageControl.Controls.Add(this.label25);
            this.tabPageControl.Controls.Add(this.label26);
            this.tabPageControl.Controls.Add(this.label20);
            this.tabPageControl.Controls.Add(this.btnIOClose);
            this.tabPageControl.Controls.Add(this.btnIOOpen);
            this.tabPageControl.Controls.Add(this.tbIOControlPort);
            this.tabPageControl.Controls.Add(this.label21);
            this.tabPageControl.Controls.Add(this.tbIOControlId);
            this.tabPageControl.Controls.Add(this.label22);
            this.tabPageControl.Controls.Add(this.label23);
            this.tabPageControl.Controls.Add(this.label16);
            this.tabPageControl.Controls.Add(this.btnSpyStop);
            this.tabPageControl.Controls.Add(this.btnSpyStart);
            this.tabPageControl.Controls.Add(this.tbSpyToId);
            this.tabPageControl.Controls.Add(this.label17);
            this.tabPageControl.Controls.Add(this.tbSpyFromId);
            this.tabPageControl.Controls.Add(this.label18);
            this.tabPageControl.Controls.Add(this.label19);
            this.tabPageControl.Controls.Add(this.label15);
            this.tabPageControl.Controls.Add(this.btnBroadcastStop);
            this.tabPageControl.Controls.Add(this.btnStartBroadcast);
            this.tabPageControl.Controls.Add(this.tbBroadcastToId);
            this.tabPageControl.Controls.Add(this.label14);
            this.tabPageControl.Controls.Add(this.tbBroadcastFromId);
            this.tabPageControl.Controls.Add(this.label13);
            this.tabPageControl.Controls.Add(this.label12);
            this.tabPageControl.Controls.Add(this.label11);
            this.tabPageControl.Controls.Add(this.tbPhoneNumber);
            this.tabPageControl.Controls.Add(this.cbPhone);
            this.tabPageControl.Controls.Add(this.tbCallExAreaId);
            this.tabPageControl.Controls.Add(this.label10);
            this.tabPageControl.Controls.Add(this.btnCallEx);
            this.tabPageControl.Controls.Add(this.btnHangEx);
            this.tabPageControl.Controls.Add(this.btnAnswerEx);
            this.tabPageControl.Controls.Add(this.tbCallExToId);
            this.tabPageControl.Controls.Add(this.label7);
            this.tabPageControl.Controls.Add(this.tbCallExFromId);
            this.tabPageControl.Controls.Add(this.label8);
            this.tabPageControl.Controls.Add(this.label9);
            this.tabPageControl.Controls.Add(this.btnCall);
            this.tabPageControl.Controls.Add(this.btnHang);
            this.tabPageControl.Controls.Add(this.btnAnswer);
            this.tabPageControl.Controls.Add(this.tbCallToId);
            this.tabPageControl.Controls.Add(this.label6);
            this.tabPageControl.Controls.Add(this.tbCallFromId);
            this.tabPageControl.Controls.Add(this.label5);
            this.tabPageControl.Controls.Add(this.label4);
            this.tabPageControl.Location = new System.Drawing.Point(4, 21);
            this.tabPageControl.Name = "tabPageControl";
            this.tabPageControl.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageControl.Size = new System.Drawing.Size(467, 305);
            this.tabPageControl.TabIndex = 0;
            this.tabPageControl.Text = "控制输入";
            this.tabPageControl.UseVisualStyleBackColor = true;
            // 
            // btn8AreaBroadcastStop
            // 
            this.btn8AreaBroadcastStop.Location = new System.Drawing.Point(403, 156);
            this.btn8AreaBroadcastStop.Name = "btn8AreaBroadcastStop";
            this.btn8AreaBroadcastStop.Size = new System.Drawing.Size(43, 23);
            this.btn8AreaBroadcastStop.TabIndex = 82;
            this.btn8AreaBroadcastStop.Text = "停止";
            this.btn8AreaBroadcastStop.UseVisualStyleBackColor = true;
            this.btn8AreaBroadcastStop.Click += new System.EventHandler(this.btn8AreaBroadcastStop_Click);
            // 
            // btn8AreaBroadcastStart
            // 
            this.btn8AreaBroadcastStart.Location = new System.Drawing.Point(358, 156);
            this.btn8AreaBroadcastStart.Name = "btn8AreaBroadcastStart";
            this.btn8AreaBroadcastStart.Size = new System.Drawing.Size(43, 23);
            this.btn8AreaBroadcastStart.TabIndex = 81;
            this.btn8AreaBroadcastStart.Text = "开始";
            this.btn8AreaBroadcastStart.UseVisualStyleBackColor = true;
            this.btn8AreaBroadcastStart.Click += new System.EventHandler(this.btn8AreaBroadcastStart_Click);
            // 
            // tb8AreaNumber
            // 
            this.tb8AreaNumber.Location = new System.Drawing.Point(286, 157);
            this.tb8AreaNumber.Name = "tb8AreaNumber";
            this.tb8AreaNumber.Size = new System.Drawing.Size(66, 21);
            this.tb8AreaNumber.TabIndex = 80;
            this.tb8AreaNumber.Text = "1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(221, 161);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 12);
            this.label30.TabIndex = 79;
            this.label30.Text = "分区编号:";
            // 
            // tb8AreaTerminalId
            // 
            this.tb8AreaTerminalId.Location = new System.Drawing.Point(170, 157);
            this.tb8AreaTerminalId.Name = "tb8AreaTerminalId";
            this.tb8AreaTerminalId.Size = new System.Drawing.Size(45, 21);
            this.tb8AreaTerminalId.TabIndex = 78;
            this.tb8AreaTerminalId.Text = "2";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(87, 161);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 12);
            this.label29.TabIndex = 77;
            this.label29.Text = "8分区终端ID:";
            // 
            // btnSDStop
            // 
            this.btnSDStop.Location = new System.Drawing.Point(404, 271);
            this.btnSDStop.Name = "btnSDStop";
            this.btnSDStop.Size = new System.Drawing.Size(43, 23);
            this.btnSDStop.TabIndex = 76;
            this.btnSDStop.Text = "停止";
            this.btnSDStop.UseVisualStyleBackColor = true;
            this.btnSDStop.Click += new System.EventHandler(this.btnSDStop_Click);
            // 
            // btnSDPlay
            // 
            this.btnSDPlay.Location = new System.Drawing.Point(359, 271);
            this.btnSDPlay.Name = "btnSDPlay";
            this.btnSDPlay.Size = new System.Drawing.Size(43, 23);
            this.btnSDPlay.TabIndex = 75;
            this.btnSDPlay.Text = "播放";
            this.btnSDPlay.UseVisualStyleBackColor = true;
            this.btnSDPlay.Click += new System.EventHandler(this.btnSDPlay_Click);
            // 
            // tbSDFileIndex
            // 
            this.tbSDFileIndex.Location = new System.Drawing.Point(283, 272);
            this.tbSDFileIndex.Name = "tbSDFileIndex";
            this.tbSDFileIndex.Size = new System.Drawing.Size(70, 21);
            this.tbSDFileIndex.TabIndex = 74;
            this.tbSDFileIndex.Text = "1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(231, 276);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 12);
            this.label24.TabIndex = 73;
            this.label24.Text = "文件编号:";
            // 
            // tbSDControlId
            // 
            this.tbSDControlId.Location = new System.Drawing.Point(139, 272);
            this.tbSDControlId.Name = "tbSDControlId";
            this.tbSDControlId.Size = new System.Drawing.Size(69, 21);
            this.tbSDControlId.TabIndex = 72;
            this.tbSDControlId.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(87, 276);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 12);
            this.label25.TabIndex = 71;
            this.label25.Text = "终端ID:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 276);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 12);
            this.label26.TabIndex = 70;
            this.label26.Text = "SD卡控制:";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Location = new System.Drawing.Point(20, 265);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(429, 2);
            this.label20.TabIndex = 69;
            // 
            // btnIOClose
            // 
            this.btnIOClose.Location = new System.Drawing.Point(404, 234);
            this.btnIOClose.Name = "btnIOClose";
            this.btnIOClose.Size = new System.Drawing.Size(43, 23);
            this.btnIOClose.TabIndex = 68;
            this.btnIOClose.Text = "断开";
            this.btnIOClose.UseVisualStyleBackColor = true;
            this.btnIOClose.Click += new System.EventHandler(this.btnIOClose_Click);
            // 
            // btnIOOpen
            // 
            this.btnIOOpen.Location = new System.Drawing.Point(359, 234);
            this.btnIOOpen.Name = "btnIOOpen";
            this.btnIOOpen.Size = new System.Drawing.Size(43, 23);
            this.btnIOOpen.TabIndex = 67;
            this.btnIOOpen.Text = "闭合";
            this.btnIOOpen.UseVisualStyleBackColor = true;
            this.btnIOOpen.Click += new System.EventHandler(this.btnIOOpen_Click);
            // 
            // tbIOControlPort
            // 
            this.tbIOControlPort.Location = new System.Drawing.Point(283, 235);
            this.tbIOControlPort.Name = "tbIOControlPort";
            this.tbIOControlPort.Size = new System.Drawing.Size(70, 21);
            this.tbIOControlPort.TabIndex = 66;
            this.tbIOControlPort.Text = "1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(231, 239);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 12);
            this.label21.TabIndex = 65;
            this.label21.Text = "IO端口:";
            // 
            // tbIOControlId
            // 
            this.tbIOControlId.Location = new System.Drawing.Point(139, 235);
            this.tbIOControlId.Name = "tbIOControlId";
            this.tbIOControlId.Size = new System.Drawing.Size(69, 21);
            this.tbIOControlId.TabIndex = 64;
            this.tbIOControlId.Text = "1";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(87, 239);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 12);
            this.label22.TabIndex = 63;
            this.label22.Text = "终端ID:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(18, 239);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 12);
            this.label23.TabIndex = 62;
            this.label23.Text = "IO口控制:";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Location = new System.Drawing.Point(20, 227);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(429, 2);
            this.label16.TabIndex = 61;
            // 
            // btnSpyStop
            // 
            this.btnSpyStop.Location = new System.Drawing.Point(404, 196);
            this.btnSpyStop.Name = "btnSpyStop";
            this.btnSpyStop.Size = new System.Drawing.Size(43, 23);
            this.btnSpyStop.TabIndex = 60;
            this.btnSpyStop.Text = "停止";
            this.btnSpyStop.UseVisualStyleBackColor = true;
            this.btnSpyStop.Click += new System.EventHandler(this.btnSpyStop_Click);
            // 
            // btnSpyStart
            // 
            this.btnSpyStart.Location = new System.Drawing.Point(359, 196);
            this.btnSpyStart.Name = "btnSpyStart";
            this.btnSpyStart.Size = new System.Drawing.Size(43, 23);
            this.btnSpyStart.TabIndex = 59;
            this.btnSpyStart.Text = "开始";
            this.btnSpyStart.UseVisualStyleBackColor = true;
            this.btnSpyStart.Click += new System.EventHandler(this.btnSpyStart_Click);
            // 
            // tbSpyToId
            // 
            this.tbSpyToId.Location = new System.Drawing.Point(216, 197);
            this.tbSpyToId.Name = "tbSpyToId";
            this.tbSpyToId.Size = new System.Drawing.Size(137, 21);
            this.tbSpyToId.TabIndex = 58;
            this.tbSpyToId.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(175, 201);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 57;
            this.label17.Text = "被叫:";
            // 
            // tbSpyFromId
            // 
            this.tbSpyFromId.Location = new System.Drawing.Point(128, 197);
            this.tbSpyFromId.Name = "tbSpyFromId";
            this.tbSpyFromId.Size = new System.Drawing.Size(30, 21);
            this.tbSpyFromId.TabIndex = 56;
            this.tbSpyFromId.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(87, 201);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 12);
            this.label18.TabIndex = 55;
            this.label18.Text = "主叫:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(18, 201);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 12);
            this.label19.TabIndex = 54;
            this.label19.Text = "监听控制:";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Location = new System.Drawing.Point(19, 186);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(429, 2);
            this.label15.TabIndex = 53;
            // 
            // btnBroadcastStop
            // 
            this.btnBroadcastStop.Location = new System.Drawing.Point(403, 129);
            this.btnBroadcastStop.Name = "btnBroadcastStop";
            this.btnBroadcastStop.Size = new System.Drawing.Size(43, 23);
            this.btnBroadcastStop.TabIndex = 52;
            this.btnBroadcastStop.Text = "停止";
            this.btnBroadcastStop.UseVisualStyleBackColor = true;
            this.btnBroadcastStop.Click += new System.EventHandler(this.btnBroadcastStop_Click);
            // 
            // btnStartBroadcast
            // 
            this.btnStartBroadcast.Location = new System.Drawing.Point(358, 129);
            this.btnStartBroadcast.Name = "btnStartBroadcast";
            this.btnStartBroadcast.Size = new System.Drawing.Size(43, 23);
            this.btnStartBroadcast.TabIndex = 51;
            this.btnStartBroadcast.Text = "开始";
            this.btnStartBroadcast.UseVisualStyleBackColor = true;
            this.btnStartBroadcast.Click += new System.EventHandler(this.btnStartBroadcast_Click);
            // 
            // tbBroadcastToId
            // 
            this.tbBroadcastToId.Location = new System.Drawing.Point(215, 130);
            this.tbBroadcastToId.Name = "tbBroadcastToId";
            this.tbBroadcastToId.Size = new System.Drawing.Size(137, 21);
            this.tbBroadcastToId.TabIndex = 50;
            this.tbBroadcastToId.Text = "2,3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(174, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 49;
            this.label14.Text = "被叫:";
            // 
            // tbBroadcastFromId
            // 
            this.tbBroadcastFromId.Location = new System.Drawing.Point(127, 130);
            this.tbBroadcastFromId.Name = "tbBroadcastFromId";
            this.tbBroadcastFromId.Size = new System.Drawing.Size(30, 21);
            this.tbBroadcastFromId.TabIndex = 48;
            this.tbBroadcastFromId.Text = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(86, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 47;
            this.label13.Text = "主叫:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 12);
            this.label12.TabIndex = 46;
            this.label12.Text = "采播控制:";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Location = new System.Drawing.Point(19, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(429, 2);
            this.label11.TabIndex = 45;
            // 
            // tbPhoneNumber
            // 
            this.tbPhoneNumber.Enabled = false;
            this.tbPhoneNumber.Location = new System.Drawing.Point(269, 93);
            this.tbPhoneNumber.Name = "tbPhoneNumber";
            this.tbPhoneNumber.Size = new System.Drawing.Size(177, 21);
            this.tbPhoneNumber.TabIndex = 44;
            // 
            // cbPhone
            // 
            this.cbPhone.AutoSize = true;
            this.cbPhone.Location = new System.Drawing.Point(209, 95);
            this.cbPhone.Name = "cbPhone";
            this.cbPhone.Size = new System.Drawing.Size(54, 16);
            this.cbPhone.TabIndex = 43;
            this.cbPhone.Text = "电话:";
            this.cbPhone.UseVisualStyleBackColor = true;
            // 
            // tbCallExAreaId
            // 
            this.tbCallExAreaId.Location = new System.Drawing.Point(322, 63);
            this.tbCallExAreaId.Name = "tbCallExAreaId";
            this.tbCallExAreaId.Size = new System.Drawing.Size(30, 21);
            this.tbCallExAreaId.TabIndex = 42;
            this.tbCallExAreaId.Text = "2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(281, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 41;
            this.label10.Text = "面板:";
            // 
            // btnCallEx
            // 
            this.btnCallEx.Location = new System.Drawing.Point(358, 62);
            this.btnCallEx.Name = "btnCallEx";
            this.btnCallEx.Size = new System.Drawing.Size(43, 23);
            this.btnCallEx.TabIndex = 40;
            this.btnCallEx.Text = "呼叫";
            this.btnCallEx.UseVisualStyleBackColor = true;
            this.btnCallEx.Click += new System.EventHandler(this.btnCallEx_Click);
            // 
            // btnHangEx
            // 
            this.btnHangEx.Location = new System.Drawing.Point(403, 35);
            this.btnHangEx.Name = "btnHangEx";
            this.btnHangEx.Size = new System.Drawing.Size(43, 23);
            this.btnHangEx.TabIndex = 39;
            this.btnHangEx.Text = "挂断";
            this.btnHangEx.UseVisualStyleBackColor = true;
            this.btnHangEx.Click += new System.EventHandler(this.btnHangEx_Click);
            // 
            // btnAnswerEx
            // 
            this.btnAnswerEx.Location = new System.Drawing.Point(358, 35);
            this.btnAnswerEx.Name = "btnAnswerEx";
            this.btnAnswerEx.Size = new System.Drawing.Size(43, 23);
            this.btnAnswerEx.TabIndex = 38;
            this.btnAnswerEx.Text = "接听";
            this.btnAnswerEx.UseVisualStyleBackColor = true;
            this.btnAnswerEx.Click += new System.EventHandler(this.btnAnswerEx_Click);
            // 
            // tbCallExToId
            // 
            this.tbCallExToId.Location = new System.Drawing.Point(248, 63);
            this.tbCallExToId.Name = "tbCallExToId";
            this.tbCallExToId.Size = new System.Drawing.Size(30, 21);
            this.tbCallExToId.TabIndex = 37;
            this.tbCallExToId.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(207, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 36;
            this.label7.Text = "被叫:";
            // 
            // tbCallExFromId
            // 
            this.tbCallExFromId.Location = new System.Drawing.Point(248, 36);
            this.tbCallExFromId.Name = "tbCallExFromId";
            this.tbCallExFromId.Size = new System.Drawing.Size(30, 21);
            this.tbCallExFromId.TabIndex = 35;
            this.tbCallExFromId.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(207, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 34;
            this.label8.Text = "主叫:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(207, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 12);
            this.label9.TabIndex = 33;
            this.label9.Text = "ID对讲到面板:";
            // 
            // btnCall
            // 
            this.btnCall.Location = new System.Drawing.Point(94, 62);
            this.btnCall.Name = "btnCall";
            this.btnCall.Size = new System.Drawing.Size(43, 23);
            this.btnCall.TabIndex = 32;
            this.btnCall.Text = "呼叫";
            this.btnCall.UseVisualStyleBackColor = true;
            this.btnCall.Click += new System.EventHandler(this.btnCall_Click);
            // 
            // btnHang
            // 
            this.btnHang.Location = new System.Drawing.Point(139, 35);
            this.btnHang.Name = "btnHang";
            this.btnHang.Size = new System.Drawing.Size(43, 23);
            this.btnHang.TabIndex = 31;
            this.btnHang.Text = "挂断";
            this.btnHang.UseVisualStyleBackColor = true;
            this.btnHang.Click += new System.EventHandler(this.btnHang_Click);
            // 
            // btnAnswer
            // 
            this.btnAnswer.Location = new System.Drawing.Point(94, 35);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(43, 23);
            this.btnAnswer.TabIndex = 30;
            this.btnAnswer.Text = "接听";
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // tbCallToId
            // 
            this.tbCallToId.Location = new System.Drawing.Point(58, 63);
            this.tbCallToId.Name = "tbCallToId";
            this.tbCallToId.Size = new System.Drawing.Size(30, 21);
            this.tbCallToId.TabIndex = 29;
            this.tbCallToId.Text = "2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "被叫:";
            // 
            // tbCallFromId
            // 
            this.tbCallFromId.Location = new System.Drawing.Point(58, 36);
            this.tbCallFromId.Name = "tbCallFromId";
            this.tbCallFromId.Size = new System.Drawing.Size(30, 21);
            this.tbCallFromId.TabIndex = 27;
            this.tbCallFromId.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 26;
            this.label5.Text = "主叫:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 25;
            this.label4.Text = "ID对讲:";
            // 
            // tabPageSearch
            // 
            this.tabPageSearch.Controls.Add(this.btnStopRingTask);
            this.tabPageSearch.Controls.Add(this.btnStartRingTask);
            this.tabPageSearch.Controls.Add(this.tbRingTaskId);
            this.tabPageSearch.Controls.Add(this.label38);
            this.tabPageSearch.Controls.Add(this.label39);
            this.tabPageSearch.Controls.Add(this.label37);
            this.tabPageSearch.Controls.Add(this.tbnStopAlarmTask);
            this.tabPageSearch.Controls.Add(this.btnStartAlarmTask);
            this.tabPageSearch.Controls.Add(this.tbAlarmTaskId);
            this.tabPageSearch.Controls.Add(this.label36);
            this.tabPageSearch.Controls.Add(this.label34);
            this.tabPageSearch.Controls.Add(this.rbPortOut);
            this.tabPageSearch.Controls.Add(this.rbPortIn);
            this.tabPageSearch.Controls.Add(this.btnPortSearch);
            this.tabPageSearch.Controls.Add(this.tbSearchPort);
            this.tabPageSearch.Controls.Add(this.label35);
            this.tabPageSearch.Controls.Add(this.label33);
            this.tabPageSearch.Controls.Add(this.btnModifyVolume);
            this.tabPageSearch.Controls.Add(this.tbVolume);
            this.tabPageSearch.Controls.Add(this.label32);
            this.tabPageSearch.Controls.Add(this.btnModifyName);
            this.tabPageSearch.Controls.Add(this.tbTerminalName);
            this.tabPageSearch.Controls.Add(this.label31);
            this.tabPageSearch.Controls.Add(this.btnSearchTerminalCount);
            this.tabPageSearch.Controls.Add(this.btnIdSearch);
            this.tabPageSearch.Controls.Add(this.tbTerminalIP);
            this.tabPageSearch.Controls.Add(this.label27);
            this.tabPageSearch.Controls.Add(this.btnIPSearch);
            this.tabPageSearch.Controls.Add(this.btnStateSearch);
            this.tabPageSearch.Controls.Add(this.tbSearchId);
            this.tabPageSearch.Controls.Add(this.label28);
            this.tabPageSearch.Location = new System.Drawing.Point(4, 21);
            this.tabPageSearch.Name = "tabPageSearch";
            this.tabPageSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSearch.Size = new System.Drawing.Size(467, 305);
            this.tabPageSearch.TabIndex = 1;
            this.tabPageSearch.Text = "状态查询";
            this.tabPageSearch.UseVisualStyleBackColor = true;
            // 
            // btnStopRingTask
            // 
            this.btnStopRingTask.Location = new System.Drawing.Point(319, 169);
            this.btnStopRingTask.Name = "btnStopRingTask";
            this.btnStopRingTask.Size = new System.Drawing.Size(75, 23);
            this.btnStopRingTask.TabIndex = 101;
            this.btnStopRingTask.Text = "停止";
            this.btnStopRingTask.UseVisualStyleBackColor = true;
            this.btnStopRingTask.Click += new System.EventHandler(this.btnStopRingTask_Click);
            // 
            // btnStartRingTask
            // 
            this.btnStartRingTask.Location = new System.Drawing.Point(238, 169);
            this.btnStartRingTask.Name = "btnStartRingTask";
            this.btnStartRingTask.Size = new System.Drawing.Size(75, 23);
            this.btnStartRingTask.TabIndex = 100;
            this.btnStartRingTask.Text = "开始";
            this.btnStartRingTask.UseVisualStyleBackColor = true;
            this.btnStartRingTask.Click += new System.EventHandler(this.btnStartRingTask_Click);
            // 
            // tbRingTaskId
            // 
            this.tbRingTaskId.Location = new System.Drawing.Point(156, 170);
            this.tbRingTaskId.Name = "tbRingTaskId";
            this.tbRingTaskId.Size = new System.Drawing.Size(75, 21);
            this.tbRingTaskId.TabIndex = 99;
            this.tbRingTaskId.Text = "1";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(91, 174);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(59, 12);
            this.label38.TabIndex = 98;
            this.label38.Text = "任务编号:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 174);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 12);
            this.label39.TabIndex = 97;
            this.label39.Text = "定时打铃";
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label37.Location = new System.Drawing.Point(13, 162);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(441, 2);
            this.label37.TabIndex = 96;
            // 
            // tbnStopAlarmTask
            // 
            this.tbnStopAlarmTask.Location = new System.Drawing.Point(319, 132);
            this.tbnStopAlarmTask.Name = "tbnStopAlarmTask";
            this.tbnStopAlarmTask.Size = new System.Drawing.Size(75, 23);
            this.tbnStopAlarmTask.TabIndex = 95;
            this.tbnStopAlarmTask.Text = "停止";
            this.tbnStopAlarmTask.UseVisualStyleBackColor = true;
            this.tbnStopAlarmTask.Click += new System.EventHandler(this.tbnStopAlarmTask_Click);
            // 
            // btnStartAlarmTask
            // 
            this.btnStartAlarmTask.Location = new System.Drawing.Point(238, 132);
            this.btnStartAlarmTask.Name = "btnStartAlarmTask";
            this.btnStartAlarmTask.Size = new System.Drawing.Size(75, 23);
            this.btnStartAlarmTask.TabIndex = 94;
            this.btnStartAlarmTask.Text = "开始";
            this.btnStartAlarmTask.UseVisualStyleBackColor = true;
            this.btnStartAlarmTask.Click += new System.EventHandler(this.btnStartAlarmTask_Click);
            // 
            // tbAlarmTaskId
            // 
            this.tbAlarmTaskId.Location = new System.Drawing.Point(156, 133);
            this.tbAlarmTaskId.Name = "tbAlarmTaskId";
            this.tbAlarmTaskId.Size = new System.Drawing.Size(75, 21);
            this.tbAlarmTaskId.TabIndex = 93;
            this.tbAlarmTaskId.Text = "1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(91, 137);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 12);
            this.label36.TabIndex = 92;
            this.label36.Text = "任务编号:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 137);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 91;
            this.label34.Text = "消防报警";
            // 
            // rbPortOut
            // 
            this.rbPortOut.AutoSize = true;
            this.rbPortOut.Location = new System.Drawing.Point(223, 98);
            this.rbPortOut.Name = "rbPortOut";
            this.rbPortOut.Size = new System.Drawing.Size(47, 16);
            this.rbPortOut.TabIndex = 90;
            this.rbPortOut.Text = "输出";
            this.rbPortOut.UseVisualStyleBackColor = true;
            // 
            // rbPortIn
            // 
            this.rbPortIn.AutoSize = true;
            this.rbPortIn.Checked = true;
            this.rbPortIn.Location = new System.Drawing.Point(167, 98);
            this.rbPortIn.Name = "rbPortIn";
            this.rbPortIn.Size = new System.Drawing.Size(47, 16);
            this.rbPortIn.TabIndex = 89;
            this.rbPortIn.TabStop = true;
            this.rbPortIn.Text = "输入";
            this.rbPortIn.UseVisualStyleBackColor = true;
            // 
            // btnPortSearch
            // 
            this.btnPortSearch.Location = new System.Drawing.Point(288, 95);
            this.btnPortSearch.Name = "btnPortSearch";
            this.btnPortSearch.Size = new System.Drawing.Size(75, 23);
            this.btnPortSearch.TabIndex = 88;
            this.btnPortSearch.Text = "端口查询";
            this.btnPortSearch.UseVisualStyleBackColor = true;
            this.btnPortSearch.Click += new System.EventHandler(this.btnPortSearch_Click);
            // 
            // tbSearchPort
            // 
            this.tbSearchPort.Location = new System.Drawing.Point(77, 96);
            this.tbSearchPort.Name = "tbSearchPort";
            this.tbSearchPort.Size = new System.Drawing.Size(73, 21);
            this.tbSearchPort.TabIndex = 87;
            this.tbSearchPort.Text = "1";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(12, 100);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 12);
            this.label35.TabIndex = 86;
            this.label35.Text = "端口号:";
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label33.Location = new System.Drawing.Point(14, 126);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(441, 2);
            this.label33.TabIndex = 84;
            // 
            // btnModifyVolume
            // 
            this.btnModifyVolume.Location = new System.Drawing.Point(380, 67);
            this.btnModifyVolume.Name = "btnModifyVolume";
            this.btnModifyVolume.Size = new System.Drawing.Size(75, 23);
            this.btnModifyVolume.TabIndex = 83;
            this.btnModifyVolume.Text = "修改音量";
            this.btnModifyVolume.UseVisualStyleBackColor = true;
            this.btnModifyVolume.Click += new System.EventHandler(this.btnModifyVolume_Click);
            // 
            // tbVolume
            // 
            this.tbVolume.Location = new System.Drawing.Point(288, 68);
            this.tbVolume.Name = "tbVolume";
            this.tbVolume.Size = new System.Drawing.Size(86, 21);
            this.tbVolume.TabIndex = 82;
            this.tbVolume.Text = "8";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(236, 72);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(59, 12);
            this.label32.TabIndex = 81;
            this.label32.Text = "终端音量:";
            // 
            // btnModifyName
            // 
            this.btnModifyName.Location = new System.Drawing.Point(156, 68);
            this.btnModifyName.Name = "btnModifyName";
            this.btnModifyName.Size = new System.Drawing.Size(75, 23);
            this.btnModifyName.TabIndex = 80;
            this.btnModifyName.Text = "修改名称";
            this.btnModifyName.UseVisualStyleBackColor = true;
            this.btnModifyName.Click += new System.EventHandler(this.btnModifyName_Click);
            // 
            // tbTerminalName
            // 
            this.tbTerminalName.Location = new System.Drawing.Point(77, 69);
            this.tbTerminalName.Name = "tbTerminalName";
            this.tbTerminalName.Size = new System.Drawing.Size(73, 21);
            this.tbTerminalName.TabIndex = 79;
            this.tbTerminalName.Text = "终端1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 73);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 12);
            this.label31.TabIndex = 78;
            this.label31.Text = "终端名称:";
            // 
            // btnSearchTerminalCount
            // 
            this.btnSearchTerminalCount.Location = new System.Drawing.Point(318, 14);
            this.btnSearchTerminalCount.Name = "btnSearchTerminalCount";
            this.btnSearchTerminalCount.Size = new System.Drawing.Size(137, 23);
            this.btnSearchTerminalCount.TabIndex = 77;
            this.btnSearchTerminalCount.Text = "终端数量查询";
            this.btnSearchTerminalCount.UseVisualStyleBackColor = true;
            this.btnSearchTerminalCount.Click += new System.EventHandler(this.btnSearchTerminalCount_Click);
            // 
            // btnIdSearch
            // 
            this.btnIdSearch.Location = new System.Drawing.Point(156, 41);
            this.btnIdSearch.Name = "btnIdSearch";
            this.btnIdSearch.Size = new System.Drawing.Size(75, 23);
            this.btnIdSearch.TabIndex = 76;
            this.btnIdSearch.Text = "ID查询";
            this.btnIdSearch.UseVisualStyleBackColor = true;
            this.btnIdSearch.Click += new System.EventHandler(this.btnIdSearch_Click);
            // 
            // tbTerminalIP
            // 
            this.tbTerminalIP.Location = new System.Drawing.Point(77, 42);
            this.tbTerminalIP.Name = "tbTerminalIP";
            this.tbTerminalIP.Size = new System.Drawing.Size(73, 21);
            this.tbTerminalIP.TabIndex = 75;
            this.tbTerminalIP.Text = "192.168.0.11";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(12, 46);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 12);
            this.label27.TabIndex = 74;
            this.label27.Text = "终端IP:";
            // 
            // btnIPSearch
            // 
            this.btnIPSearch.Location = new System.Drawing.Point(237, 14);
            this.btnIPSearch.Name = "btnIPSearch";
            this.btnIPSearch.Size = new System.Drawing.Size(75, 23);
            this.btnIPSearch.TabIndex = 73;
            this.btnIPSearch.Text = "IP查询";
            this.btnIPSearch.UseVisualStyleBackColor = true;
            this.btnIPSearch.Click += new System.EventHandler(this.btnIPSearch_Click);
            // 
            // btnStateSearch
            // 
            this.btnStateSearch.Location = new System.Drawing.Point(156, 14);
            this.btnStateSearch.Name = "btnStateSearch";
            this.btnStateSearch.Size = new System.Drawing.Size(75, 23);
            this.btnStateSearch.TabIndex = 72;
            this.btnStateSearch.Text = "状态查询";
            this.btnStateSearch.UseVisualStyleBackColor = true;
            this.btnStateSearch.Click += new System.EventHandler(this.btnStateSearch_Click);
            // 
            // tbSearchId
            // 
            this.tbSearchId.Location = new System.Drawing.Point(77, 15);
            this.tbSearchId.Name = "tbSearchId";
            this.tbSearchId.Size = new System.Drawing.Size(73, 21);
            this.tbSearchId.TabIndex = 71;
            this.tbSearchId.Text = "1";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(12, 19);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 12);
            this.label28.TabIndex = 70;
            this.label28.Text = "终端ID:";
            // 
            // statusStripMain
            // 
            this.statusStripMain.AllowMerge = false;
            this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLabelResult});
            this.statusStripMain.Location = new System.Drawing.Point(0, 489);
            this.statusStripMain.Name = "statusStripMain";
            this.statusStripMain.Size = new System.Drawing.Size(495, 22);
            this.statusStripMain.SizingGrip = false;
            this.statusStripMain.TabIndex = 11;
            this.statusStripMain.Text = "statusStrip1";
            // 
            // tsLabelResult
            // 
            this.tsLabelResult.Name = "tsLabelResult";
            this.tsLabelResult.Size = new System.Drawing.Size(480, 17);
            this.tsLabelResult.Spring = true;
            // 
            // FormDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 511);
            this.Controls.Add(this.statusStripMain);
            this.Controls.Add(this.tabControlMain);
            this.Controls.Add(this.gbOutput);
            this.Controls.Add(this.gbConfig);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "数字IP网络广播系统SDK_C#演示程序";
            this.gbConfig.ResumeLayout(false);
            this.gbConfig.PerformLayout();
            this.gbOutput.ResumeLayout(false);
            this.tabControlMain.ResumeLayout(false);
            this.tabPageControl.ResumeLayout(false);
            this.tabPageControl.PerformLayout();
            this.tabPageSearch.ResumeLayout(false);
            this.tabPageSearch.PerformLayout();
            this.statusStripMain.ResumeLayout(false);
            this.statusStripMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbConfig;
        private System.Windows.Forms.TextBox tbStatePort;
        private System.Windows.Forms.TextBox tbServerPort;
        private System.Windows.Forms.TextBox tbServerIP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSetConfig;
        private System.Windows.Forms.GroupBox gbOutput;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageControl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbPhoneNumber;
        private System.Windows.Forms.CheckBox cbPhone;
        private System.Windows.Forms.TextBox tbCallExAreaId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnCallEx;
        private System.Windows.Forms.Button btnHangEx;
        private System.Windows.Forms.Button btnAnswerEx;
        private System.Windows.Forms.TextBox tbCallExToId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbCallExFromId;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCall;
        private System.Windows.Forms.Button btnHang;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.TextBox tbCallToId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCallFromId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPageSearch;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.TextBox tbBroadcastFromId;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnBroadcastStop;
        private System.Windows.Forms.Button btnStartBroadcast;
        private System.Windows.Forms.TextBox tbBroadcastToId;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnSpyStop;
        private System.Windows.Forms.Button btnSpyStart;
        private System.Windows.Forms.TextBox tbSpyToId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbSpyFromId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnSDStop;
        private System.Windows.Forms.Button btnSDPlay;
        private System.Windows.Forms.TextBox tbSDFileIndex;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbSDControlId;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnIOClose;
        private System.Windows.Forms.Button btnIOOpen;
        private System.Windows.Forms.TextBox tbIOControlPort;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbIOControlId;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbSearchId;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button btnSearchTerminalCount;
        private System.Windows.Forms.Button btnIdSearch;
        private System.Windows.Forms.TextBox tbTerminalIP;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnIPSearch;
        private System.Windows.Forms.Button btnStateSearch;
        private System.Windows.Forms.Button btn8AreaBroadcastStop;
        private System.Windows.Forms.Button btn8AreaBroadcastStart;
        private System.Windows.Forms.TextBox tb8AreaNumber;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tb8AreaTerminalId;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnModifyName;
        private System.Windows.Forms.TextBox tbTerminalName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnModifyVolume;
        private System.Windows.Forms.TextBox tbVolume;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RadioButton rbPortOut;
        private System.Windows.Forms.RadioButton rbPortIn;
        private System.Windows.Forms.Button btnPortSearch;
        private System.Windows.Forms.TextBox tbSearchPort;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btnStopRingTask;
        private System.Windows.Forms.Button btnStartRingTask;
        private System.Windows.Forms.TextBox tbRingTaskId;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button tbnStopAlarmTask;
        private System.Windows.Forms.Button btnStartAlarmTask;
        private System.Windows.Forms.TextBox tbAlarmTaskId;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.StatusStrip statusStripMain;
        private System.Windows.Forms.ToolStripStatusLabel tsLabelResult;
    }
}

