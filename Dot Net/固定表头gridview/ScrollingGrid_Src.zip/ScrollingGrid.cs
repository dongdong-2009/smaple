/*
 * Copyright � 2005, Ashley van Gerven (ashley.vg@gmail.com)
 * All rights reserved.
 *
 * Use in source and binary forms, with or without modification, is permitted 
 * provided that the above copyright notice and disclaimer below is not removed.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */


using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;


namespace AvgControls
{
	/// <summary>
	/// Cross-browser container control for a DataGrid to freeze it's header and bottom pager while scrolling both horizontally and vertically.
	/// </summary>
	[ToolboxData("<{0}:ScrollingGrid runat=server></{0}:ScrollingGrid>")]
	[ToolboxBitmap(typeof(ScrollingGrid), "ScrollingGridIcon.bmp")]
	public class ScrollingGrid : Panel
	{
		private DataGrid grid = null;


		/// <summary>
		/// Content DIV overflow style setting. Can be: auto, scroll, hidden
		/// </summary>
		public string Overflow = "scroll";

		/// <summary>
		/// Get/set pixel width to reduce the header by - e.g. 17 = scrollbar width (if you don't want the header to extend accross the top of the scrollbar)
		/// </summary>
		public int HeaderWidthReduction = 0;

		/// <summary>
		/// Get/set pixel width to reduce the footer by
		/// </summary>
		public int FooterWidthReduction = 0;

		/// <summary>
		/// Set to false to display the DataGrid as normal (i.e. without any scrolling or frozen header etc.)
		/// </summary>
		public bool ScrollingEnabled = true;

		/// <summary>
		/// Get/set the start scroll position of the content DIV
		/// </summary>
		public Point StartScrollPos = new Point(0, 0);

		/// <summary>
		/// Get/set the location of ScrollingGrid.js
		/// </summary>
		public string ScriptPath = "";

		/// <summary>
		/// Set to false if GridLines &amp; BorderWidth properties on DataGrid should not be set for optimal results in Firefox
		/// </summary>
		public bool FirefoxBorderWorkaround = true;



		/// <summary>
		/// Constructor
		/// </summary>
		public ScrollingGrid()
		{
			// Initialise width & height
			this.Width = 450;
			this.Height = 200;
		}


		/// <summary>
		/// Adds the necessary HTML before and after it's DataGrid child control
		/// </summary>
		/// <param name="e"></param>
		protected override void OnInit(EventArgs e)
		{
			Page.RegisterClientScriptBlock("ScrollingGrid_js", "<script language=JavaScript src=" + ScriptPath + "ScrollingGrid.js></script>");

			// find the DataGrid control
			foreach (Control c in this.Controls)
			{
				if (c is DataGrid)
				{
					grid = (DataGrid)c;
					break;
				}
			}

			if (grid != null && ScrollingEnabled)
			{
				if (FirefoxBorderWorkaround)
				{
					// for best results in Firefox set these properties on the DataGrid
					grid.GridLines = GridLines.None;
					grid.BorderWidth = 0;
				}


				StringBuilder html = new StringBuilder();

				if (grid.ShowHeader)
				{
					string divHdrStyle = "overflow:hidden;";
					if (HeaderWidthReduction > 0)
						divHdrStyle += string.Format("margin-right:{0}px;", HeaderWidthReduction);

					// header div
					html.AppendFormat("<div id={0}$divHdr style='{1}'>\r\n", this.ClientID, divHdrStyle);

					// header table borders
					string border = "0";
					string style = " style='border-collapse:collapse;'";
					if (!grid.BorderWidth.IsEmpty)
						border = grid.BorderWidth.Value.ToString();
					else if (grid.GridLines == GridLines.Both)
						border = "1";

					if (grid.CellSpacing > 0) // FF doesn't display cellspacing correctly with border-collapse style
						style = "";

					string borderColor = "";
					if (!grid.BorderColor.IsEmpty)
					{
						string colorValue = grid.BorderColor.Name;
						if (colorValue.StartsWith("ff"))
							colorValue = "#" + colorValue.Substring(2);
						borderColor = " borderColor='" + colorValue + "'";
					}

					// container table + header table
					if (grid.CellPadding == -1)
						grid.CellPadding = 2;
					string cellpadding = string.Format("cellpadding='{0}'", grid.CellPadding);
					html.AppendFormat("<table cellpadding=0 cellspacing=0 id={3}$headerCntr><tr><td><table id={3}$tblHdr border='{0}' {1} cellspacing='{2}' {4}{5}>", border, cellpadding, grid.CellSpacing, this.ClientID, borderColor, style );
					html.Append(" <tr></tr></table></td></tr></table>\r\n");

					//close header div
					html.Append("</div>\r\n");
				}


				// scrolling div + 2nd container table
				html.AppendFormat("<div id={3}$divContent style='height:{1};overflow:{2};' onscroll='updateScroll(this, \"{3}\")'><table cellpadding=0 cellspacing=0 id={3}$contentCntr><tr><td>", Width, Height, this.Overflow, this.ClientID);


				// insert our html as the first control
				this.Controls.AddAt(0, new LiteralControl(html.ToString()));


				// close container table & scrolling div (appended to end)
				string appendHtml = "";
				if (grid.ShowHeader)
					appendHtml += "</td></tr></table>\r\n";
				appendHtml += "</div>\r\n";


				// hidden input for scroll position
				appendHtml += string.Format("<input type=hidden name={0}$hdnScrollPos id={0}$hdnScrollPos>\r\n", this.ClientID);


				this.Controls.Add(new LiteralControl(appendHtml));


				// check for datagrid pager
				bool lastRowIsPager = false;
				if (grid.AllowPaging && grid.PagerStyle.Visible && (grid.PagerStyle.Position == PagerPosition.Bottom || grid.PagerStyle.Position == PagerPosition.TopAndBottom))
				{
					lastRowIsPager = true;

					// pager table underneath scrolling grid
					string tblPagerStyle = "width:100%;";
					if (FooterWidthReduction > 0)
						tblPagerStyle += string.Format("margin-right:{0}px;", FooterWidthReduction);

					this.Controls.Add(new LiteralControl( string.Format("<table id={0}$tblPager cellpadding={1} cellspacing={2} style='{3}'> <tr></tr></table>\r\n", this.ClientID, grid.CellPadding, grid.CellSpacing, tblPagerStyle) ));
				}


				// javacript to initialise grid
				if (grid.ShowHeader)
					this.Controls.Add( new LiteralControl(string.Format("<script language=javascript>\r\n<!--\r\n setTimeout(\"initScrollingGrid('{0}', '{1}', {2})\", 50) \r\n//--></script>", this.ClientID, grid.ClientID, lastRowIsPager.ToString().ToLower())) );
			}

			this.Load += new EventHandler(ScrollingGrid_Load);
			base.OnInit(e);
		}


		/// <summary>
		/// Outputs start of control's container TABLE
		/// </summary>
		/// <param name="writer"></param>
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			// bg color style
			string style = "";
			if (!this.BackColor.IsEmpty)
			{
				string colorValue = this.BackColor.Name;
				if (colorValue.StartsWith("ff"))
					colorValue = "#" + colorValue.Substring(2);
				style = string.Format("background-color:{0};", colorValue);
			}

			if (ScrollingEnabled)
				style += string.Format("width:{0};", this.Width);

			string html = string.Format("<table id={0} name=ScrollingGrid style='{1} table-layout:fixed' cellpadding=0 cellspacing=0 border=0", this.ClientID, style);
			if (this.CssClass != null && this.CssClass.Length > 0)
				html += string.Format(" class='{0}'", this.CssClass);
			html += "><tr><td>\r\n";
			writer.Write(html);
		}


		/// <summary>
		/// Outputs end of control's container TABLE
		/// </summary>
		/// <param name="writer"></param>
		public override void RenderEndTag(HtmlTextWriter writer)
		{
			writer.Write("</td></tr></table>\r\n");
		}


		/// <summary>
		/// Set starting scroll position of content DIV from postback
		/// </summary>
		public void SetStartScrollPosFromPostack()
		{
			string key = this.ClientID + "$hdnScrollPos";
			if (HttpContext.Current.Request.Form[key] != null && HttpContext.Current.Request.Form[key].Length > 0)
			{
				string[] parts = HttpContext.Current.Request.Form[key].Split('-');
				this.Controls.Add( new LiteralControl(string.Format("<script language=javascript>\r\n<!--\r\n setTimeout(\"setContentScrollPos('{0}', {1}, {2})\", 100) \r\n//--></script>", this.ClientID, parts[0], parts[1])) );
			}
		}


		/// <summary>
		/// Control's Load event handler
		/// </summary>
		private void ScrollingGrid_Load(object sender, EventArgs e)
		{
			// add JS to set the starting scroll position
			if (this.StartScrollPos.X > 0 || this.StartScrollPos.Y > 0)
				this.Controls.Add( new LiteralControl(string.Format("<script language=javascript>\r\n<!--\r\n setTimeout(\"setContentScrollPos('{0}', {1}, {2})\", 100) \r\n//--></script>", this.ClientID, this.StartScrollPos.X, this.StartScrollPos.Y)) );
		}
	}
}
