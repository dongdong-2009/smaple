using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;


namespace ScrollingGridDemo
{
	public class Demo : System.Web.UI.Page
	{
		protected DataGrid Grid2;
		protected AvgControls.ScrollingGrid sg1;

		string sortCol = "OrderID";


		override protected void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}

		
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				PopulateData();
			}

			sg1.SetStartScrollPosFromPostack();
		}


		void PopulateData()
		{
			OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OleDb.4.0; Data Source=" + Server.MapPath("data.mdb"));
			conn.Open();

			OleDbDataAdapter adap = new OleDbDataAdapter("SELECT * FROM Orders ORDER BY " + this.sortCol, conn);
			DataTable tbl = new DataTable();
			adap.Fill(tbl);

			Grid2.DataSource = tbl;

			Grid2.DataBind();

			conn.Close();
		}

		
		protected void Grid2_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
		{
			Grid2.CurrentPageIndex = e.NewPageIndex;
			PopulateData();
		}


		protected void Grid2_Sort(object sender, DataGridSortCommandEventArgs e)
		{
			this.sortCol = e.SortExpression;
			PopulateData();
		}

	}
}
