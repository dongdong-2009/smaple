using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;


namespace ScrollingGridDemo
{
	public class Demo2 : System.Web.UI.Page
	{
		protected DataSet ds = new DataSet();


		override protected void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}


		private void Page_Load(object sender, System.EventArgs e)
		{
			OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OleDb.4.0; Data Source=" + Server.MapPath("data.mdb"));

			conn.Open();

			OleDbDataAdapter adap;

			adap = new OleDbDataAdapter("SELECT * FROM Orders", conn);
			adap.Fill(ds, "orders");

			conn.Close();

			if (!IsPostBack)
				DataBind();
		}


		protected void PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			((DataGrid)source).CurrentPageIndex = e.NewPageIndex;

			DataBind();
		}
	}
}
