﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CustomControls
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:ColorPicker runat=server></{0}:ColorPicker>")]
    [System.Drawing.ToolboxBitmap(typeof(ColorPicker),"Images.color_picker_icon.jpg")]
    public class ColorPicker : WebControl
    {
        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("#000000")]
        [Localizable(true)]
        public string Color
        {
            get
            {
                String s = (String)ViewState["Color"];
                return ((s == null) ? "#000000" : s);
            }

            set
            {
                ViewState["Color"] = value;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnPreRender(e);
            // Javascript
            string colorFunctions = Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Javascript.color_functions.js");
            Page.ClientScript.RegisterClientScriptInclude("color_functions.js", colorFunctions);
            string colorPicker = Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Javascript.js_color_picker_v2.js");
            Page.ClientScript.RegisterClientScriptInclude("js_color_picker_v2.js", colorPicker);

            //Images
            string script = string.Format(@"
            var form_widget_amount_slider_handle = '{0}';
            var tab_right_active = '{1}';
            var tab_right_inactive = '{2}';
            var tab_left_active = '{3}';
            var tab_left_inactive = '{4}';
            ", Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.slider_handle.gif")
             , Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.tab_right_active.gif")
             , Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.tab_right_inactive.gif")
             , Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.tab_left_active.gif")
             , Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.tab_left_inactive.gif")
             );

            Page.ClientScript.RegisterStartupScript(Page.GetType(), "initColorPicker", script, true);

            // CSS
            HtmlGenericControl csslink = new HtmlGenericControl("link");
            csslink.Attributes.Add("href", Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Styles.js_color_picker_v2.css"));
            csslink.Attributes.Add("type", "text/css");
            csslink.Attributes.Add("rel", "stylesheet");            
            Page.Header.Controls.Add(csslink);

            if (Page.IsPostBack)
                Color = Page.Request.Form[string.Concat(ID, "_input").Replace("_", "$")];
        }

        protected override void RenderContents(HtmlTextWriter output)
        {            
            StringBuilder sb = new StringBuilder();            
            string pickerurl = Page.ClientScript.GetWebResourceUrl(typeof(ColorPicker), "CustomControls.Images.color_picker_icon.jpg");
            sb.Append(string.Format(@"<table><tr><td><input type=""text"" style=""color:{3}"" size=""10"" value=""{0}"" maxlength=""7"" id=""{1}"" name=""{2}""></td><td>",Color,string.Concat(ID,"_input"),string.Concat(ID,"_input").Replace("_","$"),Color));
            sb.Append(string.Format(@"<input type=""image"" src=""{0}"" onclick=""showColorPicker(this,document.getElementById('{1}'));return false;""></td></tr></table>", pickerurl, string.Concat(ID, "_input")));
            output.Write(sb);
        }
        public static System.Drawing.Color ConvertStringToColor(string colorString)
        {
            System.Drawing.Color color;
            if (colorString[0] == '#' && colorString.Length < 8)
            {
                string s = colorString.Substring(1);
                while (s.Length != 6)
                {
                    s = string.Concat("0", s);
                }
                int red = Convert.ToInt32(s.Substring(0, 2), 16);
                int green = Convert.ToInt32(s.Substring(2, 2), 16);
                int blue = Convert.ToInt32(s.Substring(4, 2), 16);
                color = System.Drawing.Color.FromArgb(red, green, blue);
            }
            else
            {
                color = System.Drawing.Color.FromName(colorString);
            }
            return color;
        }
        public static string ColorToString(System.Drawing.Color color)
        {
            string result;
            if (color.IsKnownColor || color.IsNamedColor || color.IsSystemColor)
            {
                result = color.Name;
            }
            else
            {
                result = string.Concat("#", color.ToArgb().ToString("X").Substring(2));
            }
            return result;
        }
    }
}
