// critter.js -- J-Critters
// Created by Linn White
// License: http://creativecommons.org/licenses/by-nc-sa/3.0/us/
// Please leave the above license information intact


function Critter(agent)
{
	var critterObject = this;
	critterObject.version = '0.5';
	critterObject.hidden = true;
	critterObject.speaking = false;
	
	//The below code was found at Codylindley.com and is released under the same CC license
	var Client = 	
	{
  		viewportWidth: function() 
		{
    		return self.innerWidth || (document.documentElement.clientWidth || document.body.clientWidth);
  		},
		viewportHeight: function() 
		{
    		return self.innerHeight || (document.documentElement.clientHeight || document.body.clientHeight);
  		},
  		viewportSize: function() 
		{
    		return { width: this.viewportWidth(), height: this.viewportHeight() };
  		}
	};
	
	//Create divs for our agent
	var parentDiv = document.createElement('div');
	var bubbleTop = document.createElement('div');
	var bubbleBottom = document.createElement('div');
	var bubbleText = document.createElement('div');
	var critterDiv = document.createElement('div');
	var critterImg = document.createElement('img');
	
	//parentDiv
	parentDiv.style.position = 'absolute';
	parentDiv.style.visibility = 'hidden';
	parentDiv.style.width = '275px';
	
	//bubbleTop
	bubbleTop.style.background = 'url(bubble.gif) no-repeat top';
	bubbleTop.style.padding = '40px 8px 0px';
	bubbleTop.style.textAlign = 'center';
	
	//bubbleBottom
	bubbleBottom.style.background = 'url(bubble.gif) no-repeat bottom';
	bubbleBottom.style.padding = '40px 8px 0px';
	bubbleBottom.style.textAlign = 'center'
	bubbleBottom.innerHTML = '&nbsp;';
	
	//bubbleText
	bubbleText.style.paddingLeft = '10px';
	bubbleText.style.paddingRight = '10px';
	
	//critterDiv
	critterDiv.style.position = 'absolute';
	critterDiv.style.visibility = 'hidden';
	
	//critterImg
	critterImg.src = agent.src;

	//Methods
	
	//Draws our critter and places it in the right place
	critterObject.DrawAgent = function()
	{
		critterImg.style.width = agent.width + 'px';
		critterImg.style.height = agent.height + 'px';
		var pageY = window.pageYOffset || document.documentElement.scrollTop;
		var pageX = window.pageXOffset || document.documentElement.scrollLeft;
		critterDiv.style.left = Client.viewportWidth() + pageX - agent.width - agent.adjustLeft + 'px';
		critterDiv.style.top = Client.viewportHeight() + pageY - agent.height - agent.adjustTop  + 'px';
	}
	
	//Draws our speech balloon, relative to the citter and the speechTop/Left offsets
	critterObject.DrawBalloon = function()
	{
		parentDiv.style.left = critterDiv.offsetLeft - parentDiv.offsetWidth + agent.speechLeft + 'px';
		parentDiv.style.top = critterDiv.offsetTop - parentDiv.offsetHeight + agent.speechTop + 'px';
	}
	
	//Function that draws both balloon and citter
	critterObject.ReDraw = function()
	{
		critterObject.DrawAgent();
		critterObject.DrawBalloon();
	}
	
	//Make the word ballon appear and say stuff
	critterObject.Say = function(myText)
	{	
		critterObject.speaking = true;
		critterObject.Show();
		bubbleText.innerHTML = myText;
		critterObject.DrawBalloon();
		parentDiv.style.visibility = 'visible';		
	}
	
	//Stop talking critter!
	critterObject.Hush = function()
	{
		critterObject.speaking = false;
		bubbleText.innerHTML = '';
		parentDiv.style.visibility = 'hidden';
	}
	
	//Show our Critter
	critterObject.Show = function()
	{
		critterObject.hidden = false;
		critterDiv.style.visibility = 'visible';
	}
	
	//Remove critter
	critterObject.Hide = function()
	{
		critterObject.speaking = false;
		critterObject.hidden = true;
		critterDiv.style.visibility = 'hidden';
		parentDiv.style.visibility = 'hidden';
	}
	
	//Remove and destroy critter
	critterObject.Destroy = function()
	{
		document.body.removeChild(critterDiv);
		document.body.removeChild(parentDiv);
		if(window.addEventListener)
		{
			window.removeEventListener('scroll', function(){critterObject.ReDraw()}, false);
			window.removeEventListener('resize', function(){critterObject.ReDraw()}, false);
			critterImg.removeEventListener('click', function(){critterObject.Click()}, false);
			critterImg.removeEventListener('mouseover', function(){critterObject.MouseIn()}, false);
			critterImg.removeEventListener('mouseout', function(){critterObject.MouseOut()}, false);
		}
		else
		{
			window.onscroll = '';
			window.onresize = '';
			critterImg.onclick = '';
			critterImg.onmouseover = '';
			critterImg.onmouseout = '';
		}
		critterObject = null;
	}
	
	//What happens when you click on the agent graphic.  Default is Hush
	critterObject.Click = function()
	{
		critterObject.Hush();
	}
	
	//What happens when you move the mouse over the image.  Default is nothing;
	critterObject.MouseIn = function()
	{
		return;
	}
	
	//What happens when you move the mouse away from the image.  Default is nothing;
	critterObject.MouseOut = function()
	{
		return;
	}
	
	//Play animation
	critterObject.Play = function(animationName)
	{
		critterImg.src = agent.animations[animationName];
		critterObject.ReDraw();
	}
	
	//Ajax GET and SAY.
	critterObject.GetSay = function(url)
	{
		var ajaxObject = new Ajax();
		if(ajaxObject)
		{
			ajaxObject.open("GET", url, true)
			ajaxObject.onreadystatechange = function()
			{
				if(ajaxObject.readyState == 4)
				{
					if(ajaxObject.status == 200)
					{
						critterObject.Say(ajaxObject.responseText);
					}
					else
					{
						// 
					}
				}
			}
			ajaxObject.send(null);	
		}
	}
	
	//Ajax POST and SAY.
	critterObject.PostSay = function(url, formArray)
	{
		var ajaxObject = new Ajax();
		if(ajaxObject)
		{
			var parameters = "";
			for(i=0; i < formArray.length; i++) {
				parameters = parameters + formArray[i].name + "=" + encodeURI(formArray[i].value) + "&";
			}
			ajaxObject.open("POST", url, true);
			ajaxObject.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			ajaxObject.setRequestHeader("Content-length", parameters.length);
			ajaxObject.setRequestHeader("Connection", "close");			
			ajaxObject.onreadystatechange = function()
			{
				if(ajaxObject.readyState == 4)
				{
					if(ajaxObject.status == 200)
					{
						critterObject.Say(ajaxObject.responseText);
					}
					else
					{
						// 
					}
				}
			}
			ajaxObject.send(parameters);
		}
	}
	
	//Ajax function
	function Ajax()
	{
		var xmlhttp = false;
		var reqObj = new Array
		(
			function() {return new ActiveXObject("Msxml2.XMLHTTP");},
			function() {return new ActiveXObject("Microsoft.XMLHTTP");},
			function() {return new XMLHttpRequest();},
			function() {return window.createRequest();}
		);
		for(var i = 0; i < reqObj.length; i++)
		{
			try
			{
				xmlhttp = reqObj[i]();
				break;
			}
			catch(err)
			{
				xmlhttp = false;
			}
		}
		reqObj = null;
		return xmlhttp;
	}
					
	
	//assign some functions
	if(window.addEventListener)
	{
		window.addEventListener('scroll', function(){critterObject.ReDraw()}, false);
		window.addEventListener('resize', function(){critterObject.ReDraw()}, false);
		critterImg.addEventListener('click', function(){critterObject.Click()}, false);
		critterImg.addEventListener('mouseover', function(){critterObject.MouseIn()}, false);
		critterImg.addEventListener('mouseout', function(){critterObject.MouseOut()}, false);
	}
	else
	{
		window.onscroll = function(){critterObject.ReDraw()};
		window.onresize = function(){critterObject.ReDraw()};
		critterImg.onclick = function(){critterObject.Click()};
		critterImg.onmouseover = function(){critterObject.MouseIn()};
		critterImg.onmouseout = function(){critterObject.MouseOut()};
	}
	
	//Add all our divs to the document
	bubbleTop.appendChild(bubbleText);
	parentDiv.appendChild(bubbleTop);
	parentDiv.appendChild(bubbleBottom);
	critterDiv.appendChild(critterImg);
	document.body.appendChild(critterDiv);
	document.body.appendChild(parentDiv);
	
	//Draw everything, starts as hidden.
	critterObject.ReDraw();
	
	return critterObject;
}