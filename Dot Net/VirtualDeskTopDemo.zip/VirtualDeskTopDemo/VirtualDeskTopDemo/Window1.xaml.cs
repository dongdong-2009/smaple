﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SatanShortcutDemo.Utility;
using System.Windows.Interop;

namespace VirtualDeskTopDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private VirtualDeskTopHelper vdtHelper;

        public Window1()
        {
            InitializeComponent();
            Application.Current.Exit += new ExitEventHandler(App_Exit);
        }

        void App_Exit(object sender, ExitEventArgs e)
        {
            //缷载系统热键
            vdtHelper.UnRegisterHotKey();
            //恢复显示所有虚拟桌面组内的窗体
            vdtHelper.Dispose();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedBtn = sender as Button;
            int targetGroupIndex = Int32.Parse(clickedBtn.Content.ToString()) - 1;

            vdtHelper.SwitchGroup(targetGroupIndex);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            vdtHelper = new VirtualDeskTopHelper(this);

            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd != null && hwnd != IntPtr.Zero)
            {
                HwndSource m_source = HwndSource.FromHwnd(hwnd);
                m_source.AddHook(new HwndSourceHook(MessageHookHandler));
            }
            //注册系统热键
            vdtHelper.RegisterHotKey(VirtualDeskTopHelper.ModifyKeys.Ctrl, VirtualDeskTopHelper.HotKey.F1ToF9);
        }

        public IntPtr MessageHookHandler(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            //window消息定义的注册的按键消息
            if (msg.Equals(0x0312))
            {
                int pc = wParam.ToInt32() - VirtualDeskTopHelper.HotKeyID;
                if (pc >= 0 && pc < 9)
                {
                    vdtHelper.SwitchGroup(pc);
                }
            }
            return IntPtr.Zero;
        }
    }
}
