using System;
using System.Threading;

class Account 
{
	int balance;

	Random r = new Random();

	public Account(int initial) 
	{
		balance = initial;
	}

	int Withdraw(int amount) 
	{

		if (balance < 0) 
		{
			throw new Exception("BalanceΪ������");
		}
		return UseLock(amount);
		//return UseMonitor(amount);
		//return UseInterlocked(amount);
		
	}
	int UseLock(int amount)
	{
		lock (this)
		{
			if (balance >= amount) 
			{
				Thread.Sleep(5);
				balance = balance - amount;
				return amount;
			} 
			else 
			{
				return 0; // transaction rejected
			}
		}
	}
	int UseMonitor(int amount)
	{
		try
		{
			//I.����ʱ��
			//Monitor.Enter(this);  
    
			//II.��ָ��ʱ����������
			if(Monitor.TryEnter(this,TimeSpan.FromSeconds(30))) 
				//��30���ڻ�ȡ����������.
			{                                                                       
				if (balance >= amount) 
				{
					Thread.Sleep(5);
					balance = balance - amount;
					return amount;
				} 
				else 
				{
					return 0; // transaction rejected
				}
			}
		}
		catch
		{
			//�����쳣���Զ������������
		}
		finally
		{
			Monitor.Exit(this);  //�������������Ƿ������󣬶����ͷŶ���
			
		}
		return 0;
	}

	int UseInterlocked(int amount)
	{
		if (balance >= amount) 
		{
			int nOld =  balance - amount;
			Thread.Sleep(5);
			balance = balance - amount;
		
			Interlocked.CompareExchange(ref balance, nOld, nOld);

			return amount;
		} 
		else 
		{
			return 0; // transaction rejected
		}
	}
	public void DoTransactions() 
	{
		for (int i = 0; i < 100; i++)
		{
			Withdraw(r.Next(-50, 100));
		}
	}
}

class Test 
{
	static Thread[] threads = new Thread[10];

	public static void Main() 
	{
		Account acc = new Account (0);
		for (int i = 0; i < 10; i++) 
		{
			Thread t = new Thread(new ThreadStart(acc.DoTransactions));
			threads[i] = t;
		}
		for (int i = 0; i < 10; i++) 
		{
			threads[i].Start();
		}
		Console.WriteLine("�߳��Ѿ���������");
		Console.ReadLine();
	}
}