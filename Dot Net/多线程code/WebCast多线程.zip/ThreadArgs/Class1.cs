using System;
using System.Threading;
 
namespace ThreadArgs
{
	public class SimpleThread
	{
		private string procParameter = ""; 
		public  SimpleThread (string strPara)
		{
			procParameter = strPara;
			
		}
		public  void WorkerMethod()
		{
			Console.WriteLine ("��������Ϊ: " + procParameter);
		}
	}
	class MainClass
	{
		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			SimpleThread st = new SimpleThread("���ǲ����ַ���!");
			Thread t  = new Thread( new ThreadStart( st.WorkerMethod ) ); 
			t.Start ();
			t.Join (Timeout.Infinite);

		}
	}
}
