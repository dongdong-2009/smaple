﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Threading;

namespace ThreadSort
{
    public partial class Form1 : Form
    {
        private int[] valueArray;
        private Random randomNumber = new Random();
        private static volatile bool swaped = true;
        private DateTime startTime;
        private DateTime endTime;
        private static volatile string strng = "";
        private Hashtable threadHolder = new Hashtable();
        private static long threadCounter = 0;
        private string ThreadAndTime;
        private string OutTxt;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnSort_Click(object sender, EventArgs e)
        {
            btnSort.Enabled = false;
            valueArray = new int[Convert.ToInt32(ddlNum.SelectedItem.ToString().Trim())];
            threadHolder.Clear();
            valueArray.Initialize();
            threadCounter = 0;
            lbMsg.Text = "排序进行中...";
            /* Insert value in to the valueArray */
            for (int i = 0; i < valueArray.Length; i++)
            {
                valueArray[i] = valueArray.Length - i;
            }
            /*	Start a timer to check the time to sort the array */
            startTime = DateTime.Now;
            /* Start threads to sort the values in the arry */
            for (int t = 0; t < Convert.ToInt32(ddlThreadNum.SelectedItem.ToString().Trim()); t++)
            {
                Thread thread = new Thread(new ThreadStart(Sort));
                thread.Name = Convert.ToString(t);
                thread.Start();
            }
        }
        public void Sort()
        {
            try
            {
                while (true)
                {
                    swaped = false;
                    for (int j = 0; j < valueArray.Length - 1; j++)
                    {
                        lock (typeof(Thread))
                        {	/* If the left-hand side value is greater swap values*/
                            if (valueArray[j] > valueArray[j + 1])
                            {
                                int T = valueArray[j];
                                valueArray[j] = valueArray[j + 1];
                                valueArray[j + 1] = T;
                                swaped = true;
                            }
                        }
                    }
                    Thread.Sleep(1);
                    if (!swaped) { break; }
                }
                Thread.CurrentThread.Abort();
            }
            catch (Exception ex)
            {
                if (Interlocked.Increment(ref threadCounter) == Convert.ToInt64(ddlThreadNum.SelectedItem.ToString().ToString().Trim()))
                    Display();
            }
        }
        public void Display()
        {
            lbMsg.Text = "排序结束..";
            strng = "";
            endTime = DateTime.Now;
            for (int i = 0; i < valueArray.Length; i++)
            { strng += valueArray[i].ToString() + " "; }
            btnSort.Enabled = true;
            TimeSpan ts = endTime - startTime;
            ThreadAndTime += "Threads: " + ddlThreadNum.SelectedItem.ToString().ToString().Trim() + " 所用毫秒数：" + Convert.ToString(ts.TotalMilliseconds) + "\r\n";
            OutTxt = strng + "\r\n";
            tbOut.Text = OutTxt;
            tbResult.Text = ThreadAndTime;
        }

        private void btnClearOut_Click(object sender, EventArgs e)
        {
            OutTxt = "";
            tbOut.Text = "";
        }

        private void btnClearTime_Click(object sender, EventArgs e)
        {
            ThreadAndTime = "";
            tbResult.Text = "";
        }
    }
}