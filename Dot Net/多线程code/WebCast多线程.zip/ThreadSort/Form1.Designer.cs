﻿namespace ThreadSort
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ddlNum = new System.Windows.Forms.ComboBox();
            this.ddlThreadNum = new System.Windows.Forms.ComboBox();
            this.btnSort = new System.Windows.Forms.Button();
            this.tbOut = new System.Windows.Forms.TextBox();
            this.tbResult = new System.Windows.Forms.TextBox();
            this.btnClearOut = new System.Windows.Forms.Button();
            this.btnClearTime = new System.Windows.Forms.Button();
            this.lbMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "数组大小：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "线程个数:";
            // 
            // ddlNum
            // 
            this.ddlNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlNum.FormattingEnabled = true;
            this.ddlNum.Items.AddRange(new object[] {
            "500",
            "700",
            "800",
            "1000",
            "1500"});
            this.ddlNum.Location = new System.Drawing.Point(92, 34);
            this.ddlNum.Name = "ddlNum";
            this.ddlNum.Size = new System.Drawing.Size(121, 20);
            this.ddlNum.TabIndex = 2;
            // 
            // ddlThreadNum
            // 
            this.ddlThreadNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlThreadNum.FormattingEnabled = true;
            this.ddlThreadNum.Items.AddRange(new object[] {
            "1",
            "2",
            "5",
            "7",
            "10"});
            this.ddlThreadNum.Location = new System.Drawing.Point(320, 37);
            this.ddlThreadNum.Name = "ddlThreadNum";
            this.ddlThreadNum.Size = new System.Drawing.Size(121, 20);
            this.ddlThreadNum.TabIndex = 3;
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(486, 37);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(75, 23);
            this.btnSort.TabIndex = 4;
            this.btnSort.Text = "排序";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // tbOut
            // 
            this.tbOut.Location = new System.Drawing.Point(23, 85);
            this.tbOut.Multiline = true;
            this.tbOut.Name = "tbOut";
            this.tbOut.ReadOnly = true;
            this.tbOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOut.Size = new System.Drawing.Size(458, 177);
            this.tbOut.TabIndex = 5;
            // 
            // tbResult
            // 
            this.tbResult.Location = new System.Drawing.Point(23, 284);
            this.tbResult.Multiline = true;
            this.tbResult.Name = "tbResult";
            this.tbResult.ReadOnly = true;
            this.tbResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbResult.Size = new System.Drawing.Size(458, 177);
            this.tbResult.TabIndex = 6;
            // 
            // btnClearOut
            // 
            this.btnClearOut.Location = new System.Drawing.Point(486, 85);
            this.btnClearOut.Name = "btnClearOut";
            this.btnClearOut.Size = new System.Drawing.Size(75, 23);
            this.btnClearOut.TabIndex = 7;
            this.btnClearOut.Text = "清空";
            this.btnClearOut.UseVisualStyleBackColor = true;
            this.btnClearOut.Click += new System.EventHandler(this.btnClearOut_Click);
            // 
            // btnClearTime
            // 
            this.btnClearTime.Location = new System.Drawing.Point(486, 284);
            this.btnClearTime.Name = "btnClearTime";
            this.btnClearTime.Size = new System.Drawing.Size(75, 23);
            this.btnClearTime.TabIndex = 8;
            this.btnClearTime.Text = "清空";
            this.btnClearTime.UseVisualStyleBackColor = true;
            this.btnClearTime.Click += new System.EventHandler(this.btnClearTime_Click);
            // 
            // lbMsg
            // 
            this.lbMsg.AutoSize = true;
            this.lbMsg.Location = new System.Drawing.Point(21, 490);
            this.lbMsg.Name = "lbMsg";
            this.lbMsg.Size = new System.Drawing.Size(0, 12);
            this.lbMsg.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 511);
            this.Controls.Add(this.lbMsg);
            this.Controls.Add(this.btnClearTime);
            this.Controls.Add(this.btnClearOut);
            this.Controls.Add(this.tbResult);
            this.Controls.Add(this.tbOut);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.ddlThreadNum);
            this.Controls.Add(this.ddlNum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "使用线程进行排序";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ddlNum;
        private System.Windows.Forms.ComboBox ddlThreadNum;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.TextBox tbOut;
        private System.Windows.Forms.TextBox tbResult;
        private System.Windows.Forms.Button btnClearOut;
        private System.Windows.Forms.Button btnClearTime;
        private System.Windows.Forms.Label lbMsg;
    }
}

