using System;
using System.Threading;
 
public class SimpleThread
{

	public delegate void Start (object o);
 
	private class Args
	{
		public object o;
		public Start s;
		public void work()
		{ 
			s(o); 
		}
	}
 
	public static Thread CreateThread (Start s, Object arg)
	{

		Args a = new Args();
		a.o = arg;
		a.s = s;
		Thread t = new Thread (new ThreadStart (a.work));
		return t;
	}
}
 
class Worker
{
	public static void WorkerMethod(object o)
	{
		Console.WriteLine ("����Ϊ: " + o);
	}
}

public class Work
{
	public static void Main()
	{
		Thread t = SimpleThread.CreateThread (new SimpleThread.Start(Worker.WorkerMethod), "�����ַ���");
		t.Start ();
		t.Join (Timeout.Infinite);
	}
}