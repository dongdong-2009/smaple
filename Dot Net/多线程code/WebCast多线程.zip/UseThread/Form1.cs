﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace UseThread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tbMain .Text += "在主进程中启动一个线程\r\n";
            Thread t = new Thread(new ThreadStart(ThreadProc));//创建一个线程
            t.Start();//启动线程

            Thread ts = new Thread(new ThreadStart(ThreadProc));//创建一个线程
            ts.Start();//启动线程
            ts.Suspend();//挂起该线程

            for (int i = 0; i < 4; i++)
            {
                tbMain .Text += "主进程输出……\r\n";
                Thread.Sleep(0);//线程被阻塞的毫秒数。0表示应挂起此线程以使其他等待线程能够执行
            }

            tbMain .Text += "主线程调用线程Join 方法直到ThreadProc1线程结束.\r\n";
            t.Join();//阻塞调用线程，直到某个线程终止时为止。
            tbMain .Text += "ThreadProc1线程结束\r\n";
            ts.Resume();
            //ts.IsBackground = true;

        }
        public void ThreadProc()
        {
            for (int i = 0; i < 10; i++)
            {
                tbMain .Text += "ThreadProc: " + i.ToString() + "\r\n";
                Thread.Sleep(0);
            }
        }

    }
}