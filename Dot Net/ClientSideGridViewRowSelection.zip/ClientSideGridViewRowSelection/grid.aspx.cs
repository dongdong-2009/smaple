using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class grid : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }




    /// <summary>
    /// Check the item being bound is actually a DataRow, if it is wire up the
    /// required html events and attach the relevant javascripts 
    /// </summary>
    /// <param name="sender">GridView1</param>
    /// <param name="e">The event args for the RowDataBound event</param>
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //check the item being bound is actually a DataRow, if it is wire up the
        //required html events and attach the relevant javascripts 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes["onmouseover"] = "javascript:setMouseOverColor(this);";
            e.Row.Attributes["onmouseout"] = "javascript:setMouseOutColor(this);";
            e.Row.Attributes["onclick"] = ClientScript.GetPostBackClientHyperlink(this.GridView1, "Select$" + e.Row.RowIndex);
        }
    }

    /// <summary>
    /// Show the 1st cell value in the web pages TextBox to show the user
    /// it is actually selecting rows at client side
    /// </summary>
    /// <param name="sender"> GridView1</param>
    /// <param name="e">The event args for the SelectedIndexChanged event</param>
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[1].Text;
    }
}
