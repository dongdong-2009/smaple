/***********************************************
JAVASCRIPT FUNCTION WHICH DOES EXPAND/COLLAPSE
************************************************/
function Toggle(obj,NavigationBarId){
	if(document.getElementById(obj).style.display == 'none'){
		document.getElementById(obj).style.display = 'block';
		document.getElementById(NavigationBarId + "_Arrow").src = '<%=WebResource("System.Web.UI.WebControls.uparrow.gif")%>';
	}
	else{
		document.getElementById(obj).style.display = 'none';
		document.getElementById(NavigationBarId + "_Arrow").src = '<%=WebResource("System.Web.UI.WebControls.downarrow.gif")%>';
	}
}