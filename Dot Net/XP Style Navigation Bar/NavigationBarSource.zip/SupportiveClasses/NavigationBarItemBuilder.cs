using System;
using System.Web.UI;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// Interacts with the parser to build a NavigationBarItem control
	/// </summary>
	public class NavigationBarItemBuilder : ControlBuilder
	{
		public NavigationBarItemBuilder()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public override bool AllowWhitespaceLiterals()
		{
			return false;
		}

		public override bool HtmlDecodeLiterals()
		{
			return true;
		}
	}
}
