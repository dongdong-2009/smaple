using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using System.Web.UI.Design.WebControls;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// Summary description for NavigationBarDesigner.
	/// </summary>
	public class NavigationBarDesigner : ControlDesigner
	{
		private NavigationBar _NavigationBar;
		public NavigationBarDesigner()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public override void Initialize(System.ComponentModel.IComponent component)
		{
			base.Initialize (component);
			this._NavigationBar = (NavigationBar)component;
		}
	}
}
