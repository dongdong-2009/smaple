using System;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Reflection;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// Summary description for NavigationBarItemConverter.
	/// </summary>
	public class NavigationBarItemConverter : ExpandableObjectConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			if(destinationType == typeof(InstanceDescriptor))
			{
				return true;
			}
			return base.CanConvertTo (context, destinationType);
		}

		public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
		{
			if (destinationType == typeof(InstanceDescriptor) && value is NavigationBarItem)
			{
				NavigationBarItem item = (NavigationBarItem)value;
              
				ConstructorInfo ci = typeof(NavigationBarItem).
					GetConstructor(new Type[] {});
				if (ci != null)
				{
					return new InstanceDescriptor(ci, null, false);
				}
			}
			return base.ConvertTo (context, culture, value, destinationType);
		}

	}
}
