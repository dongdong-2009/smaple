/*************************************************************************************************
 * NAVIGATION BAR CUSTOM SERVER CONTROL. 
 * PROGRAMMED BY    : NAVANEETH.K.N
 * DATE             : SEP 27, 2007
 * ***********************************************************************************************/

using System;
using System.ComponentModel;
using System.Collections;
using System.IO;
using System.Globalization;
using System.Resources;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Drawing;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// 
	/// </summary>
	[ToolboxData("<{0}:NavigationBar runat=server></{0}:NavigationBar>"),ParseChildren(true,"Items"),PersistChildren(false),DefaultProperty("ID"),Designer(typeof(NavigationBarDesigner))]
	public class NavigationBar : System.Web.UI.WebControls.WebControl
	{
		
		//Initializing collection class
		private NavigationBarItemsCollection _Items = new NavigationBarItemsCollection();
		private bool _Collapsed = false;
		private string _HeaderText = "Menu Header";
		private string _HeaderFont = "Arial";
		private string _ItemsFont = "Arial";
		private string _HeaderFontSize = "2";
		private string _ItemsFontSize = "2";
		private string _HeaderCssClass = string.Empty;
		private string _ItemsCssClass = string.Empty;
		private Color _PanelColor = Color.FromArgb(122,161,230);
		private Color _ItemsBgColor = Color.FromArgb(214,223,247);
		private string _MenuItemSpace = "5";
		private Color _HeaderForeColor = Color.FromArgb(33,93,198);
		private string _SpacerWidth = "1";

        #region ControlProperties

        /// <summary>
        /// Gets a collection of NavigationBar item objects
        /// </summary>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content), Editor(typeof(System.ComponentModel.Design.CollectionEditor), typeof(System.Drawing.Design.UITypeEditor)), PersistenceMode(PersistenceMode.InnerDefaultProperty), MergableProperty(false)]
		public NavigationBarItemsCollection Items
		{
			get { return _Items; }
		}

		

        /// <summary>
        /// Indicates navigation bar to be collapsed
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Indicates menu appearance behaviour")]
		public bool Collapsed
		{
			get 
            {
                if (this.ViewState["Collapsed"] != null)
                    _Collapsed = (bool)this.ViewState["Collapsed"];
                return _Collapsed;
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["Collapsed"] = value;
                else
                    _Collapsed = value;
            }
		}

        /// <summary>
        /// Gets or sets header text
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Header text for the menu")] 
		public string HeaderText
		{
			get 
            {
                if (this.ViewState["HeaderText"] != null)
                    _HeaderText = (string)this.ViewState["HeaderText"];
                return _HeaderText; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["HeaderText"] = value;
                else
                    _HeaderText = value;
            }
		}

        /// <summary>
        /// Gets or sets header font
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Header font")] 
		public string HeaderFont
		{
            get 
            {
                if (this.ViewState["HeaderFont"] != null)
                    _HeaderFont = (string)this.ViewState["HeaderFont"];
                return _HeaderFont; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["HeaderFont"] = value;
                else
                    _HeaderFont = value;
            }
		}

        /// <summary>
        /// Gets or sets header font size
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Header font size")] 
		public string HeaderFontSize
		{
            get 
            {
                if (this.ViewState["HeaderFontSize"] != null)
                    _HeaderFontSize = (string)this.ViewState["HeaderFontSize"];
                return _HeaderFontSize; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["HeaderFontSize"] = value;
                else
                    _HeaderFontSize = value;
            }
		}

        /// <summary>
        /// Gets or sets navigationbar items font face
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Items font")] 
		public string ItemsFont
		{
            get 
            {
                if (this.ViewState["ItemsFont"] != null)
                    _ItemsFont = (string)this.ViewState["ItemsFont"];
                return _ItemsFont; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["ItemsFont"] = value;
                else
                    _ItemsFont = value;
            }
		}

        /// <summary>
        /// Gets or sets navigationbar items font size
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Items font size")] 
		public string ItemsFontSize
		{
            get 
            {
                if (this.ViewState["ItemsFontSize"] != null)
                    _ItemsFontSize = (string)this.ViewState["ItemsFontSize"];
                return _ItemsFontSize; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["ItemsFontSize"] = value;
                else
                    _ItemsFontSize = value;
            }
		}

        /// <summary>
        /// Gets or sets style sheet class for header
        /// </summary>
		[Bindable(true), 
		Category("Styles"),Description("CSS Class name for header")] 
		public string HeaderCssClass
		{
            get 
            {
                if (this.ViewState["HeaderCssClass"] != null)
                    _HeaderCssClass = (string)this.ViewState["HeaderCssClass"];
                return _HeaderCssClass; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["HeaderCssClass"] = value;
                else
                    _HeaderCssClass = value;
            }
		}

        /// <summary>
        /// Gets or sets stylesheet class for items
        /// </summary>
		[Bindable(true), 
		Category("Styles"),Description("CSS Class name for items")] 
		public string ItemsCssClass
		{
            get 
            {
                if (this.ViewState["ItemsCssClass"] != null)
                    _ItemsCssClass = (string)this.ViewState["ItemsCssClass"];
                return _ItemsCssClass; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["ItemsCssClass"] = value;
                else
                    _ItemsCssClass = value;
            }
		}

        /// <summary>
        /// Gets or sets panel color
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Panel color")] 
		public Color PanelColor
		{
            get 
            {
                if (this.ViewState["PanelColor"] != null)
                    _PanelColor = (Color)this.ViewState["PanelColor"];
                return _PanelColor; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["PanelColor"] = value;
                else
                    _PanelColor = value;
            }
		}

        /// <summary>
        /// Gets or sets items background color
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Items background color")] 
		public Color ItemsBgColor
		{
            get 
            {
                if (this.ViewState["ItemsBgColor"] != null)
                    _ItemsBgColor = (Color)this.ViewState["ItemsBgColor"];
                return _ItemsBgColor; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["ItemsBgColor"] = value;
                else
                    _ItemsBgColor = value;
            }
		}

        /// <summary>
        /// Gets or sets header fore color
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Header ForeColor")] 
		public Color HeaderForeColor
		{
            get 
            {
                if (this.ViewState["HeaderForeColor"] != null)
                    _HeaderForeColor = (Color)this.ViewState["HeaderForeColor"];
                return _HeaderForeColor; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["HeaderForeColor"] = value;
                else
                    _HeaderForeColor = value;
            }
		}

        /// <summary>
        /// Gets or sets space between each menu item
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Space between each menu item")] 
		public string MenuItemSpace
		{
            get 
            {
                if (this.ViewState["MenuItemSpace"] != null)
                    _MenuItemSpace = (string)this.ViewState["MenuItemSpace"];
                return _MenuItemSpace; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["MenuItemSpace"] = value;
                else
                    _MenuItemSpace = value;
            }
		}

        /// <summary>
        /// Gets or sets spacer width between left image and menu link
        /// </summary>
		[Bindable(true), 
		Category("Appearance"),Description("Space to show in between left image and hyper link")] 
		public string SpacerWidth
		{
            get 
            {
                if (this.ViewState["SpacerWidth"] != null)
                    _SpacerWidth = (string)this.ViewState["SpacerWidth"];
                return _SpacerWidth; 
            }
			set 
            {
                if (this.EnableViewState)
                    ViewState["SpacerWidth"] = value;
                else
                    _SpacerWidth = value;
            }
		}

		#endregion

		/// <summary>
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			NavigationBarParser parser = new NavigationBarParser(this);
			output.Write(parser.RenderNavigationBar());
		}

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            //Registering client script
            this.Page.ClientScript.RegisterClientScriptInclude(this.GetType(), "NavigationBarJS",
                this.Page.ClientScript.GetWebResourceUrl(this.GetType(), "System.Web.UI.WebControls.NavigationBar.js"));
        }

        #region StateManagement

        protected override void TrackViewState()
        {
            base.TrackViewState();
            ((IStateManager)this.Items).TrackViewState();
        }

        protected override object SaveViewState()
        {
            Pair p = new Pair();
            p.First = base.SaveViewState();
            p.Second = ((IStateManager)this.Items).SaveViewState();
            if (p == null)
                return null;
            else
                return p;

        }

        protected override void LoadViewState(object savedState)
        {
            if (savedState != null)
            {
                Pair p = (Pair)savedState;
                base.LoadViewState(p.First);
                ((IStateManager)this.Items).LoadViewState(p.Second);
            }
        }

        #endregion
    }
}
