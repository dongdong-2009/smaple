using System;
using System.Collections.Generic;
using System.Text;

namespace System.Web.UI.WebControls
{
    /// <summary>
    /// Manages with embeded resource in the control. This class can't be inherited
    /// </summary>
    public sealed class EmbeddedResourceManager
    {
        private NavigationBar _NavigationBar;   //Navigation bar object

        /// <summary>
        /// Initializes Embedded resource manager class
        /// </summary>
        /// <param name="Bar">Navigation bar object</param>
        public EmbeddedResourceManager(NavigationBar Bar)
        {
            _NavigationBar = Bar;
        }

        /// <summary>
        /// Gets header background image
        /// </summary>
        public string HeaderBackground
        {
            get
            {
                string BgUrl = _NavigationBar.Page.ClientScript.GetWebResourceUrl
                    (_NavigationBar.GetType(), "System.Web.UI.WebControls.headerbg.gif");
                return BgUrl;
            }
        }

        /// <summary>
        /// Top arrow
        /// </summary>
        public string UpArrow
        {
            get
            {
                string StrReturn = _NavigationBar.Page.ClientScript.GetWebResourceUrl
                    (_NavigationBar.GetType(), "System.Web.UI.WebControls.uparrow.gif");
                return StrReturn;
            }
        }

        /// <summary>
        /// Down arrow
        /// </summary>
        public string DownArrow
        {
            get
            {
                string StrReturn = _NavigationBar.Page.ClientScript.GetWebResourceUrl
                    (_NavigationBar.GetType(), "System.Web.UI.WebControls.downarrow.gif");
                return StrReturn;
            }
        }

        /// <summary>
        /// Spacer
        /// </summary>
        public string Spacer
        {
            get
            {
                string StrReturn = _NavigationBar.Page.ClientScript.GetWebResourceUrl
                    (_NavigationBar.GetType(), "System.Web.UI.WebControls.spacer.gif");
                return StrReturn;
            }
        }

        /// <summary>
        /// Spacer
        /// </summary>
        public string DefaultLeft
        {
            get
            {
                string StrReturn = _NavigationBar.Page.ClientScript.GetWebResourceUrl
                    (_NavigationBar.GetType(), "System.Web.UI.WebControls.left1.gif");
                return StrReturn;
            }
        }
    }

    
}
