using System;
using System.Web.UI.WebControls;
using System.Collections;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// A collection of System.Web.UI.WebControls.XPStyleNavigationBar.NavigationBarItem. 
	/// This class can't be inherited
	/// </summary>
	public sealed class NavigationBarItemsCollection : ICollection , IEnumerable , IList , IStateManager
	{
		ArrayList _Items = new ArrayList();
        private bool _IsTrackingViewState = false;

		public NavigationBarItemsCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region CollectionMembers

		public NavigationBarItem this[int index]
		{
			get
			{
				return (NavigationBarItem)this._Items[index];
			}
			set
			{
				this._Items[index] = (NavigationBarItem)value;
			}
		}

		/// <summary>
		/// Adds NavigationBarItem objects to collection
		/// </summary>
		/// <param name="item">Item Object</param>
		/// <returns></returns>
		public int Add(NavigationBarItem item)
		{
			return this._Items.Add(item);
		}


		/// <summary>
		/// Removes all NavigationBarItem objects from collection
		/// </summary>
		public void Clear()
		{
			this._Items.Clear();
		}

		/// <summary>
		/// Removes NavigationBarItem object from the specified index
		/// </summary>
		/// <param name="index"></param>
		public void RemoveAt(int index)
		{
			this._Items.RemoveAt(index);
		}

		public int Count
		{
			get
			{
				return this._Items.Count;
			}
		}

		public bool IsSynchronized
		{
			get
			{
				return this._Items.IsSynchronized;
			}
		}

		public void CopyTo(Array array, int index)
		{
			this._Items.CopyTo(array, index);
		}

		public object SyncRoot
		{
			get
			{
				return this._Items.SyncRoot;
			}
		}

		public IEnumerator GetEnumerator()
		{
			return this._Items.GetEnumerator();
		}

		/// <summary>
		/// Checks the specified value contained in the collection
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public bool Contains(NavigationBarItem value)
		{
			return this._Items.Contains(value);
		}

		/// <summary>
		/// Searches for the specified NavigationBarItem object
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public int IndexOf(NavigationBarItem value)
		{
			return this._Items.IndexOf(value);
		}

		/// <summary>
		/// Inserts NavigationBarItem object to the specified location
		/// </summary>
		/// <param name="index"></param>
		/// <param name="value"></param>
		public void Insert(int index, NavigationBarItem value)
		{
			this._Items.Insert(index, value);
		}

		/// <summary>
		/// Removes first occurance of a specified NavigationBarItem object
		/// </summary>
		/// <param name="value"></param>
		public void Remove(NavigationBarItem value)
		{
			this._Items.Remove(value);
		}


		#endregion

		#region IListMembers

		int IList.Add(object item)
		{
			NavigationBarItem item1 = (NavigationBarItem) item;
			int num1 = this._Items.Add(item1);
			return num1;
		}

		bool IList.Contains(object item)
		{
			return this.Contains((NavigationBarItem) item);
		}

		bool IList.IsFixedSize
		{
			get
			{
				return false;
			}
		}

		object IList.this[int index]
		{
			get
			{
				return this._Items[index];
			}
			set
			{
				this._Items[index] = (NavigationBarItem)value;
			}
		}

		bool IList.IsReadOnly
		{
			get
			{
				return this._Items.IsReadOnly;
			}
		}

		int IList.IndexOf(object item)
		{
			return this.IndexOf((NavigationBarItem) item);
		}

		void IList.Insert(int index, object item)
		{
			this.Insert(index, (NavigationBarItem) item);
		}

		void IList.Remove(object item)
		{
			this.Remove((NavigationBarItem) item);
		}

		#endregion

        #region StateManagement

        bool IStateManager.IsTrackingViewState
        {
            get { return this._IsTrackingViewState; }
        }

        void IStateManager.TrackViewState()
        {
            this._IsTrackingViewState = true;
            //Iterating through items and instructs to track viewstate
            for (int i = 0; i < this._Items.Count; i++)
            {
                ((IStateManager)this[i]).TrackViewState();
            }
        }

        object IStateManager.SaveViewState()
        {
            //Iterating through each item and calling saveviewstate
            ArrayList ObjArr = new ArrayList();
            for (int i = 0; i <= this._Items.Count-1; i++)
            {
                object obj = ((IStateManager)this[i]).SaveViewState();
                ObjArr.Add(obj);
            }
            return ObjArr;
        }

        void IStateManager.LoadViewState(object savedState)
        {
            //Iterating through the saved items. Loading each one to the collection
            if (savedState == null)
                return;     //Saved state is null. Nothing to load.

            if (savedState is ArrayList)
            {
                ArrayList ObjArr = (ArrayList)savedState;   //Casting from viewstate
                for (int i = 0; i < ObjArr.Count; i++)
                {
                    NavigationBarItem item = new NavigationBarItem();
                    ((IStateManager)item).LoadViewState(ObjArr[i]);
                }
            }
        }

        #endregion

    }
}
