using System;
using System.Text;


namespace System.Web.UI.WebControls
{
	/// <summary>
	/// Parses control. This class can't be inherited
	/// </summary>
	public sealed class NavigationBarParser
	{
		private NavigationBar _NavigationBar = null;
        private EmbeddedResourceManager Resource = null;    //Used to manage embedded resources
		public NavigationBarParser( NavigationBar NavBar )
		{
			_NavigationBar = NavBar;
            Resource = new EmbeddedResourceManager(NavBar);
		}

		/// <summary>
		/// Render navigation bar
		/// </summary>
		/// <returns></returns>
		public string RenderNavigationBar()
		{
			StringBuilder oSb = new StringBuilder();
			//Rendering starting outer panel
			oSb.Append(this.StartOuterPanel());
			oSb.Append(this.StartMenuHeader());
			oSb.Append(this.StartMenuItems());
			oSb.Append(this.EndMenuHeader());
			oSb.Append(this.EndOuterPanel());
			return oSb.ToString();
		}

		

		/// <summary>
		/// Generates outer panel for the control.
		/// </summary>
		/// <returns></returns>
		private string StartOuterPanel()
		{
			string PanelBgColor = _NavigationBar.PanelColor.Name;
			if ( PanelBgColor.StartsWith("ff") )
				PanelBgColor = "#" + PanelBgColor.Remove(0,2);
			//Panel will be named with control name + panel
			StringBuilder oSb = new StringBuilder();
			oSb.Append("<TABLE id=\"" + _NavigationBar.ID + 
				"Panel\" cellSpacing=\"0\" cellPadding=\"0\" width=\"210\" border=\"0\">" + Environment.NewLine );
			oSb.Append("<tr>" + Environment.NewLine);
			oSb.Append("<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 10px; PADDING-TOP: 10px\" bgColor=\"" + PanelBgColor + "\" align=\"center\">");
			oSb.Append(Environment.NewLine);
			return oSb.ToString();
		}

		/// <summary>
		/// Ends outer panel
		/// </summary>
		/// <returns></returns>
		private string EndOuterPanel()
		{
			StringBuilder oSb = new StringBuilder();
			oSb.Append("</td></tr></table>");
			return oSb.ToString();
		}

		/// <summary>
		/// Render menu header
		/// </summary>
		/// <returns></returns>
		private string StartMenuHeader()
		{
			string HeaderForeColor = _NavigationBar.HeaderForeColor.Name;
			if ( HeaderForeColor.StartsWith("ff") )
				HeaderForeColor = "#" + HeaderForeColor.Remove(0,2);
			StringBuilder oSb = new StringBuilder();
			oSb.Append("<TABLE id=\"" + _NavigationBar.ID + "_MenuHeader\" cellSpacing=\"0\" cellPadding=\"0\" width=\"190\" border=\"0\">");
			oSb.Append(Environment.NewLine);
			oSb.Append("<tr>");
			//oSb.Append("<TD align='left' style=\"PADDING-LEFT: 3px; BACKGROUND-POSITION: right; BACKGROUND-IMAGE: url(" + _NavigationBar.ImageLookUpPath + "headerbg.JPG); BACKGROUND-REPEAT: no-repeat\" width=\"95%\" bgColor=\"#ffffff\">");
            oSb.Append("<TD align='left' style=\"PADDING-LEFT: 3px; BACKGROUND-POSITION: right; BACKGROUND-IMAGE: url(" + Resource.HeaderBackground + "); BACKGROUND-REPEAT: no-repeat\" width=\"95%\" bgColor=\"#ffffff\">");
			//appending header. Checking any CSSClass specified
			if ( _NavigationBar.HeaderCssClass == "" )
				oSb.Append("<font size=\"" + _NavigationBar.HeaderFontSize + "\" face=\"" + _NavigationBar.HeaderFont + "\" color=\"" + HeaderForeColor + "\"><strong>" + _NavigationBar.HeaderText + "</strong></font>");
			else
				oSb.Append("<span class=\"" + _NavigationBar.HeaderCssClass + "\"><font color=\"" + HeaderForeColor +
					"\">" + _NavigationBar.HeaderText +	"</font></span>");
			oSb.Append(Environment.NewLine);
			oSb.Append("</td>");
			if ( _NavigationBar.Collapsed )
				oSb.Append("<TD align=\"right\" width=\"5%\"><a onclick=\"Toggle('" + _NavigationBar.ID + "_Items" + "','" + _NavigationBar.ID + "');\"><IMG id=\"" + _NavigationBar.ID + "_Arrow" + "\" border='0' alt=\"Colapse Panel\" src=\"" + 
					Resource.DownArrow  + "\"></a></TD>");
			else
				oSb.Append("<TD align=\"right\" width=\"5%\"><a onclick=\"Toggle('" + _NavigationBar.ID + "_Items" + "','" + _NavigationBar.ID + "');\"><IMG id=\"" + _NavigationBar.ID + "_Arrow" + "\" border='0' alt=\"Expand Panel\" src=\"" + 
					Resource.UpArrow + "\"></a></TD>");
			oSb.Append("</tr>");
			return oSb.ToString();
		}

		/// <summary>
		/// Ends menu header
		/// </summary>
		/// <returns></returns>
		private string EndMenuHeader()
		{
			return "</table>";
		}

		/// <summary>
		/// Renders menu items
		/// </summary>
		/// <returns></returns>
		private string StartMenuItems()
		{
			string ItemBgColor = _NavigationBar.ItemsBgColor.Name;
			if ( ItemBgColor.StartsWith("ff") )
				ItemBgColor = "#" + ItemBgColor.Remove(0,2);

			StringBuilder oSb = new StringBuilder();
			oSb.Append("<tr>");
			oSb.Append("<TD style=\"PADDING-LEFT: 5px\" bgColor=\"" + ItemBgColor + "\" colSpan=\"2\">");
			oSb.Append(Environment.NewLine);
			//Starting item table
			//If it is collapsed, then setting display to none
			if ( _NavigationBar.Collapsed )
				oSb.Append("<TABLE style=\"display:none\" id=\"" + _NavigationBar.ID + "_Items\" cellSpacing=\"0\" cellPadding=\"0\" width=\"100%\" border=\"0\">");
			else
				oSb.Append("<TABLE id=\"" + _NavigationBar.ID + "_Items\" cellSpacing=\"0\" cellPadding=\"0\" width=\"100%\" border=\"0\">");
			oSb.Append(Environment.NewLine);

            //First spacer before items starts
            oSb.Append("<tr><td colspan=\"3\"><img src=\"" + Resource.Spacer + "\" width='1' height='" + 
                        _NavigationBar.MenuItemSpace + "'></td></tr>");

			//Iterating through items
			foreach(NavigationBarItem item in _NavigationBar.Items)
			{
				if ( item.Visible )
				{
					oSb.Append("<tr>" + Environment.NewLine);
                    if ( item.ImagePath != "" )
					    oSb.Append("<TD align='center'><IMG border='0' alt=\"" + item.ToolTip + "\" src=\"" + 
						    item.ImagePath + "\"></TD>");
                    else
                        oSb.Append("<TD align='center'><IMG border='0' alt=\"" + item.ToolTip + "\" src=\"" +
                            Resource.DefaultLeft + "\"></TD>");   //Putting default image there
					oSb.Append(Environment.NewLine);
					//Inserting spacer image
					oSb.Append("<TD><IMG src=\"" +  Resource.Spacer + "\" width='" + _NavigationBar.SpacerWidth + "'></TD>");
					if ( _NavigationBar.ItemsCssClass == "" )
						oSb.Append("<TD align='left' width=\"85%\"><a style=\"text-decoration: none;\" target='" + item.Target + "' href='" + item.LinkURL + "' title='" + item.ToolTip + 
							"'><font size=\"" + _NavigationBar.ItemsFontSize + "\" face=\"" + _NavigationBar.ItemsFont + "\">" + item.LinkText + "</font></a></TD>");
					else
						oSb.Append("<TD align='left' width=\"85%\"><a target='" + item.Target + "' href='" + item.LinkURL + "' title='" + item.ToolTip + 
							"' class='" + _NavigationBar.ItemsCssClass + "'>" + item.LinkText + "</a></TD>");
					oSb.Append(Environment.NewLine);
					oSb.Append("</tr>");

                    //Inserting spacer between menu item
                    oSb.Append("<tr><td colspan=\"3\"><img src=\"" + Resource.Spacer + "\" width='1' height='" + 
                        _NavigationBar.MenuItemSpace + "'></td></tr>");
				}
			}
			oSb.Append("</table></td></tr>");
			return oSb.ToString();
		}
		
	}
}
