using System;
using System.ComponentModel;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace System.Web.UI.WebControls
{
	/// <summary>
	/// Represents an item in the NavigationBarControl. This class can't be inherited
	/// </summary>
	[ControlBuilder(typeof(NavigationBarItemBuilder)),DesignTimeVisible(false), TypeConverter(typeof(System.Web.UI.WebControls.NavigationBarItemConverter))]
	public class NavigationBarItem : IStateManager
	{
		private string _Text = "Menu Item";	//Used for storing items text
		private string _Url = "http://";		//Used for navigate url
		private string _ImagePath = string.Empty;	//Used for image path
		private string _ToolTip = string.Empty;
		private string _Target = "_self";
		private bool _Visible = true;

        private bool _IsTrackingViewState = false;

        #region Constructors

        /// <summary>
        /// Initializes a new navigation bar item
        /// </summary>
		public NavigationBarItem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

        /// <summary>
        /// Initializes a new navigation bar item
        /// </summary>
        /// <param name="_LinkText">Text to be displayed</param>
        /// <param name="_LinkURL">URL, where the link to be pointed</param>
        /// <param name="_Image">Image path.</param>
        /// <param name="_LinkToolTip">Tooltip text for the link</param>
        public NavigationBarItem(string _LinkText,string _LinkURL,string _Image,string _LinkToolTip)
        {
            this.LinkText = _LinkText;
            this.LinkURL = _LinkURL;
            this.ImagePath = _Image;
            this.ToolTip = _LinkToolTip;
        }

        /// <summary>
        /// Initializes a new navigation bar item
        /// </summary>
        /// <param name="_LinkText">Text to be displayed on the link</param>
        /// <param name="_LinkURL">Link URL</param>
        /// <param name="_LinkToolTip">Tooltip for link</param>
        public NavigationBarItem(string _LinkText, string _LinkURL, string _LinkToolTip)
        {
            this.LinkText = _LinkText;
            this.LinkURL = _LinkURL;
            this.ToolTip = _LinkToolTip;
        }

        #endregion

        #region ItemProperties

        [Bindable(true), 
		Category("Link"),Description("Text displayed for the link")] 
		public string LinkText
		{
			get { return _Text; }
			set { _Text = value; }
		}

		[Bindable(true), 
		Category("Link"),Description("Destination URL")] 
		public string LinkURL
		{
			get { return _Url; }
			set { _Url = value; }
		}

		[Bindable(true), 
		Category("Link"),Description("URL for left image")] 
		public string ImagePath
		{
			get { return _ImagePath; }
			set { _ImagePath = value; }
		}

		[Bindable(true), 
		Category("Link"),Description("Target frame for the link. _self opens on same window. _blank opens on a new window")] 
		public string Target
		{
			get { return _Target; }
			set { _Target = value; }
		}

		[Bindable(true), 
		Category("Link"),Description("Mouseover description for the link")] 
		public string ToolTip
		{
			get { return _ToolTip; }
			set { _ToolTip = value; }
		}

		[Bindable(true), 
		Category("Link"),Description("Indicates this items should be rendered or not")] 
		public bool Visible
		{
			get { return _Visible; }
			set { _Visible = value; }
		}

		#endregion

        #region StateManagement

        object IStateManager.SaveViewState()
        {
            ArrayList ObjArr = new ArrayList();
            ObjArr.Add(this.ImagePath);
            ObjArr.Add(this.LinkText);
            ObjArr.Add(this.LinkURL);
            ObjArr.Add(this.Target);
            ObjArr.Add(this.ToolTip);
            ObjArr.Add(this.Visible);
            return ObjArr;
        }

        void IStateManager.LoadViewState(object savedState)
        {
            //Restoring values from viewstate
            if (savedState != null && savedState is ArrayList)
            {
                ArrayList ObjArr = (ArrayList)savedState;
                this.ImagePath = (string) ObjArr[0];
                this.LinkText = (string)ObjArr[1];
                this.LinkURL = (string)ObjArr[2];
                this.Target = (string)ObjArr[3];
                this.ToolTip = (string)ObjArr[4];
                this.Visible = (bool)ObjArr[5];
            }
        }

        void IStateManager.TrackViewState()
        {
            this._IsTrackingViewState = true;
        }

        [Browsable(false)]
        bool IStateManager.IsTrackingViewState
        {
            get
            {
                return this._IsTrackingViewState;
            }
        }

        #endregion


    }
}
