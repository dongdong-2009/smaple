Imports System.Data
Imports clsDatabase

Partial Class _Default
    Inherits System.Web.UI.Page

    Dim cDatabase As New clsDatabase
    Dim cExcel As New clsExcel
    Dim bClicked As Boolean

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            txtDatabase.Text = "Northwind"
            txtFilename.Text = "C:\Northwind.xls"
        End If
    End Sub

    Protected Sub btnCreate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        If (Not bClicked) Then
            If (txtFilename.Text.Length > 0 And txtDatabase.Text.Length > 0) Then
                Dim dsDataset As DataSet

                'Get all Tables from database
                dsDataset = cDatabase.getAllTables(txtDatabase.Text)

                'Fill the Excel file
                lblResult.Text = cExcel.Create(txtFilename.Text, dsDataset)

                'Offer the file for download
                Try
                    HttpContext.Current.Response.ContentType = "application/octet-stream"
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.IO.Path.GetFileName(txtFilename.Text))
                    HttpContext.Current.Response.Clear()
                    HttpContext.Current.Response.WriteFile(txtFilename.Text)
                Catch ex As Exception

                End Try
            Else
                lblResult.Text = "Database name or Filename should not be empty!!"
            End If
        End If
        bClicked = Not bClicked
    End Sub
End Class
