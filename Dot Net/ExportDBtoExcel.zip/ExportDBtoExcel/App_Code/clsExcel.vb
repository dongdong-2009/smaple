Imports System.Data
Imports System.Runtime.InteropServices.Marshal


Public Class clsExcel
    Public Function Create(ByVal sFile As String, ByVal dsDataset As DataSet) As String
        Dim sResult As String = ""
        Dim dtTable As DataTable

        'Create Excel Application, Workbook, and WorkSheets
        Dim xlExcel As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlBook As Excel.Workbook
        Dim tblSheet As Excel.Worksheet
        Dim xlCells As Excel.Range

        xlExcel.Visible = False : xlExcel.DisplayAlerts = False
        xlBooks = xlExcel.Workbooks
        xlBook = xlBooks.Add

        Try
            For i As Integer = 0 To dsDataset.Tables.Count - 1
                dtTable = dsDataset.Tables(i)
                tblSheet = xlBook.Worksheets.Add
                tblSheet.Name = dtTable.TableName
                xlCells = tblSheet.Cells
                For iCol As Integer = 0 To dtTable.Columns.Count - 1
                    xlCells(1, iCol + 1) = dtTable.Columns(iCol).ToString
                    xlCells(1).EntireRow.Font.Bold = True
                Next
                If dsDataset.Tables(i).Rows.Count > 0 Then
                    tblSheet.Range("A2").CopyFromRecordset(ConvertToRecordset(dtTable))
                End If
                xlCells.Columns.AutoFit()
            Next
            sResult = "OK"
        Catch ex As Exception
            sResult = ex.Message
        End Try

        'Remove initial excel sheets. Within a try catch because the database could be empty 
        '(a workbook without worksheets is not allowed)
        Try
            Dim SheetCount As Integer = xlExcel.Sheets.Count
            CType(xlExcel.Sheets(SheetCount - 0), Excel.Worksheet).Delete()
            CType(xlExcel.Sheets(SheetCount - 1), Excel.Worksheet).Delete()
            CType(xlExcel.Sheets(SheetCount - 2), Excel.Worksheet).Delete()
        Catch ex As Exception
        End Try

        'Save the excel file
        xlBook.SaveAs(sFile)

        'Make sure all objects are disposed
        xlBook.Close()
        xlExcel.Quit()
        ReleaseComObject(xlCells)
        ReleaseComObject(tblSheet)
        ReleaseComObject(xlBook)
        ReleaseComObject(xlBooks)
        ReleaseComObject(xlExcel)
        xlExcel = Nothing
        xlBooks = Nothing
        xlBook = Nothing
        tblSheet = Nothing
        xlCells = Nothing

        'Let Garbage Collector know it can do it's cleanup
        GC.Collect()

        Return sResult
    End Function

    Private Shared Function ConvertToRecordset(ByVal inTable As DataTable) As ADODB.Recordset
        'Converts a DataTable to a Recordset
        Dim result As New ADODB.Recordset()
        result.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Dim resultFields As ADODB.Fields = result.Fields
        Dim inColumns As System.Data.DataColumnCollection = inTable.Columns

        For Each inColumn As DataColumn In inColumns
            resultFields.Append(inColumn.ColumnName, TranslateType(inColumn.DataType), inColumn.MaxLength, IIf(inColumn.AllowDBNull, ADODB.FieldAttributeEnum.adFldIsNullable, ADODB.FieldAttributeEnum.adFldUnspecified), Nothing)
        Next

        result.Open(System.Reflection.Missing.Value, System.Reflection.Missing.Value, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, 0)

        For Each dr As DataRow In inTable.Rows
            result.AddNew(System.Reflection.Missing.Value, System.Reflection.Missing.Value)
            For columnIndex As Integer = 0 To inColumns.Count - 1

                resultFields(columnIndex).Value = dr(columnIndex)
            Next
        Next
        Return result
    End Function

    Private Shared Function TranslateType(ByVal columnType As Type) As ADODB.DataTypeEnum
        'Translates the Datatable column types to Recordset column types
        Select Case columnType.UnderlyingSystemType.ToString()
            Case "System.Boolean"
                Return ADODB.DataTypeEnum.adBoolean
            Case "System.Byte"

                Return ADODB.DataTypeEnum.adUnsignedTinyInt
            Case "System.Char"

                Return ADODB.DataTypeEnum.adChar
            Case "System.DateTime"

                Return ADODB.DataTypeEnum.adDate
            Case "System.Decimal"

                Return ADODB.DataTypeEnum.adCurrency
            Case "System.Double"

                Return ADODB.DataTypeEnum.adDouble
            Case "System.Int16"

                Return ADODB.DataTypeEnum.adSmallInt
            Case "System.Int32"

                Return ADODB.DataTypeEnum.adInteger
            Case "System.Int64"

                Return ADODB.DataTypeEnum.adBigInt
            Case "System.SByte"

                Return ADODB.DataTypeEnum.adTinyInt
            Case "System.Single"

                Return ADODB.DataTypeEnum.adSingle
            Case "System.UInt16"

                Return ADODB.DataTypeEnum.adUnsignedSmallInt
            Case "System.UInt32"

                Return ADODB.DataTypeEnum.adUnsignedInt
            Case "System.UInt64"

                Return ADODB.DataTypeEnum.adUnsignedBigInt
            Case "System.String"
                Return ADODB.DataTypeEnum.adVarChar
            Case Else
                Return ADODB.DataTypeEnum.adVarChar
        End Select
    End Function
End Class
