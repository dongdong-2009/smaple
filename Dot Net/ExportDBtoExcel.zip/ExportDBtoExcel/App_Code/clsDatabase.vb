Imports System.Data
Imports System.Data.SqlClient


Public Class clsDatabase
    Private sDatabase As String

    Public ReadOnly Property getAllTables(ByVal strDatabase As String) As DataSet
        'Returns a DataSet which containes all Datatables found in a Database
        Get
            sDatabase = strDatabase
            Dim m_dshelp As DataSet = New DataSet

            getRequestedAllTables(m_dshelp)
            Return m_dshelp
        End Get
    End Property

    Private Function getRequestedAllTables(ByRef dsDataset As DataSet) As Boolean
        'Get all table names from the database:
        Dim sSQL As String
        Dim dsTables As DataSet = New DataSet

        sSQL = "SELECT [TableName] = so.name, [RowCount] = MAX(si.rows) " & _
                "FROM sysobjects so, sysindexes si " & _
                "WHERE so.xtype = 'U' AND si.id = OBJECT_ID(so.name) AND si.rows > 0 " & _
                "GROUP BY so.name " & _
                "ORDER BY 2 DESC"
        getData(sSQL, "Tables", dsTables)

        'Loop thrue all tablenames and perform a SELECT * [...] FROM Tablename and add them to the Dataset
        For i As Integer = 0 To dsTables.Tables(0).Rows.Count - 1
            sSQL = "SELECT * FROM [" & dsTables.Tables(0).Rows(i).Item(0) & "]"
            getData(sSQL, dsTables.Tables(0).Rows(i).Item(0), dsDataset)
        Next

    End Function

    Private Function getData(ByVal p_sql As String, ByVal p_table As String, ByRef dsDataset As DataSet) As Boolean
        'Executes a query on the database and returns adds the result to the Dataset (notice the ByRef)
        Dim objDataAdapter As SqlDataAdapter
        Dim objcommand As SqlCommand
        objcommand = New SqlCommand(p_sql, getConnection)
        objDataAdapter = New SqlDataAdapter(objcommand)
        objDataAdapter.Fill(dsDataset, p_table)
    End Function

    Private Function getConnection() As SqlConnection
        'Gets the database conection, configured in the web.config file
        If (ConfigurationManager.AppSettings("SQLPW") <> "") Then
            getConnection = New SqlConnection("Server=" & ConfigurationManager.AppSettings("SQLserver") & ";password=" & _
                                              ConfigurationManager.AppSettings("SQLPW") & "; user=" & _
                                              ConfigurationManager.AppSettings("SQLUN") & ";database=" & sDatabase)
        Else
            getConnection = New SqlConnection("Data Source=" & ConfigurationManager.AppSettings("SQLserver") & ";Initial Catalog=" & sDatabase & ";Integrated Security=True")
        End If
    End Function
End Class
