using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SlideShow1.ImageDataSource = GetImageItems();
    }
   
    private UserControl.ImageItems GetImageItems()
    {
        UserControl.ImageItems oImageItems = new UserControl.ImageItems();
        UserControl.ImageItem oImageItem = null;

        FileInfo[] Images = new DirectoryInfo(Server.MapPath("Images")).GetFiles("*.*");

        foreach (FileInfo Image in Images)
        {
            oImageItem = new UserControl.ImageItem();

            oImageItem.URL = string.Format("~/Images/{0}", Image.Name);
            oImageItem.ToolTip = Image.Name;

            oImageItems.Add(oImageItem);
        }

        return oImageItems;
    }
}
