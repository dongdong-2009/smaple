﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class DB
    {
        public void call(CallLog CL)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                z.AddToCallLogs(CL);
                z.SaveChanges();
            }
        }

        public string GetLastCarNoByCameraIP(string CameraIP)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                CurrentCall cc = z.CurrentCalls.Where(x => x.CameraIP == CameraIP).OrderByDescending(x => x.CreateDateTime).Take(1).FirstOrDefault();
                if (cc != null)
                {
                    return cc.CarNo;
                }
            }
            return string.Empty;
        }

        public ushort FindPhoneIDByCameraIP(string CameraIP)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                Phone p = z.Phones.Where(axc => axc.CameraIP == CameraIP).FirstOrDefault();
                if (p != null)
                {
                    return ushort.Parse(p.ID.ToString());
                }
                return 0;
            }
        }

        public Phone GetPhone(int ID)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                return z.Phones.Where(x => x.ID == ID).FirstOrDefault();
            }
        }

        public CallLog GetCallLogInProcess()
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                return z.CallLogs.Where(x => x.IsCompleted != true).OrderByDescending(x=>x.StartTime).FirstOrDefault();
            }
        }

        public void SetCurrentCall(CurrentCall cc)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                z.AddToCurrentCalls(cc);
                z.SaveChanges();
            }
        }

        public string GetCameraIP(string IP1, string IP2)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                string IP = string.Empty;
                if (z.Phones.Where(x => x.PhoneIP == IP1).FirstOrDefault().IsMaster == true)
                {
                    IP = IP2;
                }
                else
                {
                    IP = IP1;
                }

                return z.Phones.Where(i => i.PhoneIP == IP).FirstOrDefault().CameraIP;
            }
        }


        //public void EndCall(string SID)
        //{
        //    ZJJZXT z = new ZJJZXT();

        //    CurrentCall cc = z.CurrentCalls.Where(x => x.SID == SID).FirstOrDefault();

        //    if (cc != null)
        //    {
        //        z.DeleteObject(cc);
        //    }

        //    List<CallLog> logs = z.CallLogs.Where(x => x.SID == SID).ToList();
        //    foreach (CallLog L in logs)
        //    {
        //        L.IsCompleted = true;
        //    }

        //    z.SaveChanges();
        //}
    }
}
