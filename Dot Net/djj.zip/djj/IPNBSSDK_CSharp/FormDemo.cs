﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Model;
using System.Linq;
using System.Configuration;
using static IPNBSSDK_CSharp.CHCNetSDK;
using System.IO;

namespace IPNBSSDK_CSharp
{
    public partial class FormDemo : Form
    {
        DB db = new DB();
        #region 窗体事件

        private StatusCallBack callback;
        private CHCNetSDK.MSGCallBack m_falarmData = null;

        private delegate void SetTextCallback(string txt);

        bool m_bInitSDK = false;

        private void timer1_Tick(object sender, EventArgs e)
        {
            NET_DVR_ContinuousShoot1();
        }

        delegate void TimerEventHandler();
        delegate void btnclick(object sender, EventArgs e);

        void StartTimer()
        {
            if (button2.InvokeRequired)
            {
                btnclick bc = new btnclick(button2_Click);
                button2.Invoke(bc, null, null);
            }
            else
            {
                button2.PerformClick();
            }
        }

        void StopTimer()
        {
            if (button3.InvokeRequired)
            {
                btnclick bc = new btnclick(button4_Click);
                button3.Invoke(bc, null, null);
            }
            else
            {
                button3.PerformClick();
            }
        }

        public class CarShoot
        {
            public string CarNo = string.Empty;
            public string IP = string.Empty;
            public DateTime shootdatetime = DateTime.Now.AddSeconds(-15);
            public int times = 0;
        }

        private void ProcessCommAlarm_ITSPlate(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            string ip = pAlarmer.sDeviceIP;
            DateTime temp = DateTime.Now;
            int s = (temp - IPCarNo[ip].shootdatetime).Seconds;
            if (s < 15) return;
            
            string CarNo = IPCarNo[ip].CarNo;
            int times = IPCarNo[ip].times;
            CHCNetSDK.NET_ITS_PLATE_RESULT struITSPlateResult = new CHCNetSDK.NET_ITS_PLATE_RESULT();
            struITSPlateResult = (CHCNetSDK.NET_ITS_PLATE_RESULT)Marshal.PtrToStructure(pAlarmInfo, typeof(CHCNetSDK.NET_ITS_PLATE_RESULT));
            string carno = struITSPlateResult.struPlateInfo.sLicense;

            SetStateText(carno);
            if (carno == null || carno == "无车牌" || carno.Length <= 5)
            {
                StopTimer();
                IPCarNo[ip].CarNo = string.Empty;
                IPCarNo[ip].times = 0;
                IPCarNo[ip].shootdatetime = default(DateTime);
                return;
            }
            else
            {
                if (times == 0)
                {
                    IPCarNo[ip].shootdatetime = temp;
                }                

                IPCarNo[ip].CarNo = carno;

                if (CarNo == carno)
                {
                    switch (times)
                    {
                        case 1:
                            {
                                ushort id = db.FindPhoneIDByCameraIP(ip);
                                Phone Pfrom = db.GetPhone(id);
                                Phone Pto = db.GetPhone(1);

                                CallLog cl = new CallLog()
                                {
                                    CarNO = CarNo,
                                    Description = "START",
                                    StartTime = DateTime.Now,
                                    PhoneIDFrom = id.ToString(),
                                    PhoneIPFrom = Pfrom.PhoneIP,// (lpDgramHeader.ucParam1 == 0) ? string.Empty : string.Format("{0}.{1}.{2}.{3}", lpDgramHeader.ucParam2, lpDgramHeader.ucParam3, lpDgramHeader.ucParam4, lpDgramHeader.ucParam5),
                                    PhoneNameFrom = Pfrom.PhoneName,// Encoding.Default.GetString(lpDgramHeader.ucAttachData1).TrimEnd(new char[] { '\0' }),
                                    PhoneIDTo = 1.ToString(),
                                    PhoneIPTo = Pto.PhoneIP,
                                    PhoneNameTo = Pto.PhoneName,
                                    SID = Guid.NewGuid().ToString(),
                                    IsCompleted = false
                                };
                                //db.call(cl);

                                CurrentCall cc = new CurrentCall();
                                cc.SID = cl.SID;
                                cc.CameraIP = db.GetCameraIP(Pfrom.PhoneIP, Pto.PhoneIP);
                                cc.Audio = true;
                                db.SetCurrentCall(cc);

                                IPCarNo[ip].times = IPCarNo[ip].times + 1;
                                SetStateText("播放音频");
                                break;
                            }
                        case 2:
                            {
                                StopTimer();
                                SetStateText("timer 停止");
                                ushort id = db.FindPhoneIDByCameraIP(ip);
                                if (NativeMethod.IPNBSSDK_CtrlCall(id, 1))
                                {
                                    this.tsLabelResult.Text = "呼叫成功";
                                }
                                else
                                {
                                    this.tsLabelResult.Text = "呼叫失败";
                                }
                                IPCarNo[ip].times = 0;
                                SetStateText("呼叫");
                                break;
                            }
                        default:
                            {
                                break;
                            }
                    }
                }
                else
                {
                    SetStateText("timer 启动");
                    StartTimer();
                    IPCarNo[ip].times = IPCarNo[ip].times + 1;
                }
            }

            return;
            //保存抓拍图片
            for (int i = 0; i < struITSPlateResult.dwPicNum; i++)
            {
                if (struITSPlateResult.struPicInfo[i].dwDataLen != 0)
                {
                    string str = "D:/UserID_" + pAlarmer.lUserID + "_Pictype_" + struITSPlateResult.struPicInfo[i].byType + "_Num" + (i + 1) + ".jpg";
                    FileStream fs = new FileStream(str, FileMode.Create);
                    int iLen = (int)struITSPlateResult.struPicInfo[i].dwDataLen;
                    byte[] by = new byte[iLen];
                    Marshal.Copy(struITSPlateResult.struPicInfo[i].pBuffer, by, 0, iLen);
                    fs.Write(by, 0, iLen);
                    fs.Close();
                }
            }
            //报警设备IP地址
            string strIP = pAlarmer.sDeviceIP;

            //抓拍时间：年月日时分秒
            string strTimeYear = string.Format("{0:D4}", struITSPlateResult.struSnapFirstPicTime.wYear) +
                string.Format("{0:D2}", struITSPlateResult.struSnapFirstPicTime.byMonth) +
                string.Format("{0:D2}", struITSPlateResult.struSnapFirstPicTime.byDay) + " "
                + string.Format("{0:D2}", struITSPlateResult.struSnapFirstPicTime.byHour) + ":"
                + string.Format("{0:D2}", struITSPlateResult.struSnapFirstPicTime.byMinute) + ":"
                + string.Format("{0:D2}", struITSPlateResult.struSnapFirstPicTime.bySecond) + ":"
                + string.Format("{0:D3}", struITSPlateResult.struSnapFirstPicTime.wMilliSec);

            //上传结果
            string stringAlarm = "抓拍上传，" + "车牌：" + struITSPlateResult.struPlateInfo.sLicense + "，车辆序号：" + struITSPlateResult.struVehicleInfo.dwIndex;

            if (InvokeRequired)
            {
                object[] paras = new object[3];
                paras[0] = strTimeYear;//当前系统时间为：DateTime.Now.ToString();
                paras[1] = strIP;
                paras[2] = stringAlarm;
            }
            else
            {
                //创建该控件的主线程直接更新信息列表 
            }
        }

        public FormDemo()
        {
            InitializeComponent();
            Init();
            timer1.Stop();

            // 默认为本机IP
            this.tbServerIP.Text = System.Configuration.ConfigurationManager.AppSettings["tbServerIP"].ToString();
            tbServerPort.Text = System.Configuration.ConfigurationManager.AppSettings["tbServerPort"].ToString();
            tbStatePort.Text = System.Configuration.ConfigurationManager.AppSettings["tbStatePort"].ToString();

            // 设置回调
            callback = new StatusCallBack(OnStatusCallBack);
            NativeMethod.IPNBSSDK_SetStatusCallBack(callback, IntPtr.Zero);

            this.rtbOutput.DoubleClick += new EventHandler(rtbOutput_DoubleClick);
            this.cbPhone.CheckedChanged += new EventHandler(cbPhone_CheckedChanged);

            notifyIcon1.ShowBalloonTip(1, " ", "数字IP网络广播系统启动", ToolTipIcon.Info);

            m_bInitSDK = CHCNetSDK.NET_DVR_Init();
            m_falarmData = new CHCNetSDK.MSGCallBack(MsgCallback);
            bool l = CHCNetSDK.NET_DVR_SetDVRMessageCallBack_V30(m_falarmData, IntPtr.Zero);
            CameraLogin1();
        }

        public void MsgCallback(int lCommand, ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            //通过lCommand来判断接收到的报警信息类型，不同的lCommand对应不同的pAlarmInfo内容
            switch (lCommand)
            {
                case CHCNetSDK.COMM_ALARM: //(DS-8000老设备)移动侦测、视频丢失、遮挡、IO信号量等报警信息
                    //ProcessCommAlarm(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                case CHCNetSDK.COMM_ALARM_V30://移动侦测、视频丢失、遮挡、IO信号量等报警信息
                    //ProcessCommAlarm_V30(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                case CHCNetSDK.COMM_ALARM_RULE://进出区域、入侵、徘徊、人员聚集等行为分析报警信息
                    //ProcessCommAlarm_RULE(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                case CHCNetSDK.COMM_UPLOAD_PLATE_RESULT://交通抓拍结果上传(老报警信息类型)
                    ProcessCommAlarm_Plate(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                case CHCNetSDK.COMM_ITS_PLATE_RESULT://交通抓拍结果上传(新报警信息类型)
                    ProcessCommAlarm_ITSPlate(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                case CHCNetSDK.COMM_ALARM_PDC://客流量统计报警信息
                    //ProcessCommAlarm_PDC(ref pAlarmer, pAlarmInfo, dwBufLen, pUser);
                    break;
                default:
                    break;
            }
        }

        int ALARMCM1 = -1, UserID1 = -1;
        Int16 DVRPortNumber1;
        string DVRIPAddress1, DVRUserName1, DVRPassword1;
        Dictionary<string, CarShoot> IPCarNo = new Dictionary<string, CarShoot>();
        void Init()
        {
            DVRIPAddress1 = System.Configuration.ConfigurationManager.AppSettings["DVRIPAddress1"].ToString();
            DVRPortNumber1 = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["DVRPortNumber1"]);
            DVRUserName1 = System.Configuration.ConfigurationManager.AppSettings["DVRUserName1"].ToString();
            DVRPassword1 = System.Configuration.ConfigurationManager.AppSettings["DVRPassword1"].ToString();
            CarShoot cs1 = new CarShoot();
            cs1.IP = DVRIPAddress1;
            IPCarNo.Add(DVRIPAddress1, cs1);
        }

        void CameraLogin1()
        {
            CHCNetSDK.NET_DVR_DEVICEINFO_V30 DeviceInfo = new CHCNetSDK.NET_DVR_DEVICEINFO_V30();

            //登录设备 Login the device
            UserID1 = CHCNetSDK.NET_DVR_Login_V30(DVRIPAddress1, DVRPortNumber1, DVRUserName1, DVRPassword1, ref DeviceInfo);
            if (UserID1 < 0)
            {
                uint iLastErr = CHCNetSDK.NET_DVR_GetLastError();
                string str = "NET_DVR_Login_V30 failed, error code= " + iLastErr; //登录失败，输出错误号
                MessageBox.Show(str);
                return;
            }
            else
            {
                //登录成功
                //MessageBox.Show("Login Success!");
            }

            CHCNetSDK.NET_DVR_SETUPALARM_PARAM struAlarmParam = new CHCNetSDK.NET_DVR_SETUPALARM_PARAM();
            struAlarmParam.dwSize = (uint)Marshal.SizeOf(struAlarmParam);
            struAlarmParam.byLevel = 1; //0- 一级布防,1- 二级布防
            struAlarmParam.byAlarmInfoType = 1;//智能交通设备有效，新报警信息类型
            int ALARMCM1 = CHCNetSDK.NET_DVR_SetupAlarmChan_V41(UserID1, ref struAlarmParam);
        }

        void NET_DVR_ContinuousShoot1()
        {
            if (UserID1 < 0)
            {
                return;
            }
            System.Diagnostics.Process.Start(@"ContinuousShoot\bin\ContinuousShoot.exe", UserID1.ToString());

            //NET_DVR_SNAPCFG struSnapCfg = new NET_DVR_SNAPCFG();
            //struSnapCfg.dwSize = (uint)Marshal.SizeOf(struSnapCfg);
            //struSnapCfg.bySnapTimes = 1;
            //struSnapCfg.wSnapWaitTime = 1;
            //struSnapCfg.byRelatedDriveWay = 0;

            //bool x = CHCNetSDK.NET_DVR_ContinuousShoot(UserID1, struSnapCfg);
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                if (ALARMCM1 >= 0)
                {
                    CHCNetSDK.NET_DVR_CloseAlarmChan_V30(ALARMCM1);
                }

                if (UserID1 >= 0)
                {
                    CHCNetSDK.NET_DVR_Logout(UserID1);
                    UserID1 = -1;
                }
                if (m_bInitSDK == true)
                {
                    CHCNetSDK.NET_DVR_Cleanup();
                }
                if (disposing)
                {
                    if (components != null)
                    {
                        components.Dispose();
                    }
                }

                base.Dispose(disposing);
            }
            catch (Exception EX)
            {

            }
        }

        #endregion

        #region 设置及回调

        private void OnStatusCallBack(IntPtr dwInstance, IntPtr wParam, IntPtr lParam)
        {
            // 消息回调            
            IPNBSSDK_STATE state = (IPNBSSDK_STATE)wParam.ToInt32();
            DGRAMHEADER_STATUS lpDgramHeader = (DGRAMHEADER_STATUS)Marshal.PtrToStructure(lParam, typeof(DGRAMHEADER_STATUS));
            string strState = string.Empty;
            ushort wDialogFromID = 0;
            ushort wDialogToID = 0;
            ushort wTermFromID = (ushort)(lpDgramHeader.ucParam1 | (lpDgramHeader.ucParam2 << 8));
            ushort wTaskNo = (ushort)(lpDgramHeader.ucParam3 | (lpDgramHeader.ucParam4 << 8));

            if (lpDgramHeader.ucFunction == 0xD1)
            {
                // V2.2(2011-5-9)之前的服务器版本
                // wDialogFromID = lpDgramHeader.ucParam3;
                // wDialogToID = lpDgramHeader.ucParam4;

                // V2.2(2011-5-9)及之后的服务器版本
                byte[] pID = new byte[4];
                IntPtr intptr = new IntPtr(lParam.ToInt32() + Marshal.SizeOf(lpDgramHeader));
                Marshal.Copy(intptr, pID, 0, 4);
                wDialogFromID = (byte)(pID[0] | (pID[1] << 8));
                wDialogToID = (byte)(pID[2] | (pID[3] << 8));
            }

            switch (state)
            {
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_NULL:
                    strState = string.Format("终端{0} 空闲", wTermFromID);
                    if (lpDgramHeader.ucParam3 == 0)
                        strState += (" 未登录");
                    else
                        strState += (" 登录");
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_LIVE_PLAY:
                    strState = string.Format("终端{0} 实时采播", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_TERMER_RING:
                    strState = string.Format("终端{0} 定时打铃", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_TERMER_PROGRAMS:
                    strState = string.Format("终端{0} 定时节目", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_SERVER_FIRE_ALARM:
                    strState = string.Format("终端{0} 服务器消防报警", wTermFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_CALL:
                    strState = string.Format("终端{0}(面板序号{1}) 呼叫 终端{2}", wDialogFromID, lpDgramHeader.ucParam5 + 1, wDialogToID);
                    try
                    {
                        Phone Pfrom = db.GetPhone(wDialogFromID);
                        Phone Pto = db.GetPhone(wDialogToID);
                        string CameraIP = db.GetCameraIP(Pfrom.PhoneIP, Pto.PhoneIP);
                        string CarNo = IPCarNo[CameraIP].CarNo;
                        DateTime createdatetime = IPCarNo[CameraIP].shootdatetime;
                        if (CarNo == string.Empty)
                        {
                            CarNo = db.GetLastCarNoByCameraIP(CameraIP);
                        }

                        CallLog cl = new CallLog()
                        {
                            CarNO = CarNo,
                            Description = "START",
                            StartTime = DateTime.Now,
                            PhoneIDFrom = wDialogFromID.ToString(),
                            PhoneIPFrom = Pfrom.PhoneIP,// (lpDgramHeader.ucParam1 == 0) ? string.Empty : string.Format("{0}.{1}.{2}.{3}", lpDgramHeader.ucParam2, lpDgramHeader.ucParam3, lpDgramHeader.ucParam4, lpDgramHeader.ucParam5),
                            PhoneNameFrom = Pfrom.PhoneName,// Encoding.Default.GetString(lpDgramHeader.ucAttachData1).TrimEnd(new char[] { '\0' }),
                            PhoneIDTo = wDialogToID.ToString(),
                            PhoneIPTo = Pto.PhoneIP,
                            PhoneNameTo = Pto.PhoneName,
                            SID = Guid.NewGuid().ToString(),
                            IsCompleted = false
                        };
                        db.call(cl);

                        //if (Pfrom.IsMaster != true)
                        {
                            CurrentCall cc = new CurrentCall();
                            cc.SID = cl.SID;
                            cc.CarNo = CarNo;
                            cc.CameraIP = CameraIP;
                            cc.CreateDateTime = createdatetime;
                            db.SetCurrentCall(cc);
                        }
                    }
                    catch (Exception ex)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine(ex.Message);
                        if (ex.InnerException != null)
                        {
                            sb.AppendLine(ex.InnerException.Message);
                        }
                        //MessageBox.Show(sb.ToString());
                    }

                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_BEGIN:
                    strState = string.Format("终端{0} 与 终端{1} 开始对讲", wDialogFromID, wDialogToID);

                    try
                    {
                        CallLog c = db.GetCallLogInProcess();

                        if (c.PhoneIDFrom == wDialogFromID.ToString())
                        {
                            CallLog cl = new CallLog()
                            {
                                CarNO = c.CarNO,
                                Description = "COM",
                                StartTime = DateTime.Now,
                                PhoneIDFrom = c.PhoneIDFrom,
                                PhoneIPFrom = c.PhoneIPFrom,
                                PhoneNameFrom = c.PhoneNameFrom,
                                PhoneIDTo = c.PhoneIDTo,
                                PhoneIPTo = c.PhoneIPTo,
                                PhoneNameTo = c.PhoneNameTo,
                                SID = c.SID,
                                IsCompleted = false
                            };
                            db.call(cl);
                            EndCurrentCall(c.SID);
                        }
                    }
                    catch (Exception ex)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine(ex.Message);
                        if (ex.InnerException != null)
                        {
                            sb.AppendLine(ex.InnerException.Message);
                        }
                        //MessageBox.Show(sb.ToString());
                    }
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_DIALOG_END:
                    strState = string.Format("终端{0} 与 终端{1} 停止对讲", wDialogFromID, wDialogToID);

                    try
                    {
                        //Phone p1 = db.GetPhone(wDialogFromID);
                        //Phone p2 = db.GetPhone(wDialogToID);
                        //string PhoneIDFrom = string.Empty;
                        //string PhoneIPFrom = string.Empty;
                        //string PhoneNameFrom = string.Empty;
                        //string PhoneIDTo = string.Empty;
                        //string PhoneIPTo = string.Empty;
                        //string PhoneNameTo = string.Empty;

                        //if (p1.IsMaster == true)
                        //{
                        //    PhoneIDFrom = p1.ID.ToString();
                        //    PhoneIPFrom = p1.PhoneIP;
                        //    PhoneNameFrom = p1.PhoneName;
                        //    PhoneIDTo = p2.ID.ToString();
                        //    PhoneIPTo = p2.PhoneIP;
                        //    PhoneNameTo = p2.PhoneName;
                        //}
                        //else
                        //{
                        //    PhoneIDFrom = p2.ID.ToString();
                        //    PhoneIPFrom = p2.PhoneIP;
                        //    PhoneNameFrom = p2.PhoneName;
                        //    PhoneIDTo = p1.ID.ToString();
                        //    PhoneIPTo = p1.PhoneIP;
                        //    PhoneNameTo = p1.PhoneName;
                        //}

                        CallLog c = db.GetCallLogInProcess();

                        if (c != null && c.PhoneIDFrom == wDialogFromID.ToString())
                        {
                            CallLog cl = new CallLog()
                            {
                                CarNO = c.CarNO,
                                Description = "END",
                                EndTime = DateTime.Now,
                                PhoneIDFrom = c.PhoneIDFrom,
                                PhoneIPFrom = c.PhoneIPFrom,
                                PhoneNameFrom = c.PhoneNameFrom,
                                PhoneIDTo = c.PhoneIDTo,
                                PhoneIPTo = c.PhoneIPTo,
                                PhoneNameTo = c.PhoneNameTo,
                                SID = c.SID,
                                IsCompleted = true
                            };
                            db.call(cl);
                            EndCall(c);
                        }
                    }
                    catch (Exception ex)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine(ex.Message);
                        if (ex.InnerException != null)
                        {
                            sb.AppendLine(ex.InnerException.Message);
                        }
                        //MessageBox.Show(sb.ToString());
                    }

                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM1:
                    strState = string.Format("终端{0} 端口1报警", wDialogFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM2:
                    strState = string.Format("终端{0} 端口2报警", wDialogFromID);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ALARM_EX:
                    strState = string.Format("终端{0} 扩展端口{1}报警", wDialogFromID, lpDgramHeader.ucParam3);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_NULL:
                    strState = string.Format("{0}号任务 : 空闲", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_TERMER_RING_BEGIN:
                    strState = string.Format("{0}号任务 : 定时打铃 : 执行", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_TERMER_RING_END:
                    strState = string.Format("{0}号任务 : 定时打铃 : 停止", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_FIRE_ALARM_BEGIN:
                    strState = string.Format("{0}号任务 : 消防报警 : 执行", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TASK_FIRE_ALARM_END:
                    strState = string.Format("{0}号任务 : 消防报警 : 停止", wTaskNo);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_IP:
                    if (lpDgramHeader.ucParam1 == 0)
                        strState = "查询IP结果 : 失败";
                    else
                        strState = string.Format("查询IP结果 : 成功 {0}.{1}.{2}.{3}", lpDgramHeader.ucParam2,
                                        lpDgramHeader.ucParam3, lpDgramHeader.ucParam4, lpDgramHeader.ucParam5);
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_ID:
                    if (lpDgramHeader.ucParam1 == 0)
                        strState = "查询ID结果 : 失败";
                    else
                        strState = string.Format("查询ID结果 : 成功 {0}",
                            lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_TERMINAL_COUNT:
                    strState = string.Format("查询终端数量结果 : {0}",
                            lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8));
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_PORT_STATE:
                    strState = string.Format("查询终端 {0} {1}端口 {2} 状态 : {3}",
                        lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8),
                        (lpDgramHeader.ucParam1 & 0x80) == 0 ? "输入" : "输出",
                        lpDgramHeader.ucParam1 & 0x7F,
                        lpDgramHeader.ucParam4 == 0 ? "断开" : "闭合");
                    break;
                case IPNBSSDK_STATE.IPNBSSDK_STATE_SD_PLAY_STATE:
                    strState = string.Format("终端 {0} SD卡 {1}",
                        lpDgramHeader.ucParam2 | (lpDgramHeader.ucParam3 << 8),
                        lpDgramHeader.ucParam1 == 0 ? ("停止") : ("播放"));
                    break;
            }

            if (lpDgramHeader.ucFunction == 0xD2 && lpDgramHeader.ucAttachData1[0] != '\0')
            {
                string strTemp = string.Format("\r\n终端名称 :{0}\r\n", Encoding.Default.GetString(lpDgramHeader.ucAttachData1).TrimEnd(new char[] { '\0' }));
                strState += strTemp;
                strTemp = string.Format("IP地址 : {0}.{1}.{2}.{3}\r\n", lpDgramHeader.ucAttachData2[0],
                    lpDgramHeader.ucAttachData2[1], lpDgramHeader.ucAttachData2[2], lpDgramHeader.ucAttachData2[3]);
                strState += strTemp;
                strTemp = string.Format("音量 : {0}", lpDgramHeader.ucAttachData2[4]);
                strState += strTemp;
            }

            if (lpDgramHeader.ucFunction == 0xD1 && lpDgramHeader.ucParam2 == 0x30)
            {
                // 接收到创建对讲录音文件消息
                IntPtr intptr = Marshal.AllocHGlobal(32);
                Marshal.Copy(lpDgramHeader.ucAttachData1, 0, intptr, 32);
                CREATE_FILE_INFO pCreateFileInfo = (CREATE_FILE_INFO)Marshal.PtrToStructure(intptr, typeof(CREATE_FILE_INFO));
                string pchFilePath = Encoding.Default.GetString(lpDgramHeader.ucAttachData1, 32, 18).TrimEnd(new char[] { '\0' });
                string strTemp = string.Format("创建录音文件(终端{0}): {1}", pCreateFileInfo.wTermID, pCreateFileInfo);
                strState += strTemp;
            }

            SetStateText(strState);
        }

        private static void EndCurrentCall(string SID)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                CurrentCall cc = z.CurrentCalls.Where(x => x.SID == SID).FirstOrDefault();

                if (cc != null)
                {
                    cc.IsCompleted = true;
                }

                z.SaveChanges();
            }
        }

        private static void EndCall(CallLog c)
        {
            using (ZJJZXT z = new ZJJZXT())
            {
                CurrentCall cc = z.CurrentCalls.Where(x => x.SID == c.SID).FirstOrDefault();

                if (cc != null)
                {
                    //z.DeleteObject(cc);
                    cc.IsCompleted = true;
                }

                List<CallLog> logs = z.CallLogs.Where(x => x.SID == c.SID).ToList();
                foreach (CallLog L in logs)
                {
                    L.IsCompleted = true;
                }

                z.SaveChanges();
            }
        }

        void cbPhone_CheckedChanged(object sender, EventArgs e)
        {
            this.tbPhoneNumber.Enabled = this.cbPhone.Checked;
        }

        void rtbOutput_DoubleClick(object sender, EventArgs e)
        {
            // 清除文本
            this.rtbOutput.Clear();
        }

        private void SetStateText(string txt)
        {
            if (this.rtbOutput.InvokeRequired)
            {
                SetTextCallback callback = new SetTextCallback(SetStateText);
                Invoke(callback, new object[] { txt });
            }
            else
            {
                this.rtbOutput.AppendText(txt + "\r\n");
                this.rtbOutput.SelectionStart = this.rtbOutput.TextLength;
                this.rtbOutput.ScrollToCaret();
            }
        }

        private void btnSetConfig_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_SetServerIP(this.tbServerIP.Text)
                && NativeMethod.IPNBSSDK_SetServerPort(ushort.Parse(this.tbServerPort.Text))
                && NativeMethod.IPNBSSDK_SetStatePort(ushort.Parse(this.tbStatePort.Text)))
                this.tsLabelResult.Text = "设置成功";
            else
                this.tsLabelResult.Text = "设置失败";
        }

        #endregion


        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            StartTimer();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StopTimer();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NET_DVR_ContinuousShoot1();
        }


        #region 呼叫

        private void btnCall_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlCall(ushort.Parse(this.tbCallFromId.Text), ushort.Parse(this.tbCallToId.Text)))
                this.tsLabelResult.Text = "呼叫成功";
            else
                this.tsLabelResult.Text = "呼叫失败";
        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlAnswer(ushort.Parse(this.tbCallFromId.Text)))
                this.tsLabelResult.Text = "接听成功";
            else
                this.tsLabelResult.Text = "接听失败";
        }

        private void btnHang_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlHang(ushort.Parse(this.tbCallFromId.Text)))
                this.tsLabelResult.Text = "挂断成功";
            else
                this.tsLabelResult.Text = "挂断失败";
        }

        private void btnCallEx_Click(object sender, EventArgs e)
        {
            if (this.cbPhone.Checked)
            {
                if (NativeMethod.IPNBSSDK_CtrlCallPhone(ushort.Parse(this.tbCallExFromId.Text), ushort.Parse(this.tbCallExToId.Text),
                    byte.Parse(this.tbCallExAreaId.Text), this.tbPhoneNumber.Text))
                    this.tsLabelResult.Text = "呼叫成功";
                else
                    this.tsLabelResult.Text = "呼叫失败";
            }
            else
            {
                if (NativeMethod.IPNBSSDK_CtrlCallEx(ushort.Parse(this.tbCallExFromId.Text), ushort.Parse(this.tbCallExToId.Text),
                    byte.Parse(this.tbCallExAreaId.Text)))
                    this.tsLabelResult.Text = "呼叫成功";
                else
                    this.tsLabelResult.Text = "呼叫失败";
            }
        }

        private void btnAnswerEx_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlAnswerEx(ushort.Parse(this.tbCallExFromId.Text)))
                this.tsLabelResult.Text = "接听成功";
            else
                this.tsLabelResult.Text = "接听失败";
        }

        private void btnHangEx_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlHangEx(ushort.Parse(this.tbCallExFromId.Text)))
                this.tsLabelResult.Text = "挂断成功";
            else
                this.tsLabelResult.Text = "挂断失败";
        }

        #endregion

        #region 采播

        private void btnStartBroadcast_Click(object sender, EventArgs e)
        {
            string[] tmps = this.tbBroadcastToId.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<ushort> toIdList = new List<ushort>();
            ushort id;
            foreach (string tmp in tmps)
            {
                if (ushort.TryParse(tmp, out id))
                    toIdList.Add(id);
            }

            if (NativeMethod.IPNBSSDK_CtrlBroadcast_CSharp(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, true))
                this.tsLabelResult.Text = "开始采播成功";
            else
                this.tsLabelResult.Text = "开始采播失败";
        }

        private void btnBroadcastStop_Click(object sender, EventArgs e)
        {
            string[] tmps = this.tbBroadcastToId.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<ushort> toIdList = new List<ushort>();
            ushort id;
            foreach (string tmp in tmps)
            {
                if (ushort.TryParse(tmp, out id))
                    toIdList.Add(id);
            }

            if (NativeMethod.IPNBSSDK_CtrlBroadcast_CSharp(ushort.Parse(this.tbBroadcastFromId.Text), toIdList, false))
                this.tsLabelResult.Text = "停止采播成功";
            else
                this.tsLabelResult.Text = "停止采播失败";
        }

        private void btn8AreaBroadcastStart_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlBroadcastSingle(ushort.Parse(this.tbBroadcastFromId.Text), ushort.Parse(this.tb8AreaTerminalId.Text),
                byte.Parse(this.tb8AreaNumber.Text), true))
                this.tsLabelResult.Text = "开始【8分区】采播成功";
            else
                this.tsLabelResult.Text = "开始【8分区】采播失败";
        }

        private void btn8AreaBroadcastStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlBroadcastSingle(ushort.Parse(this.tbBroadcastFromId.Text), ushort.Parse(this.tb8AreaTerminalId.Text),
                byte.Parse(this.tb8AreaNumber.Text), false))
                this.tsLabelResult.Text = "停止【8分区】采播成功";
            else
                this.tsLabelResult.Text = "停止【8分区】采播失败";
        }

        #endregion

        #region 监听、IO控制、SD卡播放

        private void btnSpyStart_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlMonitor(ushort.Parse(this.tbSpyFromId.Text), ushort.Parse(this.tbSpyToId.Text), true))
                this.tsLabelResult.Text = "开始监听成功";
            else
                this.tsLabelResult.Text = "开始监听失败";
        }

        private void btnSpyStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlMonitor(ushort.Parse(this.tbSpyFromId.Text), ushort.Parse(this.tbSpyToId.Text), false))
                this.tsLabelResult.Text = "停止监听成功";
            else
                this.tsLabelResult.Text = "停止监听失败";
        }

        private void btnIOOpen_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlIO(ushort.Parse(this.tbIOControlId.Text), byte.Parse(this.tbIOControlPort.Text), true))
                this.tsLabelResult.Text = "IO口闭合成功";
            else
                this.tsLabelResult.Text = "IO口闭合失败";
        }

        private void btnIOClose_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlIO(ushort.Parse(this.tbIOControlId.Text), byte.Parse(this.tbIOControlPort.Text), false))
                this.tsLabelResult.Text = "IO口断开成功";
            else
                this.tsLabelResult.Text = "IO口断开失败";
        }

        private void btnSDPlay_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSDPlay(ushort.Parse(this.tbSDControlId.Text), true, byte.Parse(this.tbSDFileIndex.Text)))
                this.tsLabelResult.Text = "SD卡文件播放成功";
            else
                this.tsLabelResult.Text = "SD卡文件播放失败";
        }

        private void btnSDStop_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSDPlay(ushort.Parse(this.tbSDControlId.Text), false, byte.Parse(this.tbSDFileIndex.Text)))
                this.tsLabelResult.Text = "SD卡文件停止成功";
            else
                this.tsLabelResult.Text = "SD卡文件停止失败";
        }

        #endregion

        #region 终端查询

        private void btnSearchTerminalCount_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryTermCount())
                this.tsLabelResult.Text = "查询终端数量成功";
            else
                this.tsLabelResult.Text = "查询终端数量失败";
        }

        private void btnStateSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryState(ushort.Parse(this.tbSearchId.Text)))
                this.tsLabelResult.Text = "查询终端状态成功";
            else
                this.tsLabelResult.Text = "查询终端状态失败";
        }

        private void btnIPSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryIP(ushort.Parse(this.tbSearchId.Text)))
                this.tsLabelResult.Text = "查询终端IP成功";
            else
                this.tsLabelResult.Text = "查询终端IP失败";
        }

        private void btnIdSearch_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlQueryID(this.tbTerminalIP.Text))
                this.tsLabelResult.Text = "查询终端ID成功";
            else
                this.tsLabelResult.Text = "查询终端ID失败";
        }

        private void btnModifyName_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSetName(ushort.Parse(this.tbSearchId.Text), this.tbTerminalName.Text))
                this.tsLabelResult.Text = "设置终端名称成功";
            else
                this.tsLabelResult.Text = "设置终端名称失败";
        }

        private void btnModifyVolume_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlSetVolume(ushort.Parse(this.tbSearchId.Text), byte.Parse(this.tbVolume.Text)))
                this.tsLabelResult.Text = "设置终端音量成功";
            else
                this.tsLabelResult.Text = "设置终端音量失败";
        }

        private void btnPortSearch_Click(object sender, EventArgs e)
        {
            byte m_wQueryPort = byte.Parse(this.tbSearchPort.Text);
            if (this.rbPortIn.Checked)
                m_wQueryPort |= 0x80;
            if (NativeMethod.IPNBSSDK_CtrlQueryPort(ushort.Parse(this.tbSearchId.Text), m_wQueryPort))
                this.tsLabelResult.Text = "查询终端端口状态成功";
            else
                this.tsLabelResult.Text = "查询终端端口状态失败";
        }

        #endregion

        #region 任务

        private void btnStartAlarmTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlFireAlarm(ushort.Parse(this.tbAlarmTaskId.Text), true))
                this.tsLabelResult.Text = "开始报警成功";
            else
                this.tsLabelResult.Text = "开始报警失败";
        }

        private void tbnStopAlarmTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlFireAlarm(ushort.Parse(this.tbAlarmTaskId.Text), false))
                this.tsLabelResult.Text = "停止报警成功";
            else
                this.tsLabelResult.Text = "停止报警失败";
        }

        private void btnStartRingTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlTimerRing(ushort.Parse(this.tbRingTaskId.Text), true))
                this.tsLabelResult.Text = "开始定时打铃成功";
            else
                this.tsLabelResult.Text = "开始定时打铃失败";
        }

        private void btnStopRingTask_Click(object sender, EventArgs e)
        {
            if (NativeMethod.IPNBSSDK_CtrlTimerRing(ushort.Parse(this.tbRingTaskId.Text), false))
                this.tsLabelResult.Text = "停止定时打铃成功";
            else
                this.tsLabelResult.Text = "停止定时打铃失败";
        }
        #endregion

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (showWindow)
            {
                this.Opacity = 0.0;
            }
            else
            {
                this.Opacity = 100.0;
            }
            showWindow = !showWindow;
        }

        bool showWindow;
        private void FormDemo_Load(object sender, EventArgs e)
        {
            this.Opacity = 0.0;
            showWindow = false;
        }


        public void ProcessCommAlarm(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            CHCNetSDK.NET_DVR_ALARMINFO struAlarmInfo = new CHCNetSDK.NET_DVR_ALARMINFO();

            struAlarmInfo = (CHCNetSDK.NET_DVR_ALARMINFO)Marshal.PtrToStructure(pAlarmInfo, typeof(CHCNetSDK.NET_DVR_ALARMINFO));

            string strIP = pAlarmer.sDeviceIP;
            string stringAlarm = "";
            int i = 0;

            switch (struAlarmInfo.dwAlarmType)
            {
                case 0:
                    stringAlarm = "信号量报警，报警报警输入口：" + struAlarmInfo.dwAlarmInputNumber + "，触发录像通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM; i++)
                    {
                        if (struAlarmInfo.dwAlarmRelateChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 1:
                    stringAlarm = "硬盘满，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM; i++)
                    {
                        if (struAlarmInfo.dwDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 2:
                    stringAlarm = "信号丢失，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM; i++)
                    {
                        if (struAlarmInfo.dwChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 3:
                    stringAlarm = "移动侦测，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM; i++)
                    {
                        if (struAlarmInfo.dwChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 4:
                    stringAlarm = "硬盘未格式化，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM; i++)
                    {
                        if (struAlarmInfo.dwDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 5:
                    stringAlarm = "读写硬盘出错，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM; i++)
                    {
                        if (struAlarmInfo.dwDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 6:
                    stringAlarm = "遮挡报警，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM; i++)
                    {
                        if (struAlarmInfo.dwChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 7:
                    stringAlarm = "制式不匹配，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM; i++)
                    {
                        if (struAlarmInfo.dwChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 8:
                    stringAlarm = "非法访问";
                    break;
                default:
                    stringAlarm = "其他未知报警信息";
                    break;
            }

            if (InvokeRequired)
            {
                object[] paras = new object[3];
                paras[0] = DateTime.Now.ToString();
                paras[1] = strIP;
                paras[2] = stringAlarm;
            }
            else
            {
                //创建该控件的主线程直接更新信息列表 
            }
        }

        private void ProcessCommAlarm_V30(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {

            CHCNetSDK.NET_DVR_ALARMINFO_V30 struAlarmInfoV30 = new CHCNetSDK.NET_DVR_ALARMINFO_V30();

            struAlarmInfoV30 = (CHCNetSDK.NET_DVR_ALARMINFO_V30)Marshal.PtrToStructure(pAlarmInfo, typeof(CHCNetSDK.NET_DVR_ALARMINFO_V30));

            string strIP = pAlarmer.sDeviceIP;
            string stringAlarm = "";
            int i;

            switch (struAlarmInfoV30.dwAlarmType)
            {
                case 0:
                    stringAlarm = "信号量报警，报警报警输入口：" + struAlarmInfoV30.dwAlarmInputNumber + "，触发录像通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byAlarmRelateChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + "\\";
                        }
                    }
                    break;
                case 1:
                    stringAlarm = "硬盘满，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " ";
                        }
                    }
                    break;
                case 2:
                    stringAlarm = "信号丢失，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 3:
                    stringAlarm = "移动侦测，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 4:
                    stringAlarm = "硬盘未格式化，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 5:
                    stringAlarm = "读写硬盘出错，报警硬盘号：";
                    for (i = 0; i < CHCNetSDK.MAX_DISKNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byDiskNumber[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 6:
                    stringAlarm = "遮挡报警，报警通道：";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 7:
                    stringAlarm = "制式不匹配，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 8:
                    stringAlarm = "非法访问";
                    break;
                case 9:
                    stringAlarm = "视频信号异常，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 10:
                    stringAlarm = "录像/抓图异常，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 11:
                    stringAlarm = "智能场景变化，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 12:
                    stringAlarm = "阵列异常";
                    break;
                case 13:
                    stringAlarm = "前端/录像分辨率不匹配，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                case 15:
                    stringAlarm = "智能侦测，报警通道";
                    for (i = 0; i < CHCNetSDK.MAX_CHANNUM_V30; i++)
                    {
                        if (struAlarmInfoV30.byChannel[i] == 1)
                        {
                            stringAlarm += (i + 1) + " \\ ";
                        }
                    }
                    break;
                default:
                    stringAlarm = "其他未知报警信息";
                    break;
            }

            if (InvokeRequired)
            {
                object[] paras = new object[3];
                paras[0] = DateTime.Now.ToString();
                paras[1] = strIP;
                paras[2] = stringAlarm;

            }
            else
            {
                //创建该控件的主线程直接更新信息列表 
            }

        }

        CHCNetSDK.NET_VCA_TRAVERSE_PLANE m_struTraversePlane = new CHCNetSDK.NET_VCA_TRAVERSE_PLANE();
        CHCNetSDK.NET_VCA_AREA m_struVcaArea = new CHCNetSDK.NET_VCA_AREA();
        CHCNetSDK.NET_VCA_INTRUSION m_struIntrusion = new CHCNetSDK.NET_VCA_INTRUSION();
        CHCNetSDK.UNION_STATFRAME m_struStatFrame = new CHCNetSDK.UNION_STATFRAME();
        CHCNetSDK.UNION_STATTIME m_struStatTime = new CHCNetSDK.UNION_STATTIME();

        private void ProcessCommAlarm_RULE(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            CHCNetSDK.NET_VCA_RULE_ALARM struRuleAlarmInfo = new CHCNetSDK.NET_VCA_RULE_ALARM();
            struRuleAlarmInfo = (CHCNetSDK.NET_VCA_RULE_ALARM)Marshal.PtrToStructure(pAlarmInfo, typeof(CHCNetSDK.NET_VCA_RULE_ALARM));

            //报警信息
            string stringAlarm = "";
            uint dwSize = (uint)Marshal.SizeOf(struRuleAlarmInfo.struRuleInfo.uEventParam);

            switch (struRuleAlarmInfo.struRuleInfo.wEventTypeEx)
            {
                case (ushort)CHCNetSDK.VCA_RULE_EVENT_TYPE_EX.ENUM_VCA_EVENT_TRAVERSE_PLANE:
                    IntPtr ptrTraverseInfo = Marshal.AllocHGlobal((Int32)dwSize);
                    Marshal.StructureToPtr(struRuleAlarmInfo.struRuleInfo.uEventParam, ptrTraverseInfo, false);
                    m_struTraversePlane = (CHCNetSDK.NET_VCA_TRAVERSE_PLANE)Marshal.PtrToStructure(ptrTraverseInfo, typeof(CHCNetSDK.NET_VCA_TRAVERSE_PLANE));
                    stringAlarm = "穿越警戒面，目标ID：" + struRuleAlarmInfo.struTargetInfo.dwID;
                    //警戒面边线起点坐标: (m_struTraversePlane.struPlaneBottom.struStart.fX, m_struTraversePlane.struPlaneBottom.struStart.fY)
                    //警戒面边线终点坐标: (m_struTraversePlane.struPlaneBottom.struEnd.fX, m_struTraversePlane.struPlaneBottom.struEnd.fY)
                    break;
                case (ushort)CHCNetSDK.VCA_RULE_EVENT_TYPE_EX.ENUM_VCA_EVENT_ENTER_AREA:
                    IntPtr ptrEnterInfo = Marshal.AllocHGlobal((Int32)dwSize);
                    Marshal.StructureToPtr(struRuleAlarmInfo.struRuleInfo.uEventParam, ptrEnterInfo, false);
                    m_struVcaArea = (CHCNetSDK.NET_VCA_AREA)Marshal.PtrToStructure(ptrEnterInfo, typeof(CHCNetSDK.NET_VCA_AREA));
                    stringAlarm = "目标进入区域，目标ID：" + struRuleAlarmInfo.struTargetInfo.dwID;
                    //m_struVcaArea.struRegion 多边形区域坐标
                    break;
                case (ushort)CHCNetSDK.VCA_RULE_EVENT_TYPE_EX.ENUM_VCA_EVENT_EXIT_AREA:
                    IntPtr ptrExitInfo = Marshal.AllocHGlobal((Int32)dwSize);
                    Marshal.StructureToPtr(struRuleAlarmInfo.struRuleInfo.uEventParam, ptrExitInfo, false);
                    m_struVcaArea = (CHCNetSDK.NET_VCA_AREA)Marshal.PtrToStructure(ptrExitInfo, typeof(CHCNetSDK.NET_VCA_AREA));
                    stringAlarm = "目标离开区域，目标ID：" + struRuleAlarmInfo.struTargetInfo.dwID;
                    //m_struVcaArea.struRegion 多边形区域坐标
                    break;
                case (ushort)CHCNetSDK.VCA_RULE_EVENT_TYPE_EX.ENUM_VCA_EVENT_INTRUSION:
                    IntPtr ptrIntrusionInfo = Marshal.AllocHGlobal((Int32)dwSize);
                    Marshal.StructureToPtr(struRuleAlarmInfo.struRuleInfo.uEventParam, ptrIntrusionInfo, false);
                    m_struIntrusion = (CHCNetSDK.NET_VCA_INTRUSION)Marshal.PtrToStructure(ptrIntrusionInfo, typeof(CHCNetSDK.NET_VCA_INTRUSION));
                    stringAlarm = "周界入侵，目标ID：" + struRuleAlarmInfo.struTargetInfo.dwID;
                    //m_struIntrusion.struRegion 多边形区域坐标
                    break;
                default:
                    stringAlarm = "其他行为分析报警，目标ID：" + struRuleAlarmInfo.struTargetInfo.dwID;
                    break;
            }


            //报警图片保存
            if (struRuleAlarmInfo.dwPicDataLen > 0)
            {
                FileStream fs = new FileStream("行为分析报警抓图.jpg", FileMode.Create);
                int iLen = (int)struRuleAlarmInfo.dwPicDataLen;
                byte[] by = new byte[iLen];
                Marshal.Copy(struRuleAlarmInfo.pImage, by, 0, iLen);
                fs.Write(by, 0, iLen);
                fs.Close();
            }

            //报警时间：年月日时分秒
            string strTimeYear = ((struRuleAlarmInfo.dwAbsTime >> 26) + 2000).ToString();
            string strTimeMonth = ((struRuleAlarmInfo.dwAbsTime >> 22) & 15).ToString("d2");
            string strTimeDay = ((struRuleAlarmInfo.dwAbsTime >> 17) & 31).ToString("d2");
            string strTimeHour = ((struRuleAlarmInfo.dwAbsTime >> 12) & 31).ToString("d2");
            string strTimeMinute = ((struRuleAlarmInfo.dwAbsTime >> 6) & 63).ToString("d2");
            string strTimeSecond = ((struRuleAlarmInfo.dwAbsTime >> 0) & 63).ToString("d2");
            string strTime = strTimeYear + "-" + strTimeMonth + "-" + strTimeDay + " " + strTimeHour + ":" + strTimeMinute + ":" + strTimeSecond;

            //报警设备IP地址
            string strIP = struRuleAlarmInfo.struDevInfo.struDevIP.sIpV4;

            //将报警信息添加进列表
            if (InvokeRequired)
            {
                object[] paras = new object[3];
                paras[0] = strTime;
                paras[1] = strIP;
                paras[2] = stringAlarm;
            }
            else
            {
                //创建该控件的主线程直接更新信息列表 
            }
        }

        private void ProcessCommAlarm_Plate(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            CHCNetSDK.NET_DVR_PLATE_RESULT struPlateResultInfo = new CHCNetSDK.NET_DVR_PLATE_RESULT();
            uint dwSize = (uint)Marshal.SizeOf(struPlateResultInfo);

            struPlateResultInfo = (CHCNetSDK.NET_DVR_PLATE_RESULT)Marshal.PtrToStructure(pAlarmInfo, typeof(CHCNetSDK.NET_DVR_PLATE_RESULT));

            //保存抓拍图片
            string str = "";
            if (struPlateResultInfo.byResultType == 1 && struPlateResultInfo.dwPicLen != 0)
            {
                str = "D:/UserID_" + pAlarmer.lUserID + "_近景图.jpg";
                FileStream fs = new FileStream(str, FileMode.Create);
                int iLen = (int)struPlateResultInfo.dwPicLen;
                byte[] by = new byte[iLen];
                Marshal.Copy(struPlateResultInfo.pBuffer1, by, 0, iLen);
                fs.Write(by, 0, iLen);
                fs.Close();
            }
            if (struPlateResultInfo.dwPicPlateLen != 0)
            {
                str = "D:/UserID_" + pAlarmer.lUserID + "_车牌图.jpg";
                FileStream fs = new FileStream(str, FileMode.Create);
                int iLen = (int)struPlateResultInfo.dwPicPlateLen;
                byte[] by = new byte[iLen];
                Marshal.Copy(struPlateResultInfo.pBuffer2, by, 0, iLen);
                fs.Write(by, 0, iLen);
                fs.Close();
            }
            if (struPlateResultInfo.dwFarCarPicLen != 0)
            {
                str = "D:/UserID_" + pAlarmer.lUserID + "_远景图.jpg";
                FileStream fs = new FileStream(str, FileMode.Create);
                int iLen = (int)struPlateResultInfo.dwFarCarPicLen;
                byte[] by = new byte[iLen];
                Marshal.Copy(struPlateResultInfo.pBuffer5, by, 0, iLen);
                fs.Write(by, 0, iLen);
                fs.Close();
            }

            //报警设备IP地址
            string strIP = pAlarmer.sDeviceIP;

            //抓拍时间：年月日时分秒
            string strTimeYear = System.Text.Encoding.UTF8.GetString(struPlateResultInfo.byAbsTime);

            //上传结果
            string stringAlarm = "抓拍上传，" + "车牌：" + struPlateResultInfo.struPlateInfo.sLicense + "，车辆序号：" + struPlateResultInfo.struVehicleInfo.dwIndex;

            if (InvokeRequired)
            {
                object[] paras = new object[3];
                paras[0] = strTimeYear; //当前PC系统时间为DateTime.Now.ToString();
                paras[1] = strIP;
                paras[2] = stringAlarm;
            }
            else
            {
                //创建该控件的主线程直接更新信息列表 
            }
        }

        private void ProcessCommAlarm_PDC(ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {

        }
    }
}
