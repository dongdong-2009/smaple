﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;

namespace IPNBSSDK_CSharp
{
    public partial class AlarmDemo : Form
    {
        private Int32 m_lUserID = -1;

        private CHCNetSDK.MSGCallBack m_falarmData = null;


        public AlarmDemo()
        {
            InitializeComponent();
            bool m_bInitSDK = CHCNetSDK.NET_DVR_Init();
            if (m_bInitSDK == false)
            {
                MessageBox.Show("NET_DVR_Init error!");
                return;
            }

            //设置报警回调函数
            m_falarmData = new CHCNetSDK.MSGCallBack(MsgCallback);
            CHCNetSDK.NET_DVR_SetDVRMessageCallBack_V30(m_falarmData, IntPtr.Zero);
            login(); setalarm();

        }

        public void MsgCallback(int lCommand, ref CHCNetSDK.NET_DVR_ALARMER pAlarmer, IntPtr pAlarmInfo, uint dwBufLen, IntPtr pUser)
        {
            //通过lCommand来判断接收到的报警信息类型，不同的lCommand对应不同的pAlarmInfo内容
            switch (lCommand)
            {

                default:
                    break;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {



        }

        void login()
        {
            CHCNetSDK.NET_DVR_DEVICEINFO_V30 DeviceInfo = new CHCNetSDK.NET_DVR_DEVICEINFO_V30();

            //登录设备 Login the device
            m_lUserID = CHCNetSDK.NET_DVR_Login_V30("192.168.1.64", 8000, "admin", "hom184812600", ref DeviceInfo);
            if (m_lUserID < 0)
            {

                return;
            }
        }

        private void btn_SetAlarm_Click(object sender, EventArgs e)
        {
            setalarm();
        }

        void setalarm()
        {
            CHCNetSDK.NET_DVR_SETUPALARM_PARAM struAlarmParam = new CHCNetSDK.NET_DVR_SETUPALARM_PARAM();
            struAlarmParam.dwSize = (uint)Marshal.SizeOf(struAlarmParam);
            struAlarmParam.byLevel = 1; //0- 一级布防,1- 二级布防
            struAlarmParam.byAlarmInfoType = 1;//智能交通设备有效，新报警信息类型
            int adc = CHCNetSDK.NET_DVR_SetupAlarmChan_V41(m_lUserID, ref struAlarmParam);
        }




        private void button1_Click(object sender, EventArgs e)
        {
            CHCNetSDK.NET_DVR_SNAPCFG struSnapCfg = new CHCNetSDK.NET_DVR_SNAPCFG();
            struSnapCfg.dwSize = (uint)Marshal.SizeOf(struSnapCfg);
            struSnapCfg.bySnapTimes = 1;
            struSnapCfg.wSnapWaitTime = 1;
            struSnapCfg.byRelatedDriveWay = 0;

            bool x = CHCNetSDK.NET_DVR_ContinuousShoot(m_lUserID, struSnapCfg);
        }
    }
}
