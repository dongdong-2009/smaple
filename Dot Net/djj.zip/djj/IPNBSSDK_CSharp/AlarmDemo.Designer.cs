﻿namespace IPNBSSDK_CSharp
{
    partial class AlarmDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewAlarmInfo = new System.Windows.Forms.ListView();
            this.ColumnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_SetAlarm = new System.Windows.Forms.Button();
            this.btnCloseAlarm = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.ColumnNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnIP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewDevice = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // listViewAlarmInfo
            // 
            this.listViewAlarmInfo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnHeader1,
            this.ColumnHeader2,
            this.columnHeader3});
            this.listViewAlarmInfo.FullRowSelect = true;
            this.listViewAlarmInfo.GridLines = true;
            this.listViewAlarmInfo.Location = new System.Drawing.Point(223, 111);
            this.listViewAlarmInfo.MultiSelect = false;
            this.listViewAlarmInfo.Name = "listViewAlarmInfo";
            this.listViewAlarmInfo.Size = new System.Drawing.Size(413, 421);
            this.listViewAlarmInfo.TabIndex = 32;
            this.listViewAlarmInfo.TabStop = false;
            this.listViewAlarmInfo.UseCompatibleStateImageBehavior = false;
            this.listViewAlarmInfo.View = System.Windows.Forms.View.Details;
            // 
            // ColumnHeader1
            // 
            this.ColumnHeader1.Text = "报警时间";
            this.ColumnHeader1.Width = 140;
            // 
            // ColumnHeader2
            // 
            this.ColumnHeader2.Text = "报警设备";
            this.ColumnHeader2.Width = 114;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "报警信息";
            this.columnHeader3.Width = 246;
            // 
            // btn_SetAlarm
            // 
            this.btn_SetAlarm.Location = new System.Drawing.Point(4, 507);
            this.btn_SetAlarm.Name = "btn_SetAlarm";
            this.btn_SetAlarm.Size = new System.Drawing.Size(91, 25);
            this.btn_SetAlarm.TabIndex = 43;
            this.btn_SetAlarm.Text = "全部布防";
            this.btn_SetAlarm.UseVisualStyleBackColor = true;
            this.btn_SetAlarm.Click += new System.EventHandler(this.btn_SetAlarm_Click);
            // 
            // btnCloseAlarm
            // 
            this.btnCloseAlarm.Location = new System.Drawing.Point(111, 507);
            this.btnCloseAlarm.Name = "btnCloseAlarm";
            this.btnCloseAlarm.Size = new System.Drawing.Size(90, 25);
            this.btnCloseAlarm.TabIndex = 45;
            this.btnCloseAlarm.Text = "全部撤防";
            this.btnCloseAlarm.UseVisualStyleBackColor = true;


            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 464);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 13);
            this.label9.TabIndex = 47;
            this.label9.Text = "注：鼠标右键删除选中的设备";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(482, 464);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 54;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ColumnNumber
            // 
            this.ColumnNumber.Text = "UserID";
            this.ColumnNumber.Width = 50;
            // 
            // ColumnIP
            // 
            this.ColumnIP.Text = "设备IP地址";
            this.ColumnIP.Width = 90;
            // 
            // ColumnStatus
            // 
            this.ColumnStatus.Text = "状态";
            this.ColumnStatus.Width = 160;
            // 
            // listViewDevice
            // 
            this.listViewDevice.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewDevice.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnNumber,
            this.ColumnIP,
            this.ColumnStatus});
            this.listViewDevice.FullRowSelect = true;
            this.listViewDevice.GridLines = true;
            this.listViewDevice.HideSelection = false;
            this.listViewDevice.Location = new System.Drawing.Point(4, 111);
            this.listViewDevice.Name = "listViewDevice";
            this.listViewDevice.Size = new System.Drawing.Size(213, 390);
            this.listViewDevice.TabIndex = 44;
            this.listViewDevice.TabStop = false;
            this.listViewDevice.UseCompatibleStateImageBehavior = false;
            this.listViewDevice.View = System.Windows.Forms.View.Details;


            // 
            // AlarmDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 605);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnCloseAlarm);
            this.Controls.Add(this.listViewDevice);
            this.Controls.Add(this.btn_SetAlarm);
            this.Controls.Add(this.listViewAlarmInfo);
            this.Name = "AlarmDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alarm Test Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView listViewAlarmInfo;
        private System.Windows.Forms.ColumnHeader ColumnHeader1;
        private System.Windows.Forms.ColumnHeader ColumnHeader2;
        private System.Windows.Forms.Button btn_SetAlarm;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button btnCloseAlarm;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColumnHeader ColumnNumber;
        private System.Windows.Forms.ColumnHeader ColumnIP;
        private System.Windows.Forms.ColumnHeader ColumnStatus;
        private System.Windows.Forms.ListView listViewDevice;
    }
}

