﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace IPNBSSDK_CSharp
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            // 查找C++ dll
            if (!System.IO.File.Exists(Application.StartupPath + "\\IPNBSSDK.dll"))
            {
                MessageBox.Show("未在程序目录找到 [IPNBSSDK.dll] 文件!", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormDemo());
        }
    }
}
