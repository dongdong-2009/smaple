﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using static ContinuousShoot.CHCNetSDK;

namespace ContinuousShoot
{
    class Program
    {
        static bool m_bInitSDK;
        static void Main(string[] args)
        {
            if (args == null|| args.Count() == 0)
            {
                Console.WriteLine("参数错误");
                Console.Read();
                return;
            }
          
            try
            {                
                m_bInitSDK = CHCNetSDK.NET_DVR_Init();

                if (!m_bInitSDK)
                {
                    Console.WriteLine("SDK初始化异常");
                    Console.Read();
                }

                CameraLogin1();
                if (!NET_DVR_ContinuousShoot(Convert.ToInt32(args[0])))
                {
                    Console.WriteLine("抓拍异常");
                    Console.Read();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("抓拍异常"+ ex.Message);
                Console.Read();
            }
            finally
            {
                try
                {
                    if (ALARMCM1 >= 0)
                    {
                        CHCNetSDK.NET_DVR_CloseAlarmChan_V30(ALARMCM1);
                    }

                    if (UserID1 >= 0)
                    {
                        CHCNetSDK.NET_DVR_Logout(UserID1);
                    }
                    if (m_bInitSDK == true)
                    {
                        CHCNetSDK.NET_DVR_Cleanup();
                    }                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine("final:" + ex.Message);
                    Console.Read();
                }
            }
        }

        static bool NET_DVR_ContinuousShoot(int u)
        {           
            NET_DVR_SNAPCFG struSnapCfg = new NET_DVR_SNAPCFG();
            struSnapCfg.dwSize = (uint)Marshal.SizeOf(struSnapCfg);
            struSnapCfg.bySnapTimes = 1;
            struSnapCfg.wSnapWaitTime = 1;
            struSnapCfg.byRelatedDriveWay = 0;

            bool x = CHCNetSDK.NET_DVR_ContinuousShoot(u, struSnapCfg);
            return x;
        }

        static int ALARMCM1 = -1, UserID1 = -1;
        static Int16 DVRPortNumber1;
        static string DVRIPAddress1, DVRUserName1, DVRPassword1;
        static void CameraLogin1()
        {
            DVRIPAddress1 = System.Configuration.ConfigurationManager.AppSettings["DVRIPAddress1"].ToString();
            DVRPortNumber1 = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["DVRPortNumber1"]);
            DVRUserName1 = System.Configuration.ConfigurationManager.AppSettings["DVRUserName1"].ToString();
            DVRPassword1 = System.Configuration.ConfigurationManager.AppSettings["DVRPassword1"].ToString();

            CHCNetSDK.NET_DVR_DEVICEINFO_V30 DeviceInfo = new CHCNetSDK.NET_DVR_DEVICEINFO_V30();

            //登录设备 Login the device
            UserID1 = CHCNetSDK.NET_DVR_Login_V30(DVRIPAddress1, DVRPortNumber1, DVRUserName1, DVRPassword1, ref DeviceInfo);
            if (UserID1 < 0)
            {
                uint iLastErr = CHCNetSDK.NET_DVR_GetLastError();
                string str = "NET_DVR_Login_V30 failed, error code= " + iLastErr; //登录失败，输出错误号
                Console.WriteLine(str);
                Console.ReadLine();
                return;
            }

            CHCNetSDK.NET_DVR_SETUPALARM_PARAM struAlarmParam = new CHCNetSDK.NET_DVR_SETUPALARM_PARAM();
            struAlarmParam.dwSize = (uint)Marshal.SizeOf(struAlarmParam);
            struAlarmParam.byLevel = 1; //0- 一级布防,1- 二级布防
            struAlarmParam.byAlarmInfoType = 1;//智能交通设备有效，新报警信息类型
            int ALARMCM1 = CHCNetSDK.NET_DVR_SetupAlarmChan_V41(UserID1, ref struAlarmParam);
            if (ALARMCM1 < 0)
            {
                uint iLastErr = CHCNetSDK.NET_DVR_GetLastError();
                string str = "NET_DVR_SetupAlarmChan_V41 failed, error code= " + iLastErr; //登录失败，输出错误号
                Console.WriteLine(str);
                Console.ReadLine();
                return;
            }
        }
    }
}
