﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            ZJJZXT z = new ZJJZXT();
           Console.WriteLine(z.CallLogs.Count());
            Console.Read();
        }
    }
}
