using System;
using System.Collections.Generic;
using org.in2bits.MyXls.ByteUtil;

namespace org.in2bits.MyXls
{
    /// <summary>
    /// A main class for an XlsDocument, representing one Worksheet in the Workbook.  The 
    /// Worksheet holds the Cells in its Rows.
    /// </summary>
    public class Worksheet
    {
        private readonly XlsDocument _doc;

        private readonly List<ColumnInfo> _columnInfos = new List<ColumnInfo>();
        private readonly List<MergeArea> _mergeAreas = new List<MergeArea>();

        private readonly Cells _cells;
        private readonly Rows _rows;
        private readonly RowBlocks _rowBlocks;

        private WorksheetVisibilities _visibility;
        private WorksheetTypes _sheettype;
        private string _name;
        private int _streamByteLength;
        private int[] _dbCellOffsets;
        private bool _protected = false;

        private CachedBlockRow _cachedBlockRow;

        internal Worksheet(XlsDocument doc)
        {
            _doc = doc;

            _visibility = WorksheetVisibilities.Default;
            _sheettype = WorksheetTypes.Default;
            _streamByteLength = 0;

            _dbCellOffsets = new int[0];

            _cells = new Cells(this);
            _rows = new Rows();
            _rowBlocks = new RowBlocks(this);

            _cachedBlockRow = CachedBlockRow.Empty;

            _columnInfos = new List<ColumnInfo>();
        }

        internal Worksheet(XlsDocument _doc, List<Record> sheetRecords) : this(_doc)
        {
            
        }

        internal XlsDocument Document
        {
            get { return _doc; }
        }

        /// <summary>
        /// Gets or sets the Name of this Worksheet.
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// Gets or sets the Visibility of this Worksheet.
        /// </summary>
        public WorksheetVisibilities Visibility
        {
            get { return _visibility; }
            set { _visibility = value; }
        }

        /// <summary>
        /// Gets or sets the Worksheet Type of this Worksheet.
        /// </summary>
        public WorksheetTypes SheetType
        {
            get { return _sheettype; }
            set { _sheettype = value; }
        }

        /// <summary>
        /// Gets the Cells collection of this Worksheet.
        /// </summary>
        public Cells Cells
        {
            get { return _cells; }
        }

        /// <summary>
        /// Gets the Rows collection of this Worksheet.
        /// </summary>
        public Rows Rows
        {
            get { return _rows; }
        }

        /// <summary>
        /// Gets or sets whether this Worksheet is Protected (the Locked/Hidden status 
        /// of objects such as cells is enforced by Excel).
        /// </summary>
        public bool Protected
        {
            get { return _protected; }
            set { _protected = value; }
        }

        internal int StreamByteLength
        {
            get { return _streamByteLength; }
        }

        internal int[] DBCellOffsets
        {
            set { _dbCellOffsets = value; }
        }

        internal Bytes Bytes
        {
            get
            {
                //NOTE: See excelfileformat.pdf Sec. 4.2

                Bytes bytesA = new Bytes();
                Bytes bytesB = new Bytes();
                Bytes bytesC = new Bytes();
                Bytes bytesD = new Bytes();
                Bytes bytesE = new Bytes();
//                int defaultColumnWidthOffset = 0;
                int rowBlock1Offset;

                //TODO: Move the rest of these sections to private functions like WINDOW2
                bytesD.Append(_rowBlocks.Bytes); //This is first so the RowBlocks interface can calculate the
                //DBCELLOffsets array used below

                //bytesA = BOF (inc) to INDEX (exc)
                //bytesB = INDEX
                //bytesC = INDEX (exc) to RowBlocks (exc)
                //bytesD = RowBlocks
                //bytesE = RowBlocks (exc) to EOF (inc)

                bytesA.Append(Record.GetBytes(RID.BOF, new byte[] { 0x00, 0x06, 0x10, 0x00, 0xAF, 0x18, 0xCD, 0x07, 0xC1, 0x40, 0x00, 0x00, 0x06, 0x01, 0x00, 0x00 }));

                if (_protected)
                    bytesC.Append(Record.GetBytes(RID.PROTECT, new byte[] { 0x01, 0x00 }));
                bytesC.Append(COLINFOS()); //Out of order for a reason - see rowblock1offset calc below

                rowBlock1Offset = _doc.Workbook.Worksheets.StreamOffset;
                int j = _doc.Workbook.Worksheets.GetIndex(Name);
                for (int i = 1; i < j; i++)
                    rowBlock1Offset += _doc.Workbook.Worksheets[i].StreamByteLength;
                rowBlock1Offset += bytesA.Length + (20 + (4 * (_dbCellOffsets.Length - 1))) + bytesC.Length;

                bytesB.Append(INDEX(rowBlock1Offset));

                //BEGIN Worksheet View Settings Block
                bytesE.Append(WINDOW2());
                //END Worksheet View Settings Block

                bytesE.Append(MERGEDCELLS());
                bytesE.Append(Record.GetBytes(RID.EOF, new byte[0]));

                bytesA.Append(bytesB);
                bytesA.Append(bytesC);
                bytesA.Append(bytesD);
                bytesA.Append(bytesE);

                _streamByteLength = bytesA.Length;

                return bytesA;
            }
        }

        private Bytes INDEX(int baseLength)
        {
            Bytes index = new Bytes();

            //Not used
            index.Append(new byte[] { 0x00, 0x00, 0x00, 0x00 });

            //Index to first used row (0-based)
            index.Append(BitConverter.GetBytes(_rows.MinRow - 1));

            //Index to first row of unused tail of sheet(last row + 1, 0-based)
            index.Append(BitConverter.GetBytes(_rows.MaxRow));

            //Absolute stream position of the DEFCOLWIDTH record
            //TODO: Implement Worksheet.INDEX Absolute stream position of the DEFCOLWIDTH record (not necessary)
            index.Append(BitConverter.GetBytes((uint)0));

            for (int i = 1; i < _dbCellOffsets.Length; i++)
                index.Append(BitConverter.GetBytes((uint)(baseLength + _dbCellOffsets[i])));

            return Record.GetBytes(RID.INDEX, index);
        }

        private Bytes WINDOW2()
        {
            Bytes window2 = new Bytes();

            //TODO: Implement options - excelfileformat.pdf pp.210-211
            if (_doc.Workbook.Worksheets.GetIndex(Name) == 0) //NOTE: This was == 1, but the base of the worksheets collection must have changed
                window2.Append(new byte[] { 0xB6, 0x06 });
            else
                window2.Append(new byte[] { 0xB6, 0x04 });
            window2.Append(new byte[] { 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 });

            return Record.GetBytes(RID.WINDOW2, window2);
        }

        private Bytes COLINFOS()
        {
            Bytes colinfos = new Bytes();

            for (int i = 0; i < _columnInfos.Count; i++)
                colinfos.Append(_columnInfos[i].Bytes);

            return colinfos;
        }

        private Bytes MERGEDCELLS()
        {
            Bytes mergedcells = new Bytes();

            int areaIndex = 0;
            int mergeAreaCount = _mergeAreas.Count;
            long areasPerRecord = 1027;
            int recordsRequired = (int)Math.Ceiling(_mergeAreas.Count/(double)areasPerRecord);
            for (int recordIndex = 0; recordIndex < recordsRequired; recordIndex++)
            {
                ushort blockAreaIndex = 0;
                Bytes rangeAddresses = new Bytes();
                while (areaIndex < mergeAreaCount && blockAreaIndex < areasPerRecord)
                {
                    rangeAddresses.Append(CellRangeAddress(_mergeAreas[areaIndex]));

                    blockAreaIndex++;
                    areaIndex++;
                }
                rangeAddresses.Prepend(BitConverter.GetBytes(blockAreaIndex));
                mergedcells.Append(Record.GetBytes(RID.MERGEDCELLS, rangeAddresses));
            }

            return mergedcells;
        }

        private Bytes CellRangeAddress(MergeArea mergeArea)
        {
            return CellRangeAddress(mergeArea.RowMin, mergeArea.RowMax, mergeArea.ColMin, mergeArea.ColMax);
        }

        private Bytes CellRangeAddress(ushort minRow, ushort maxRow, ushort minCol, ushort maxCol)
        {
            minRow--;
            maxRow--;
            minCol--;
            maxCol--;
            Bytes rangeAddress = new Bytes();
            rangeAddress.Append(BitConverter.GetBytes(minRow));
            rangeAddress.Append(BitConverter.GetBytes(maxRow));
            rangeAddress.Append(BitConverter.GetBytes(minCol));
            rangeAddress.Append(BitConverter.GetBytes(maxCol));
            return rangeAddress;
        }

        //TODO: I think this should actually be MRBlockRow --- see use in RowBlocks.BlockRow
        internal CachedBlockRow CachedBlockRow
        {
            get { return _cachedBlockRow; }
            set { _cachedBlockRow = value; }
        }

        /// <summary>
        /// Adds a Column Info record to this Worksheet.
        /// </summary>
        /// <param name="columnInfo">The ColumnInfo object to add to this Worksheet.</param>
        public void AddColumnInfo(ColumnInfo columnInfo)
        {
            //TODO: Implement existence checking & deletion / overwriting / not-adding
            //NOTE: Don't know if this is necessary (i.e. does Excel allow "adding" values of overlapping ColInfos?
            _columnInfos.Add(columnInfo);
        }

        //TODO: Optionally provide overload with bool parameter to decide whether to throw
        //exception instead of losing values.
        /// <summary>
        /// Adds a MergeArea to this Worksheet.  The mergeArea is verified not to
        /// overlap with any previously defined area.  NOTE Values and formatting
        /// in all cells other than the first in mergeArea (scanning left to right,
        /// top to bottom) will be lost.
        /// </summary>
        /// <param name="mergeArea">The MergeArea to add to this Worksheet.</param>
        public void AddMergeArea(MergeArea mergeArea)
        {
            foreach (MergeArea existingArea in _mergeAreas)
            {
                bool colsOverlap = false;
                bool rowsOverlap = false;

                //if they overlap, either mergeArea will surround existingArea, 
                if (mergeArea.ColMin < existingArea.ColMin && existingArea.ColMax < mergeArea.ColMax)
                    colsOverlap = true;
                //or existingArea will contain >= 1 of mergeArea's Min and Max indices
                else if ((existingArea.ColMin <= mergeArea.ColMin && existingArea.ColMax >= mergeArea.ColMin) ||
                    (existingArea.ColMin <= mergeArea.ColMax && existingArea.ColMax >= mergeArea.ColMax))
                    colsOverlap = true;

                if (mergeArea.RowMin < existingArea.RowMin && existingArea.RowMax < mergeArea.RowMax)
                    rowsOverlap = true;
                else if ((existingArea.RowMin <= mergeArea.RowMin && existingArea.RowMax >= mergeArea.RowMin) ||
                    (existingArea.RowMin <= mergeArea.RowMax && existingArea.RowMax >= mergeArea.RowMax))
                    rowsOverlap = true;

                if (colsOverlap && rowsOverlap)
                    throw new ArgumentException("overlaps with existing MergeArea", "mergeArea");
            }

            //TODO: Add ref to this mergeArea to all rows in its range, and add checking on Cell
            //addition methods to validate they are not being added within the mergedarea, other
            //than as the top-left cell.

            _mergeAreas.Add(mergeArea);
        }
    }

}
