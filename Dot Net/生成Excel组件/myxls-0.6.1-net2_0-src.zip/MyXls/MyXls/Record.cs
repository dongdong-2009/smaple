using System;
using System.Collections.Generic;
using org.in2bits.MyXls.ByteUtil;

namespace org.in2bits.MyXls
{
    internal struct Record
    {
        private byte[] _rid;
        private Bytes _data;

        internal Record(byte[] rid, byte[] data)
        {
            _rid = org.in2bits.MyXls.RID.ByteArray(rid);
            _data = new Bytes(data);
        }

        internal byte[] RID
        {
            get { return _rid; }
        }

        internal Bytes Data
        {
            get { return _data; }
        }

        internal static Bytes GetBytes(byte[] rid, byte[] data)
        {
            return GetBytes(rid, new Bytes(data));
        }

        internal static Bytes GetBytes(byte[] rid, Bytes data)
        {
            if (rid.Length != 2)
                throw new ArgumentException("must be 2 bytes", "rid");
            ushort len = (ushort)data.Length;
            Bytes record = new Bytes();
            record.Append(rid);
            record.Append(BitConverter.GetBytes(len));
            record.Append(data);
            return record;
        }

        public static List<Record> GetAll(Bytes stream)
        {
            int i = 0;
            List<Record> records = new List<Record>();
            while (i < (stream.Length - 4))
            {
                byte[] rid = stream.Get(i, 2).ByteArray;
                if (rid[0] == 0x00 && rid[1] == 0x00)
                    break;
                int length = BitConverter.ToUInt16(stream.Get(i + 2, 2).ByteArray, 0);
                byte[] data = stream.Get(i + 4, length).ByteArray;
                Record record = new Record(rid, data);
                i += (4 + length);
                records.Add(record);
            }

            return records;
        }
    }
}
