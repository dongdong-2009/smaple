namespace org.in2bits.MyXls
{
    internal interface IXFTarget
    {
        void UpdateId(XF fromXF);
    }
}
