using System;
using System.IO;
using System.Text;
using org.in2bits.MyOle2;
using org.in2bits.MyOle2.Metadata;
using org.in2bits.MyXls.ByteUtil;

namespace org.in2bits.MyXls
{
    /// <summary>
    /// The root class of MyXls, containing general configuration properties and references to
    /// the Workbook as well as the MyOle2 Document which will contain and format the workbook
    /// when Sending or Saving.
    /// </summary>
	public class XlsDocument
	{
		private readonly MyOle2.Ole2Document _ole2Doc;
		private readonly Workbook _workbook;
		private readonly SummaryInformationSection _summaryInformation;
        private readonly DocumentSummaryInformationSection _documentSummaryInformation;

		private string _fileName = "Book1.xls";
		private bool _isLittleEndian = true;
		private bool _forceStandardOle2Stream = false;

        /// <summary>
        /// Initializes a new instance of the XlsDocument class.
        /// </summary>
		public XlsDocument()
		{
			_forceStandardOle2Stream = false;
			_isLittleEndian = true;

			_ole2Doc = new MyOle2.Ole2Document();
			SetOleDefaults();

            _summaryInformation = new SummaryInformationSection();
            _documentSummaryInformation = new DocumentSummaryInformationSection();

			_workbook = new Workbook(this);
		}

        /// <summary>
        /// Initializes a new XlsDocument from the provided file, reading in as much information
        /// from the file as possible and representing it appropriately with MyXls objects
        /// (Workbook, Worksheets, Cells, etc.).
        /// </summary>
        /// <param name="fileName">The name of the file to read into this XlsDocument.</param>
        public XlsDocument(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                throw new ArgumentException("Can't be null or Empty", "fileName");

            if (!File.Exists(fileName))
                throw new FileNotFoundException("Source File not found", fileName);

            _ole2Doc = new Ole2Document();
            _ole2Doc.Load(File.Open(fileName, FileMode.Open, FileAccess.Read, FileShare.Read));

            //TODO: SummaryInformationSection and DocumentSummaryInformationSections should be read by MyOle2

            _workbook = new Workbook(this, _ole2Doc.Streams[_ole2Doc.Streams.GetIndex(org.in2bits.MyOle2.Directory.Biff8Workbook)].Bytes);
        }

        /// <summary>
        /// Gets or sets the FileName (no path) for this XlsDocument (effective when sending
        /// to a Web client via the Send method).
        /// </summary>
		public string FileName
		{
			get { return _fileName; }
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentException("FileName cannot be null or Empty");

				if (string.Compare(value.Substring(value.Length - 4), ".xls", true) != 0)
					value = string.Format("{0}.xls", value);

				_fileName = value;
			}
		}

		private void SetOleDefaults()
		{
			//Can be any 16-byte value per OOo compdocfileformat.pdf
			_ole2Doc.DocUID = new byte[16];

			//Most common (BIFF8) value per OOo compdocfileformat.pdf
			_ole2Doc.SectorSize = 9;

			//Most common (BIFF8) value per OOo compdocfileformat.pdf
			_ole2Doc.ShortSectorSize = 6;

			//Most common (BIFF8) value per OOo compdocfileformat
			_ole2Doc.StandardStreamMinBytes = 4096;
		}

		/// <summary>
		/// Gets this org.in2bits.MyXls XlsDocument's OLE2 Document.
		/// </summary>
		public MyOle2.Ole2Document OLEDoc { get { return _ole2Doc; } }

		/// <summary>
		/// Gets this org.in2bits.MyXls XlsDocument's Workbook.
		/// </summary>
		public Workbook Workbook { get { return _workbook; } }

        /// <summary>
        /// Gets a Bytes object containing all the bytes of this OleDocument's stream.
        /// </summary>
        public Bytes Bytes
		{
			get
			{
			    _ole2Doc.Streams.AddNamed(_workbook.Bytes, BIFF8.NameWorkbook, true);

			    MetadataStream summaryInformationStream = new MetadataStream(_ole2Doc);
			    summaryInformationStream.Sections.Add(_summaryInformation);
			    _ole2Doc.Streams.AddNamed(GetStandardOLE2Stream(summaryInformationStream.Bytes), BIFF8.NameSummaryInformation, true);

			    MetadataStream documentSummaryInformationStream = new MetadataStream(_ole2Doc);
			    documentSummaryInformationStream.Sections.Add(_documentSummaryInformation);
			    _ole2Doc.Streams.AddNamed(GetStandardOLE2Stream(documentSummaryInformationStream.Bytes), BIFF8.NameDocumentSummaryInformation, true);

				return _ole2Doc.Bytes;
			}
		}

        /// <summary>
        /// Gets the SummaryInformationSection for this XlsDocument.
        /// </summary>
        public SummaryInformationSection SummaryInformation
        {
            get { return _summaryInformation; }
        }

        /// <summary>
        /// Gets the DocumentSummaryInformationSection for this XlsDocument.
        /// </summary>
        public DocumentSummaryInformationSection DocumentSummaryInformation
        {
            get { return _documentSummaryInformation; }
        }

        /// <summary>
        /// Methods available to send XlsDocument to HTTP Client (Content-disposition header setting)
        /// </summary>
        public enum SendMethods
        {
            /// <summary>The client browser should try to open the file within browser window.</summary>
            Inline,

            /// <summary>The client browser should prompt to Save or Open the file.</summary>
            Attachment
        }

        private static string GetContentDisposition(SendMethods sendMethod)
        {
            if (sendMethod == SendMethods.Attachment)
                return "attachment";
            else if (sendMethod == SendMethods.Inline)
                return "inline";
            else
                throw new NotSupportedException();
        }

        /// <summary>
        /// Valid in an ASP.NET context only.  Sends this XlsDocument to the client with the 
        /// given FileName as an attachment file, via the HttpResponse object.  Clears
        /// the Response before sending and ends the Response after sending.
        /// </summary>
        public void Send()
        {
            Send(SendMethods.Attachment);
        }

        /// <summary>
        /// Valid in an ASP.NET context only.  Sends this XlsDocument to the client with the 
        /// given FileName as an attached or inline file, via the HttpResponse object.  Clears
        /// the Response before sending and ends the Response after sending.
        /// </summary>
		public void Send(SendMethods sendMethod)
		{
			//only applies in Classic ASP context?
		    System.Web.HttpContext context = System.Web.HttpContext.Current;
            if (context == null)
                throw new ApplicationException("Current System.Web.HttpContext not found - Send failed.");

            if (!context.Response.Buffer)
            {
                context.Response.Buffer = true;
                context.Response.Clear();
            }

		    context.Response.ContentType = "application/vnd.ms-excel";
            context.Response.AddHeader("Content-Disposition", string.Format("{0};filename={1}", GetContentDisposition(sendMethod), FileName));
		    context.Response.Flush();
		    context.Response.BinaryWrite(Bytes.ByteArray);
		}

        /// <summary>
        /// Save this XlsDocument to the Current Directory. The FileName property will be used for
        /// the FileName.
        /// </summary>
        /// <param name="overwrite">Whether to overwrite if the specified file already exists.</param>
        public void Save(bool overwrite)
        {
            Save(null, overwrite);
        }

        /// <summary>
        /// Save this XlsDocument to the Current Directory.  The FileName property will be used
        /// for the FileName.  Will not overwrite.
        /// </summary>
        public void Save()
        {
            Save(null);
        }

        /// <summary>
        /// Save this XlsDocument to the given path.  The FileName property will be used for the
        /// FileName.  Will not overwrite.
        /// </summary>
        /// <param name="path">The Path to which to save this XlsDocument.</param>
        public void Save(string path)
        {
            Save(path, false);
        }

        /// <summary>
        /// Save this XlsDocument to the given path.  The FileName property will be used for the
        /// FileName.
        /// </summary>
        /// <param name="path">The Path to which to save this XlsDocument.</param>
        /// <param name="overwrite">Whether to overwrite if the specified file already exists.</param>
        public void Save(string path, bool overwrite)
        {
            if (path == null)
                path = Environment.CurrentDirectory;
            string separator = Path.DirectorySeparatorChar.ToString();
            if (!path.EndsWith(separator))
                path += separator;
            string fileName = path + FileName;
            if (File.Exists(fileName))
            {
                if (overwrite)
                    File.Delete(fileName);
                else
                    throw new IOException(string.Format("File {0} already exists.", fileName));
            }
            byte[] bytes = Bytes.ByteArray;
            File.WriteAllBytes(fileName, bytes);
        }

        /// <summary>
        /// Gets whether this XlsDocument is Little Endian.  In the current implementation of
        /// MyXLS, this is always true.
        /// </summary>
		public bool IsLittleEndian
		{
			get { return _isLittleEndian; }
		}

        /// <summary>
        /// Gets or sets whether to force the XlsDocument data to be padded to the length
        /// of a Standard Stream in its MyOle2 document container, if it is less than 
        /// standard length without padding.
        /// </summary>
		public bool ForceStandardOle2Stream
		{
			get { return _forceStandardOle2Stream; }
			set { _forceStandardOle2Stream = value; }
		}

        internal Bytes GetStandardOLE2Stream(Bytes bytes)
		{
			uint standardLength = _ole2Doc.StandardStreamMinBytes;
			uint padLength = standardLength = ((uint)bytes.Length % standardLength);
			if (padLength < standardLength)
				bytes.Append(new byte[padLength]);
			return bytes;
		}

        internal static string ReadBinUniStr1(Bytes bytes)
        {
            return ReadBinUniStr(bytes, 255);
        }

        internal static Bytes BinUniStr1(string text)
		{
			return BinUniStr(text, 255);
		}

        internal static string ReadBinUniStr2(Bytes bytes)
        {
            return ReadBinUniStr(bytes, 65535);
        }

        internal static Bytes BinUniStr2(string text)
		{
			return BinUniStr(text, 65535);
		}

        private static Bytes BinUniStr(string text, int limit)
		{
			int textLength;
			byte[] binaryLength = new byte[0], compression, compressedText = new byte[0];

			textLength = text.Length;
			if (textLength > limit)
			{
				text = text.Substring(0, limit);
//				textLength = limit;
			}

			if (limit == 255)
				binaryLength = new byte[1] { (byte)text.Length };
			else if (limit == 65535)
				binaryLength = BitConverter.GetBytes((ushort) text.Length);

			if (IsCompressible(text))
			{
				compression = new byte[1];
				char[] chars = text.ToCharArray();
				compressedText = new byte[chars.Length];
				for (int i = 0; i < chars.Length; i++)
					compressedText[i] = (byte) chars[i];
			}
			else
			{
				compression = new byte[1] {1};
			}

			Bytes bytes = new Bytes();
			bytes.Append(binaryLength);
			bytes.Append(compression);
			if (compressedText.Length > 0)
				bytes.Append(compressedText);
			else
				bytes.Append(Encoding.Unicode.GetBytes(text));
			return bytes;
		}

        private static string ReadBinUniStr(Bytes bytes, int limit)
        {
            int length = 0;
            byte[] textBytes = new byte[0];
            bool compressed = false;
            if (limit == 255)
            {
                length = (int) bytes.Get(1).ByteArray[0];
                compressed = (bytes.Get(1, 1).ByteArray[0] == 0x00);
                textBytes = bytes.Get(2, bytes.Length - 2).ByteArray;
            }
            else if (limit == 65535)
            {
                length = BitConverter.ToUInt16(bytes.Get(2).ByteArray, 0);
                compressed = (bytes.Get(2, 1).ByteArray[0] == 0x00);
                textBytes = bytes.Get(3, bytes.Length - 3).ByteArray;
            }

            if (compressed)
                return (new string(Encoding.UTF8.GetChars(textBytes)));
            else 
                return (new string(Encoding.Unicode.GetChars(textBytes)));
        }

        private static bool IsCompressible(string text)
		{
			byte[] textBytes = Encoding.Unicode.GetBytes(text);

			for (int i = 1; i < textBytes.Length; i += 2)
			{
				if (textBytes[i] != 0)
					return false;
			}

			return true;
		}

        /// <summary>
        /// Gets a new XF (Formatting) object for use on this document.
        /// </summary>
        /// <returns></returns>
        public XF NewXF()
        {
            return new XF(this);
        }
	}
}

