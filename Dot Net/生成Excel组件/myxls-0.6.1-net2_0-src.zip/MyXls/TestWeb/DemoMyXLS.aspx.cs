using System;
using org.in2bits.MyXls;

namespace org.in2bits.MyXls
{
    public partial class DemoMyXLS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            org.in2bits.MyXls.XlsDocument doc = new XlsDocument();
            doc.FileName = "TestingAgain.xls";

            //doc.Workbook.ProtectContents = true;

            for (int s = 1; s <= 5; s++)
            {
                string sheetName = Request.Form["txtSheet" + s].Replace(",", string.Empty);
                
                if (sheetName.Trim() == string.Empty)
                    continue;

                int rowMin, rowCount, colMin, colCount;

                try
                {
                    rowMin = int.Parse(Request.Form["txtRowMin" + s]);
                    rowCount = int.Parse(Request.Form["txtRows" + s]);
                    colMin = int.Parse(Request.Form["txtColMin" + s]);
                    colCount = int.Parse(Request.Form["txtCols" + s]);
                }
                catch
                {
                    continue;
                }

                if (rowCount > 65535) rowCount = 65535;
                if (rowCount < 0) rowCount = 0;
                if (rowMin < 1) rowMin = 1;
                if (rowMin > 32767) rowMin = 32767;

                if (colCount > 255) colCount = 255;
                if (colCount < 1) colCount = 1;
                if (colMin < 1) colMin = 1;
                if (colMin > 100) colMin = 100;

                if (sheetName.Length > 35) sheetName = sheetName.Substring(0, 35);

                Worksheet sheet = doc.Workbook.Worksheets.Add(sheetName);
                //sheet.Protected = true;
                Cells cells = sheet.Cells;

                for (int row = 0; row <= rowCount; row++)
                {
                    if (row == 0)
                    {
                        for (int col = 1; col <= colCount; col++)
                        {
                            Cell cell = cells.Add(rowMin + row, colMin + col - 1, "Fld" + col);
                            cell.Font.Weight = 700;
                            cell.DiagonalAscending = true;
                            cell.DiagonalLineColor = Colors.Black;
                            cell.DiagonalLineStyle = 2;
                            //cell.Pattern = 18;
                            //cell.PatternColorIndex = 0;
                            //cell.PatternBackgroundColor = Colors.Green;
                            cell.Locked = true;
                        }
                    }
                    else
                    {
                        for (int col = 1; col <= colCount; col++)
                        {
                            Cell cell = cells.Add(rowMin + row, colMin + col - 1, /*row + col*/1.001);
                            cell.Locked = false;
                        }
                    }
                }
            }

            doc.Send();
            Response.Flush();
            Response.End();
        }
    }
}
