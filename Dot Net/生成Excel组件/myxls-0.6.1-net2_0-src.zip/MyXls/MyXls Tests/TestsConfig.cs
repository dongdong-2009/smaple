using System;

namespace org.in2bits.MyOle2
{
    public static class TestsConfig
    {
        /// <summary>
        /// Useful files for tests have to be stored in ExamplesFolder
        /// </summary>
        public static string ExamplesFolder
        {
            get
            {
                if (System.IO.Directory.Exists("..\\..\\..\\Docs\\TestExamples\\"))
                {
                    return "..\\..\\..\\Docs\\TestExamples\\";
                }
                if (System.IO.Directory.Exists("..\\..\\Docs\\TestExamples\\"))
                {
                    return "..\\..\\Docs\\TestExamples\\";
                }
                throw new ApplicationException("Examples Folder not found!");
            }
        }
    }
}