using System;
using NUnit.Framework;
using org.in2bits.MyXls.ByteUtil;

namespace org.in2bits.MyXls
{
    [TestFixture]
    public class CellTests : MyXlsTestFixture
    {
        [Test]
        public void WriteDateTime()
        {
            DateTime dateTime = DateTime.Now;
            XlsDocumentDelegate docDelegate = delegate(XlsDocument doc)
              {
                  Worksheet sheet = doc.Workbook.Worksheets.Add("Sheet1");

                  Cell cell = sheet.Cells.Add(1, 1, dateTime);
                  Assert.AreEqual(dateTime.ToOADate(), cell.Value, "Cell value");
              };
            string fileName = WriteDocument(docDelegate);
            double dateTimeDouble = Math.Round(dateTime.ToOADate(), 2);
            string dateTimeString = dateTimeDouble.ToString();
            AssertPropertyViaExcelOle(fileName, CellProperties.Text, dateTimeString, "Date value (text)");
        }

        [Test]
        public void Write1()
        {
            string fileName = Write1Cell(1);
            AssertPropertyViaExcelOle(fileName, CellProperties.Value, 1.ToString(), "Cell Value");
        }

        [Test]
        public void Write1_1()
        {
            string fileName = Write1Cell(1.1);
            AssertPropertyViaExcelOle(fileName, CellProperties.Value, (1.1).ToString(), "Cell Value");
        }

        [Test]
        public void Write1_01()
        {
            string fileName = Write1Cell(1.01);
            AssertPropertyViaExcelOle(fileName, CellProperties.Value, (1.01).ToString(), "Cell Value");
        }

        [Test]
        public void Write1_001()
        {
            string fileName = Write1Cell(1.001);
            AssertPropertyViaExcelOle(fileName, CellProperties.Value, (1.001).ToString(), "Cell Value");
        }

        [Test]
        public void WriteN2825_48()
        {
            string fileName = Write1Cell(-2825.48);
            AssertPropertyViaExcelOle(fileName, CellProperties.Value, (-2825.48).ToString(), "Cell Value");
        }

        [Test]
        public void DoubleIsLittleEndian()
        {
            double dbl = 123.4567;
            Bytes bytes = new Bytes(BitConverter.GetBytes(dbl));
            Bytes.Bits bits = bytes.GetBits();
            Bytes.Bits mostSigBits = bits.Get(2, 62);
            double newDbl = mostSigBits.ToDouble();
            Assert.AreEqual(dbl, newDbl, 0.000001, "Values are different");
        }

        [Test]
        public void ChoppedDoubleIsValidDecimalRK()
        {
            double dbl = 123.4567;
            Bytes bytes = new Bytes(BitConverter.GetBytes(dbl));
            Bytes.Bits bits = bytes.GetBits();
            Bytes.Bits mostSigBits = bits.Get(34, 30);
            double newDbl = mostSigBits.ToDouble();
            Assert.AreEqual(dbl, newDbl, 0.001, "Values are too different");
        }

        private Worksheet GetBaseMergeAreaOverlapTestSheet()
        {
            XlsDocument doc = new XlsDocument();
            Worksheet sheet = doc.Workbook.Worksheets.Add("Sheet1");
            sheet.Cells.Merge(2, 4, 10, 15);
            return sheet;
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingColumnsThrowsA()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 4, 8, 11);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingColumnsThrowsB()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 4, 10, 12);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingColumnsThrowsC()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 4, 12, 15);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingColumnsThrowsD()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 4, 12, 18);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingRowsThrowsA()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(1, 2, 11, 12);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingRowsThrowsB()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(2, 3, 11, 12);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingRowsThrowsC()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 4, 11, 12);
        }

        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void MergingOverlappingRowsThrowsD()
        {
            GetBaseMergeAreaOverlapTestSheet().Cells.Merge(3, 8, 11, 12);
        }

        [Test]
        public void MergeA1toC1()
        {
            XlsDocumentDelegate docDelegate = delegate(XlsDocument doc)
                {
                    Worksheet sheet = doc.Workbook.Worksheets.Add("Sheet1");
                    Cell cell = sheet.Cells.Add(1, 1, "ValA1");
                    cell = sheet.Cells.Add(1, 2, "ValB1");
                    cell = sheet.Cells.Add(1, 3, "ValC1");
                    cell = sheet.Cells.Add(2, 1, "ValA2");
                    cell = sheet.Cells.Add(2, 2, "ValB2");
                    cell = sheet.Cells.Add(2, 3, "ValC2");
                    sheet.Cells.Merge(1, 1, 1, 3);
                };
            string fileName = WriteDocument(docDelegate);
            AssertPropertyViaExcelOle(1, 1, 1, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "A1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 1, 2, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "B1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 1, 3, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "C1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 2, 1, fileName, CellProperties.MergeAreaCount, (1).ToString(),
                                      "A2 should have MergeArea with 1 cells");
            AssertPropertyViaExcelOle(1, 2, 2, fileName, CellProperties.MergeAreaCount, (1).ToString(),
                                      "B2 should have MergeArea with 1 cells");
            AssertPropertyViaExcelOle(1, 2, 3, fileName, CellProperties.MergeAreaCount, (1).ToString(),
                                      "C2 should have MergeArea with 1 cells");
        }

        [Test]
        public void MergeA1toC1andB2toC2()
        {
            XlsDocumentDelegate docDelegate = delegate(XlsDocument doc)
                {
                    Worksheet sheet = doc.Workbook.Worksheets.Add("Sheet1");
                    Cell cell = sheet.Cells.Add(1, 1, "ValA1");
                    cell = sheet.Cells.Add(1, 2, "ValB1");
                    cell = sheet.Cells.Add(1, 3, "ValC1");
                    cell = sheet.Cells.Add(2, 1, "ValA2");
                    cell = sheet.Cells.Add(2, 2, "ValB2");
                    cell = sheet.Cells.Add(2, 3, "ValC2");
                    sheet.Cells.Merge(1, 1, 1, 3);
                    sheet.Cells.Merge(2, 2, 2, 3);
                };
            string fileName = WriteDocument(docDelegate);
            AssertPropertyViaExcelOle(1, 1, 1, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "A1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 1, 2, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "B1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 1, 3, fileName, CellProperties.MergeAreaCount, (3).ToString(),
                                      "C1 should have MergeArea with 3 cells");
            AssertPropertyViaExcelOle(1, 2, 1, fileName, CellProperties.MergeAreaCount, (1).ToString(),
                                      "A2 should have MergeArea with 1 cells");
            AssertPropertyViaExcelOle(1, 2, 2, fileName, CellProperties.MergeAreaCount, (2).ToString(),
                                      "B2 should have MergeArea with 2 cells");
            AssertPropertyViaExcelOle(1, 2, 3, fileName, CellProperties.MergeAreaCount, (2).ToString(),
                                      "C2 should have MergeArea with 2 cells");
        }
    }
}
