using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using NUnit.Framework;
using org.in2bits.MyOle2;
using org.in2bits.MyXls.ByteUtil;
using Directory=org.in2bits.MyOle2.Directory;

namespace org.in2bits.MyXls
{
    [TestFixture]
    public class XlsDocumentTests : MyXlsTestFixture
    {
        [Test]
        public void DotNetUnicodeString()
        {
            string myString = "hello";
            byte[] myBytes = Encoding.Unicode.GetBytes(myString); //BitConverter.GetBytes(myString);
            Debug.WriteLine(myString.ToCharArray().Length);
            Assert.AreEqual(10, myBytes.Length);
            Assert.AreEqual(104, (byte)('h'));
            Assert.AreEqual(104, myBytes[0]);
            Assert.AreEqual(0, myBytes[1]);
            Assert.AreEqual(101, myBytes[2]);
            Assert.AreEqual(0, myBytes[3]);
            Assert.AreEqual(108, myBytes[4]);
            Assert.AreEqual(0, myBytes[5]);
            Assert.AreEqual(108, myBytes[6]);
            Assert.AreEqual(0, myBytes[7]);
            Assert.AreEqual(111, myBytes[8]);
            Assert.AreEqual(0, myBytes[9]);
        }

        [Test]
        public void EmptyWorkbook()
        {
            XlsDocument doc = new XlsDocument();
            SetTestMetadata(doc);
            string expected = TestsConfig.ExamplesFolder + "empty.xls";
            string actual = "empty.xls";
            WriteBytesToFile(doc.Bytes, actual);
            AssertFilesBinaryEqual(expected, actual);
        }

        [Test]
        public void GetBytesTwice()
        {
            XlsDocument doc = new XlsDocument();
            int expectedLength = doc.Bytes.ByteArray.Length;
            Assert.AreEqual(expectedLength, doc.Bytes.ByteArray.Length);
        }

        [Test]
        public void Rows1Cols1Row1Col1()
        {
            string expected = TestsConfig.ExamplesFolder + "Rows1Cols1Row1Col1.xls";

            string actual = "Rows1Cols1Row1Col1.xls";

            XlsDocument doc = GetSimple("BIFF8Sheet_", 1, 1, 1, 1, 1);
            doc.FileName = actual;

            WriteBytesToFile(doc.Bytes, actual);
            AssertFilesBinaryEqual(expected, actual);
        }

        [Test]
        public void Rows2Cols1Row1Col1()
        {
            string expected = TestsConfig.ExamplesFolder + "Rows2Cols1Row1Col1.xls";

            string actual = "Rows2Cols1Row1Col1.xls";

            XlsDocument doc = GetSimple("BIFF8Sheet_", 1, 2, 1, 1, 1);
            doc.FileName = actual;

            WriteBytesToFile(doc.Bytes, actual);
            AssertFilesBinaryEqual(expected, actual);
        }

        [Test]
        public void Save()
        {
            string fileName = "TestSave.xls";
            XlsDocument doc = new XlsDocument();
            doc.FileName = fileName;
            string path = Environment.CurrentDirectory;
            if (!path.EndsWith("\\"))
                path += "\\";
            if (File.Exists(path + fileName))
                File.Delete(path + fileName);
            Assert.IsFalse(File.Exists(path + fileName));
            doc.Save();
            Assert.IsTrue(File.Exists(path + fileName));
            File.Delete(path + fileName);
        }

        [Test]
        public void GetStreamsFromBaseline2003Xls()
        {
            string fileName = "..\\..\\..\\Docs\\Baseline2003.xls";
            Assert.IsTrue(File.Exists(fileName), "Baseline2003.xls not found");
            XlsDocument xls = new XlsDocument(fileName);
            Assert.AreEqual(3, xls.OLEDoc.Streams.Count, "# streams found in Ole Document");
            Bytes workbookBytes = xls.OLEDoc.Streams[xls.OLEDoc.Streams.GetIndex(Directory.Biff8Workbook)].Bytes;
            Assert.IsNotNull(workbookBytes);
            Assert.IsFalse(0 == workbookBytes.Length);
            Assert.IsNotNull(xls.Workbook, "Workbook object");
            Assert.IsNotNull(xls.Workbook.Worksheets, "Worksheets collection");
            Assert.AreEqual(3, xls.Workbook.Worksheets.Count);
            Assert.AreEqual("Sheet1", xls.Workbook.Worksheets[0].Name, "Sheet 1 Name");
            Assert.AreEqual("Sheet2", xls.Workbook.Worksheets[1].Name, "Sheet 2 Name");
            Assert.AreEqual("Sheet3", xls.Workbook.Worksheets[2].Name, "Sheet 3 Name");
        }

        private static void SetTestMetadata(XlsDocument doc)
        {
            doc.SummaryInformation.CreateTimeDate = new DateTime(2007, 1, 1);
            doc.SummaryInformation.LastSavedBy = "Tester";
        }

        private static XlsDocument GetSimple(string sbase, int sct, int rct, int cct, int rmin, int cmin)
        {
            XlsDocument doc = new XlsDocument();
            SetTestMetadata(doc);

            for (int s = 1; s <= sct; s++)
            {
                string sName = string.Format("{0}{1}", sbase, s);
                if (sName.Length > 35)
                    sName = sName.Substring(0, 35);
                Worksheet sht = doc.Workbook.Worksheets.Add(sName); //Add sheet (and name it)
                Cells cells = sht.Cells; //Grab Sheet.Cells Collection object

                for (int r = 0; r <= rct; r++)
                {
                    if (r == 0) //Add Header row
                    {
                        for (int c = 1; c <= cct; c++) //Iterate columns
                        {
                            cells.Add((ushort)(rmin + r), (ushort)(cmin + c - 1), "Fld" + c); //Add Header cells
                        }
                    }
                    else //Write data row
                    {
                        for (int c = 1; c <= cct; c++) //Iterate columns
                        {
                            cells.Add((ushort)(rmin + r), (ushort)(cmin + c - 1), -1 * (r + c)); //Add Value cells
                        }
                    }
                }
            }

            return doc;
        }

        private void AssertFilesBinaryEqual(string expectedFileName, string actualFileName)
        {
            int row = 0;
            FileStream expectedStream = new FileInfo(expectedFileName).Open(FileMode.Open, FileAccess.Read);
            FileStream actualStream = new FileInfo(actualFileName).Open(FileMode.Open, FileAccess.Read);

            string failMessage = string.Empty;

            try
            {
                while (!IsEOF(expectedStream) && !IsEOF(actualStream))
                {
                    byte[] bufferExpected = new byte[16];
                    byte[] bufferActual = new byte[16];

                    expectedStream.Read(bufferExpected, 0, 16);
                    actualStream.Read(bufferActual, 0, 16);

                    int i = 0;
                    for (; i < 16; i++)
                        if (bufferExpected[i] != bufferActual[i]) break;

                    if (i < 16)
                    {
                        int diffPosition = row * 16 + i;
                        failMessage = string.Format("files differ at byte {0}", diffPosition);
                        break;
                    }

                    row++;
                }

                if (failMessage == string.Empty)
                {
                    if (!IsEOF(expectedStream))
                        Assert.Fail("expected is longer");
                    else if (!IsEOF(actualStream))
                        Assert.Fail("actual is longer");
                }
            }
            finally
            {
                expectedStream.Close();
                expectedStream.Dispose();
                actualStream.Close();
                actualStream.Dispose();
            }

            if (failMessage != string.Empty)
                AssertFailMyXls(failMessage, expectedFileName, actualFileName);
        }

        private void AssertFailMyXls(string message, string expectedFile, string actualFile)
        {
            Ole2Document n2doc = new Ole2Document();
            FileStream fs = new FileInfo(actualFile).Open(FileMode.Open, FileAccess.Read);
            n2doc.Load(fs);
            fs.Close();
            Bytes actualWorksheet = n2doc.Streams[n2doc.Streams.GetIndex(Directory.Biff8Workbook)].Bytes;
            n2doc = new Ole2Document();
            fs = new FileInfo(expectedFile).Open(FileMode.Open, FileAccess.Read);
            n2doc.Load(fs);
            fs.Close();
            Bytes expectedWorksheet = n2doc.Streams[n2doc.Streams.GetIndex(Directory.Biff8Workbook)].Bytes;
            string expectedWorksheetFile = "ExpectedWorksheet.records";
            string actualWorksheetFile = "ActualWorksheet.records";
            WriteRecordsToFile(actualWorksheet, actualWorksheetFile);
            WriteRecordsToFile(expectedWorksheet, expectedWorksheetFile);

            Process ueProc = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "uedit32";
            startInfo.Arguments =
                string.Format("/a \"{0}\" \"{1}\" \"{2}\" \"{3}\"", expectedFile, actualFile, expectedWorksheetFile,
                              actualWorksheetFile);
            ueProc.StartInfo = startInfo;
            ueProc.Start();
            Assert.Fail(message);
        }

        private static void WriteRecordsToFile(Bytes bytes, string fileName)
        {
            FileInfo fi = new FileInfo(fileName);
            FileStream fs = fi.Open(FileMode.Create, FileAccess.Write);
            int pos = 0;
            StringBuilder sb = new StringBuilder();
            while (pos < bytes.Length)
            {
                byte[] ridArray = bytes.Get(pos, 2).ByteArray;
                sb.Append(RID.Name(ridArray));
                sb.Append(" ");
                pos += 2;
                ushort len = BitConverter.ToUInt16(bytes.Get(pos, 2).ByteArray, 0);
                pos += 2;
                byte[] byteArray = bytes.Get(pos, len).ByteArray;
                foreach (byte b in byteArray)
                {
                    sb.Append(GetByteHex(b));
                    sb.Append(" ");
                }
                sb.Append(Environment.NewLine);
                pos += byteArray.Length;
            }
            string records = sb.ToString();
            fs.Write(Encoding.ASCII.GetBytes(records), 0, records.Length);
            fs.Flush();
            fs.Close();
        }

        private static string GetByteHex(byte b)
        {
            int int1 = (int)Math.Floor(b * 1.0 / 16);
            int int2 = (int)(b % 16);

            return new string(new char[] { GetHexChar(int1), GetHexChar(int2) });
        }

        private static char GetHexChar(int i)
        {
            if (i <= 9)
                i += 48;
            else
                i += 55;
            return (char)i;
        }

        private static bool IsEOF(FileStream stream)
        {
            return (stream.Position >= stream.Length);
        }

        private static void WriteBytesToFile(byte[] bytes, string fileName)
        {
            FileInfo fi = new FileInfo(fileName);
            if (File.Exists(fi.Name))
                File.Delete(fi.Name);
            FileStream fileStream = fi.Open(FileMode.Create, FileAccess.Write, FileShare.Read);
            fileStream.Write(bytes, 0, bytes.Length);
            fileStream.Close();
            fileStream.Dispose();
        }

        private static void WriteBytesToFile(byte[] bytes)
        {
            WriteBytesToFile(bytes, "test.bin");
        }

        private static void WriteBytesToFile(Bytes bytes, string fileName)
        {
            WriteBytesToFile(bytes.ByteArray, fileName);
        }
    }
}
