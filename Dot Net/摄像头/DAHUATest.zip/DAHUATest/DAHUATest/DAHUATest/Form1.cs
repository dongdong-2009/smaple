﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace DAHUATest
{
    public partial class Form1 : Form
    {        
        public Form1()
        {
            InitializeComponent();
            //初始化车牌抓拍
            //string PlateType = "无";//Common.ReadRegister("PlateType");
            string IP1 = "172.31.8.165";//Common.ReadRegister("PlateIP");
            string port = "37777";//Common.ReadRegister("PlatePort");
            if (IP1.Length > 7)
            {
                InitDH(ref disConnect, ref onlineEvent, ref nLoginID, IP1, ref DHdeviceInfo, ushort.Parse(port), nAnalyhandle);
                if (RunDH(ref cbAnalyzerDat, ref nAnalyhandle, nLoginID))
                {
                    //lPlate1.ImageIndex = 0;
                    //Common.WriteLog("车牌抓拍1初始化成功");
                }
            }
        }
        /// <summary>
        /// 二进制流数据转化为图像
        /// </summary>
        /// <param name="vehicleImage">二进制流</param>
        /// <returns></returns>
        public static Image StreamToImage(byte[] vehicleImage)
        {
            if (vehicleImage.Length < 100)
            {
                return null;
            }
            System.IO.MemoryStream ms = new MemoryStream(vehicleImage);
            System.Drawing.Image img = System.Drawing.Image.FromStream(ms);
            ms.Close();
            return img;

        }

        /// <summary>
        /// 图像转化为二进制流
        /// </summary>
        /// <param name="img">图像</param>
        /// <returns></returns>
        public static byte[] ImageToStream(System.Drawing.Image img)
        {
            try
            {
                System.IO.MemoryStream ms = new MemoryStream();
                byte[] vehicleImage = null;
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                vehicleImage = ms.GetBuffer();
                ms.Close();
                return vehicleImage;
            }
            catch
            {
                //Common.WriteLog("图片转换为二进制流时发生错误");
                return null;
            }
        }
        /// <summary>
        /// 按照指定大小生成图片
        /// </summary>
        /// <param name="img">原图片</param>
        /// <param name="width">要转化的目标图片宽度</param>
        /// <param name="height">要转化的目标图片高度</param>
        /// <returns>目标图片</returns>
        public static Image CreateImage(Image img, int width, int height)
        {
            Image map = new Bitmap(width, height);
            try
            {
                using (Graphics g = Graphics.FromImage(map))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    g.Clear(Color.Transparent);
                    g.DrawImage(img,
                        new Rectangle(0, 0, width, height),
                                new Rectangle(0, 0, img.Width, img.Height),
                                GraphicsUnit.Pixel);
                }
            }
            catch
            {
                //Common.WriteLog("二进制流转换为图片时发生错误");
            }
            return map;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static byte[] CreatePlateImage(int width, int height, string Mode ,bool color)
        {
            Bitmap image = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(image))
            {
                //SolidBrush brBg = new SolidBrush(Color.Black   );
                if (color)
                {
                    g.FillRectangle(Brushes.Orange, 0, 0, width, height);
                    Font font = new Font("黑体", 40, FontStyle.Bold);
                    g.DrawString(Mode, font, Brushes.Black, width / 2 - 120, height / 2 - 30);

                }
                else
                {
                    g.FillRectangle(Brushes.Blue, 0, 0, width, height);
                    Font font = new Font("黑体", 40, FontStyle.Bold);
                    g.DrawString(Mode, font, Brushes.White, width / 2 - 120, height / 2 - 30);                   
                }
            }

            return ImageToStream(image);
        }
        private void ShowPicture(Video video)
        {
            Image newimg = null;
            try
            {                //近景图片
                //this.Invoke(listBox1.Items.Add(video.Plate));
                try
                {

                    newimg = StreamToImage(video.NearImage);
                    if (newimg != null)
                    {
                        //image.NearImage = video.NearImage;
                        this.pbFarImage.Image = newimg;
                    }
                    else
                    {
                        //image.NearImage = CreatePlateImage(300, 300, "近景图");
                    }

                }
                catch
                {
                    //Common.WriteLog("车牌图解析错误");
                    //image.NearImage = CreatePlateImage(300, 300, "近景图");
                }
                //车牌图片 
                try
                {
                    if (video.Plate == "无车牌")
                    {
                        //image.PlateImage = plateImg;
                        //pbNearImage.BackgroundImage = StreamToImage(plateImg);
                    }
                    else
                    {
                        newimg = StreamToImage(video.PlateImage);
                        if (newimg != null)
                        {
                            //image.PlateImage = video.PlateImage;
                            pbNearImage.Image = newimg;
                        }
                        else
                        {
                            //image.PlateImage = CreatePlateImage(300, 200, "车牌图");
                        }
                    }
                }
                catch
                {
                    //Common.WriteLog("车牌图解析错误");
                    //image.PlateImage = CreatePlateImage(300, 200, "车牌图");
                }
            }
            catch
            {
                //Common.WriteLog("图片呈现失败");
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //plateImg = CreatePlateImage(300, 80, "无车牌");
        }

        #region 车牌识别 大华
        private Video video;
        private string sUserName = "admin";
        private string sPassword = "a4008713369";

        private int nLoginID;
        private int nAnalyhandle;//订阅分析句柄 
        private bool bOnline = true;
        private fDisConnect disConnect;
        private fHaveReConnect onlineEvent;
        private fAnalyzerDataCallBack cbAnalyzerDat;
        private NET_DEVICEINFO DHdeviceInfo = new NET_DEVICEINFO();

        //初始化
        private void InitDH(ref fDisConnect disConnect, ref fHaveReConnect onlineEvent, ref int nLoginID, string sDeviceIP, ref NET_DEVICEINFO DHdeviceInfo, ushort wDevicePort, int nAnalyhandle)
        {
            try
            {
                disConnect = new fDisConnect(DisConnectEvent);
                DHClient.DHInit(disConnect, IntPtr.Zero);

                onlineEvent = new fHaveReConnect(OnlineEvent);
                DHClient.DHSetAutoReconnect(onlineEvent, IntPtr.Zero);
                int nError = -1;

                nLoginID = DHClient.DHLogin(sDeviceIP, wDevicePort, sUserName, sPassword,
                    out DHdeviceInfo, out nError);

                if (nLoginID != 0)
                {
                    //Common.WriteLog(string.Format("{0}> Login Device {1} Success.", System.DateTime.Now.ToShortTimeString(), sDeviceIP));
                }
                else
                {
                    //Common.WriteLog(string.Format("Login Device {0} Failed.", sDeviceIP));
                }
            }
            catch
            {
                //Common.WriteLog("大华车牌识别器初始化失败");
            }

        }
        //运行
        private bool RunDH(ref fAnalyzerDataCallBack cbAnalyzerDat, ref int nAnalyhandle, int nLoginID)
        {
            try
            {
                cbAnalyzerDat = new fAnalyzerDataCallBack(AnalyzerDataCallBack);
                nAnalyhandle = DHClient.DHRealLoadPictureEx(nLoginID, 0, EventIvs.EVENT_IVS_ALL, true/*true： 传图片数据；false：不传图片，只传事件信息*/, cbAnalyzerDat, 0, IntPtr.Zero);
                if (nAnalyhandle != 0)
                {
                    //Common.WriteLog("消息订阅成功");
                    return true;
                }
                else
                {
                    //Common.WriteLog("订阅失败，需要交由其他线程，重新订阅");
                    return false;
                }
            }
            catch
            {
                //Common.WriteLog("大华车牌识别器运行时出错");
                return false;
            }
        }
        //结束
        private void EndDH(int nAnalyhandle, int nLoginID)
        {
            try
            {
                if (nAnalyhandle != 0) //关闭消息订阅
                {
                    DHClient.DHStopLoadPic(nAnalyhandle);
                }

                if (nLoginID != 0)  //登出设备
                {
                    DHClient.DHLogout(nLoginID);
                }

                DHClient.DHCleanup();
            }
            catch
            {
                //Common.WriteLog("大华车牌识别器结束时失败");
            }
        }
        //设备离线，停止订阅句柄；
        private void DisConnectEvent(int lLoginID, StringBuilder pchDVRIP, int nDVRPort, IntPtr dwUser)
        {
            try
            {
                System.DateTime curdate = System.DateTime.Now;
                //Common.WriteLog(string.Format("{0}>Device {1} Logout.", curdate.ToShortTimeString(), pchDVRIP));
                if (lLoginID == nLoginID)
                {
                    bOnline = false;
                    if (nAnalyhandle != 0)
                    {
                        DHClient.DHStopLoadPic(nAnalyhandle);
                        nAnalyhandle = 0;
                    }
                }
           }
            catch
            {
                //Common.WriteLog("大华车牌识别器离线时出错");
            }
        }
        //设备重新在线，重新订阅事件；
        private void OnlineEvent(int lLoginID, StringBuilder pchDVRIP, int nDVRPort, IntPtr dwUser)
        {
            if (lLoginID == nLoginID)
            {
                bOnline = true;
                //Common.WriteLog(string.Format(string.Format("{0}>Device {1} Reconnected!", System.DateTime.Now.ToShortTimeString(), pchDVRIP)));
                try
                {

                    nAnalyhandle = DHClient.DHRealLoadPictureEx(nLoginID, 0, EventIvs.EVENT_IVS_ALL, true/*true： 传图片数据；false：不传图片，只传事件信息*/, cbAnalyzerDat, 0, IntPtr.Zero);
                    if (nAnalyhandle != 0)
                    {
                        //Common.WriteLog("重新订阅消息成功");
                    }
                    else
                    {
                        //Common.WriteLog(DHClient.LastOperationInfo.errCode + DHClient.LastOperationInfo.errMessage);
                    }
                }
                catch
                {
                    //Common.WriteLog(DHClient.LastOperationInfo.errCode + DHClient.LastOperationInfo.errMessage);
                }
            }
        }

        private int AnalyzerDataCallBack(Int32 lAnalyzerHandle, UInt32 dwAlarmType, IntPtr pAlarmInfo, IntPtr pBuffer, UInt32 dwBufSize, UInt32 dwUser, Int32 nSequence, IntPtr reserved)
        {
            try
            {
                video = new Video();
                //处理图片
                if (dwBufSize > 0)
                {
                    processBufferImg(pBuffer, dwBufSize);
                }


                if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_RUNREDLIGHT)
                {
                    DEV_EVENT_TRAFFIC_RUNREDLIGHT_INFO Info = new DEV_EVENT_TRAFFIC_RUNREDLIGHT_INFO();
                    Info = (DEV_EVENT_TRAFFIC_RUNREDLIGHT_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_RUNREDLIGHT_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFICJUNCTION)
                {
                    DEV_EVENT_TRAFFICJUNCTION_INFO Info = new DEV_EVENT_TRAFFICJUNCTION_INFO();
                    Info = (DEV_EVENT_TRAFFICJUNCTION_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFICJUNCTION_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_TURNLEFT)
                {
                    DEV_EVENT_TRAFFIC_TURNLEFT_INFO Info = new DEV_EVENT_TRAFFIC_TURNLEFT_INFO();
                    Info = (DEV_EVENT_TRAFFIC_TURNLEFT_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_TURNLEFT_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_TURNRIGHT)
                {
                    DEV_EVENT_TRAFFIC_TURNRIGHT_INFO Info = new DEV_EVENT_TRAFFIC_TURNRIGHT_INFO();
                    Info = (DEV_EVENT_TRAFFIC_TURNRIGHT_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_TURNRIGHT_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_OVERSPEED)
                {
                    DEV_EVENT_TRAFFIC_OVERSPEED_INFO Info = new DEV_EVENT_TRAFFIC_OVERSPEED_INFO();
                    Info = (DEV_EVENT_TRAFFIC_OVERSPEED_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_OVERSPEED_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_UNDERSPEED)
                {
                    DEV_EVENT_TRAFFIC_UNDERSPEED_INFO Info = new DEV_EVENT_TRAFFIC_UNDERSPEED_INFO();
                    Info = (DEV_EVENT_TRAFFIC_UNDERSPEED_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_UNDERSPEED_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFICGATE)
                {
                    DEV_EVENT_TRAFFICGATE_INFO Info = new DEV_EVENT_TRAFFICGATE_INFO();
                    Info = (DEV_EVENT_TRAFFICGATE_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFICGATE_INFO));
                    Console.WriteLine("Speed = {0}", Info.nSpeed);
                    Console.WriteLine("Name = {0}", DHClient.DHByteArrayToString(Info.szName));
                    ShowEventFileInfo(Info.stuFileInfo);
                }
                else if (dwAlarmType == EventIvs.EVENT_IVS_TRAFFIC_MANUALSNAP)
                {
                    DEV_EVENT_TRAFFIC_MANUALSNAP_INFO Info = new DEV_EVENT_TRAFFIC_MANUALSNAP_INFO();
                    Info = (DEV_EVENT_TRAFFIC_MANUALSNAP_INFO)Marshal.PtrToStructure(pAlarmInfo, typeof(DEV_EVENT_TRAFFIC_MANUALSNAP_INFO));
                    PrintTrafficCarInfo(Info.stTrafficCar);
                    ShowEventFileInfo(Info.stuFileInfo);
                }

                else
                {
                    //Common.WriteLog("Get Event =" + dwAlarmType.ToString());
                }

            }
            catch
            {
                //Common.WriteLog("大华车牌识别事件触发时出错");
            }
            return 0;
        }
        private byte[] byteSelect(byte[] source)
        {
            int j = 0;
            for (int i = 0; i < source.Length; i++)
            {
                if (source[i] > 10)
                    j++;
            }
            byte[] result = new byte[j];
            j = 0;
            for (int i = 0; i < source.Length; i++)
            {
                if (source[i] > 10)
                {
                    result[j++] = source[i];
                }
            }
            return result;
        }
        private void PrintTrafficCarInfo(DEV_EVENT_TRAFFIC_TRAFFICCAR_INFO stTrafficCar)
        {
            try
            {
                video.ReachTime = DateTime.Now;
                string plate = DHClient.DHByteArrayToString(byteSelect(stTrafficCar.szPlateNumber));
                if (plate.Length != 7)
                {
                    plate = "未识别";
                }
                //StreamWriter sw = new StreamWriter("d:\a.txt",true);//写下移行，不带true覆盖原来
                //sw.WriteLine(plate);
                //sw.Flush();
                //sw.Close();
                video.Plate = plate;
                bool isColorY = false;
                string color = DHClient.DHByteArrayToString(byteSelect(stTrafficCar.szPlateColor));
                switch (color)
                {
                    case "Blue":
                        video.PlateColor = "蓝";
                        break;
                    case "Yellow":
                        video.PlateColor = "黄";
                        isColorY = true;
                        break;
                    case "White":
                        video.PlateColor = "白";
                        break;
                    case "Black":
                        video.PlateColor = "黑";
                        break;
                    default:
                        video.PlateColor = "未知";
                        break;

                }
                //添加车牌自绘图片
                video.PlateImage = CreatePlateImage(this.pbNearImage.Width, this.pbNearImage.Height, video.Plate ,isColorY);
                video.plateSize = video.PlateImage.Length;
                ShowPicture(video);
                //AddAndMatchPlate(video);
            }
            catch
            {
                //Common.WriteLog("大华车牌识别处理车牌时出错");
            }

        }

        //pBuffer为Jpg图片缓冲数据,可以自行处理
        private void processBufferImg(IntPtr pBuffer, UInt32 dwBufSize)
        {
            byte[] buffer = new byte[dwBufSize];
            Marshal.Copy(pBuffer, buffer, 0, (int)dwBufSize);
            video.FarImage = buffer;
            video.farSize = buffer.Length;
            video.NearImage = buffer;
            video.nearSize = buffer.Length;
        }

        //显示图片文件组别信息
        private void ShowEventFileInfo(DH_EVENT_FILE_INFO info)
        {
            Console.WriteLine("groupid = {0}", info.nGroupId);
            Console.WriteLine("fileType （0:普通，1：合成，2：抠图）= {0}", info.bFileType);
            Console.WriteLine("count ={0}", info.bCount);
            Console.WriteLine("index ={0}", info.bIndex);
        }

        #endregion

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            EndDH(nAnalyhandle, nLoginID);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Video v = new Video();
            v.Plate = "试" + DateTime.Now.ToString("HHmmss");
            v.LaneNum = 2;            v.PlateColor = "黑";
            v.ReachTime = DateTime.Now;                   //new DateTime(0x0D, 0x0C, 0x0A, 0x10, 0x1E, 0x19);
            video = v;
            ShowPicture(video);
        }

    }
}
