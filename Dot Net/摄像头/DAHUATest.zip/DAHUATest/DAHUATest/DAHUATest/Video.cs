﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAHUATest
{
    
    public class Video
    {
       
        private string vNo;
        
        public string VNo
        {
            get
            {
                return this.vNo;
            }
            set
            {
                this.vNo = value;
            }
        }
        private string plate;
       
        public string Plate
        {
            get
            {
                return plate;
            }
            set
            {
                this.plate = value;
            }
        }
        private int laneNum;
       
        public int LaneNum
        {
            get
            {
                return this.laneNum;
            }
            set
            {
                this.laneNum = value;
            }
        }
        private DateTime reachTime;
       
        public DateTime ReachTime
        {
            get
            {
                return this.reachTime;
            }
            set
            {
                this.reachTime = value;
            }
        }
        public int plateSize;
        private byte[] plateImage;
        public byte[] PlateImage
        {
            get
            {
                return this.plateImage;
            }
            set
            {
                this.plateImage = value;
            }
        }
        public int farSize;
        private byte[] farImage;
        
        public byte[] FarImage
        {
            get
            {
                return this.farImage;
            }
            set
            {
                this.farImage = value;
            }
        }
        public int nearSize;
        private byte[] nearImage;
       
        public byte[] NearImage
        {
            get
            {
                return this.nearImage;
            }
            set
            {
                this.nearImage = value;
            }
        }
        private string plateColor;
       
        public string PlateColor
        {
            get
            {
                return this.plateColor;
            }
            set
            {
                this.plateColor = value;
            }
        }        
    }
}
