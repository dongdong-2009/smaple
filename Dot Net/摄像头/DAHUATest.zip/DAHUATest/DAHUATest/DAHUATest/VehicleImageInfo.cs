﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAHUATest
{
    /// <summary>
    /// 车辆抓拍图片信息模型
    /// </summary>
    [Serializable]
    public class VehicleImageInfo
    {
        private string vehicleNo;
        /// <summary>
        /// 获取或设置过车序号
        /// </summary>
        public string VehicleNo
        {
            get
            {
                return this.vehicleNo;
            }
            set
            {
                this.vehicleNo = value;
            }
        }
        private string stationId;
        /// <summary>
        /// 获取或设置监测点编号
        /// </summary>
        public string StationId
        {
            get
            {
                return this.stationId;
            }
            set
            {
                this.stationId = value;
            }
        }
        private byte[] farImage;
        /// <summary>
        /// 获取或设置远景图片
        /// </summary>
        public byte[] FarImage
        {
            get
            {
                return this.farImage;
            }
            set
            {
                this.farImage = value;
            }
        }
        private byte[] nearImage;
        /// <summary>
        /// 获取或设置近景图片
        /// </summary>
        public byte[] NearImage
        {
            get
            {
                return this.nearImage;
            }
            set
            {
                this.nearImage = value;
            }
        }
        private byte[] plateImage;
        /// <summary>
        /// 获取或设置车牌图片
        /// </summary>
        public byte[] PlateImage
        {
            get
            {
                return this.plateImage;
            }
            set
            {
                this.plateImage = value;
            }
        }
    }
}
