using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ImageManager;

namespace ImageResizingSample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //use WebManager to get the file, and save it
            IImageInfo img = WebManager.GetImageInfo(fileUploader);
            img.Path = "uploadedImages";
            img.Save();

            //now create resized versions, and save them
            IImageInfo imgLarge = img.ResizeMe(null, 300);		//constrain to 300 pixels wide
            imgLarge.Save("uploadedImages/large");			//save file in a folder named "large"

            IImageInfo imgMedium = img.ResizeMe(185, null);	//constrain to 185 pixels high
            imgMedium.Save("uploadedImages/medium");

            IImageInfo imgSmall = img.ResizeMe(null, 100);	//constrain to 100 pixels wide
            imgSmall.Save("uploadedImages/small");

            IImageInfo imgTiny = img.ResizeMe(50, null);	    //constrain to 50 pixels high
            imgTiny.Save("uploadedImages/tiny");

            //now display the resized images
            pnlResults.Visible = true;
            imgFullSize.ImageUrl = string.Format("uploadedImages/{0}", img.FileName);
            img300.ImageUrl = string.Format("uploadedImages/large/{0}", imgLarge.FileName);
            img185.ImageUrl = string.Format("uploadedImages/medium/{0}", imgMedium.FileName);
            img100.ImageUrl = string.Format("uploadedImages/small/{0}", imgSmall.FileName);
            img50.ImageUrl = string.Format("uploadedImages/tiny/{0}", imgTiny.FileName);

            litFull.Text = WebManager.GetImageSize(img);
            litLarge.Text = WebManager.GetImageSize(imgLarge);
            litMedium.Text = WebManager.GetImageSize(imgMedium);
            litSmall.Text = WebManager.GetImageSize(imgSmall);
            litTiny.Text = WebManager.GetImageSize(imgTiny);
        }
    }
}
