/*                           ASCII Art Generator Web Page
 *                           ============================
 *                     Created by Sau Fan Lee (wraith10@yahoo.com)
 *                        Copyleft (c) 2005 Sau Fan Lee (GPL)
 *                                All rights granted.
 *
 * (But please include this Credits section if you want to use it for your own apps.)
 */

using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using AsciiArt;

namespace Ascii {
    public class AsciiArt : System.Web.UI.Page {
        protected System.Web.UI.HtmlControls.HtmlForm Form1;
        protected System.Web.UI.WebControls.TextBox txtImageUrl;
        protected System.Web.UI.HtmlControls.HtmlInputFile txtImageFile;
        protected System.Web.UI.WebControls.CheckBox chkUseAlpha;
        protected System.Web.UI.WebControls.CheckBox chkUseNum;
        protected System.Web.UI.WebControls.CheckBox chkUseBasic;
        protected System.Web.UI.WebControls.CheckBox chkUseExtended;
        protected System.Web.UI.WebControls.CheckBox chkUseBlock;
        protected System.Web.UI.WebControls.TextBox txtFixedChars;
        protected System.Web.UI.WebControls.TextBox txtWidth;
        protected System.Web.UI.WebControls.TextBox txtHeight;
        protected System.Web.UI.WebControls.RadioButton radSize;
        protected System.Web.UI.WebControls.RadioButton radScale;
        protected System.Web.UI.WebControls.RadioButton radScale1;
        protected System.Web.UI.WebControls.RadioButton radScale2;
        protected System.Web.UI.WebControls.RadioButton radScale3;
        protected System.Web.UI.WebControls.RadioButton radScale4;
        protected System.Web.UI.WebControls.RadioButton radScale5;
        protected System.Web.UI.WebControls.RadioButton radScale6;
        protected System.Web.UI.WebControls.RadioButton radScale7;
        protected System.Web.UI.WebControls.RadioButton radScale8;
        protected System.Web.UI.WebControls.RadioButton radScale9;
        protected System.Web.UI.WebControls.RadioButton radScale10;
        protected System.Web.UI.WebControls.RadioButton radScale11;
        protected System.Web.UI.WebControls.RadioButton radScale12;
        protected System.Web.UI.WebControls.RadioButton radScale13;
        protected System.Web.UI.WebControls.RadioButton radScale14;
        protected System.Web.UI.WebControls.RadioButton radScale15;
        protected System.Web.UI.WebControls.RadioButton radScale16;
        protected System.Web.UI.WebControls.RadioButton radMultiColor;
        protected System.Web.UI.WebControls.RadioButton radSingleColor;
        protected System.Web.UI.WebControls.TextBox txtFontSize;
        protected System.Web.UI.WebControls.TextBox txtForeColor;
        protected System.Web.UI.WebControls.TextBox txtBackColor;
        protected System.Web.UI.WebControls.CheckBox chkGrayScale;
        protected System.Web.UI.WebControls.CheckBox chkTextOnly;
        protected System.Web.UI.WebControls.CheckBox chkDownload;
        protected System.Web.UI.WebControls.CheckBox chkUseFixed;
        protected System.Web.UI.WebControls.Button btnSetImage;
        protected System.Web.UI.WebControls.Button btnAsciiFy;
        protected System.Web.UI.WebControls.Button btnClear;
        protected System.Web.UI.WebControls.Image imgOrigImage;
        protected System.Web.UI.WebControls.Label lblError;
        protected System.Web.UI.WebControls.Button btnResetFixedChars;
        protected System.Web.UI.WebControls.Label lblAsciiImage;

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e) {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnSetImage.Click += new System.EventHandler(this.btnSetImage_Click);
            this.btnResetFixedChars.Click += new System.EventHandler(this.btnResetFixedChars_Click);
            this.btnAsciiFy.Click += new System.EventHandler(this.btnAsciiFy_Click);
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion

        #region Fields

        private ImageToText AsciiArtist = null;

        #endregion

        #region Properties

        // Default image file.
        private string defaultImageFile = null;

        public string DefaultImageFile {
            get {
                if (defaultImageFile == null)
                    defaultImageFile = ToolsLib.LoadConfig ("DefaultImageFile", "");
                return (defaultImageFile);
            }
        }

        // Image sub-folder name.
        private string imageFolderName = null;

        public string ImageFolderName {
            get {
                if (imageFolderName == null) imageFolderName = ToolsLib.LoadConfig
                    ("ImageSubFolder", "").Trim().TrimEnd (new char[] {'\\', '/'});
                return (imageFolderName);
            }
        }

        // Image folder path.
        private string imageFolderPath = null;

        public string ImageFolderPath {
            get {
                if (imageFolderPath == null) {
                    string folder = Server.MapPath (".\\") + ImageFolderName;
                    if (ImageFolderName != "") folder += "\\";
                    imageFolderPath = folder;
                }

                return (imageFolderPath);
            }
        }

        // Image url path.
        public string ImageUrlPath {
            get {
                string url = CurrentUrlPath + ImageFolderName;
                if (ImageFolderName != "") url += "/";
                return (url);
            }
        }

        // Current URL without web-page filename.
        private string CurrentUrlPath {
            get {
                string url = Request.Url.ToString();
                int idx = url.IndexOf ('?');
                if (idx >= 0) url = url.Substring (0, idx);
                idx = url.LastIndexOf ('/');
                return (url.Substring (0, idx + 1));
            }
        }

        #endregion

        #region Methods

        #region Miscellaneous Methods

        // Add error message to screen.
        private void ShowError (string msg) {
            if (msg == null) return;
            lblError.Text += "ERROR: " + msg + "<br>\n";
            lblError.Visible = true;
        }

        // Store uploaded file and retrieve its filename.
        private string GetPostedFileName() {
            if (txtImageFile.PostedFile == null) return (null);
            string fileType = txtImageFile.PostedFile.ContentType;
            string fileName = txtImageFile.PostedFile.FileName.Trim();
            int index = fileName.LastIndexOfAny (new char[] {'/', '\\'});
            fileName = fileName.Substring (index + 1);
            if (fileName == "") return (null);

            if (!fileType.ToLower().StartsWith ("image/")) {
                ShowError ("Invalid image type!");
                return (null);
            }

            try {
                txtImageFile.PostedFile.SaveAs (ImageFolderPath + fileName);
                return (fileName);
            } catch (Exception e) {
                ShowError (e.Message);
                return (null);
            }
        }

        // Convert a local URL to a local path.
        private string UrlToLocalPath (string url) {
            if (url == null) return (null);
            string baseUrl = CurrentUrlPath;

            if (url.StartsWith (baseUrl)) {
                return (Server.MapPath (url.Substring (baseUrl.Length)));
            } else {
                return (null);
            }
        }

        // Retrieve a filename from a path or URL.
        private static string GetFileName (string filePath) {
            if (filePath == null) return (null);
            int index = filePath.LastIndexOf ('?');
            if (index >= 0) filePath = filePath.Substring (0, index);
            index = filePath.LastIndexOfAny (new char[] {'/', '\\'});
            filePath = filePath.Substring (index + 1);
            return (filePath == "" ? null : filePath);
        }

        #endregion

        #region Methods for Creating/Destroying Image To ASCII Converter

        // Create ImageToText object.
        private bool CreateImageConverter (string imagePath, bool useCurrentSettings,
                                           bool resetFixedChars) {
            // Create/Get ASCII Art Converter.
            try {
                string path = UrlToLocalPath (imagePath);
                if (path == null) path = imagePath;
                AsciiArtist = new ImageToText (path);
            } catch (FileNotFoundException) {
                ShowError ("Cannot find image file at: " + txtImageUrl.Text);
                return (false);
            } catch (Exception exc) {
                ShowError (exc.Message);
                return (false);
            }

            // Setup configurations of ASCII Art Converter.
            if (useCurrentSettings) {
                AsciiArtist.UseAlpabets = chkUseAlpha.Checked;
                AsciiArtist.UseNumbers = chkUseNum.Checked;
                AsciiArtist.UseBasicSymbols = chkUseBasic.Checked;
                AsciiArtist.UseExtendedSymbols = chkUseExtended.Checked;
                AsciiArtist.UseBlockSymbols = chkUseBlock.Checked;
                AsciiArtist.UseFixedChars = chkUseFixed.Checked;
                if (!resetFixedChars) AsciiArtist.FixedChars = txtFixedChars.Text.ToCharArray();

                try {
                    AsciiArtist.FontSize = (int) UInt16.Parse (txtFontSize.Text);
                } catch {
                    txtFontSize.Text = AsciiArtist.FontSize.ToString();
                    ShowError ("Invalid font size! Reset to default value.");
                }

                AsciiArtist.BackColor = txtBackColor.Text;
                AsciiArtist.FontColor = txtForeColor.Text;
                AsciiArtist.UseColors = radMultiColor.Checked;
                AsciiArtist.IsGrayScale = chkGrayScale.Checked;
                AsciiArtist.IsHtmlOutput = !chkTextOnly.Checked;
            }

            return (true);
        }

        // Dispose ImageToText object.
        private void DestroyImageConverter() {
            if (AsciiArtist != null) {
                AsciiArtist.Dispose();
                AsciiArtist = null;
            }
        }

        #endregion

        #region Methods for Image To ASCII Conversions

        // Convert image to ascii text-image using ImageToText object.
        private string GetAsciiImage (bool useBlock) {
            if (AsciiArtist == null) return (null);;
            int width = -1;
            int height = -1;
            int scale = 1;

            // Retrieve image width.
            if (txtWidth.Text != "") {
                string val = txtWidth.Text;
                bool isPercent = false;

                if (val.EndsWith ("%")) {
                    isPercent = true;
                    val = val.Substring (0, val.Length - 1);
                }

                try {
                    width = (int) UInt16.Parse (val);

                    if (isPercent) {
                        width = AsciiArtist.ImageWidth * width / 100;
                        txtWidth.Text = width.ToString();
                    }
                } catch {
                    width = AsciiArtist.ImageWidth;
                    txtWidth.Text = width.ToString();
                    ShowError ("Invalid image width! Reset to default value.");
                }
            }

            // Retrieve image height.
            if (txtHeight.Text != "") {
                string val = txtHeight.Text;
                bool isPercent = false;

                if (val.EndsWith ("%")) {
                    isPercent = true;
                    val = val.Substring (0, val.Length - 1);
                }

                try {
                    height = (int) UInt16.Parse (val);

                    if (isPercent) {
                        height = AsciiArtist.ImageHeight * height / 100;
                        txtHeight.Text = height.ToString();
                    }
                } catch {
                    height = AsciiArtist.ImageHeight;
                    txtHeight.Text = height.ToString();
                    ShowError ("Invalid image height! Reset to default value.");
                }
            }

            // Validate image width & height.
            if ((txtWidth.Text == "") && (txtHeight.Text == "")) {
                width = AsciiArtist.ImageWidth;
                height = AsciiArtist.ImageHeight;
                txtWidth.Text = width.ToString();
                txtHeight.Text = height.ToString();
            } else if (txtWidth.Text == "") {
                width = height * AsciiArtist.ImageWidth / AsciiArtist.ImageHeight;
                txtWidth.Text = width.ToString();
            } else if (txtHeight.Text == "") {
                height = width * AsciiArtist.ImageHeight / AsciiArtist.ImageWidth;
                txtHeight.Text = height.ToString();
            }

            // Retrieve scaling factor.
            foreach (Control comp in Form1.Controls) {
                RadioButton radScale = comp as RadioButton;
                if (radScale == null) continue;
                if (!radScale.Checked) continue;
                if (radScale.ID.Length < 9) continue;
                if (!radScale.ID.StartsWith ("radScale")) continue;

                try {
                    scale = Int32.Parse (radScale.ID.Substring (8));
                    break;
                } catch {}
            }

            // Ascii-fy image.
            try {
                if (radScale.Checked) {
                    return (AsciiArtist.GetAsciiImage (scale, useBlock));
                } else {
                    return (AsciiArtist.GetAsciiImage (width, height, useBlock));
                }
            } catch (Exception exc) {
                ShowError (exc.Message);
                return (null);
            }
        }

        #endregion

        #region Form Events

        private void Page_Load (object sender, System.EventArgs e) {
            bool isReset = (Request[btnClear.ID] != null);
            bool isResetFixedChars = (Request[btnResetFixedChars.ID] != null);
            bool useCurrentSettings = (IsPostBack && !isReset);

            // Setup file uploads and image URL.
            if (isReset) {
                txtImageUrl.Text = ImageUrlPath + DefaultImageFile;
            } else {
                string fileName = GetPostedFileName();

                if (fileName != null) {
                    txtImageUrl.Text = ImageUrlPath + fileName;
                } else if (txtImageUrl.Text == "") {
                    txtImageUrl.Text = ImageUrlPath + DefaultImageFile;
                } else {
                    txtImageUrl.Text = txtImageUrl.Text.Trim();
                }
            }

            imgOrigImage.ImageUrl = txtImageUrl.Text;

            // Create & setup ASCII Art Converter.
            if (!CreateImageConverter (txtImageUrl.Text, useCurrentSettings,
                                       isResetFixedChars)) return;
            if (isResetFixedChars)
                txtFixedChars.Text = new String (AsciiArtist.FixedChars);

            if (!useCurrentSettings) {  // reset settings
                chkUseAlpha.Checked = AsciiArtist.UseAlpabets;
                chkUseNum.Checked = AsciiArtist.UseNumbers;
                chkUseBasic.Checked = AsciiArtist.UseBasicSymbols;
                chkUseExtended.Checked = AsciiArtist.UseExtendedSymbols;
                chkUseBlock.Checked = AsciiArtist.UseBlockSymbols;
                chkUseFixed.Checked = AsciiArtist.UseFixedChars;
                txtFixedChars.Text = new String (AsciiArtist.FixedChars);
                txtFontSize.Text = AsciiArtist.FontSize.ToString();
                txtBackColor.Text = AsciiArtist.BackColor;
                txtForeColor.Text = AsciiArtist.FontColor;

                foreach (Control comp in Form1.Controls) {
                    RadioButton radio = comp as RadioButton;
                    if (radio != null) radio.Checked = false;
                }

                radSingleColor.Checked = !AsciiArtist.UseColors;
                radMultiColor.Checked = AsciiArtist.UseColors;
                chkGrayScale.Checked = AsciiArtist.IsGrayScale;
                radScale.Checked = true;
                radScale1.Checked = true;
                txtWidth.Text = AsciiArtist.ImageWidth.ToString();
                txtHeight.Text = AsciiArtist.ImageHeight.ToString();
                chkTextOnly.Checked = !AsciiArtist.IsHtmlOutput;
                chkDownload.Checked = false;
            }
        }

        private void btnAsciiFy_Click (object sender, System.EventArgs e) {
            bool isHtml = !chkTextOnly.Checked;
            bool isView = !chkDownload.Checked;
            string ascii = GetAsciiImage (isHtml || isView);
            string newLine = (isHtml ? AsciiArtist.HtmlNewLine : AsciiArtist.TextNewLine);
            int size = AsciiArtist.FontSize;
            DestroyImageConverter();
            if (ascii == null) return;

            if (isView) {
                lblAsciiImage.Text = ascii;
            } else {
                string fileName = GetFileName (txtImageUrl.Text);
                Response.Clear();
                Response.ContentType = (isHtml ? "text/html" : "text/plain");
                Response.AddHeader ("Content-Disposition", "attachment; filename=\""
                                    + fileName + (isHtml ? ".html" : ".txt") + "\"");
                Response.Flush();

                if (isHtml) {
                    Response.Output.WriteLine
                        ("<html>{0}<head>{0}<title>ASCII Image of {1}</title>{0}"
                         + "<script language='javascript'>{0}  function ChangeSize() {{{0}"
                         + "    var size = document.all['ImageSize'].selectedIndex + 1;{0}"
                         + "    var height = Math.floor (size * 3 / 5);{0}"
                         + "    if ((size % 5) % 2 == 1) height++;{0}"
                         + "    document.all['AsciiImage'].style.fontSize = size + 'px';{0}"
                         + "    document.all['AsciiImage'].style.lineHeight = height + 'px';"
                         + "{0}  }}{0}</script>{0}</head>{0}<body bgcolor='{2}' text='{3}'>"
                         + "{0}<div align='center'><br>", newLine, fileName,
                         txtBackColor.Text, txtForeColor.Text);
                }

                Response.Output.WriteLine (ascii);

                if (isHtml) {
                    Response.Output.WriteLine
                        ("<b><i>ASCII Image of {1}</i></b>{0}<form>{0}<b>(Size:{0}"
                         + "<select id='ImageSize' onchange='ChangeSize()'>",
                         newLine, fileName);

                    for (int i = 1; i <= 20; i++) {
                        string selected = (size == i ? " selected='selected'" : "");
                        Response.Output.WriteLine
                            ("  <option value='{0}'{1}>{0}</option>", i, selected);
                    }

                    Response.Output.WriteLine
                        ("</select>{0})</b>{0}</form>{0}</div>{0}</body>{0}</html>",
                         newLine);
                }

                Response.Flush();
                Response.End();
            }
        }

        private void btnClear_Click (object sender, System.EventArgs e) {
            DestroyImageConverter();
        }

        private void btnSetImage_Click(object sender, System.EventArgs e) {
            DestroyImageConverter();
        }

        private void btnResetFixedChars_Click (object sender, System.EventArgs e) {
            DestroyImageConverter();
        }

        #endregion

        #endregion
    }
}
