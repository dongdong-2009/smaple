/*                            ASCII Art Generator Library
 *                            ===========================
 *                     Created by Sau Fan Lee (wraith10@yahoo.com)
 *                        Copyleft (c) 2005 Sau Fan Lee (GPL)
 *                                All rights granted.
 *
 * (But please include this Credits section if you want to use it for your own apps.)
 */
//#define UseOldAsciiGen
//#define AltGrayScale

using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Text;

namespace AsciiArt {
    public class ImageToText {
        #region Constants & Fields

        // Constants
        public const string DefaultAsciiDataFile = @".\ASCII.xml";
        public const string DefaultAsciiDataEntryName = "ascii";

#if AltGrayScale
        private const float GrayScaleRed = 0.3086f;
        private const float GrayScaleGreen = 0.6094f;
        private const float GrayScaleBlue = 0.0820f;
#else
        private const float GrayScaleRed = 0.2125f;
        private const float GrayScaleGreen = 0.7154f;
        private const float GrayScaleBlue = 0.0721f;
#endif

        /** Public Fields **/

        // Font information
        public string FontFamily = "Courier New, Courier, monospace";
        public int FontSize = 12;
        public string FontColor = "#000000";
        public string BackColor = "#FFFFFF";

        // ASCII information
        public bool UseAlpabets = true;          // Use standard alphabets in Ascii Art.
        public bool UseNumbers = true;           // Use numbers in Ascii Art.
        public bool UseBasicSymbols = true;      // Use basic non-Unicode symbols
                                                 //   (punctuation marks) that have font-
                                                 //   independent brightness in Ascii Art.
        public bool UseExtendedSymbols = false;  // Use other non-Unicode symbols
                                                 //   (punctuation marks) that have font-
                                                 //   dependent brightness in Ascii Art.
        public bool UseBlockSymbols = false;     // Use blocks, pipes, and other Unicode
                                                 //   symbols in Ascii Art (HTML only).
        public bool UseFixedChars = false;       // Use a fixed user-defined character set
                                                 //   in Ascii Art.
        public bool UseColors = true;            // Use colors in text in Ascii Art
                                                 //   (HTML only).
        public bool IsGrayScale = false;         // If use colors, use grayscale colors.
        public bool IsHtmlOutput = true;         // Use HTML formatting & colors.

        // Private Fields
        private MemoryStream ImageStream = null;
        private Image ImageFile = null;

        #endregion

        #region Properties

        #region ASCII XML Data File Path

        private string asciiDataFile = null;

        public string AsciiDataFile {
            get {
                if (asciiDataFile == null) {
                    asciiDataFile = ToolsLib.GetPathName
                        (ToolsLib.DefaultCurrentDirectory, DefaultAsciiDataFile);
                }

                return (asciiDataFile);
            }

            set {
                if (value == null) {
                    value = ".";
                } else {
                    value = value.Trim().TrimEnd ('\\', '/');
                }

                if (value == "") value = ".";
                asciiDataFile = ToolsLib.GetPathName
                    (ToolsLib.DefaultCurrentDirectory, value);
            }
        }

        #endregion

        #region ASCII XML Entry Tag-Name

        private string asciiDataEntryName = DefaultAsciiDataEntryName;

        public string AsciiDataEntryName {
            get { return (asciiDataEntryName); }
            set { if (value != null) asciiDataEntryName = value; }
        }

        #endregion

        #region HTML Block For ASCII Image Encapsulation

        // Start of <pre> block.
        public string BlockStart {
            get {
                if (IsHtmlOutput) {
                    int height = FontSize * 3 / 5;
                    if ((FontSize % 5) % 2 == 1) height++;

                    return ("<pre id='AsciiImage' style='letter-spacing: 0px; font-family: "
                            + FontFamily + "; color: " + FontColor +
                            "; background-color: " + BackColor + "; font-size: "
                            + FontSize + "px; line-height: " + height + "px'>");
                } else {
                    return ("<xmp id='AsciiImage' style='color: " + FontColor +
                            "; background-color: " + BackColor + "; font-size: "
                            + FontSize + "px'>");
                }
            }
        }

        // End of </pre> block.
        public string BlockEnd {
            get { return (IsHtmlOutput ? "</pre>" : "</xmp>"); }
        }

        #endregion

        #region New-Line Characters

        // Newline characters for HTML output.
        private string htmlNewLine = "\n";

        public string HtmlNewLine {
            get { return (htmlNewLine); }
            set { if ((value != null) && (value != "")) htmlNewLine = value; }
        }

        // Newline characters for Text output.
        private string textNewLine = "\r\n";

        public string TextNewLine {
            get { return (textNewLine); }
            set { if ((value != null) && (value != "")) textNewLine = value; }
        }

        #endregion

        #region Fixed Character Set

        private char[] fixedChars = new char[] {' ', '.', ':', ',', ';', '+', 'i', 'j',
                                                't', 'f', 'L', 'G', 'D', 'K', 'W', '#'};

        public char[] FixedChars {
            get { return (fixedChars); }
            set { if (value != null) fixedChars = value; }
        }

        #endregion

        #region Image Size

        public int ImageWidth {
            get { return (ImageFile == null ? -1 : ImageFile.Width); }
        }

        public int ImageHeight {
            get { return (ImageFile == null ? -1 : ImageFile.Height); }
        }

        #endregion

        #region ASCII Data

        // Original ASCII data (from file).
        private DataTable asciiDataTable = null;
        private object AsciiDataTableMutex = new object();

        private DataTable AsciiDataTable {
            get {
                if (asciiDataTable == null) {
                    lock (AsciiDataTableMutex) {
                        if (asciiDataTable == null) {  // *still* null
                            DataSet ds = new DataSet();
                            ds.ReadXml (AsciiDataFile);
                            DataTable dt = ds.Tables[AsciiDataEntryName];
                            dt.CaseSensitive = true;
                            asciiDataTable = dt;
                        }
                    }
                }

                return (asciiDataTable);
            }
        }

        // Filtered ASCII data for HTML View.
        private DataView asciiDataHtml = null;
        private object AsciiDataHtmlMutex = new object();

        private DataView AsciiDataHtml {
            get {
                // Create DataView.
                lock (AsciiDataHtmlMutex) {
                    if (asciiDataHtml == null) asciiDataHtml = new DataView (AsciiDataTable);
                    SetupAsciiData (asciiDataHtml, true);
                    return (asciiDataHtml);
                }
            }
        }

        // Filtered ASCII data for Text View.
        private DataView asciiDataText = null;
        private object AsciiDataTextMutex = new object();

        private DataView AsciiDataText {
            get {
                // Create DataView.
                lock (AsciiDataTextMutex) {
                    if (asciiDataText == null) asciiDataText = new DataView (AsciiDataTable);
                    SetupAsciiData (asciiDataText, false);
                    return (asciiDataText);
                }
            }
        }

        // ASCII data initializer.
        private void SetupAsciiData (DataView asciiData, bool isHtml) {
            // Row filters.
            string filter = "";

            if (UseFixedChars) {
                filter = "htmlchar in (";
                foreach (char c in FixedChars) filter += "'" + CharToHtml (c) + "',";
                filter = filter.Substring (0, filter.Length - 1) + ")";
            } else {
                if (UseAlpabets) filter += "type = 1 OR ";
                if (UseNumbers) filter += "type = 2 OR ";
                if (UseBasicSymbols) filter += "type = 3 OR ";
                if (UseExtendedSymbols) filter += "type = 4 OR ";
                if (UseBlockSymbols && isHtml) filter += "type = 5 OR ";

                if (filter.Length > 0) {
                    filter = filter.Substring (0, filter.Length - 4);
                    if (!isHtml) filter = "(" + filter + ")";
                } else {
                    filter = "type = 0";
                }
            }

            if (!isHtml) filter += " AND id > 31 AND id < 127";
            if (asciiData.RowFilter != filter) asciiData.RowFilter = filter;

            // Row sorting.
            string sort;

            switch (FontSize) {
                case 13: sort = "c13"; break;
                case 16: sort = "c16"; break;
                default: sort = "c20"; break;
            }

            if (asciiData.Sort != sort) asciiData.Sort = sort;
        }

        #endregion

        #endregion

        #region Constructors & Destructors

        // Constructor based on image file-path or URL.
        public ImageToText (string imageFile) {
            if (imageFile.ToLower().StartsWith ("http")) {
                try {
                    HttpWebRequest req = (HttpWebRequest) WebRequest.Create (imageFile);
                    req.Credentials = CredentialCache.DefaultCredentials;
                    req.Proxy = WebProxy.GetDefaultProxy();
                    if (req.Proxy.Credentials == null)
                        req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    req.UserAgent = "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0)";
                    req.Method = "GET";

                    WebResponse resp = req.GetResponse();
                    byte[] data = new byte[resp.ContentLength];
                    Stream rawStream = resp.GetResponseStream();
                    int total = 0;

                    while (total < data.Length) {
                        total += rawStream.Read (data, total, data.Length - total);
                    }

                    rawStream.Close();
                    ImageStream = new MemoryStream (data, 0, total);
                    ImageFile = Image.FromStream (ImageStream);
                } catch {
                    if (ImageStream != null) ImageStream.Close();
                    throw new ArgumentException ("Cannot open image at specified URL!");
                }
            } else {
                ImageFile = Image.FromFile (imageFile);
            }
        }

        // Constructor based on image contents.
        public ImageToText (byte[] image) {
            ImageStream = new MemoryStream (image);
            ImageFile = Image.FromStream (ImageStream);
        }

        // Destructor.
        ~ImageToText() {
            Dispose();
        }

        // Manual destructor.
        public void Dispose() {
            if (ImageFile != null) {
                ImageFile.Dispose();
                ImageFile = null;
            }

            if (ImageStream != null) {
                ImageStream.Close();
                ImageStream = null;
            }
        }

        #endregion

        #region Methods

        #region Methods for HTML Entity Conversions

        public static char HtmlToChar (string htmlEntity) {
            // Check invalid values.
            if ((htmlEntity == null) || (htmlEntity == "")) return (Char.MinValue);

            // Characters (Not HTML Entities).
            if (htmlEntity[0] != '&') {
                if (htmlEntity.Length > 1) return (Char.MinValue);
                return (htmlEntity[0]);
            }

            // Check invalid values in HTML Entities.
            if (htmlEntity.Length == 1) return ('&');
            if (htmlEntity[htmlEntity.Length - 1] != ';') return (Char.MinValue);

            // ASCII Code HTML Entities.
            if (htmlEntity[1] == '#') {
                string code = htmlEntity.Substring (2, htmlEntity.Length - 3);

                try {
                    return ((char) Int32.Parse (code));
                } catch {}
            }

            // Standard HTML Entities.
            //if (htmlEntity == "&nbsp;") return (' ');
            if (htmlEntity == "&amp;") return ('&');
            if (htmlEntity == "&lt;") return ('<');
            if (htmlEntity == "&gt;") return ('>');
            //if (htmlEntity == "&quot;") return ('"');
            return (Char.MinValue);
        }

        public static string CharToHtml (char character) {
            int code = (int) character;
            if ((code < 32) || (code > 126)) return ("&#" + code + ";");

            switch (character) {
                //case ' ': return ("&nbsp;");
                case '&': return ("&amp;");
                case '<': return ("&lt;");
                case '>': return ("&gt;");
                //case '"': return ("&quot;");
                default: return (character.ToString());
            }
        }

        #endregion

        #region Methods for Image Transformations

        // brightness = -1 to 1 (default = 0)
        // contrast = 0 to 4 (default = 1, pure-gray = 0)
        // saturation = 0 to 3 (default = 1, grayscale = 0)
        // gamma = 0 to 4 (Default = 1)
        private static ColorMatrix GetColorMatrix (float brightness, float contrast,
                                                   float saturation, float gamma) {
            if (brightness < -1f) brightness = -1f;
            if (brightness > 1f) brightness = 1f;
            if (contrast < 0f) contrast = 0f;
            if (saturation < 0f) saturation = 0f;
            if (gamma < 0f) gamma = 0f;

            float Wf = (1f - contrast) / 2f + brightness;
            float Rf = (1f - saturation) * GrayScaleRed * contrast;
            float Gf = (1f - saturation) * GrayScaleGreen * contrast;
            float Bf = (1f - saturation) * GrayScaleBlue * contrast;
            float Rf2 = Rf + saturation * contrast;
            float Gf2 = Gf + saturation * contrast;
            float Bf2 = Bf + saturation * contrast;

            return (new ColorMatrix (new float[][] {
                new float[] {Rf2, Rf, Rf, 0f, 0f},
                new float[] {Gf, Gf2, Gf, 0f, 0f},
                new float[] {Bf, Bf, Bf2, 0f, 0f},
                new float[] {0f, 0f, 0f, 1f, 0f},
                new float[] {Wf, Wf, Wf, 0f, gamma}  // we store gamma temporarily here
            }));
        }

        // Returns a resized image based on the given size and portion.
        private static Bitmap GetResizedImage (Image image, int width,
                                               int height, Rectangle section) {
            Bitmap newImage = new Bitmap (width, height);

            try {
                using (Graphics g = Graphics.FromImage (newImage)) {
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;

                    g.DrawImage (image, new Rectangle (0, 0, width, height), 
                                 section.X, section.Y, section.Width, section.Height,
                                 GraphicsUnit.Pixel);
                }
            } catch {
                newImage.Dispose();
                throw;
            }

            return (newImage);
        }

        // Returns a transformed image based on the given color transformation matrix.
        private static Bitmap GetTransformedImage (Image image, ColorMatrix matrix) {
            Bitmap newImage = new Bitmap (image.Width, image.Height);

            try {
                using (ImageAttributes info = new ImageAttributes()) {
                    info.SetGamma (matrix.Matrix44);
                    matrix.Matrix44 = 1f;
                    info.SetColorMatrix (matrix);

                    using (Graphics g = Graphics.FromImage (newImage)) {
                        g.DrawImage (image, new Rectangle (0, 0, image.Width, image.Height),
                                     0, 0, image.Width, image.Height,
                                     GraphicsUnit.Pixel, info);
                    }
                }
            } catch {
                newImage.Dispose();
                throw;
            }

            return (newImage);
        }

        #endregion

        #region Methods for Creating ASCII Art

#if !UseOldAsciiGen
        public string GetAsciiImage (int downScale, bool usePreBlock) {
            int width = ImageFile.Width / downScale;
            int height = ImageFile.Height / downScale;
            Rectangle section = new Rectangle (0, 0, ImageFile.Width, ImageFile.Height);
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix gray = GetColorMatrix (0f, 1f, 0f, 1f);

            try {
                return (GetAsciiImage (image, null, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (double scale, bool usePreBlock) {
            int width = (int) (ImageFile.Width * scale);
            int height = (int) (ImageFile.Height * scale);
            Rectangle section = new Rectangle (0, 0, ImageFile.Width, ImageFile.Height);
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix gray = GetColorMatrix (0f, 1f, 0f, 1f);

            try {
                return (GetAsciiImage (image, null, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (bool usePreBlock) {
            Bitmap image = new Bitmap (ImageFile);
            ColorMatrix gray = GetColorMatrix (0f, 1f, 0f, 1f);

            try {
                return (GetAsciiImage (image, null, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (int width, int height, bool usePreBlock) {
            Rectangle section = new Rectangle (0, 0, ImageFile.Width, ImageFile.Height);
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix gray = GetColorMatrix (0f, 1f, 0f, 1f);

            try {
                return (GetAsciiImage (image, null, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }
#endif

        public string GetAsciiImage (float brightness, float contrast,
                                     float saturation, float gamma, bool usePreBlock) {
            Bitmap image = new Bitmap (ImageFile);
            ColorMatrix color = GetColorMatrix (brightness, contrast, saturation, gamma);
            ColorMatrix gray = GetColorMatrix (brightness, contrast, 0f, gamma);

            try {
                return (GetAsciiImage (image, color, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (int width, int height,
                                     Rectangle section, bool usePreBlock) {
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix gray = GetColorMatrix (0f, 1f, 0f, 1f);

            try {
                return (GetAsciiImage (image, null, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (int width, int height, float brightness, float contrast,
                                     float saturation, float gamma, bool usePreBlock) {
            Rectangle section = new Rectangle (0, 0, ImageFile.Width, ImageFile.Height);
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix color = GetColorMatrix (brightness, contrast, saturation, gamma);
            ColorMatrix gray = GetColorMatrix (brightness, contrast, 0f, gamma);

            try {
                return (GetAsciiImage (image, color, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        public string GetAsciiImage (int width, int height, Rectangle section,
                                     float brightness, float contrast, float saturation,
                                     float gamma, bool usePreBlock) {
            Bitmap image = GetResizedImage (ImageFile, width, height, section);
            ColorMatrix color = GetColorMatrix (brightness, contrast, saturation, gamma);
            ColorMatrix gray = GetColorMatrix (brightness, contrast, 0f, gamma);

            try {
                return (GetAsciiImage (image, color, gray, usePreBlock));
            } finally {
                image.Dispose();
            }
        }

        #endregion

        #region Methods for Processing ASCII Conversions

        private string GetHexColor (Color color) {
            int colorCode = (color.ToArgb() & 0xFFFFFF);
            string hexColor = "00000" + colorCode.ToString ("X");
            return (hexColor.Substring (hexColor.Length - 6));
        }

        private string GetAsciiImage (Bitmap image, ColorMatrix colorMatrix,
                                      ColorMatrix grayMatrix, bool usePreBlock) {
            StringBuilder ascii = new StringBuilder();
            if (usePreBlock) ascii.Append (BlockStart);
            GetAsciiImage (ascii, image, colorMatrix, grayMatrix);
            if (usePreBlock) ascii.Append (BlockEnd);
            return (ascii.ToString());
        }

        private void GetAsciiImage (StringBuilder output, Bitmap image,
                                    ColorMatrix colorMatrix, ColorMatrix grayMatrix) {
            Bitmap colorImage = null;
            Bitmap grayImage = null;

            try {
                // Create images for conversion.
                colorImage = ((colorMatrix == null) || !IsHtmlOutput || !UseColors ||
                              IsGrayScale ? image : GetTransformedImage (image, colorMatrix));
                grayImage = (grayMatrix == null ? image :
                             GetTransformedImage (image, grayMatrix));

                // Retrieve appropiate ASCII Data.
                DataView asciiData = (IsHtmlOutput ? AsciiDataHtml : AsciiDataText);

                if (asciiData.Count == 0)
                    throw new DataException ("No ASCII characters to use!");

                if ((asciiData.Count == 1) && (!UseColors || !IsHtmlOutput))
                    throw new DataException ("Too few ASCII characters to use!");

                // Get list of ASCII characters sorted by brightness.
                string[] ascii = new string[asciiData.Count];

                for (int i = 0; i < asciiData.Count; i++) {
                    string htmlChar = asciiData[i]["htmlchar"].ToString();
                    ascii[i] = (IsHtmlOutput ? htmlChar : HtmlToChar (htmlChar).ToString());
                }

                // Ascii-fy each image pixels.
                string prevColor = null;
                string color;

                for (int y = 0; y < grayImage.Height; y++) {
                    for (int x = 0; x < grayImage.Width; x++) {
                        Color pixel = grayImage.GetPixel (x, y);
                        int index = pixel.R * ascii.Length / 256;
                        string ch = ascii[ascii.Length - index - 1];

                        if (IsHtmlOutput && UseColors) {
                            if (!IsGrayScale) pixel = colorImage.GetPixel (x, y);
                            color = GetHexColor (pixel);

                            if (color != prevColor) {
                                if (prevColor != null) output.Append ("</font>");
                                prevColor = color;
                                output.Append ("<font color='#");
                                output.Append (color);
                                output.Append ("'>");
                            }
                        }

                        output.Append (ch);
                    }

                    if (prevColor != null) {
                        output.Append ("</font>");
                        prevColor = null;
                    }

                    output.Append (IsHtmlOutput ? HtmlNewLine : TextNewLine);
                }
            } finally {
                if ((colorImage != null) && (colorImage != image)) colorImage.Dispose();
                if ((grayImage != null) && (grayImage != image)) grayImage.Dispose();
            }
        }

        #endregion

        #region Old Methods for Creating ASCII Art

#if UseOldAsciiGen
        public string GetAsciiImage (bool usePreBlock) {
            Bitmap bmp = new Bitmap (ImageFile);
            string ascii = GetAsciiImage (bmp, bmp.Width, bmp.Height);
            if (usePreBlock) ascii = BlockStart + ascii + BlockEnd;
            return (ascii);
        }

        public string GetAsciiImage (int downScale, bool usePreBlock) {
            Bitmap bmp = new Bitmap (ImageFile);
            string ascii = GetAsciiImage (bmp, bmp.Width / downScale,
                                          bmp.Height / downScale);
            if (usePreBlock) ascii = BlockStart + ascii + BlockEnd;
            return (ascii);
        }

        public string GetAsciiImage (double scale, bool usePreBlock) {
            int width = (int) (ImageFile.Width * scale);
            int height = (int) (ImageFile.Height * scale);
            Bitmap bmp = new Bitmap (ImageFile, width, height);
            string ascii = GetAsciiImage (bmp, width, height);
            if (usePreBlock) ascii = BlockStart + ascii + BlockEnd;
            return (ascii);
        }

        public string GetAsciiImage (int width, int height, bool usePreBlock) {
            Bitmap bmp = new Bitmap (ImageFile, width, height);
            string ascii = GetAsciiImage (bmp, width, height);
            if (usePreBlock) ascii = BlockStart + ascii + BlockEnd;
            return (ascii);
        }
#endif

        #endregion

        #region Old Methods for Processing ASCII Conversions

        // Main image to ASCII conversion method.
        private string GetAsciiImage (Bitmap image, int width, int height) {
            // Retrieve appropiate ASCII Data.
            DataView asciiData = (IsHtmlOutput ? AsciiDataHtml : AsciiDataText);

            if (asciiData.Count == 0)
                throw new DataException ("No ASCII characters to use!");

            if ((asciiData.Count == 1) && (!UseColors || !IsHtmlOutput))
                throw new DataException ("Too few ASCII characters to use!");

            // Get list of ASCII characters sorted by brightness.
            string[] ascii = new string[asciiData.Count];

            for (int i = 0; i < asciiData.Count; i++) {
                string htmlChar = asciiData[i]["htmlchar"].ToString();
                ascii[i] = (IsHtmlOutput ? htmlChar : HtmlToChar (htmlChar).ToString());
            }

            // Calculate image sampling parameters.
            int wLen = image.Width / width;
            int hLen = image.Height / height;
            int wInit = (image.Width - wLen * width) / 2;
            int hInit = (image.Height - hLen * height) / 2;

            // Ascii-fy each image sampling block.
            StringBuilder asciiImage = new StringBuilder();
            string prevColor = null;
            string color;
            int brightness;
            Rectangle block;

            for (int h = hInit; h < image.Height; h += hLen) {
                for (int w = wInit; w < image.Width; w += wLen) {
                    block = new Rectangle (w, h, wLen, hLen);
                    GetImageBlockInfo (image, block, ascii.Length, IsGrayScale,
                                       out color, out brightness);

                    if (UseColors && IsHtmlOutput && (color != prevColor)) {
                        if (prevColor != null) asciiImage.Append ("</font>");
                        prevColor = color;
                        asciiImage.Append ("<font color='#" + color + "'>");
                    }

                    asciiImage.Append (ascii[brightness]);
                }

                if (prevColor != null) {
                    asciiImage.Append ("</font>");
                    prevColor = null;
                }

                asciiImage.Append (IsHtmlOutput ? HtmlNewLine : TextNewLine);
            }

            return (asciiImage.ToString());
        }

        // Get an image sampling block's average brightness and color.
        private static void GetImageBlockInfo (Bitmap image, Rectangle block,
                                               int brightLevels, bool isGrayScale,
                                               out string hexColor, out int brightness) {
            int red = 0, green = 0, blue = 0;
            int maxX = block.X + block.Width;
            int maxY = block.Y + block.Height;

            if (maxX > image.Width) {
                maxX = image.Width;
                block.Width = maxX - block.X;
            }

            if (maxY > image.Height) {
                maxY = image.Height;
                block.Height = maxY - block.Y;
            }

            for (int y = block.Y; y < maxY; y++) {
                for (int x = block.X; x < maxX; x++) {
                    Color c = image.GetPixel (x, y);
                    red += c.R;
                    green += c.G;
                    blue += c.B;
                }
            }

            int area = block.Width * block.Height;
            red /= area;
            green /= area;
            blue /= area;

            int grayScale = 2125 * red + 7154 * green + 721 * blue;

            if (brightLevels > 842) {
                brightness = (int) (grayScale * (long) brightLevels / 2560000);
            } else {
                brightness = grayScale * brightLevels / 2560000;
            }

            brightness = brightLevels - brightness - 1;

            if (isGrayScale) {
                int gray = grayScale / 10000;
                hexColor = "00000" + ((gray << 16) | (gray << 8) | gray).ToString ("X");
                hexColor = hexColor.Substring (hexColor.Length - 6);
            } else {
                hexColor = "00000" + ((red << 16) | (green << 8) | blue).ToString ("X");
                hexColor = hexColor.Substring (hexColor.Length - 6);
            }
        }

        #endregion

        #endregion
    }
}
