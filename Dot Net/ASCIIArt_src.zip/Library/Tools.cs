/*                          Generic Tools Library
 *                          =====================
 * Description: A common tools library for you to add to your project.
 *
 * Author: Sau Fan Lee
 * Email: leesf20@yahoo.com
 * Version: 1.2.1 (2004-2005)
 *
 * Note: Requires reference to 'System.Web.dll' if 'UseWeb' is defined.
 *       Also, this class should NOT be compiled as a stand-alone DLL.
 */
#define UseWeb

using System;
using System.Configuration;
using System.IO;
using System.Reflection;

#if UseWeb
using System.Web;
#endif

namespace AsciiArt {
    [Serializable]
    internal class ToolsLib {

        /****************** Constructors ******************/

        public ToolsLib() {}

        /******************* Properties *******************/

        #region Current Directory Location

        // Get default current directory.
        private static string defaultCurrentDirectory = null;

        public static string DefaultCurrentDirectory {
            get {
                if (defaultCurrentDirectory == null) {
#if UseWeb
                    try {
                        defaultCurrentDirectory = HttpContext.Current.Server.MapPath (".");
                    } catch {
#endif
                        try {
                            string asmName = Assembly.GetEntryAssembly().Location;
                            defaultCurrentDirectory = (new FileInfo (asmName)).DirectoryName;
                        } catch {
                            try {
                                string asmName = Assembly.GetExecutingAssembly().Location;
                                defaultCurrentDirectory = (new FileInfo (asmName)).DirectoryName;
                            } catch {
                                try {
                                    defaultCurrentDirectory = Directory.GetCurrentDirectory();
                                } catch {
                                    defaultCurrentDirectory = ".";
                                }
                            }
                        }
#if UseWeb
                    }
#endif
                }

                return (defaultCurrentDirectory);
            }
        }

        // Get or set current directory.
        // Note: This property is NOT the same as the actual system
        //       'current working directory' (CWD).
        private string currentDirectory = null;

        public string CurrentDirectory {
            get {
                if (currentDirectory == null) currentDirectory = DefaultCurrentDirectory;
                return (currentDirectory);
            }

            set {
                if (value != null) {
                    value = value.Trim().TrimEnd ('\\');
                    if (value != "") currentDirectory = value;
                }
            }
        }

        #endregion

        /******************** Methods *********************/

        #region Paths Resolving Methods

        // Get the full path-name of the current directory and relative path.
        public string GetPathName (string relPath) {
            return (GetPathName (CurrentDirectory, relPath));
        }

        // Get the full path-name of the given rootPath and relative path.
        public static string GetPathName (string rootPath, string relPath) {
            if (relPath == null) return (null);
            string path = relPath.Trim();

            if (path == ".") {
                path = rootPath;
            } else if (path == "..") {
                path = rootPath + "\\..";
            } else if (path.StartsWith (".\\")) {
                path = rootPath + path.Substring (1);
            } else if (path.StartsWith ("..\\")) {
                path = rootPath + "\\" + path;
            }

            return (path);
        }

        #endregion

        #region .Config File Values Loading Methods

        public static string LoadConfig (string keyName, string defaultValue) {
            return (LoadConfig (keyName, defaultValue, true));
        }

        public static string LoadConfig (string keyName, string defaultValue,
                                         bool allowEmptyString) {
            try {
                string val = ConfigurationSettings.AppSettings[keyName];
                if ((val == "") && !allowEmptyString) return (defaultValue);
                return (val == null ? defaultValue : val);
            } catch {
                return (defaultValue);
            }
        }

        public static int LoadConfig (string keyName, int defaultValue) {
            try {
                return (Int32.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static uint LoadConfig (string keyName, uint defaultValue) {
            try {
                return (UInt32.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static long LoadConfig (string keyName, long defaultValue) {
            try {
                return (Int64.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static ulong LoadConfig (string keyName, ulong defaultValue) {
            try {
                return (UInt64.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static float LoadConfig (string keyName, float defaultValue) {
            try {
                return (Single.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static double LoadConfig (string keyName, double defaultValue) {
            try {
                return (Double.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        public static bool LoadConfig (string keyName, bool defaultValue) {
            try {
                return (Boolean.Parse (ConfigurationSettings.AppSettings[keyName]));
            } catch {
                return (defaultValue);
            }
        }

        #endregion
    }
}
