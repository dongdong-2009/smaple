
#region AcedRegistry Class Reference
/*
--------------------------------------------------------------------------------
public class AcedRegistry : IDisposable

  Provides methods for writing/reading typed data to/from the registry.

--------------------------------------------------------------------------------
ctor
--------------------------------------------------------------------------------

public AcedRegistry(AcedRootKey registryRootKey, string registryKey,
  bool writable)

  Opens a root registry key specified by the "registryRootKey" parameter.
  Then, opens a key passed as string via the "registryKey" parameter. If the
  value of the "writable" parameter is False the registry key is opened in
  the read-only mode. If that value is True the registry key is opened (or
  created if not exists) in the read-write mode.
  
  For example, you may pass the AcedRootKey.LocalMachine value in the first
  parameter and the @"Software\CompanyName\ApplicationName" string in the
  "registryKey" parameter. The following is the list of possible values
  for the "registryRootKey" parameter. Each value corresponds to an instance
  of the root key exposed by the Microsoft.Win32.Registry class:
  
  AcedRootKey.ClassesRoot,
  AcedRootKey.CurrentConfig,
  AcedRootKey.CurrentUser,
  AcedRootKey.DynData,
  AcedRootKey.LocalMachine,
  AcedRootKey.PerformanceData,
  AcedRootKey.Users

--------------------------------------------------------------------------------
Property
--------------------------------------------------------------------------------

public Microsoft.Win32.RegistryKey RegistryKey { get; }

  Gets the related instance of the Microsoft.Win32.RegistryKey class. This
  property returns null if there was an error during opening or creating a
  registry key in the constructor of this class.

--------------------------------------------------------------------------------
Methods
--------------------------------------------------------------------------------

public void Dispose()

  Closes the related registry key and flushes it to disk if its contents have
  been modified.

public void Put(string valueName, String value)
public void Put(string valueName, Byte[] value)
public void Put(string valueName, Int32 value)
public void Put(string valueName, Boolean value)
public void Put(string valueName, DateTime value)
public void Put(string valueName, Decimal value)
public void Put(string valueName, Double value)
public void Put(string valueName, Guid value)
public void Put(string valueName, Int64 value)

  Writes the "value" to the open registry key with value name specified by the
  first parameter ("valueName").

public bool Get(string valueName, ref String value)
public bool Get(string valueName, ref Byte[] value)
public bool Get(string valueName, ref Int32 value)
public bool Get(string valueName, ref Boolean value)
public bool Get(string valueName, ref DateTime value)
public bool Get(string valueName, ref Decimal value)
public bool Get(string valueName, ref Double value)
public bool Get(string valueName, ref Guid value)
public bool Get(string valueName, ref Int64 value)

  Reads a value of the corresponding type with the specified name ("valueName")
  from the open registry key. It is then returned in the "value" parameter.
  The method returns True if the value was successfully read. If there is
  no value with such a name in the current registry key the method returns
  False and does not modify the "value" parameter.

public String GetDef(string valueName, String defaultValue)
public Byte[] GetDef(string valueName, Byte[] defaultValue)
public Int32 GetDef(string valueName, Int32 defaultValue)
public Boolean GetDef(string valueName, Boolean defaultValue)
public DateTime GetDef(string valueName, DateTime defaultValue)
public Decimal GetDef(string valueName, Decimal defaultValue)
public Double GetDef(string valueName, Double defaultValue)
public Guid GetDef(string valueName, Guid defaultValue)
public Int64 GetDef(string valueName, Int64 defaultValue)

  Reads a value of the corresponding type with the specified name ("valueName")
  from the open registry key and returns that value as method's result. If there
  is no value with such a name in the related registry key the method returns a
  value of the "defaultValue" parameter.

--------------------------------------------------------------------------------
*/
#endregion

using System;

namespace Aced.Misc
{
    using MS = Microsoft.Win32;

    // AcedRootKey enumeration

    public enum AcedRootKey
    {
        ClassesRoot,
        CurrentConfig,
        CurrentUser,
        DynData,
        LocalMachine,
        PerformanceData,
        Users
    }

    // AcedRegistry class

    public class AcedRegistry : IDisposable
    {
        private MS.RegistryKey _registryKey;

        public AcedRegistry(AcedRootKey registryRootKey, string registryKey, bool writable)
        {
            switch (registryRootKey)
            {
                case AcedRootKey.ClassesRoot:
                    _registryKey = !writable
                        ? MS.Registry.ClassesRoot.OpenSubKey(registryKey, false)
                        : MS.Registry.ClassesRoot.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.CurrentConfig:
                    _registryKey = !writable
                        ? MS.Registry.CurrentConfig.OpenSubKey(registryKey, false)
                        : MS.Registry.CurrentConfig.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.CurrentUser:
                    _registryKey = !writable
                        ? MS.Registry.CurrentUser.OpenSubKey(registryKey, false)
                        : MS.Registry.CurrentUser.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.DynData:
                    _registryKey = !writable
                        ? MS.Registry.DynData.OpenSubKey(registryKey, false)
                        : MS.Registry.DynData.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.LocalMachine:
                    _registryKey = !writable
                        ? MS.Registry.LocalMachine.OpenSubKey(registryKey, false)
                        : MS.Registry.LocalMachine.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.PerformanceData:
                    _registryKey = !writable
                        ? MS.Registry.PerformanceData.OpenSubKey(registryKey, false)
                        : MS.Registry.PerformanceData.CreateSubKey(registryKey);
                    break;
                case AcedRootKey.Users:
                    _registryKey = !writable
                        ? MS.Registry.Users.OpenSubKey(registryKey, false)
                        : MS.Registry.Users.CreateSubKey(registryKey);
                    break;
            }
        }

        public void Dispose()
        {
            if (_registryKey != null)
            {
                _registryKey.Close();
                _registryKey = null;
            }
        }

        public MS.RegistryKey RegistryKey
        {
            get { return _registryKey; }
        }

        // String values

        public void Put(string valueName, string value)
        {
            if (_registryKey != null)
                _registryKey.SetValue(valueName, value == null ? "" : value);
        }

        public bool Get(string valueName, ref string value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    value = (string)v;
                    return true;
                }
            }
            return false;
        }

        public string GetDef(string valueName, string defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                    defaultValue = (string)v;
            }
            return defaultValue;
        }

        // Byte[] values

        public void Put(string valueName, byte[] value)
        {
            if (_registryKey != null)
                _registryKey.SetValue(valueName, value == null ? new byte[0] : value);
        }

        public bool Get(string valueName, ref byte[] value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    value = (byte[])v;
                    return true;
                }
            }
            return false;
        }

        public byte[] GetDef(string valueName, byte[] defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                    defaultValue = (byte[])v;
            }
            return defaultValue;
        }

        // Int32 values

        public void Put(string valueName, int value)
        {
            if (_registryKey != null)
                _registryKey.SetValue(valueName, value);
        }

        public bool Get(string valueName, ref int value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    value = (int)v;
                    return true;
                }
            }
            return false;
        }

        public int GetDef(string valueName, int defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                    defaultValue = (int)v;
            }
            return defaultValue;
        }

        // Boolean values

        public void Put(string valueName, bool value)
        {
            if (_registryKey != null)
                _registryKey.SetValue(valueName, value ? 1 : 0);
        }

        public bool Get(string valueName, ref bool value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    value = (int)v != 0;
                    return true;
                }
            }
            return false;
        }

        public bool GetDef(string valueName, bool defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                    defaultValue = (int)v != 0;
            }
            return defaultValue;
        }

        // DateTime values

        public unsafe void Put(string valueName, DateTime value)
        {
            if (_registryKey != null)
            {
                byte[] bytes = new byte[8];
                fixed (byte* pBytes = &bytes[0])
                    *((DateTime*)pBytes) = value;
                _registryKey.SetValue(valueName, bytes);
            }
        }

        public unsafe bool Get(string valueName, ref DateTime value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        value = *((DateTime*)pBytes);
                    return true;
                }
            }
            return false;
        }

        public unsafe DateTime GetDef(string valueName, DateTime defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        defaultValue = *((DateTime*)pBytes);
                }
            }
            return defaultValue;
        }

        // Decimal values

        public unsafe void Put(string valueName, decimal value)
        {
            if (_registryKey != null)
            {
                byte[] bytes = new byte[16];
                fixed (byte* pBytes = &bytes[0])
                    *((decimal*)pBytes) = value;
                _registryKey.SetValue(valueName, bytes);
            }
        }

        public unsafe bool Get(string valueName, ref decimal value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        value = *((decimal*)pBytes);
                    return true;
                }
            }
            return false;
        }

        public unsafe decimal GetDef(string valueName, decimal defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        defaultValue = *((decimal*)pBytes);
                }
            }
            return defaultValue;
        }

        // Double values

        public unsafe void Put(string valueName, double value)
        {
            if (_registryKey != null)
            {
                byte[] bytes = new byte[8];
                fixed (byte* pBytes = &bytes[0])
                    *((double*)pBytes) = value;
                _registryKey.SetValue(valueName, bytes);
            }
        }

        public unsafe bool Get(string valueName, ref double value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        value = *((double*)pBytes);
                    return true;
                }
            }
            return false;
        }

        public unsafe double GetDef(string valueName, double defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        defaultValue = *((double*)pBytes);
                }
            }
            return defaultValue;
        }

        // Guid values

        public void Put(string valueName, Guid value)
        {
            if (_registryKey != null)
                _registryKey.SetValue(valueName, value.ToByteArray());
        }

        public bool Get(string valueName, ref Guid value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    value = new Guid((byte[])v);
                    return true;
                }
            }
            return false;
        }

        public Guid GetDef(string valueName, Guid defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                    defaultValue = new Guid((byte[])v);
            }
            return defaultValue;
        }

        // Int64 values

        public unsafe void Put(string valueName, long value)
        {
            if (_registryKey != null)
            {
                byte[] bytes = new byte[8];
                fixed (byte* pBytes = &bytes[0])
                    *((long*)pBytes) = value;
                _registryKey.SetValue(valueName, bytes);
            }
        }

        public unsafe bool Get(string valueName, ref long value)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        value = *((long*)pBytes);
                    return true;
                }
            }
            return false;
        }

        public unsafe long GetDef(string valueName, long defaultValue)
        {
            if (_registryKey != null)
            {
                object v = _registryKey.GetValue(valueName, null);
                if (v != null)
                {
                    byte[] bytes = (byte[])v;
                    fixed (byte* pBytes = &bytes[0])
                        defaultValue = *((long*)pBytes);
                }
            }
            return defaultValue;
        }
    }
}
