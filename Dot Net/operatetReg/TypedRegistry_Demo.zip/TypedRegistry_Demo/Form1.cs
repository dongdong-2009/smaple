using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using Aced.Misc;

namespace TypedRegistry_Demo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button loadConfigButton;
		private System.Windows.Forms.Button saveConfigButton;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button loadPictureButton;
		private System.Windows.Forms.Button clearPictureButton;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.RadioButton radioButton9;
		private System.Windows.Forms.RadioButton radioButton8;
		private System.Windows.Forms.RadioButton radioButton7;
		private System.Windows.Forms.RadioButton radioButton6;
		private System.Windows.Forms.RadioButton radioButton5;
		private System.Windows.Forms.RadioButton radioButton4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.loadConfigButton = new System.Windows.Forms.Button();
			this.saveConfigButton = new System.Windows.Forms.Button();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.loadPictureButton = new System.Windows.Forms.Button();
			this.clearPictureButton = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.radioButton9 = new System.Windows.Forms.RadioButton();
			this.radioButton8 = new System.Windows.Forms.RadioButton();
			this.radioButton7 = new System.Windows.Forms.RadioButton();
			this.radioButton6 = new System.Windows.Forms.RadioButton();
			this.radioButton5 = new System.Windows.Forms.RadioButton();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// loadConfigButton
			// 
			this.loadConfigButton.Location = new System.Drawing.Point(260, 16);
			this.loadConfigButton.Name = "loadConfigButton";
			this.loadConfigButton.Size = new System.Drawing.Size(200, 23);
			this.loadConfigButton.TabIndex = 10;
			this.loadConfigButton.Text = "Load Data From Windows Registry";
			this.loadConfigButton.Click += new System.EventHandler(this.loadConfigButton_Click);
			// 
			// saveConfigButton
			// 
			this.saveConfigButton.Location = new System.Drawing.Point(260, 48);
			this.saveConfigButton.Name = "saveConfigButton";
			this.saveConfigButton.Size = new System.Drawing.Size(200, 23);
			this.saveConfigButton.TabIndex = 11;
			this.saveConfigButton.Text = "Save Data In Windows Registry";
			this.saveConfigButton.Click += new System.EventHandler(this.saveConfigButton_Click);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(16, 80);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(220, 21);
			this.dateTimePicker1.TabIndex = 3;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(16, 28);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(220, 21);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "Some text info";
			// 
			// checkBox1
			// 
			this.checkBox1.Checked = true;
			this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox1.Location = new System.Drawing.Point(148, 132);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(96, 24);
			this.checkBox1.TabIndex = 6;
			this.checkBox1.Text = "Boolean value";
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(16, 132);
			this.numericUpDown1.Maximum = new System.Decimal(new int[] {
																		   100000,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(108, 21);
			this.numericUpDown1.TabIndex = 5;
			this.numericUpDown1.ThousandsSeparator = true;
			this.numericUpDown1.Value = new System.Decimal(new int[] {
																		 12345,
																		 0,
																		 0,
																		 0});
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "String value:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "DateTime value:";
			// 
			// loadPictureButton
			// 
			this.loadPictureButton.Location = new System.Drawing.Point(16, 258);
			this.loadPictureButton.Name = "loadPictureButton";
			this.loadPictureButton.Size = new System.Drawing.Size(108, 23);
			this.loadPictureButton.TabIndex = 8;
			this.loadPictureButton.Text = "Load Image...";
			this.loadPictureButton.Click += new System.EventHandler(this.loadPictureButton_Click);
			// 
			// clearPictureButton
			// 
			this.clearPictureButton.Location = new System.Drawing.Point(132, 258);
			this.clearPictureButton.Name = "clearPictureButton";
			this.clearPictureButton.Size = new System.Drawing.Size(104, 23);
			this.clearPictureButton.TabIndex = 9;
			this.clearPictureButton.Text = "Clear Image";
			this.clearPictureButton.Click += new System.EventHandler(this.clearPictureButton_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 116);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Numeric value:";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "All image files|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.ico;*.wmf;*.emf";
			this.openFileDialog1.Title = "Open";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.radioButton9);
			this.groupBox1.Controls.Add(this.radioButton8);
			this.groupBox1.Controls.Add(this.radioButton7);
			this.groupBox1.Controls.Add(this.radioButton6);
			this.groupBox1.Controls.Add(this.radioButton5);
			this.groupBox1.Controls.Add(this.radioButton4);
			this.groupBox1.Controls.Add(this.radioButton3);
			this.groupBox1.Controls.Add(this.radioButton2);
			this.groupBox1.Controls.Add(this.radioButton1);
			this.groupBox1.Location = new System.Drawing.Point(16, 164);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(220, 80);
			this.groupBox1.TabIndex = 7;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Enumeration value";
			// 
			// radioButton9
			// 
			this.radioButton9.Location = new System.Drawing.Point(140, 52);
			this.radioButton9.Name = "radioButton9";
			this.radioButton9.Size = new System.Drawing.Size(76, 20);
			this.radioButton9.TabIndex = 8;
			this.radioButton9.Text = "Violet";
			// 
			// radioButton8
			// 
			this.radioButton8.Location = new System.Drawing.Point(140, 36);
			this.radioButton8.Name = "radioButton8";
			this.radioButton8.Size = new System.Drawing.Size(76, 16);
			this.radioButton8.TabIndex = 7;
			this.radioButton8.Text = "Orange";
			// 
			// radioButton7
			// 
			this.radioButton7.Location = new System.Drawing.Point(140, 16);
			this.radioButton7.Name = "radioButton7";
			this.radioButton7.Size = new System.Drawing.Size(76, 20);
			this.radioButton7.TabIndex = 6;
			this.radioButton7.Text = "Black";
			// 
			// radioButton6
			// 
			this.radioButton6.Location = new System.Drawing.Point(76, 52);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.Size = new System.Drawing.Size(60, 20);
			this.radioButton6.TabIndex = 5;
			this.radioButton6.Text = "White";
			// 
			// radioButton5
			// 
			this.radioButton5.Location = new System.Drawing.Point(76, 36);
			this.radioButton5.Name = "radioButton5";
			this.radioButton5.Size = new System.Drawing.Size(60, 16);
			this.radioButton5.TabIndex = 4;
			this.radioButton5.Text = "Brown";
			// 
			// radioButton4
			// 
			this.radioButton4.Checked = true;
			this.radioButton4.Location = new System.Drawing.Point(76, 16);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(60, 20);
			this.radioButton4.TabIndex = 3;
			this.radioButton4.TabStop = true;
			this.radioButton4.Text = "Green";
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(12, 52);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(60, 20);
			this.radioButton3.TabIndex = 2;
			this.radioButton3.Text = "Blue";
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(12, 36);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(60, 16);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "Yellow";
			// 
			// radioButton1
			// 
			this.radioButton1.Location = new System.Drawing.Point(12, 16);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(60, 20);
			this.radioButton1.TabIndex = 0;
			this.radioButton1.Text = "Red";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.pictureBox1);
			this.groupBox2.Location = new System.Drawing.Point(260, 88);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(200, 192);
			this.groupBox2.TabIndex = 12;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Image (binary data)";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(4, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(192, 172);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 9;
			this.pictureBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(480, 297);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.clearPictureButton);
			this.Controls.Add(this.loadPictureButton);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.numericUpDown1);
			this.Controls.Add(this.checkBox1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.saveConfigButton);
			this.Controls.Add(this.loadConfigButton);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "TypedRegistry Test Application";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Closed += new System.EventHandler(this.Form1_Closed);
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private enum MyColors
		{
			Red,
			Yellow,
			Blue,
			Green,
			Brown,
			White,
			Black,
			Orange,
			Violet
		}

		private const string
			DemoRegistryKeyName = "Software\\TypedRegistryDemo",

			//let's save the string in the default value of the registry key
			cfgStringValueName = "",
			cfgDateTimeValueName = "DateTimeValue",
			cfgDecimalValueName = "DecimalValue",
			cfgBooleanValueName = "BooleanValue",
			cfgEnumValueName = "EnumerationElement",
			cfgByteArrayValueName = "Image";

		private static string _stringValue;
		private static DateTime _dateTimeValue;
		private static decimal _decimalValue;
		private static bool _booleanValue;
		private static MyColors _enumValue;
		private static byte[] _byteArrayValue;

		private static void LoadConfig()
		{
			using (AcedRegistry config = new AcedRegistry(AcedRootKey.CurrentUser,
					   DemoRegistryKeyName, false))
			{
				config.Get(cfgStringValueName, ref _stringValue);
				config.Get(cfgDateTimeValueName, ref _dateTimeValue);
				config.Get(cfgDecimalValueName, ref _decimalValue);
				config.Get(cfgBooleanValueName, ref _booleanValue);
				_enumValue = (MyColors)config.GetDef(cfgEnumValueName, (int)_enumValue);
				config.Get(cfgByteArrayValueName, ref _byteArrayValue);
			}
		}

		private static void SaveConfig()
		{
			using (AcedRegistry config = new AcedRegistry(AcedRootKey.CurrentUser,
					   DemoRegistryKeyName, true))
			{
				config.Put(cfgStringValueName, _stringValue);
				config.Put(cfgDateTimeValueName, _dateTimeValue);
				config.Put(cfgDecimalValueName, _decimalValue);
				config.Put(cfgBooleanValueName, _booleanValue);
				config.Put(cfgEnumValueName, (int)_enumValue);
				config.Put(cfgByteArrayValueName, _byteArrayValue);
			}
		}

		private void UpdateChanges()
		{
			_stringValue = textBox1.Text;
			_dateTimeValue = dateTimePicker1.Value;
			_decimalValue = numericUpDown1.Value;
			_booleanValue = checkBox1.Checked;
			if (radioButton1.Checked)
				_enumValue = MyColors.Red;
			else if (radioButton2.Checked)
				_enumValue = MyColors.Yellow;
			else if (radioButton3.Checked)
				_enumValue = MyColors.Blue;
			else if (radioButton4.Checked)
				_enumValue = MyColors.Green;
			else if (radioButton5.Checked)
				_enumValue = MyColors.Brown;
			else if (radioButton6.Checked)
				_enumValue = MyColors.White;
			else if (radioButton7.Checked)
				_enumValue = MyColors.Black;
			else if (radioButton8.Checked)
				_enumValue = MyColors.Orange;
			else if (radioButton9.Checked)
				_enumValue = MyColors.Violet;
			Image image = pictureBox1.Image;
			if (image == null)
				_byteArrayValue = null;
			else
			{
				MemoryStream ms = new MemoryStream();
				image.Save(ms, ImageFormat.Png);
				ms.Close();
				_byteArrayValue = ms.ToArray();
			}
		}

		private void RefreshControls()
		{
			textBox1.Text = _stringValue;
			dateTimePicker1.Value = _dateTimeValue;
			numericUpDown1.Value = _decimalValue;
			checkBox1.Checked = _booleanValue;
			switch (_enumValue)
			{
				case MyColors.Red:
					radioButton1.PerformClick();
					break;
				case MyColors.Yellow:
					radioButton2.PerformClick();
					break;
				case MyColors.Blue:
					radioButton3.PerformClick();
					break;
				case MyColors.Green:
					radioButton4.PerformClick();
					break;
				case MyColors.Brown:
					radioButton5.PerformClick();
					break;
				case MyColors.White:
					radioButton6.PerformClick();
					break;
				case MyColors.Black:
					radioButton7.PerformClick();
					break;
				case MyColors.Orange:
					radioButton8.PerformClick();
					break;
				case MyColors.Violet:
					radioButton9.PerformClick();
					break;
			}
			if (_byteArrayValue == null || _byteArrayValue.Length == 0)
				pictureBox1.Image = null;
			else
			{
				MemoryStream ms = new MemoryStream(_byteArrayValue);
				pictureBox1.Image = Image.FromStream(ms);
				ms.Close();
			}
		}

		private void loadPictureButton_Click(object sender, System.EventArgs e)
		{
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
				pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
		}

		private void clearPictureButton_Click(object sender, System.EventArgs e)
		{
			pictureBox1.Image = null;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			UpdateChanges();
			LoadConfig();
			RefreshControls();
		}

		private void Form1_Closed(object sender, System.EventArgs e)
		{
			UpdateChanges();
			SaveConfig();
		}

		private void loadConfigButton_Click(object sender, System.EventArgs e)
		{
			LoadConfig();
			RefreshControls();
		}

		private void saveConfigButton_Click(object sender, System.EventArgs e)
		{
			UpdateChanges();
			SaveConfig();
		}
	}
}
