using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Default7 : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection Con = new SqlConnection(Cn);
            string sel = "select ParentName,ParentID,Dateof from ParentTable";
            SqlCommand cmd = new SqlCommand(sel, Con);

            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("ParentID", typeof(string)));
            dt.Columns.Add(new DataColumn("ChildId", typeof(string)));
            dt.Columns.Add(new DataColumn("Name", typeof(string)));
            dt.Columns.Add(new DataColumn("Dateof", typeof(string)));
            Con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {

                DataRow dr = dt.NewRow();
                int Pid = Convert.ToInt32(reader["ParentID"]);
                dr["ParentID"] = (reader["ParentID"]);
                dr["ChildId"] = null;
                dr["Name"] = (reader["ParentName"]);
                dr["Dateof"] = reader["Dateof"]; 
                dt.Rows.Add(dr);

                DataTable Mytable = Test(Pid.ToString());
                foreach (DataRow dro in Mytable.Rows)
                {
                    DataRow dr2 = dt.NewRow();
                    dr2["ChildId"] = dro["ChildId"];
                    dr2["Name"] = dro["ChildName"];
                    dr2["Dateof"] = dro["Dateof"];
                    dt.Rows.Add(dr2);
                }




            }
            reader.Close();
            Con.Close();
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
    protected DataTable Test(string ParentId)
    {
        SqlConnection Con = new SqlConnection(Cn);
        DataTable dt = new DataTable();
        dt.Columns.Add(new DataColumn("ChildName", typeof(string)));
        dt.Columns.Add(new DataColumn("ChildId", typeof(string)));
        dt.Columns.Add(new DataColumn("Dateof", typeof(string)));
        string sel2 = "select Dateof,ChildName,ChildId from ChildTable where ParentId=" + ParentId;
        SqlCommand cmd_2 = new SqlCommand(sel2, Con);
        Con.Open();
        SqlDataReader reader2 = cmd_2.ExecuteReader();
        while (reader2.Read())
        {
            DataRow dr2 = dt.NewRow();
            dr2["ChildName"] = reader2["ChildName"];
            dr2["ChildId"] = reader2["ChildId"]; 
            dr2["Dateof"] = reader2["Dateof"];
            dt.Rows.Add(dr2);
        }
        return dt;
    }
     protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[1].Visible = false;
            e.Row.Cells[2].Visible = false;
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[1].Visible = false;
            e.Row.Cells[2].Visible = false;
            Button MinButton = (Button)e.Row.Cells[0].FindControl("MinBT");
            MinButton.CommandArgument = e.Row.RowIndex.ToString();
            Button addButton = (Button)e.Row.Cells[0].FindControl("PluseBT");
            addButton.CommandArgument = e.Row.RowIndex.ToString();
            // e.Row.Cells[3].Visible = false;
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string ShowHide=e.Row.Cells[1].Text;
            ShowHide = ShowHide.Replace("&nbsp;", "");
            if (ShowHide.Trim().Length == 0)
            {
                Button Bt_Min=(Button)e.Row.Cells[0].FindControl("MinBT");
                Bt_Min.Visible=false;
                 Button Bt_plus=(Button)e.Row.Cells[0].FindControl("PluseBT");
                Bt_plus.Visible=false;
                
            }


        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "_Show")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = GridView1.Rows[index];
            int G_Count = GridView1.Rows.Count;
            for (int i = index + 1; i < G_Count; i++)
            {
                if (GridView1.Rows[i].Cells[1].Text == "&nbsp;")
                {
                    GridView1.Rows[i].Visible = true;
                }
                else
                {
                    Button Bt_Min = (Button)row.Cells[0].FindControl("MinBT");
                    Bt_Min.Visible = true;
                    Button Bt_plus = (Button)row.Cells[0].FindControl("PluseBT");
                    Bt_plus.Visible = false;
                    break;

                }
                Button Bt_Min1 = (Button)row.Cells[0].FindControl("MinBT");
                Bt_Min1.Visible = true;
                Button Bt_plus1 = (Button)row.Cells[0].FindControl("PluseBT");
                Bt_plus1.Visible = false;
            }

        }
        if (e.CommandName == "_Hide")
        {
           int index = Convert.ToInt32(e.CommandArgument);
           GridViewRow row = GridView1.Rows[index];
           int G_Count=GridView1.Rows.Count;
           for (int i = index+1; i < G_Count; i++)
           {
               if (GridView1.Rows[i].Cells[1].Text == "&nbsp;")
               {
                   GridView1.Rows[i].Visible = false;
               }
               else
               {
                   Button Bt_Min = (Button)row.Cells[0].FindControl("MinBT");
                   Bt_Min.Visible = false;
                   Button Bt_plus = (Button)row.Cells[0].FindControl("PluseBT");
                   Bt_plus.Visible = true;
                   break;
                 
               }
               Button Bt_Min1 = (Button)row.Cells[0].FindControl("MinBT");
               Bt_Min1.Visible = false;
               Button Bt_plus1 = (Button)row.Cells[0].FindControl("PluseBT");
               Bt_plus1.Visible = true;
           }
          

        }
    }
}
