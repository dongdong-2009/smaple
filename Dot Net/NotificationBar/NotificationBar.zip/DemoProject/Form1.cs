﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoProject
{
    public partial class Form1 : Form
    {
        bool animate = false;

        public Form1()
        {
            InitializeComponent();
        }

        void UpdateComboBox()
        {
            comboBox1.Items.Clear();

            for (int i = 0; i < imageList1.Images.Count; i++)
            {
                comboBox1.Items.Add(i.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string file = openFileDialog1.FileName;
                imageList1.Images.Add(Image.FromFile(file));
                UpdateComboBox();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            notificationBar1.PlaySoundWhenShown = checkBox1.Checked;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            notificationBar1.ImageIndex = Convert.ToInt16(comboBox1.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int milli = (int)numericUpDown1.Value;
            int times = (int)numericUpDown2.Value;

            notificationBar1.Flash(milli, times);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            notificationBar1.Text = richTextBox1.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (notificationBar1.Visible)
            {
                notificationBar1.Hide(animate);
            }
            else
            {
                notificationBar1.Show(animate);
            }
        }

        private void flashOnceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            notificationBar1.Flash(1);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            animate = checkBox2.Checked;
        }
    }
}
