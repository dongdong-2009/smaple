using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace popupform
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Timer timer1;
		private System.ComponentModel.IContainer components;
		int X=0;
		int Y=0;
		private System.Windows.Forms.Timer timer2;
		private System.Windows.Forms.Timer timer3;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.LinkLabel linkLabel1;		

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code 
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.timer2 = new System.Windows.Forms.Timer(this.components);
			this.timer3 = new System.Windows.Forms.Timer(this.components);
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// timer2
			// 
			this.timer2.Interval = 10;
			this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
			// 
			// timer3
			// 
			this.timer3.Interval = 3000;
			this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(226, 72);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// linkLabel1
			// 
			this.linkLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.linkLabel1.Location = new System.Drawing.Point(0, 72);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(226, 72);
			this.linkLabel1.TabIndex = 2;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "New Article has been added to Codeproject.com.Rate this article if you like it.";
			this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(192)), ((System.Byte)(128)));
			this.ClientSize = new System.Drawing.Size(226, 144);
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.pictureBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "CodeProject Alert";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		# region Code in Form Load  
		private void Form1_Load(object sender, System.EventArgs e)
		{
			/*The Screen.GetWorkingArea(control) will provide you the working
			area of a screen without the system tray area. The working area 
			depends on the resolution of your monitor*/
			
			X=Screen.GetWorkingArea(this).Width; // This line gives the width of working area
			Y=Screen.GetWorkingArea(this).Height; // This line gives the width of working area			
			this.Location=new Point(X-this.Width,Y+this.Height); // This line sets the initial location of the form
			
			timer1.Enabled=true;	
			timer1.Start();   // We'll start the timer which handles the opening of form.
		}
		
		# endregion

		# region Code for Opening the Form and displaying it for some time 
		private void timer1_Tick(object sender, System.EventArgs e)
		{
			/* The logic is that, first we will open the form below
			   taskbar at specified location and then in Timer's TICK event 
			   we'll just bring the form above taskbar to have the animated 
			   effect.
			  */
			int i = this.Location.Y; // First we will know form's Y-axis location
									 // which will act as upper limit for form's location
			if(i>Y-this.Height)		
			{				
				this.Location=new Point(X-this.Width,i-8);	// Here we just change the location
															// of form by 8 pixels(i-8)
			}
			else   // else we stop Timer1 and start Timer3 which holds the form for some time
			{
				timer1.Stop();
				timer1.Enabled=false;

				timer3.Start();
				timer3.Enabled=true;
			}
		}

		# endregion

		# region Code for Closing the Form  
		private void timer2_Tick(object sender, System.EventArgs e)
		{
			/*
			   Here the logic is same as opening the form, only location value of Y-axis
			   is increased, so that form slowly hides behind Task Bar.
			 */
			timer3.Stop();
			timer3.Enabled=false;

			int i = this.Location.Y;
			if(i<Y)
			{
				this.Location=new Point(X-this.Width,i+8);	
			}
			else
			{
				timer2.Stop();
				timer2.Enabled=false;
				this.Close();				
			}
		}

		# endregion

		# region Start Closing the Form  
		private void timer3_Tick(object sender, System.EventArgs e)
		{
			timer2.Start();          // Here we start Timer2 which handles closing of form
			timer2.Enabled=true;
		}
		# endregion	    	
        
		
	}
}
