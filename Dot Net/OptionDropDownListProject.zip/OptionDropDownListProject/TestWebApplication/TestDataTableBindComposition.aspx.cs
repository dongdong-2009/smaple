using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OptionDropDownList;

namespace TestWebApplication
{
  public partial class TestDataTableBindComposition : System.Web.UI.Page
  {
    private DataTable CreateDataTableSource()
    {
      DataTable dt = new DataTable();
      DataRow dr;

      dt.Columns.Add(new DataColumn("id", typeof(Int32)));
      dt.Columns.Add(new DataColumn("name", typeof(String)));
      dt.Columns.Add(new DataColumn("surname", typeof(String)));
      dt.Columns.Add(new DataColumn("office", typeof(String)));
      dt.Columns.Add(new DataColumn("degree", typeof(Int32)));

      for (int i = 0; i < 9; i++)
      {
        dr = dt.NewRow();

        dr[0] = i;
        dr[1] = "Name " + i.ToString();
        dr[2] = "Surname " + i.ToString();
        dr[3] = (((i % 2) == 0) ? "Development" : "Customer services");
        dr[4] = i;

        dt.Rows.Add(dr);
      }
      
      return dt;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      this.OptionGroupSelect1.DataTextField = "surname";
      this.OptionGroupSelect1.DataValueField = "id";
      this.OptionGroupSelect1.OptionGroupField = "office";

      this.OptionGroupSelect1.DataSource = this.CreateDataTableSource();
      this.OptionGroupSelect1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
      OptionGroupItem item = this.OptionGroupSelect1.SelectedItem;
      this.Label1.Text = item.Value;
      this.Label2.Text = item.Text;
      this.Label3.Text = item.OptionGroup;
    }
  }
}
