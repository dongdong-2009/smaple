using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TestWebApplication
{
  public partial class TestItemDesignTimeAndDataBind : System.Web.UI.Page
  {
    private ICollection CreateDataSource()
    {
      DataTable dt = new DataTable();
      DataRow dr;

      dt.Columns.Add(new DataColumn("id", typeof(String)));
      dt.Columns.Add(new DataColumn("letter", typeof(String)));
      dt.Columns.Add(new DataColumn("letters", typeof(String)));

      dr = dt.NewRow();
      dr[0] = "A";
      dr[1] = "letter A";
      dr[2] = "letters";
      dt.Rows.Add(dr);

      dr = dt.NewRow();
      dr[0] = "B";
      dr[1] = "letter B";
      dr[2] = "letters";
      dt.Rows.Add(dr);

      DataView dv = new DataView(dt);
      return dv;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!this.IsPostBack)
      {
        this.OptionGroupSelect1.DataTextField = "letter";
        this.OptionGroupSelect1.DataValueField = "id";
        this.OptionGroupSelect1.OptionGroupField = "letters";

        this.OptionGroupSelect1.DataSource = this.CreateDataSource();
        this.OptionGroupSelect1.DataBind();
      }
    }

    protected void OptionGroupSelect1_ValueChanged(object sender, EventArgs e)
    {
      this.Label1.Text = 
        this.OptionGroupSelect1.SelectedItem.Value + "-" + this.OptionGroupSelect1.SelectedItem.Text;
    }
  }
}
