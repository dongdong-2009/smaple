using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using OptionDropDownList;

namespace TestWebApplication
{
  public partial class TestDataListBindComposition : System.Web.UI.Page
  {
    private ICollection CreateDataSource()
    {
      List<OptionGroupItem> lista = new List<OptionGroupItem>();

      for (int i = 0; i < 9; i++)
      {
        OptionGroupItem item = new OptionGroupItem();
        item.Value = i.ToString();
        item.Text = "Name " + i.ToString();
        item.OptionGroup = (((i % 2) == 0) ? "Development" : "Customer services");

        lista.Add(item);
      }

      return lista;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      this.OptionGroupSelect1.DataSource = this.CreateDataSource();
      this.OptionGroupSelect1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
      OptionGroupItem item = this.OptionGroupSelect1.SelectedItem;
      this.Label1.Text = item.Value;
      this.Label2.Text = item.Text;
      this.Label3.Text = item.OptionGroup;
    }
  }
}
