using System;
using System.Web.UI;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace OptionDropDownList
{
  class OptionGroupItemBuilder : ControlBuilder
  {
    /// <summary>
    /// GetChildControlType
    /// </summary>
    /// <param name="tagName"></param>
    /// <param name="attributes"></param>
    /// <returns></returns>
    public override Type GetChildControlType(String tagName, IDictionary attributes)
    {
      if (tagName.Contains("OptionGroupItem")) return typeof(OptionGroupItem);
      else return null;
    }

    /// <summary>
    /// AppendLiteralString
    /// </summary>
    /// <param name="s"></param>
    public override void AppendLiteralString(string s)
    {
    }
  }
}
