using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using OptionDropDownList;

namespace TestWebApplication
{
  public partial class TestProgrammaticComposition : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!this.IsPostBack)
      {
        this.OptionGroupSelect1.Items.Add(new OptionGroupItem("A", "Letter A", "Letters"));
        this.OptionGroupSelect1.Items.Add(new OptionGroupItem("B", "Letter B", "Letters"));
        this.OptionGroupSelect1.Items.Add(new OptionGroupItem("C", "Letter C", "Letters"));
      }

      this.OptionGroupSelect1.ValueChanged += new EventHandler(OptionGroupSelect1_ValueChanged);
    }

    void OptionGroupSelect1_ValueChanged(object sender, EventArgs e)
    {
      this.Response.Write("Selected value: " + this.OptionGroupSelect1.SelectedValue);
    }
  }
}
