using System;
using System.Collections;
using System.Text;
using System.Reflection; 

namespace SortingMethods
{
    /// <summary>
    /// Reflection based General use IComparer for Sorting
    /// </summary>
    public class GeneralComparer: IComparer
    {
        public string MemberName = string.Empty;
        public string SortOrder = string.Empty;
        public ArrayList MethodParameters = null;

        /// <summary>
        /// Default constructor for use in instances.
        /// </summary>
        public GeneralComparer()
        {
        }

        /// <summary>
        /// Constructor for in-line instantiation
        /// </summary>
        /// <param name="memberName">string of the member name to use for comparison</param>
        /// <param name="sortOrder">string of the sort order (case independent)</param>
        /// <param name="methodParameters">object array of parameters to use for method, null otherwise.</param>
        public GeneralComparer(string memberName, string sortOrder, object[] methodParameters)
        {
            this.MemberName = memberName;
            this.SortOrder = sortOrder;
            if (methodParameters != null)
            {
                this.MethodParameters = new ArrayList(methodParameters);
            }
        }

        /// <summary>
        /// Implementing method for IComparer
        /// </summary>
        /// <param name="objOne">Object to compare from</param>
        /// <param name="objTwo">Object to compare to</param>
        /// <returns>int of the comparison, or 0 if equal</returns>
        public int Compare(object objOne, object objTwo)
        {
            IComparable iComparable1 = GetComparable(objOne);
            IComparable iComparable2 = GetComparable(objTwo);

            if (SortOrder != null && SortOrder.ToUpper().Equals("ASC"))
            {
                return iComparable1.CompareTo(iComparable2);
            }
            else
            {
                return iComparable2.CompareTo(iComparable1);
            }
        }

        /// <summary>
        /// Return an IComparable for use in the Compare method
        /// </summary>
        /// <param name="obj">object to get IComparable from</param>
        /// <returns>IComparable for this object</returns>
        private IComparable GetComparable(object obj)
        {
            MemberInfo[] mi =  obj.GetType().GetMember(MemberName);
            if (mi.Length > 0)
            {
                if (mi[0].MemberType == MemberTypes.Property)
                {
                    PropertyInfo pi = obj.GetType().GetProperty(MemberName);

                    return (IComparable)pi.GetValue(obj, null);
                }
                else if (mi[0].MemberType == MemberTypes.Method)
                {
                    Type[] signatureTypes = new Type[0];
                    if (MethodParameters != null && MethodParameters.Count > 0)
                    {
                        signatureTypes = new Type[MethodParameters.Count];
                        for (int i = 0; i < MethodParameters.Count; i++)
                        {
                            signatureTypes[i] = MethodParameters[i].GetType();
                        }
                        return (IComparable)obj.GetType().GetMethod(MemberName, signatureTypes).Invoke(obj, MethodParameters.ToArray());
                    }
                    else
                    {
                        return (IComparable)obj.GetType().GetMethod(MemberName, signatureTypes).Invoke(obj, null);
                    }
                }
                else
                {
                    throw new Exception("Member name: " + MemberName + " is not a Public Property or a Public Method in Type: " + obj.GetType().Name + ".");
                }
            }
            else
            {
                throw new Exception("Member name: " + MemberName + " not found.");
            }
        }
    }
}
