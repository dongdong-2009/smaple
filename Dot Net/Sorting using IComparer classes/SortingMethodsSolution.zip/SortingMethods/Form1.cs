using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SortingMethods
{
    public partial class Form1 : Form
    {
        List<DataObject> array;

        public Form1()
        {
            InitializeComponent();
        }

        private void RunSorting()
        {
            Reset(); // Clears labels and fields.

            // Test of method parameters
            List<object> ps = new List<object>();
            ps.Add(1);

            // Start Datetime stored
            DateTime sortStart = DateTime.Now;

            // Sort the Collection using the Selected comparer
            // -----------------------------------------------
            if (comboBoxSorts.SelectedIndex == 0)// Generic Comparer
            {
                array.Sort(new GenericComparer<DataObject>("ID", "asc", null));
            }
            else if (comboBoxSorts.SelectedIndex == 1) // General Comparer
            {
                // General Comparer does not support generic collections,
                // have to use an ArrayList.  This comparer class can be used
                // in previous framework versions.
                ArrayList arr2 = new ArrayList();
                arr2.AddRange(array);
                arr2.Sort(new GeneralComparer("ID", "asc", null));
            }
            else if (comboBoxSorts.SelectedIndex == 2) // Name Comparer
            {
                array.Sort(new NameComparer());
            }
            else if (comboBoxSorts.SelectedIndex == 3) // Reverse Name Comparer
            {
                array.Sort(new RevNameComparer());
            }
            else if (comboBoxSorts.SelectedIndex == 4) // Default Comparer
            {
                array.Sort();
            }
            // -----------------------------------------------
            // Sort End DateTime stored.
            DateTime sortEnd = DateTime.Now;
            // Calculate timespan
            TimeSpan sortDuration = sortEnd - sortStart;
            // Set Label
            this.labelSortTimespan.Text = "" + sortDuration.TotalMilliseconds + " milliseconds";

            Thread.Sleep(5);
            // Show sorted in GUI
            if (cxBxShowList.Checked)
            {
                for (int i = 0; i < array.Count; i++)
                {
                    //string key = se.Keys[i];
                    DataObject dobj = array[i];
                    textBox1.AppendText(dobj.ID + "\n");
                }
            }
            labelDone.Text = "Done!";
        }

        /// <summary>
        /// Resets the label text values to  ""
        /// </summary>
        private void Reset()
        {
            labelDone.Text = "Creating items";
            this.labelSortTimespan.Text = "";
            textBox1.Text = "";
            this.Refresh();
        }

        /// <summary>
        /// Creates and returns an Item collection to use for sorting.
        /// </summary>
        /// <returns>Generic List of items (unsorted)</returns>
        private void CreateItems()
        {
            Creator creator = new Creator();

            int amt = int.Parse(textBoxAmt.Text);

            // Get Start DateTime
            DateTime startCreate = DateTime.Now;

            // Get a collection of DataObjects to start with
            array = creator.CreateList(amt);


            // Get End DateTime
            DateTime endCreate = DateTime.Now;
            // Calculate timespan for creation and set labels
            TimeSpan duration1 = endCreate - startCreate;
            labelDone.Text = "Items Created ready to Sort";
            this.Refresh();
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            RunSorting();
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            CreateItems();
            buttonRun.Enabled = true;
        }
    }
}