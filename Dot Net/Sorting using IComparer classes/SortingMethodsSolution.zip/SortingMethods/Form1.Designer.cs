namespace SortingMethods
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRun = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxAmt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxSorts = new System.Windows.Forms.ComboBox();
            this.cxBxShowList = new System.Windows.Forms.CheckBox();
            this.labelSortTimespan = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelDone = new System.Windows.Forms.Label();
            this.buttonCreate = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonRun
            // 
            this.buttonRun.Enabled = false;
            this.buttonRun.Location = new System.Drawing.Point(3, 4);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(75, 23);
            this.buttonRun.TabIndex = 0;
            this.buttonRun.Text = "Run";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.comboBoxSorts);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(5, 540);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(366, 36);
            this.panel1.TabIndex = 1;
            // 
            // textBoxAmt
            // 
            this.textBoxAmt.Location = new System.Drawing.Point(108, 6);
            this.textBoxAmt.Name = "textBoxAmt";
            this.textBoxAmt.Size = new System.Drawing.Size(153, 20);
            this.textBoxAmt.TabIndex = 3;
            this.textBoxAmt.Text = "200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "# of items to create:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.buttonRun);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(283, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(83, 36);
            this.panel3.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(366, 397);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonCreate);
            this.panel2.Controls.Add(this.cxBxShowList);
            this.panel2.Controls.Add(this.textBoxAmt);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(5, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(366, 59);
            this.panel2.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Sort using:";
            // 
            // comboBoxSorts
            // 
            this.comboBoxSorts.FormattingEnabled = true;
            this.comboBoxSorts.Items.AddRange(new object[] {
            "Generic Comparer",
            "General Comparer",
            "Name Comparer",
            "Reverse Name Comparer",
            "Default"});
            this.comboBoxSorts.Location = new System.Drawing.Point(64, 6);
            this.comboBoxSorts.Name = "comboBoxSorts";
            this.comboBoxSorts.Size = new System.Drawing.Size(213, 21);
            this.comboBoxSorts.TabIndex = 5;
            this.comboBoxSorts.Text = "Generic Comparer";
            // 
            // cxBxShowList
            // 
            this.cxBxShowList.AutoSize = true;
            this.cxBxShowList.Checked = true;
            this.cxBxShowList.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cxBxShowList.Location = new System.Drawing.Point(3, 36);
            this.cxBxShowList.Name = "cxBxShowList";
            this.cxBxShowList.Size = new System.Drawing.Size(138, 17);
            this.cxBxShowList.TabIndex = 4;
            this.cxBxShowList.Text = "Show Sorted List Below";
            this.cxBxShowList.UseVisualStyleBackColor = true;
            // 
            // labelSortTimespan
            // 
            this.labelSortTimespan.AutoSize = true;
            this.labelSortTimespan.Location = new System.Drawing.Point(101, 11);
            this.labelSortTimespan.Name = "labelSortTimespan";
            this.labelSortTimespan.Size = new System.Drawing.Size(0, 13);
            this.labelSortTimespan.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Timespan to Sort:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(5, 64);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(366, 476);
            this.panel4.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.labelDone);
            this.panel5.Controls.Add(this.labelSortTimespan);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 397);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(366, 79);
            this.panel5.TabIndex = 4;
            // 
            // labelDone
            // 
            this.labelDone.AutoSize = true;
            this.labelDone.Location = new System.Drawing.Point(0, 46);
            this.labelDone.Name = "labelDone";
            this.labelDone.Size = new System.Drawing.Size(38, 13);
            this.labelDone.TabIndex = 3;
            this.labelDone.Text = "Ready";
            // 
            // buttonCreate
            // 
            this.buttonCreate.Location = new System.Drawing.Point(268, 4);
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(93, 23);
            this.buttonCreate.TabIndex = 5;
            this.buttonCreate.Text = "Create Array";
            this.buttonCreate.UseVisualStyleBackColor = true;
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 581);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox textBox1;
        private System.Windows.Forms.TextBox textBoxAmt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelSortTimespan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cxBxShowList;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label labelDone;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxSorts;
        private System.Windows.Forms.Button buttonCreate;
    }
}

