using System;
using System.Collections.Generic;
using System.Text;

namespace SortingMethods
{

    public class DataObject: IComparable
    {
        private string _id;
	    public string ID
	    {
		    get 
		    { 
			    return _id;
		    }
		    set 
		    { 
			    _id = value;
		    }
	    }

        public string GetID()
        {
            return _id;
        }

        public int GetID(int i)
        {
            return ~i;
        }

        public int CompareTo(object obj)
        {
            if (obj is DataObject)
            {
                DataObject oVar = obj as DataObject;
                return String.Compare(_id, oVar.ID, true);
            }
            else if (obj is string)
            {
                return String.Compare(_id, obj as string);
            }
            else
            {
                return -1;
            }
        }
    }
}
