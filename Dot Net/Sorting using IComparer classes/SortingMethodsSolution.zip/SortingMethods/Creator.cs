using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Text;

namespace SortingMethods
{
    public class Creator
    {
        char[] alpha = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
        char[] number = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        
        public Creator()
        {
        }

        public List<DataObject> CreateList(int number)
        {
            List<DataObject> list = new List<DataObject>();

            for (int i = 0; i < number; i++)
            {
                string sId = GetUnique(i);

                DataObject dObj = new DataObject();
                dObj.ID = sId;

                list.Add(dObj);
                Thread.Sleep(1);
            }

            return list;
        }


        private string GetUnique(int i)
        {
            Random aRandom = new Random();
            int iAlpha = 2;
            iAlpha = aRandom.Next(0, alpha.Length - 1);

            char c = alpha[iAlpha];

            return c + "" + i;
        }
    }
}
