using System;
using System.Collections.Generic;
using System.Text;

namespace SortingMethods
{
    /// <summary>
    /// Class used to sort DataObjects (Ascending)
    /// </summary>
    public class NameComparer: IComparer<DataObject>
    {
        public NameComparer()
        {
        }

        #region IComparer<DataObject> Members

        public int Compare(DataObject x, DataObject y)
        {
            return x.ID.CompareTo(y.ID);
        }

        public int Compare(DataObject x, string y)
        {
            return x.ID.CompareTo(y);
        }

        #endregion
    }

    /// <summary>
    /// Class to sort DataObjects (Descending)
    /// </summary>
    public class RevNameComparer : IComparer<DataObject>
    {
        public RevNameComparer()
        {
        }

        #region IComparer<DataObject> Members

        public int Compare(DataObject x, DataObject y)
        {
            return x.ID.CompareTo(y.ID) * -1;
        }

        public int Compare(DataObject x, string y)
        {
            return x.ID.CompareTo(y) * -1;
        }

        #endregion
    }
}
