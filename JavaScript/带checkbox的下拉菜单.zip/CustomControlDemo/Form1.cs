using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CustomControlDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
    #region Form Controls
    private UtilityLibrary.Combos.CheckCombo checkCombo1;
    private UtilityLibrary.Combos.DateCombo dateCombo1;
    private UtilityLibrary.Combos.TreeCombo treeCombo1;
    private System.Windows.Forms.ImageList imageList1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.CheckBox checkBox1;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.CheckBox checkBox2;
    private System.ComponentModel.IContainer components;
    #endregion

    #region Initialize/Finilize methods
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
    #endregion

    #region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
      this.checkCombo1 = new UtilityLibrary.Combos.CheckCombo();
      this.dateCombo1 = new UtilityLibrary.Combos.DateCombo();
      this.treeCombo1 = new UtilityLibrary.Combos.TreeCombo();
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.checkBox1 = new System.Windows.Forms.CheckBox();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.checkBox2 = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // checkCombo1
      // 
      this.checkCombo1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.checkCombo1.Location = new System.Drawing.Point(16, 32);
      this.checkCombo1.Name = "checkCombo1";
      this.checkCombo1.ReadOnly = true;
      this.checkCombo1.Size = new System.Drawing.Size(302, 21);
      this.checkCombo1.TabIndex = 0;
      this.checkCombo1.Text = "checkCombo1";
      this.checkCombo1.TreeImageList = null;
      this.checkCombo1.DataFill += new UtilityLibrary.Combos.TreeCombo.FillTreeByDataHandler(this.checkCombo1_DataFill);
      // 
      // dateCombo1
      // 
      this.dateCombo1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.dateCombo1.Location = new System.Drawing.Point(16, 80);
      this.dateCombo1.Name = "dateCombo1";
      this.dateCombo1.ReadOnly = true;
      this.dateCombo1.Size = new System.Drawing.Size(302, 21);
      this.dateCombo1.TabIndex = 1;
      this.dateCombo1.Text = "dateCombo1";
      this.dateCombo1.Value = new System.DateTime(((long)(0)));
      // 
      // treeCombo1
      // 
      this.treeCombo1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.treeCombo1.Location = new System.Drawing.Point(16, 128);
      this.treeCombo1.Name = "treeCombo1";
      this.treeCombo1.ReadOnly = true;
      this.treeCombo1.Size = new System.Drawing.Size(302, 21);
      this.treeCombo1.TabIndex = 2;
      this.treeCombo1.Text = "treeCombo1";
      this.treeCombo1.TreeImageList = this.imageList1;
      this.treeCombo1.DataFill += new UtilityLibrary.Combos.TreeCombo.FillTreeByDataHandler(this.treeCombo1_DataFill);
      // 
      // imageList1
      // 
      this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
      this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Fuchsia;
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(416, 16);
      this.label1.TabIndex = 3;
      this.label1.Text = "Check Combo Box:";
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 64);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(416, 16);
      this.label2.TabIndex = 3;
      this.label2.Text = "DateTime Combo Box:";
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 112);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(416, 16);
      this.label3.TabIndex = 3;
      this.label3.Text = "Tree Combo Box:";
      // 
      // checkBox1
      // 
      this.checkBox1.Checked = true;
      this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
      this.checkBox1.Location = new System.Drawing.Point(16, 168);
      this.checkBox1.Name = "checkBox1";
      this.checkBox1.Size = new System.Drawing.Size(136, 16);
      this.checkBox1.TabIndex = 4;
      this.checkBox1.Text = "ReadOnly State";
      this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
      // 
      // label4
      // 
      this.label4.BackColor = System.Drawing.SystemColors.ControlDark;
      this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
      this.label4.Location = new System.Drawing.Point(16, 192);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(304, 24);
      this.label4.TabIndex = 5;
      this.label4.Text = "<checked combo value>";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label5
      // 
      this.label5.BackColor = System.Drawing.SystemColors.ControlDark;
      this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
      this.label5.Location = new System.Drawing.Point(16, 224);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(304, 24);
      this.label5.TabIndex = 5;
      this.label5.Text = "<DateTime combo value>";
      this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label6
      // 
      this.label6.BackColor = System.Drawing.SystemColors.ControlDark;
      this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
      this.label6.Location = new System.Drawing.Point(16, 256);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(304, 24);
      this.label6.TabIndex = 5;
      this.label6.Text = "<Tree combo value>";
      this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // checkBox2
      // 
      this.checkBox2.Checked = true;
      this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
      this.checkBox2.Cursor = System.Windows.Forms.Cursors.Default;
      this.checkBox2.Location = new System.Drawing.Point(168, 168);
      this.checkBox2.Name = "checkBox2";
      this.checkBox2.Size = new System.Drawing.Size(144, 16);
      this.checkBox2.TabIndex = 6;
      this.checkBox2.Text = "Enabled";
      this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(330, 295);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.checkBox2,
                                                                  this.label4,
                                                                  this.checkBox1,
                                                                  this.label1,
                                                                  this.treeCombo1,
                                                                  this.dateCombo1,
                                                                  this.checkCombo1,
                                                                  this.label2,
                                                                  this.label3,
                                                                  this.label5,
                                                                  this.label6});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.MinimumSize = new System.Drawing.Size(336, 320);
      this.Name = "Form1";
      this.Text = "Custom Combo Demo";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);

    }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

    
    #region Event Handlers
    private void checkCombo1_DataFill(object sender, UtilityLibrary.Combos.TreeCombo.EventArgsTreeDataFill e)
    {
      e.BindedControl.Nodes.Add( "Test1" );
      e.BindedControl.Nodes.Add( "Test11" );
      e.BindedControl.Nodes.Add( "Test12" );
      e.BindedControl.Nodes.Add( "Test13" );
      e.BindedControl.Nodes.Add( "Test14" );
      e.BindedControl.Nodes.Add( "Test2" );
      e.BindedControl.Nodes.Add( "Test21" );
      e.BindedControl.Nodes.Add( "Test22" );
      e.BindedControl.Nodes.Add( "Test23" );
    }

    private void treeCombo1_DataFill(object sender, UtilityLibrary.Combos.TreeCombo.EventArgsTreeDataFill e)
    {
      TreeNode node = e.BindedControl.Nodes.Add( "Test1" );
      TreeNode node1;

      node.Nodes.Add( "Test11" );
      node.Nodes.Add( "Test12" );
      node.Nodes.Add( "Test13" );
      node.Nodes.Add( "Test14" );
      node = e.BindedControl.Nodes.Add( "Test2" );
      node.Nodes.Add( "Test21" );
      node.Nodes.Add( "Test22" );
      node.Nodes.Add( "Test23" );
      node1 = node.Nodes.Add( "Test24" );
      node1.Nodes.Add( "Test241" );
      node1.Nodes.Add( "Test242" );
      node1.Nodes.Add( "Test243" );
      node1.Nodes.Add( "Test244" );
      node = e.BindedControl.Nodes.Add( "Test3" );
      node.Nodes.Add( "Test31" );
      node.Nodes.Add( "Test32" );
      node.Nodes.Add( "Test33" );
      node.Nodes.Add( "Test34" );
      node = e.BindedControl.Nodes.Add( "Test4" );
      node.Nodes.Add( "Test41" );
      node.Nodes.Add( "Test42" );
      node.Nodes.Add( "Test43" );
      node.Nodes.Add( "Test44" );
      node = e.BindedControl.Nodes.Add( "Test5" );
      node.Nodes.Add( "Test51" );
      node.Nodes.Add( "Test52" );
      node.Nodes.Add( "Test53" );
      node.Nodes.Add( "Test54" );    
    }

    private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
    {
      treeCombo1.ReadOnly = 
        dateCombo1.ReadOnly = 
        checkCombo1.ReadOnly = checkBox1.Checked;
    }

    private void Form1_Load(object sender, System.EventArgs e)
    {
      label4.DataBindings.Add( "Text", checkCombo1, "Value" );
      label5.DataBindings.Add( "Text", dateCombo1, "Value" );
      label6.DataBindings.Add( "Text", treeCombo1, "Value" );
    }

    private void checkBox2_CheckedChanged(object sender, System.EventArgs e)
    {
      treeCombo1.Enabled = 
        dateCombo1.Enabled = 
        checkCombo1.Enabled = checkBox2.Checked;
    }
    #endregion
	}
}
