using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Drawing;

namespace AlienMenuControl
{
        public class AlienMenuItems : CollectionBase
        {

            private AlienMenuControl owner;

            public AlienMenuItems(
                   AlienMenuControl c
                ) : base()
            {
                this.owner = c;
            }
            public AlienMenuItems() : base()
            {
            }

            public AlienMenuItem this[int idx]
            {
                get
                {
                    return (AlienMenuItem)InnerList[idx];
                }
            }
            public AlienMenuItem Add(
                   string sText
                )
            {
                AlienMenuItem aclb = new AlienMenuItem(owner);
                aclb.Text = sText;
                InnerList.Add(aclb);
                owner.CalcMenuSize();
                return aclb;

            }
            public AlienMenuItem Add(
                   string sText,
                   string sDescription
                )
            {
                AlienMenuItem aclb = new AlienMenuItem(owner);
                aclb.Text = sText;
                aclb.Description = sDescription;
                InnerList.Add(aclb);
                owner.CalcMenuSize();
                return aclb;

            }
            public AlienMenuItem Add(
                string sText,
                string sDescription,
                Image img
                )
            {
                AlienMenuItem btn = new AlienMenuItem(owner);
                btn.Text = sText;
                btn.Description = sDescription;
                btn.Image = img;

               
                InnerList.Add(btn);
                owner.CalcMenuSize();
                
                return btn;
                
            }
            public AlienMenuItem Add(
                string sText,
                Image img
                )
            {
                AlienMenuItem btn = new AlienMenuItem(owner);
                btn.Text = sText;
                btn.Image = img;
               
                InnerList.Add(btn);
                owner.CalcMenuSize();
                return btn;

            }
            public void Add(AlienMenuItem btn)
            {
                
                List.Add(btn);
                btn.Owner = this.owner;
                owner.CalcMenuSize();
              
                
            }
            public int IndexOf(object o)
            {
                return InnerList.IndexOf(o);
            }
            protected override void OnInsertComplete(int index, object value)
            {
                AlienMenuItem btn = (AlienMenuItem)value;
                btn.Owner = this.owner;
                owner.CalcMenuSize();
                base.OnInsertComplete(index, value);
            }
            protected override void OnSetComplete(int index, object oldValue, object newValue)
            {
                AlienMenuItem btn = (AlienMenuItem)newValue;
                btn.Owner = this.owner;
                owner.CalcMenuSize();
                base.OnSetComplete(index, oldValue, newValue);
            }
            public AlienMenuControl Owner
            {
                get
                {
                    return this.owner;
                }
            }
            protected override void OnClearComplete()
            {
                owner.CalcMenuSize();   
                base.OnClearComplete();
            }
        
        
        }
        
}
