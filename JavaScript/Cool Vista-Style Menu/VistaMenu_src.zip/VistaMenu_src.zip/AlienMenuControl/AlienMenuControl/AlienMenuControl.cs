
// *************************************************************************
// Cool Vista-style menu control
// Created by: Nedim Sabic
// nesa@ei.upv.es
// 
//   TODO LIST :
//   
//   - Item's text alignment
//   - Item's icon alignment
//   - Smooth item's text scrolling ( for animating purpose)
//   - Menu animating
//   - Hiding / showing sidebar at runtime (button)
//   - Tooltip for items
//
// *************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace AlienMenuControl
{
    [DefaultEvent("AlienMenuItemClick")]
    public partial class AlienMenuControl : UserControl
    {

        #region Private members
        /// <summary>
        /// Start gradient color for menu panel.
        /// </summary>
        private Color m_clrMenuPanelStart = Color.FromArgb(102, 102, 102);
        /// <summary>
        /// End gradient color for menu panel.
        /// </summary>
        private Color m_clrMenuPanelEnd = Color.FromArgb(42, 42, 42);
        /// <summary>
        /// Outer border color for menu.
        /// </summary>
        private Color m_clrOuterBorder = Color.FromArgb(29, 29, 29);
        /// <summary>
        /// Inner border color for menu.
        /// </summary>
        private Color m_clrInnerBorder = Color.FromArgb(158, 158, 158);
        /// <summary>
        /// Collection of menu items.
        /// </summary>
        private AlienMenuItems items = new AlienMenuItems();
        /// <summary>
        /// Item's height.
        /// </summary>
        private int m_lItemHeight = 48;
        /// <summary>
        /// Side bar width.
        /// </summary>
        private int m_lBarWidth = 25;
        /// <summary>
        /// Font used for side bar caption.
        /// </summary>
        private Font m_fntBar = new Font("Visitor TT2 BRK", 12);
        /// <summary>
        /// Font color used for side bar caption.
        /// </summary>
        private Color m_clrCaptionBar = Color.White;
        /// <summary>
        /// Gradient start color for sidebar fill.
        /// </summary>
        private Color m_clrGradientBarStart = Color.FromArgb(142, 142, 142);
        /// <summary>
        /// Gradient end color for sidebar fill.
        /// </summary>
        private Color m_clrGradientBarEnd = Color.FromArgb(42, 42, 42);
        /// <summary>
        /// Sidebar's icon.
        /// </summary>
        private Bitmap m_bmpBar;
        /// <summary>
        /// Caption displayed in side bar.
        /// </summary>
        private string m_sCaptionBar = "Alien Cool Menu";
        /// <summary>
        /// Indicates if side bar is rendered.
        /// </summary>
        private bool m_bDrawBar = false;
        /// <summary>
        /// Indicates if flat separatos are rendered.
        /// </summary>
        private bool m_bFlatSeparators = false;
        /// <summary>
        /// Color for flat separators.
        /// </summary>
        private Color m_clrFlatSeparators = Color.Silver;
        /// <summary>
        /// Background image for menu panel.
        /// </summary>
        private Bitmap m_bmpBackImage;
        /// <summary>
        /// Background image position.
        /// </summary>
        private ContentAlignment m_ImageAlign = ContentAlignment.TopRight;
        #endregion

        #region Properties
        /// <summary>
        /// Gets/ sets if sidebar is rendered.
        /// </summary>
        [Description("Gets / sets if sidebar is rendered.")]
        public bool SideBar
        {
            get
            {
                return this.m_bDrawBar;
            }
            set
            {
                this.m_bDrawBar = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets sidebar's font.
        /// </summary>
        [Description("Sidebar's font")]
        public Font SideBarFont
        {
            get
            {
                return this.m_fntBar;
            }
            set
            {
                this.m_fntBar = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets sidebar's font color.
        /// </summary>
        [Description("Sidebar's font color")]
        public Color SideBarFontColor
        {
            get
            {
                return this.m_clrCaptionBar;
            }
            set
            {
                this.m_clrCaptionBar = value;
                if (m_bDrawBar)
                  Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets caption for sidebar.
        /// </summary>
        [Description("Gets / sets caption for a sidebar")]
        public string SideBarCaption
        {
            
            get
            {   
                return this.m_sCaptionBar;
            }
            set
            {
                this.m_sCaptionBar = value;
                if (m_bDrawBar)
                    Invalidate();
            }
        }
        /// <summary>
        /// Gets / sets start color for sidebar fill:
        /// </summary>
        [Description("Start color for sidebar fill")]
        public Color SideBarStartGradient
        {
            get
            {
                return this.m_clrGradientBarStart;
            }
            set
            {
                this.m_clrGradientBarStart = value;
                if (m_bDrawBar)
                    Invalidate();
            }
        
        }
        /// <summary>
        /// Gets / sets end color for sidebar fill:
        /// </summary>
        [Description("Start color for sidebar fill")]
        public Color SideBarEndGradient
        {
            get
            {
                return this.m_clrGradientBarEnd;
            }
            set
            {
                this.m_clrGradientBarEnd = value;
                if (m_bDrawBar)
                    Invalidate();
            }

        }
        /// <summary>
        /// Gets / sets side bar image.
        /// </summary>
        [Description("Image for sidebar")]
        public Bitmap SideBarBitmap
        {
            get
            {
                return this.m_bmpBar;
            }
            set
            {
                this.m_bmpBar = value;
                if (m_bDrawBar)
                    Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets start gradient color for menu:
        /// </summary>
        [Description("Menu's start gradient color")]
        public Color MenuStartColor
        {
            get
            {
                return this.m_clrMenuPanelStart;
            }
            set
            {
                this.m_clrMenuPanelStart = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets end gradient color for menu:
        /// </summary>
        [Description("Menu's end gradient color")]
        public Color MenuEndColor
        {
            get
            {
                return this.m_clrMenuPanelEnd;
            }
            set
            {
                this.m_clrMenuPanelEnd = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets inner border color for menu:
        /// </summary>
        [Description("Menu's inner border color")]
        public Color MenuInnerBorderColor
        {
            get
            {
                return this.m_clrInnerBorder;
            }
            set
            {
                this.m_clrInnerBorder = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets outer border color for menu:
        /// </summary>
        [Description("Menu's outer border color")]
        public Color MenuOuterBorderColor
        {
            get
            {
                return this.m_clrOuterBorder;
            }
            set
            {
                this.m_clrOuterBorder = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets/ sets item's height:
        /// </summary>
        [Description("Item's height")]
        public int ItemHeight
        {
            get
            {
                return this.m_lItemHeight;
            }
            set
            {
                this.m_lItemHeight = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets menu items:
        /// </summary>
        [Description("Menu items")]
        public AlienMenuItems Items
        {
            get
            {
                return this.items;
            }
        }
        /// <summary>
        /// Gets / sets background bitmap:
        /// </summary>
        [Description("Background bitmap")]
        public Bitmap BackMenuImage
        {
            get
            {
                return this.m_bmpBackImage;
            }
            set
            {
                this.m_bmpBackImage = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Indicates if flat separators are rendered:
        /// </summary>
        [Description("Activates flat separators")]
        public bool FlatSeparators
        {
            get
            {
                return this.m_bFlatSeparators;
            }
            set
            {
                this.m_bFlatSeparators = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets / sets flat separator's color:
        /// </summary>
        [Description("Flat separator's color:")]
        public Color FlatSeparatorsColor
        {
            get
            {
                return this.m_clrFlatSeparators;
            }
            set
            {
                this.m_clrFlatSeparators = value;
                Invalidate();
            }
        }
        /// <summary>
        /// Gets / sets background image
        /// </summary>
        [Description("Background image")]
        public ContentAlignment BackImageAlign
        {
            get
            {
                return this.m_ImageAlign;
            }
            set
            {
                this.m_ImageAlign = value;
                Invalidate();
            }
        }
        #endregion

        #region AlienMenuItemClickArgs
        public class AlienMenuItemClickArgs : EventArgs
        {
            private AlienMenuItem i;
            public AlienMenuItemClickArgs(
                   AlienMenuItem item
                )
                : base()
            {
                i = item;
            }

            public AlienMenuItem Item
            {
                get
                {
                    return i;
                }
            }
        }
        #endregion
       
        #region Delegates / events
        public delegate void AlienMenuItemClickHandler(AlienMenuItemClickArgs e);
        public event AlienMenuItemClickHandler AlienMenuItemClick;
        #endregion

        #region Constructor
        public AlienMenuControl() : base()
        {
            // designer call:
            InitializeComponent();

            // control styles:
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                ControlStyles.DoubleBuffer |
                ControlStyles.SupportsTransparentBackColor |
                ControlStyles.ResizeRedraw |
                ControlStyles.UserPaint, true);

            this.items = new AlienMenuItems(this);
        }
        #endregion

        #region Overrides
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try
            {
               

                DrawMenuPanel(e.Graphics, e.ClipRectangle, m_clrMenuPanelStart, m_clrMenuPanelEnd);
                DrawOuterBorder(e.Graphics, e.ClipRectangle, m_clrOuterBorder);
                DrawInnerBorder(e.Graphics, e.ClipRectangle, m_clrInnerBorder);
                if (!this.DesignMode)
                {
                    
                    DrawBackImage(e.Graphics, e.ClipRectangle);
                    DrawMenuItems(e.Graphics, e.ClipRectangle, 7);

                    if (m_bDrawBar)
                    {
                        DrawSideBar(e.Graphics, m_clrGradientBarStart, m_clrGradientBarEnd, m_bmpBar, m_sCaptionBar);
                    }
                }
            }
            catch (Exception exc)
            {
            }
        }

        protected override void OnMouseDown(
            System.Windows.Forms.MouseEventArgs e
            )
        {
            base.OnMouseDown(e);
            int lIndex = -1;

            if (m_bDrawBar)
                lIndex = HitTestItem(e.X, e.Y);
            else
                lIndex = (e.Y + 1) / (m_lItemHeight + 2);
            
            if (e.Button == MouseButtons.Left)
            {
                for (int i = 0; i < items.Count; i++)
                {
                    if (lIndex == i)
                    {
                        if (items[i].Disabled)
                            return;
                        
                        items[i].MouseDown = true;
                        Invalidate();

                        AlienMenuItemClickArgs item =
                            new AlienMenuItemClickArgs(items[i]);
                        if (AlienMenuItemClick != null)
                            AlienMenuItemClick(item);
                    }
                }
            }

        }
        protected override void OnMouseUp(
            System.Windows.Forms.MouseEventArgs e
            )
        {
            base.OnMouseUp(e);
            if (e.Button == MouseButtons.Left)
            {
                for (int i = 0; i < items.Count; i++)
                {
                    if (items[i].MouseDown)
                    {
                        items[i].MouseDown = false;
                        Invalidate();
                    }
                }
            }


        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int lIndex = -1;
            bool bChanged = false;
            
            if (m_bDrawBar)
                lIndex = HitTestItem(e.X, e.Y);
            else
                lIndex = (e.Y + 1) / (m_lItemHeight + 2);

            if (lIndex >= 0 && lIndex < items.Count)
            {

                for (int idx = 0; idx < items.Count; idx++)
                {
                    if (idx == lIndex)
                    {
                        if (!items[idx].Hovering)
                        {

                            items[idx].Hovering = true;
                            Cursor = Cursors.Hand;
                            bChanged = true;
                        }
                    }
                    else
                    {
                        if (items[idx].Hovering)
                        {
                            items[idx].Hovering = false;
                            bChanged = true;
                        }
                    }
                    
                 }
            }
            
            if (bChanged)
            {
                this.Invalidate();
            }

        }
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Hovering)
                {
                    items[i].Hovering = false;
                    Invalidate();
                }
            }
            Cursor = Cursors.Default;
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Draws menu base panel.
        /// </summary>
        /// <param name="gfx">Graphics object</param>
        /// <param name="rc"> Menu rectangle</param>
        /// <param name="clrStart">Start gradient color</param>
        /// <param name="clrEnd">End gradient color</param>
        private void DrawMenuPanel(
            Graphics gfx,
            Rectangle rc,
            Color clrStart,
            Color clrEnd
                )
        {
            rc.Inflate(-1, -1);
            using (GraphicsPath pathMenuPanel =
                      RoundRect((RectangleF)rc, 7, 7, 7, 7))
            {
                using (LinearGradientBrush lgb =
                           new LinearGradientBrush(
                           rc,
                           m_clrMenuPanelStart,
                           m_clrMenuPanelEnd,
                           90f))
                {

                    gfx.SmoothingMode = SmoothingMode.HighQuality;
                    gfx.CompositingQuality = CompositingQuality.HighQuality;
                    gfx.FillPath(lgb, pathMenuPanel);
                }
            
            }
            
        }
        /// <summary>
        /// Draws outer border.
        /// </summary>
        /// <param name="gfx">Graphics object</param>
        /// <param name="rc">Menu rectangle</param>
        /// <param name="clr">Border color</param>
        private void DrawOuterBorder(
            Graphics gfx,
            Rectangle rc,
            Color clr)
        {
            rc.Inflate(-1, -1);
            using (GraphicsPath pathMenuPanel =
                      RoundRect((RectangleF)rc, 7, 7, 7, 7))
            {
                using (Pen pen = new Pen(clr))
                {
                    gfx.SmoothingMode = SmoothingMode.HighQuality;
                    gfx.CompositingQuality = CompositingQuality.HighQuality;
                    gfx.DrawPath(pen, pathMenuPanel);
                }

            }
        
        
        }
        /// <summary>
        /// Draws inner border.
        /// </summary>
        /// <param name="gfx">Graphics object</param>
        /// <param name="rc">Menu rectangle</param>
        /// <param name="clr">Border color</param>
        private void DrawInnerBorder(
            Graphics gfx,
            Rectangle rc,
            Color clr)
        {

            rc.Inflate(-2, -2);
            using (GraphicsPath pathMenuPanel =
                      RoundRect((RectangleF)rc, 7, 7, 7, 7))
            {
                using (Pen pen = new Pen(clr))
                {
                    gfx.SmoothingMode = SmoothingMode.HighQuality;
                    gfx.CompositingQuality = CompositingQuality.HighQuality;
                    gfx.DrawPath(pen, pathMenuPanel);
                }

            }


        }
        /// <summary>
        /// Draws background image:
        /// </summary>
        /// <param name="gfx">Graphics object</param>
        /// <param name="rc">Menu rectangle</param>
        private void DrawBackImage(
            Graphics gfx,
            Rectangle rc
            )
        {
            if (m_bmpBackImage != null)
            {
                int lW =  m_bmpBackImage.Width;
                int lH = m_bmpBackImage.Height;
                Rectangle rcImage = new Rectangle(
                    0,
                    0,
                    lW,
                    lH
                    );
                
                switch (m_ImageAlign)
                {
                    case ContentAlignment.BottomCenter:
                        rcImage.X = rc.Width / 2 - lW / 2;
                        rcImage.Y = rc.Height - lH - 2;
                        break;
                    case ContentAlignment.BottomLeft:
                        rcImage.X = rc.Left + 2;
                        rcImage.Y = rc.Height - lH - 2;
                        break;
                    case ContentAlignment.BottomRight:
                        rcImage.X = rc.Right - lW -  2;
                        rcImage.Y = rc.Height - lH - 2;
                        break;
                    case ContentAlignment.MiddleCenter:
                        rcImage.X = rc.Width / 2 - lW / 2;
                        rcImage.Y = rc.Height / 2 - lH / 2;
                        break;
                    case ContentAlignment.MiddleLeft:
                        rcImage.X = rc.Left + 2;
                        rcImage.Y = rc.Height / 2 - lH / 2;
                        break;
                    case ContentAlignment.MiddleRight:
                        rcImage.X = rc.Right - lW - 2; 
                        rcImage.Y = rc.Height / 2 - lH / 2;
                        break;
                    case ContentAlignment.TopCenter:
                        rcImage.X = rc.Width / 2 - lW / 2;
                        rcImage.Y = rc.Top + 2;
                        break;
                    case ContentAlignment.TopLeft:
                        rcImage.X = rc.Left + 2;
                        rcImage.Y = rc.Top + 2;
                        break;
                    case ContentAlignment.TopRight:
                        rcImage.X = rc.Right - lW - 2;
                        rcImage.Y = rc.Top + 2;
                        break;

                }

                gfx.DrawImage(
                    m_bmpBackImage,
                    rcImage
                );
            
            }
        
        }
        /// <summary>
        /// Renders menu items.
        /// </summary>
        /// <param name="gfx">Graphics object</param>
        /// <param name="rc">Menu rectangle</param>
        /// <param name="r">Selection radius</param>
        private void DrawMenuItems(
             Graphics gfx,
             Rectangle rc,
             float r
            )
        {
            Rectangle rcItem = new Rectangle();
            rcItem.X = 5;
            rcItem.Y = 4;
            rcItem.Width = rc.Width - 10;
            rcItem.Height = m_lItemHeight;

            if (m_bDrawBar){
            
                rcItem.X = m_lBarWidth;
                rcItem.Width -= m_lBarWidth - 5;
            }
            
            Rectangle rcUpRect = rcItem;
            Rectangle rcDownRect = rcItem;

            rcUpRect.Height /= 2;
            rcDownRect.Height /= 2;
            rcDownRect.Y = rcUpRect.Height + 3;

            if (items == null || items.Count == 0)
                return;

            gfx.SmoothingMode = SmoothingMode.HighQuality;
            gfx.CompositingQuality = CompositingQuality.HighQuality;
            gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            foreach (AlienMenuItem item in items) {
               
                #region Draw selection
                try
                {
                    item.Left = rcItem.X;
                    item.Top = rcItem.Y;
                    if (item.Hovering)
                    {
                        // draw upper rectangle:
                        using (LinearGradientBrush brush =
                                    new LinearGradientBrush(
                                    rcUpRect,
                                    item.SelectionStartColor,
                                    item.SelectionEndColor,
                                    LinearGradientMode.Vertical))
                        {
                            using (GraphicsPath itemPath =
                                        RoundRect((RectangleF)rcUpRect, r, r, 0, 0))
                            {
                                gfx.FillPath(brush, itemPath);


                            }
                        }
                        // draw lower rectangle:
                        using (LinearGradientBrush brush =
                                    new LinearGradientBrush(
                                    rcDownRect,
                                    item.SelectionStartColorStart,
                                    item.SelectionEndColorEnd,
                                    LinearGradientMode.Vertical))
                        {
                            using (GraphicsPath itemPath =
                                        RoundRect((RectangleF)rcDownRect, 0, 0, r, r))
                            {
                                gfx.FillPath(brush, itemPath);


                            }
                        }

                        Rectangle rcItemInner = rcItem;
                        if (item.MouseDown)
                        {
                            rcItemInner.Inflate(-2, -2);
                        }
                        else
                        {
                            rcItemInner.Inflate(-1, -1);
                        }

                        // draw selection borders:
                        using (Pen pen = new Pen(item.OuterBorder), penOuter = new Pen(item.InnerBorder))
                        {
                            using (GraphicsPath outerBorder =
                                       RoundRect((RectangleF)rcItem, r, r, r, r))
                            {
                                gfx.DrawPath(pen, outerBorder);
                            }

                            using (GraphicsPath innerBorder =
                                       RoundRect((RectangleF)rcItemInner, r, r, r, r))
                            {
                                gfx.DrawPath(penOuter, innerBorder);
                            }
                        }



                    }
                }
                catch (Exception e)
                {
                }
                #endregion
                
                #region Draw icons
                
                if (item.Image != null)
                {
                    Rectangle rcIcon = new Rectangle();
                    rcIcon.X = rcItem.X + 2;
                    rcIcon.Y = rcItem.Bottom - item.Image.Height;
                    rcIcon.Width = item.Image.Width;
                    rcIcon.Height = item.Image.Height;

                    if (item.Disabled)
                    {
                        ControlPaint.DrawImageDisabled(
                            gfx,
                            item.Image,
                            rcIcon.X,
                            rcIcon.Y,
                            Color.Transparent);
                    }
                    else
                    {
                        gfx.DrawImage(
                            item.Image,
                            rcIcon
                        );
                    }
                }

                #endregion

                #region Draw separators
                Point pStart = new Point(rcItem.Left + 3, rcItem.Bottom );
                Point pEnd = new Point(rcItem.Right - 3, rcItem.Bottom );

                using (Pen pInner = new Pen(m_clrInnerBorder), 
                                pOuter = new Pen(m_clrOuterBorder))
                {               

                        if (!m_bFlatSeparators)
                        {
                            // don't draw separator for last item:
                            if (items.IndexOf(item) < items.Count - 1)
                            {
                                gfx.DrawLine(pOuter, pStart, pEnd);
                                pStart.Y += 1; pEnd.Y += 1;
                                gfx.DrawLine(pInner, pStart, pEnd);
                            }
                        }
                        else
                        {
                            Pen pFlat = new Pen(m_clrFlatSeparators);
                            // don't draw separator for last item:
                            pStart.Y += 1; pEnd.Y += 1;
                            if (items.IndexOf(item) < items.Count - 1)
                                gfx.DrawLine(pFlat, pStart, pEnd);
                            // clean up:
                            pFlat.Dispose();
                        }

                }
                #endregion

                #region Draw item's text
                StringFormat sf = new StringFormat();
                StringFormat sfUpper = new StringFormat();
                sfUpper.Trimming = StringTrimming.EllipsisCharacter;
                sfUpper.FormatFlags = StringFormatFlags.LineLimit;
                sf.Trimming = StringTrimming.EllipsisCharacter;
                sf.FormatFlags = StringFormatFlags.LineLimit;
                
                Rectangle rcCaption = rcUpRect;
                Rectangle rcContent = rcDownRect;
                
                if (item.Image != null)
                {
                    sfUpper.Alignment = StringAlignment.Near;
                    sfUpper.LineAlignment = StringAlignment.Near;
                    sfUpper.LineAlignment = StringAlignment.Center;
                    sf.Alignment = StringAlignment.Near;

                    Rectangle rcImage = new Rectangle(
                          rcItem.X + 2,
                          rcItem.Y,
                          item.Image.Width,
                          item.Image.Height);
                    
                    rcCaption.X = rcImage.Right + 2;
                    rcContent.X = rcImage.Right + 4;
                    rcCaption.Width -= rcImage.Width;
                    rcContent.Width -= rcImage.Width + 4;
                }
                else
                {
                    sfUpper.Alignment = StringAlignment.Center;
                    sfUpper.LineAlignment = StringAlignment.Near;
                    sfUpper.LineAlignment = StringAlignment.Center;
                    sf.Alignment = StringAlignment.Center;
                }
                // draw text for item's caption:
                gfx.DrawString(item.Text, item.CaptionFont, new SolidBrush(item.CaptionColor), rcCaption, sfUpper);
                // for description:
                gfx.DrawString(item.Description, item.ContentFont, new SolidBrush(item.ContentColor), rcContent, sf);

                sfUpper.Dispose();
                sf.Dispose();
                #endregion

                #region Update positions
                rcUpRect.Y += rcItem.Height + 2;
                rcDownRect.Y += rcItem.Height + 2;
                rcItem.Y += rcItem.Height + 2;
                #endregion
            }
            
        }
        /// <summary>
        /// Draws vertical side bar.
        /// </summary>
        /// <param name="g">Graphics object</param>
        /// <param name="clrStart">Start gradient color</param>
        /// <param name="clrEnd">End gradient color</param>
        /// <param name="icon">Icon to draw</param>
        /// <param name="sBarCaption">Caption to draw</param>
        private void DrawSideBar(
            Graphics g,
            Color clrStart,
            Color clrEnd,
            Bitmap icon,
            string sBarCaption
            )
        {

            Rectangle rcBar = new Rectangle();
            rcBar.Width = m_lBarWidth;
            rcBar.Height = ClientRectangle.Height;

            rcBar.Inflate(-2, -2);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            // fill bar:
            using (GraphicsPath barPath =
                        RoundRect((RectangleF)rcBar, 7, 0, 0, 7))
            {
                using (LinearGradientBrush lgbBar =
                          new LinearGradientBrush(
                          rcBar,
                          clrStart,
                          clrEnd,
                          LinearGradientMode.Vertical))
                {

                    g.FillPath(
                        lgbBar,
                        barPath
                   );
                }

            }
            
            // draw caption:
            Rectangle rcBarText = rcBar;
            SolidBrush sb = new SolidBrush(m_clrCaptionBar);
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            if (icon != null)
            {
                // make space for icon:
                g.TranslateTransform(rcBar.Width / 2 - 5, rcBar.Height - icon.Height);
            }
            else
            {   // just text:
                g.TranslateTransform(rcBar.Width / 2 - 5, rcBar.Height);
            }
            g.RotateTransform(270);
            g.DrawString(
                sBarCaption,
                m_fntBar,
                sb,
                0,
                0
            );
            g.ResetTransform();

            // draw icon:
            Rectangle rcIcon = new Rectangle();
            if (icon != null)
            {
                rcIcon.X = rcBar.Width / 2 - 5;
                rcIcon.Y = rcBar.Bottom - icon.Width - 2;
                rcIcon.Width = icon.Width;
                rcIcon.Height = icon.Height;
                g.DrawImage(
                    icon,
                    rcIcon
                );
            }
            
            // clean-up:
            sb.Dispose();


        }
        /// <summary>
        /// Make given rectangle rounded.
        /// </summary>
        /// <param name="r">Rectangle to be rounded</param>
        /// <param name="r1">Radius 1</param>
        /// <param name="r2">Radius 2</param>
        /// <param name="r3">Radius 3</param>
        /// <param name="r4">Radius 4</param>
        /// <returns></returns>
        private GraphicsPath RoundRect(RectangleF r, float r1, float r2, float r3, float r4)
        {
            float x = r.X, y = r.Y, w = r.Width, h = r.Height;
            GraphicsPath rr = new GraphicsPath();
            rr.AddBezier(x, y + r1, x, y, x + r1, y, x + r1, y);
            rr.AddLine(x + r1, y, x + w - r2, y);
            rr.AddBezier(x + w - r2, y, x + w, y, x + w, y + r2, x + w, y + r2);
            rr.AddLine(x + w, y + r2, x + w, y + h - r3);
            rr.AddBezier(x + w, y + h - r3, x + w, y + h, x + w - r3, y + h, x + w - r3, y + h);
            rr.AddLine(x + w - r3, y + h, x + r4, y + h);
            rr.AddBezier(x + r4, y + h, x, y + h, x, y + h - r4, x, y + h - r4);
            rr.AddLine(x, y + h - r4, x, y + r1);
            return rr;
        }
        /// <summary>
        /// Hittest function used when sidebar is rendered.
        /// </summary>
        /// <param name="x"> Mouse x coordinate</param>
        /// <param name="y"> Mouse y coordinate</param>
        /// <returns></returns>
        private int HitTestItem(
            int x,
            int y
            )
        {
            int code = -1;

            if ((x > m_lBarWidth) && (x <= this.ClientRectangle.Width))
            {
                if ((y >= 2) && (y <= this.ClientRectangle.Height))
                {
                    AlienMenuItem item = null;
                    for (int idx = 0; idx < items.Count; idx++)
                    {
                        item = items[idx];
                        if (y >= item.Top)
                        {
                            if (y < item.Top + m_lItemHeight)
                            {
                                code = idx;
                                break;
                            }
                        }
                    }
                }
            }
            if (code == -1)
            {
                // cursor inside side bar:
                for (int i = 0; i < items.Count; i++)
                {
                    // unhover any hovering item:   
                    items[i].Hovering = false;
                    Cursor = Cursors.Default;
                    Invalidate();
                }
            }
            return code;

        }
        #endregion
        
        #region Public methods
        /// <summary>
        /// Calculates menu height.
        /// </summary>
        public void CalcMenuSize()
        {
            
            if (!this.DesignMode){

                int lHeight = (items.Count  ) * (m_lItemHeight + 3 ) + 1 ;
                this.MaximumSize = new Size(this.Width, lHeight );
                this.Size = new Size(this.Width, lHeight);
                Invalidate();
            }
           
        }
        #endregion
    }
}