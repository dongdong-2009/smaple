using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Drawing2D;
using System.Drawing;


namespace AlienMenuControl
{
    public class AlienMenuItem
    {
        public AlienMenuItem(AlienMenuControl c)
        {
            owner = c;
        }
        public AlienMenuItem()
        {
        }

        private AlienMenuControl owner;
        private Image ButtonImage;
        private string sText = "";
        private string sTextContent = "";

        private bool bHovering = false;
        private bool bMouseDown = false;
        private bool bDisabled = false;

        private Font fnt = new Font("Visitor TT2 BRK", 9);
        private Font fntC = new Font("Visitor TT2 BRK", 15);

        private Object Tag = null;

        private Color clrOuterBorder = Color.FromArgb(29, 29, 29);
        private Color clrInnerBorder = Color.FromArgb(158, 158, 158);

        private Color clrSelectionStartColor = Color.FromArgb(142, 142, 142);
        private Color clrSelectionEndColor = Color.FromArgb(104, 104, 104);
        private Color clrSelectionStartColorStart = Color.FromArgb(74, 74, 74);
        private Color clrSelectionEndColorEnd = Color.FromArgb(106, 106, 106);

        private Color clrCaptionFont = Color.YellowGreen;
        private Color clrContentFont = Color.White;

        private int m_lTop;
        private int m_lLeft;

        public AlienMenuControl Owner
        {
            get
            {
                return this.owner;
            }
            set
            {
                this.owner = value;
            }
        }
        public int Top

        {
            get
            {
                return this.m_lTop;
            }
            set
            {
                this.m_lTop = value;
            }
        }
        public int Left
        {
            get
            {
                return this.m_lLeft;
            }
            set
            {
                this.m_lLeft = value;
            }
        }
        public Color SelectionStartColor
        {
            get
            {
                return this.clrSelectionStartColor;
            }
            set
            {
                this.clrSelectionStartColor = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color SelectionEndColor
        {
            get
            {
                return this.clrSelectionEndColor;
            }
            set
            {
                this.clrSelectionEndColor = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color SelectionEndColorEnd
        {
            get
            {
                return this.clrSelectionEndColorEnd;
            }
            set
            {
                this.clrSelectionEndColorEnd = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color SelectionStartColorStart
        {
            get
            {
                return this.clrSelectionStartColorStart;
            }
            set
            {
                this.clrSelectionStartColorStart = value;
                if (owner != null) owner.Invalidate();
            }
        }

        public string Text
        {
            get
            {
                return this.sText;
            }
            set
            {
                this.sText = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public string Description
        {
            get
            {
                return this.sTextContent;
            }
            set
            {
                this.sTextContent = value;
                if (owner != null) owner.Invalidate();
            }
        }
       

        public Image Image
        {
            get
            {
                return this.ButtonImage;
            }
            set
            {

                this.ButtonImage = value;
                if (owner != null) owner.Invalidate();

            }
        }
        public Font ContentFont
        {
            get
            {
                return fnt;
            }
            set
            {
                this.fnt = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Font CaptionFont
        {
            get
            {
                return fntC;
            }
            set
            {
                this.fntC = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public bool Hovering
        {
            get
            {
                return bHovering;
            }
            set
            {
                this.bHovering = value;
            }
        }
        public bool MouseDown
        {
            get
            {
                return bMouseDown;
            }
            set
            {
                this.bMouseDown = value;
            }
        }
        public bool Disabled
        {
            get
            {
                return bDisabled;
            }
            set
            {
                this.bDisabled = value;
            }
        }
        public Object ItemTag
        {
            get
            {
                return this.Tag;
            }
            set
            {
                this.Tag = value;
            }
        }
        public Color InnerBorder
        {
            get
            {
                return this.clrInnerBorder;
            }
            set
            {
                this.clrInnerBorder = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color OuterBorder
        {
            get
            {
                return this.clrOuterBorder;
            }
            set
            {
                this.clrOuterBorder = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color CaptionColor
        {
            get
            {
                return this.clrCaptionFont;
            }
            set
            {
                this.clrCaptionFont = value;
                if (owner != null) owner.Invalidate();
            }
        }
        public Color ContentColor
        {
            get
            {
                return this.clrContentFont;
            }
            set
            {
                this.clrContentFont = value;
                if (owner != null) owner.Invalidate();
            }
        }

                


    }
}
