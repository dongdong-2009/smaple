using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MenuControlTest
{
    public partial class frmMenuTest : Form
    {
        public enum Theme
        {
            eeDefault,
            eePink,
            eeBlue
        }
       
        public frmMenuTest()
        {
            InitializeComponent();
        }

        private void frmMenuTest_Load(object sender, EventArgs e)
        {
            alienMenuControl1.Items.Add("Adobe Acrobat","Put your Adobe Acrobat description here", MenuControlTest.Properties.Resources.Adobe_Acrobat_3D);
            alienMenuControl1.Items.Add("Adobe GoLive CS2", "Put your Adobe GoLive description here", MenuControlTest.Properties.Resources.Adobe_GoLive_CS2);
            alienMenuControl1.Items.Add("Adobe InDesign CS2", "Put your Adobe InDesign description here", MenuControlTest.Properties.Resources.Adobe_InDesign_CS2);
            alienMenuControl1.Items.Add("Adobe Bridge CS2","Put your Adobe Bridge description here", MenuControlTest.Properties.Resources.Adobe_Bridge_CS2);
            alienMenuControl1.Items.Add("Adobe Illustrator CS2", "Put your Adobe Illustrator description here",MenuControlTest.Properties.Resources.Adobe_Illustrator_CS2);
            alienMenuControl1.Items.Add("Adobe Image-Ready CS2", "Put your Adobe Image Ready description here", MenuControlTest.Properties.Resources.Adobe_Image_Ready);
            alienMenuControl1.Items.Add("Adobe Photoshop CS2", "Put your Adobe Photoshop description here", MenuControlTest.Properties.Resources.Adobe_Photoshop_CS2);
            alienMenuControl1.Items.Add("Adobe Acrobat Distiller", "Put your Adobe Acrobat Distiller description here", MenuControlTest.Properties.Resources.Adobe_Acrobat_Distiller);
             

            alienMenuControl1.SideBar = true;
            alienMenuControl1.SideBarCaption = "Adobe Family Products";

            alienMenuControl2.MenuStartColor = Color.FromArgb(174, 203, 237);
            alienMenuControl2.MenuEndColor = Color.FromArgb(97, 142, 201);
            alienMenuControl2.MenuInnerBorderColor = Color.FromArgb(146, 179, 224);
            alienMenuControl2.MenuOuterBorderColor = Color.FromArgb(195, 217, 235);
            alienMenuControl2.BackMenuImage = MenuControlTest.Properties.Resources.nibblerimage;
            alienMenuControl2.BackImageAlign = ContentAlignment.BottomCenter;

            alienMenuControl2.Items.Add("BENDER", "Full name Bender Bending Rodr�guez, designated Bending Unit 22, is a fictional robot character...", MenuControlTest.Properties.Resources.bender);
            alienMenuControl2.Items.Add("LEELA","Is the only person from her species that lives on earth. She was brought up in an orphanage and attended...", MenuControlTest.Properties.Resources.leela);
            alienMenuControl2.Items.Add("FRY","He suffered 3 heart attacks in high school after drinking 100 cans of Cola a week...", MenuControlTest.Properties.Resources.frai);
            alienMenuControl2.Items.Add("NIBBLER","Is a respected Lord on his home planet Eternium and is posted under cover as a 'dumb' pet so as to guard...", MenuControlTest.Properties.Resources.nibble);
            alienMenuControl2.Items.Add("PROFESOR","Is the oldest living member of The Academy of Professors. He was born in 2841.", MenuControlTest.Properties.Resources.profesor_farsnworth);
           
            foreach (AlienMenuControl.AlienMenuItem item in alienMenuControl2.Items){

                if (item.Text.Equals("NIBBLER"))
                {
                    item.CaptionColor = Color.Black;
                   
                }
                else if (item.Text.Equals("FRY"))
                {
                    item.CaptionColor = Color.FromArgb(253, 179, 16);
                   
                }
                else if (item.Text.Equals("LEELA"))
                {
                    item.CaptionColor = Color.FromArgb(184, 127, 210);
                   
                }
                else if (item.Text.Equals("BENDER"))
                {
                    item.CaptionColor = Color.FromArgb(132, 146, 160);
                    
                }
                else if (item.Text.Equals("PROFESOR"))
                {
                    item.CaptionColor = Color.White;
                    
                }
                item.SelectionStartColor = Color.FromArgb(226, 238, 252);
                item.SelectionStartColorStart = Color.FromArgb(225, 234, 249);
                item.SelectionEndColor = Color.FromArgb(196, 218, 241);
                item.SelectionEndColorEnd = Color.FromArgb(195, 216, 243);
                item.InnerBorder = Color.FromArgb(146, 179, 224);
                item.OuterBorder = Color.FromArgb(195, 217, 255);
                item.CaptionFont = new Font("Tahoma", 11, FontStyle.Bold);
                item.ContentFont = new Font("Tahoma", 7);
                item.ContentColor = Color.FromArgb(89, 120, 185);
               
            }
            alienMenuControl3.MenuEndColor = Color.FromArgb(81, 69, 59);
            alienMenuControl3.MenuStartColor = Color.FromArgb(115, 107, 101);
            alienMenuControl3.MenuInnerBorderColor = Color.FromArgb(167, 162, 158);
            alienMenuControl3.MenuOuterBorderColor = Color.FromArgb(47, 37, 28);
            alienMenuControl3.FlatSeparators = true;
            alienMenuControl3.SideBar = true;
            alienMenuControl3.SideBarCaption = "Halloween themed menu";
            alienMenuControl3.SideBarEndGradient = Color.FromArgb(81, 69, 59);
            alienMenuControl3.SideBarStartGradient = Color.DarkOrange;
            alienMenuControl3.SideBarBitmap = MenuControlTest.Properties.Resources.Hat;

            alienMenuControl3.Items.Add("No image", "This item doesn't have icon");
            alienMenuControl3.Items.Add("No description", MenuControlTest.Properties.Resources.Shock);
            alienMenuControl3.Items.Add("Disabled item", "This is sad disabled item", MenuControlTest.Properties.Resources.Sad);
            alienMenuControl3.Items.Add("Complete item", "Rich item", MenuControlTest.Properties.Resources.EasyMoney);
           

            alienMenuControl3.Items[2].Disabled = true;

            foreach (AlienMenuControl.AlienMenuItem item in alienMenuControl3.Items) {

                item.SelectionStartColor = Color.FromArgb(153, 127, 142);
                item.SelectionStartColorStart = Color.FromArgb(89, 81, 74);
                item.SelectionEndColor = Color.FromArgb(117, 110, 104);
                item.SelectionEndColorEnd = Color.FromArgb(121, 113, 106);
                item.InnerBorder = Color.FromArgb(183, 179, 179);
                item.OuterBorder = Color.FromArgb(0, 0, 0);
                item.CaptionColor = Color.DarkOrange;
            }

            alienMenuControl4.ItemHeight = 23;
            alienMenuControl4.Items.Add("View Captivate", "www.captivate.com", MenuControlTest.Properties.Resources.Captivate.GetThumbnailImage(20,20,null,IntPtr.Zero));
            alienMenuControl4.Items.Add("View ColdFusion", "www.coldfusion.com", MenuControlTest.Properties.Resources.Coldfusion.GetThumbnailImage(20, 20, null, IntPtr.Zero));
            alienMenuControl4.Items.Add("View Dreamwaver", "www.dreamwaver.net", MenuControlTest.Properties.Resources.Dreamweaver.GetThumbnailImage(20, 20, null, IntPtr.Zero));
            alienMenuControl4.Items.Add("View Flash", "www.flash.net", MenuControlTest.Properties.Resources.Flash.GetThumbnailImage(20, 20, null, IntPtr.Zero));

            foreach (AlienMenuControl.AlienMenuItem item in alienMenuControl4.Items){
                item.CaptionFont = new Font("Tahoma", 9, FontStyle.Bold);
               
            }

            alienMenuControl5.Items.Add("My Computer", "Explore your files..", MenuControlTest.Properties.Resources.mypc);
            alienMenuControl5.Items.Add("My Favorites" , "Stores your internet favorites...", MenuControlTest.Properties.Resources.favorites);
            alienMenuControl5.Items.Add("My Documents", "Stores your documents...", MenuControlTest.Properties.Resources.mydocuments);
            
            alienMenuControl5.MenuStartColor = Color.FromArgb(239, 239, 239);
            alienMenuControl5.MenuEndColor = Color.FromArgb(202, 202, 202);
            alienMenuControl5.MenuInnerBorderColor = Color.FromArgb(254, 254, 254);
            alienMenuControl5.MenuOuterBorderColor = Color.FromArgb(192, 192, 192);
            alienMenuControl5.SideBar = true;
            alienMenuControl5.SideBarCaption = "Mac style menu";
            alienMenuControl5.SideBarEndGradient = Color.FromArgb(202, 202, 202);
            alienMenuControl5.SideBarStartGradient = Color.FromArgb(202, 202, 202);
            alienMenuControl5.SideBarFontColor = Color.Black;
            alienMenuControl5.SideBarBitmap =((Bitmap) MenuControlTest.Properties.Resources.favorites.GetThumbnailImage(22, 22, null, IntPtr.Zero));
            
            foreach (AlienMenuControl.AlienMenuItem item in alienMenuControl5.Items){
                item.SelectionStartColor = Color.FromArgb(152, 193, 233);
                item.SelectionEndColor = Color.FromArgb(134, 186, 237);
                item.SelectionStartColorStart = Color.FromArgb(104, 169, 234);
                item.SelectionEndColorEnd = Color.FromArgb(169, 232, 255);
                item.InnerBorder = Color.FromArgb(254, 254, 254);
                item.OuterBorder = Color.FromArgb(231, 231, 231);
                item.CaptionFont = new Font("Tahoma", 10, FontStyle.Bold);
                item.ContentFont = new Font("Tahoma", 7);
                item.CaptionColor = Color.Black;
                item.ContentColor = Color.Black;

            
            
            }

            cboAlign.SelectedItem = cboAlign.Items[cboAlign.Items.IndexOf("BottomCenter")];
            lstThemes.SelectedItem = lstThemes.Items[lstThemes.Items.IndexOf("Default")];
        }

        private void alienMenuControl1_AlienMenuItemClick(AlienMenuControl.AlienMenuControl.AlienMenuItemClickArgs e)
        {
            MessageBox.Show(
                e.Item.Text + " clicked.",
                "Item clicked",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void chkSiderBar_CheckedChanged(object sender, EventArgs e)
        {
            alienMenuControl1.SideBar = chkSiderBar.Checked;
        }

        private void alienMenuControl3_AlienMenuItemClick(AlienMenuControl.AlienMenuControl.AlienMenuItemClickArgs e)
        {
            MessageBox.Show(
                e.Item.Text + " clicked.",
                "Item clicked",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void chkFlat_CheckedChanged(object sender, EventArgs e)
        {
            alienMenuControl1.FlatSeparators = chkFlat.Checked;
        }

        private void cboAlign_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboAlign.SelectedItem.ToString())
            {
                case "MiddleLeft":
                    alienMenuControl2.BackImageAlign = ContentAlignment.MiddleLeft;
                    break;
                case "MiddleRight":
                    alienMenuControl2.BackImageAlign = ContentAlignment.MiddleRight;
                    break;
                case "MiddleCenter":
                    alienMenuControl2.BackImageAlign = ContentAlignment.MiddleCenter;
                    break;
                case "BottomLeft":
                    alienMenuControl2.BackImageAlign = ContentAlignment.BottomLeft;
                    break;
                case "BottomRight":
                    alienMenuControl2.BackImageAlign = ContentAlignment.BottomRight;
                    break;
                case "BottomCenter":
                    alienMenuControl2.BackImageAlign = ContentAlignment.BottomCenter;
                    break;
                case "TopRight":
                    alienMenuControl2.BackImageAlign = ContentAlignment.TopRight;
                    break;
                case "TopLeft":
                    alienMenuControl2.BackImageAlign = ContentAlignment.TopLeft;
                    break;
                case "TopCenter":
                    alienMenuControl2.BackImageAlign = ContentAlignment.TopCenter;
                    break;

            }
           
        }

        private void ApplyMenuTheme(
              Theme theme,
              AlienMenuControl.AlienMenuControl c
            )
        {
            switch (theme)
            {
                case Theme.eePink:
                    c.MenuStartColor = Color.FromArgb(247, 241, 241);
                    c.MenuEndColor = Color.FromArgb(220, 167, 169);
                    c.MenuInnerBorderColor = Color.FromArgb(243, 219, 225);
                    c.MenuOuterBorderColor = Color.FromArgb(189, 129, 136);

                    foreach (AlienMenuControl.AlienMenuItem item in c.Items)
                    {
                        item.SelectionStartColor = Color.FromArgb(222, 176, 189);
                        item.SelectionEndColor = Color.FromArgb(215, 161, 176);
                        item.SelectionStartColorStart = Color.FromArgb(203, 136, 138);
                        item.SelectionEndColorEnd = Color.FromArgb(186, 111, 113);

                        item.InnerBorder = Color.FromArgb(243, 219, 225);
                        item.OuterBorder = Color.FromArgb(189, 129, 136);
                        item.ContentColor = Color.Black;
                        item.CaptionColor = Color.Black;
                    }
                    break;
                case Theme.eeBlue:
                    c.MenuStartColor = Color.FromArgb(101, 105, 113);
                    c.MenuEndColor = Color.FromArgb(41, 49, 63);
                    c.MenuInnerBorderColor = Color.FromArgb(158, 160, 165);
                    c.MenuOuterBorderColor = Color.FromArgb(28, 33, 34);

                    foreach (AlienMenuControl.AlienMenuItem item in c.Items)
                    {
                        item.SelectionStartColor = Color.FromArgb(146, 151, 162);
                        item.SelectionEndColor = Color.FromArgb(91, 98, 113);
                        item.SelectionStartColorStart = Color.FromArgb(57, 68, 89);
                        item.SelectionEndColorEnd = Color.FromArgb(52, 62, 81);

                        item.InnerBorder = Color.FromArgb(179, 183, 191);
                        item.OuterBorder = Color.FromArgb(93, 97, 105);
                        item.ContentColor = Color.White;
                        item.CaptionColor = Color.Gold;
                    }
                    break;
                case Theme.eeDefault:
                    c.MenuStartColor = Color.FromArgb(102, 102, 102);
                    c.MenuEndColor = Color.FromArgb(42, 42, 42);
                    c.MenuInnerBorderColor = Color.FromArgb(158, 158, 158);
                    c.MenuOuterBorderColor = Color.FromArgb(29, 29, 29);

                    foreach (AlienMenuControl.AlienMenuItem item in c.Items)
                    {
                        item.SelectionStartColor = Color.FromArgb(142, 142, 142);
                        item.SelectionEndColor = Color.FromArgb(104, 104, 104);
                        item.SelectionStartColorStart = Color.FromArgb(74, 74, 74);
                        item.SelectionEndColorEnd = Color.FromArgb(106, 106, 106);

                        item.InnerBorder = Color.FromArgb(158, 158, 158);
                        item.OuterBorder = Color.FromArgb(29, 29, 29);
                        item.ContentColor = Color.White;
                        item.CaptionColor = Color.YellowGreen;
                    }
                    break;
            }

        
        }

        private void lstThemes_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (lstThemes.SelectedItem.ToString())
            {
                case "Pink":
                    ApplyMenuTheme(Theme.eePink, alienMenuControl4);
                    break;
                case "Blue":
                    ApplyMenuTheme(Theme.eeBlue, alienMenuControl4);
                    break;
                case "Default":
                    ApplyMenuTheme(Theme.eeDefault, alienMenuControl4);
                    break;
            }
        }

        

        
    }
}