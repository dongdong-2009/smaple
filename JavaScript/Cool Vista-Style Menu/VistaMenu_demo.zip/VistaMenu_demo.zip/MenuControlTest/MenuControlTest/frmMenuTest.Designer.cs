﻿namespace MenuControlTest
{
    partial class frmMenuTest
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkFlat = new System.Windows.Forms.CheckBox();
            this.chkSiderBar = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboAlign = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lstThemes = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.alienMenuControl4 = new AlienMenuControl.AlienMenuControl();
            this.alienMenuControl5 = new AlienMenuControl.AlienMenuControl();
            this.alienMenuControl3 = new AlienMenuControl.AlienMenuControl();
            this.alienMenuControl2 = new AlienMenuControl.AlienMenuControl();
            this.alienMenuControl1 = new AlienMenuControl.AlienMenuControl();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkFlat);
            this.groupBox1.Controls.Add(this.chkSiderBar);
            this.groupBox1.Controls.Add(this.alienMenuControl1);
            this.groupBox1.Location = new System.Drawing.Point(11, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 530);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu with sidebar ";
            // 
            // chkFlat
            // 
            this.chkFlat.AutoSize = true;
            this.chkFlat.Location = new System.Drawing.Point(13, 465);
            this.chkFlat.Name = "chkFlat";
            this.chkFlat.Size = new System.Drawing.Size(126, 17);
            this.chkFlat.TabIndex = 2;
            this.chkFlat.Text = "Show flat separators";
            this.chkFlat.UseVisualStyleBackColor = true;
            this.chkFlat.CheckedChanged += new System.EventHandler(this.chkFlat_CheckedChanged);
            // 
            // chkSiderBar
            // 
            this.chkSiderBar.AutoSize = true;
            this.chkSiderBar.Checked = true;
            this.chkSiderBar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSiderBar.Location = new System.Drawing.Point(14, 447);
            this.chkSiderBar.Name = "chkSiderBar";
            this.chkSiderBar.Size = new System.Drawing.Size(120, 17);
            this.chkSiderBar.TabIndex = 1;
            this.chkSiderBar.Text = "Show / hide sidebar";
            this.chkSiderBar.UseVisualStyleBackColor = true;
            this.chkSiderBar.CheckedChanged += new System.EventHandler(this.chkSiderBar_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cboAlign);
            this.groupBox2.Controls.Add(this.alienMenuControl2);
            this.groupBox2.Location = new System.Drawing.Point(291, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(273, 397);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Menu without sidebar, but background image";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 358);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Image align:";
            // 
            // cboAlign
            // 
            this.cboAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAlign.FormattingEnabled = true;
            this.cboAlign.Items.AddRange(new object[] {
            "BottomLeft",
            "BottomRight",
            "BottomCenter",
            "MiddleLeft",
            "MiddleRight",
            "MiddleCenter",
            "TopLeft",
            "TopRight",
            "TopCenter"});
            this.cboAlign.Location = new System.Drawing.Point(104, 355);
            this.cboAlign.Name = "cboAlign";
            this.cboAlign.Size = new System.Drawing.Size(153, 21);
            this.cboAlign.TabIndex = 1;
            this.cboAlign.SelectedIndexChanged += new System.EventHandler(this.cboAlign_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.alienMenuControl5);
            this.groupBox3.Controls.Add(this.alienMenuControl3);
            this.groupBox3.Location = new System.Drawing.Point(579, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(273, 395);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Disabled items, flat separators, sidebar icon";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lstThemes);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.alienMenuControl4);
            this.groupBox4.Location = new System.Drawing.Point(292, 406);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(560, 136);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Themes";
            // 
            // lstThemes
            // 
            this.lstThemes.FormattingEnabled = true;
            this.lstThemes.Items.AddRange(new object[] {
            "Default",
            "Pink",
            "Blue"});
            this.lstThemes.Location = new System.Drawing.Point(283, 45);
            this.lstThemes.Name = "lstThemes";
            this.lstThemes.Size = new System.Drawing.Size(167, 69);
            this.lstThemes.TabIndex = 2;
            this.lstThemes.SelectedIndexChanged += new System.EventHandler(this.lstThemes_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(278, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select theme to apply:";
            // 
            // alienMenuControl4
            // 
            this.alienMenuControl4.BackImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.alienMenuControl4.BackMenuImage = null;
            this.alienMenuControl4.FlatSeparators = false;
            this.alienMenuControl4.FlatSeparatorsColor = System.Drawing.Color.Silver;
            this.alienMenuControl4.ItemHeight = 48;
            this.alienMenuControl4.Location = new System.Drawing.Point(14, 19);
            this.alienMenuControl4.MaximumSize = new System.Drawing.Size(300, 400);
            this.alienMenuControl4.MenuEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl4.MenuInnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.alienMenuControl4.MenuOuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.alienMenuControl4.MenuStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.alienMenuControl4.MinimumSize = new System.Drawing.Size(200, 46);
            this.alienMenuControl4.Name = "alienMenuControl4";
            this.alienMenuControl4.SideBar = false;
            this.alienMenuControl4.SideBarBitmap = null;
            this.alienMenuControl4.SideBarCaption = "Alien Cool Menu";
            this.alienMenuControl4.SideBarEndGradient = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl4.SideBarFont = new System.Drawing.Font("Visitor TT2 BRK", 12F);
            this.alienMenuControl4.SideBarFontColor = System.Drawing.Color.White;
            this.alienMenuControl4.SideBarStartGradient = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.alienMenuControl4.Size = new System.Drawing.Size(242, 106);
            this.alienMenuControl4.TabIndex = 0;
            // 
            // alienMenuControl5
            // 
            this.alienMenuControl5.BackImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.alienMenuControl5.BackMenuImage = null;
            this.alienMenuControl5.FlatSeparators = false;
            this.alienMenuControl5.FlatSeparatorsColor = System.Drawing.Color.Silver;
            this.alienMenuControl5.ItemHeight = 48;
            this.alienMenuControl5.Location = new System.Drawing.Point(14, 230);
            this.alienMenuControl5.MaximumSize = new System.Drawing.Size(300, 400);
            this.alienMenuControl5.MenuEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl5.MenuInnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.alienMenuControl5.MenuOuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.alienMenuControl5.MenuStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.alienMenuControl5.MinimumSize = new System.Drawing.Size(300, 46);
            this.alienMenuControl5.Name = "alienMenuControl5";
            this.alienMenuControl5.SideBar = false;
            this.alienMenuControl5.SideBarBitmap = null;
            this.alienMenuControl5.SideBarCaption = "Alien Cool Menu";
            this.alienMenuControl5.SideBarEndGradient = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl5.SideBarFont = new System.Drawing.Font("Visitor TT2 BRK", 12F);
            this.alienMenuControl5.SideBarFontColor = System.Drawing.Color.White;
            this.alienMenuControl5.SideBarStartGradient = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.alienMenuControl5.Size = new System.Drawing.Size(300, 151);
            this.alienMenuControl5.TabIndex = 1;
            // 
            // alienMenuControl3
            // 
            this.alienMenuControl3.BackImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.alienMenuControl3.BackMenuImage = null;
            this.alienMenuControl3.FlatSeparators = false;
            this.alienMenuControl3.FlatSeparatorsColor = System.Drawing.Color.Silver;
            this.alienMenuControl3.ItemHeight = 48;
            this.alienMenuControl3.Location = new System.Drawing.Point(6, 17);
            this.alienMenuControl3.MaximumSize = new System.Drawing.Size(300, 187);
            this.alienMenuControl3.MenuEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl3.MenuInnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.alienMenuControl3.MenuOuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.alienMenuControl3.MenuStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.alienMenuControl3.MinimumSize = new System.Drawing.Size(200, 46);
            this.alienMenuControl3.Name = "alienMenuControl3";
            this.alienMenuControl3.SideBar = false;
            this.alienMenuControl3.SideBarBitmap = null;
            this.alienMenuControl3.SideBarCaption = "Alien Cool Menu";
            this.alienMenuControl3.SideBarEndGradient = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl3.SideBarFont = new System.Drawing.Font("Visitor TT2 BRK", 12F);
            this.alienMenuControl3.SideBarFontColor = System.Drawing.Color.White;
            this.alienMenuControl3.SideBarStartGradient = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.alienMenuControl3.Size = new System.Drawing.Size(261, 187);
            this.alienMenuControl3.TabIndex = 0;
            this.alienMenuControl3.AlienMenuItemClick += new AlienMenuControl.AlienMenuControl.AlienMenuItemClickHandler(this.alienMenuControl3_AlienMenuItemClick);
            // 
            // alienMenuControl2
            // 
            this.alienMenuControl2.BackImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.alienMenuControl2.BackMenuImage = null;
            this.alienMenuControl2.FlatSeparators = false;
            this.alienMenuControl2.FlatSeparatorsColor = System.Drawing.Color.Silver;
            this.alienMenuControl2.ItemHeight = 48;
            this.alienMenuControl2.Location = new System.Drawing.Point(15, 19);
            this.alienMenuControl2.MaximumSize = new System.Drawing.Size(247, 330);
            this.alienMenuControl2.MenuEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl2.MenuInnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.alienMenuControl2.MenuOuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.alienMenuControl2.MenuStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.alienMenuControl2.MinimumSize = new System.Drawing.Size(247, 330);
            this.alienMenuControl2.Name = "alienMenuControl2";
            this.alienMenuControl2.SideBar = false;
            this.alienMenuControl2.SideBarBitmap = null;
            this.alienMenuControl2.SideBarCaption = "Alien Cool Menu";
            this.alienMenuControl2.SideBarEndGradient = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl2.SideBarFont = new System.Drawing.Font("Visitor TT2 BRK", 12F);
            this.alienMenuControl2.SideBarFontColor = System.Drawing.Color.White;
            this.alienMenuControl2.SideBarStartGradient = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.alienMenuControl2.Size = new System.Drawing.Size(247, 330);
            this.alienMenuControl2.TabIndex = 0;
            // 
            // alienMenuControl1
            // 
            this.alienMenuControl1.BackImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.alienMenuControl1.BackMenuImage = null;
            this.alienMenuControl1.FlatSeparators = false;
            this.alienMenuControl1.FlatSeparatorsColor = System.Drawing.Color.Silver;
            this.alienMenuControl1.ItemHeight = 48;
            this.alienMenuControl1.Location = new System.Drawing.Point(10, 21);
            this.alienMenuControl1.MaximumSize = new System.Drawing.Size(247, 330);
            this.alienMenuControl1.MenuEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl1.MenuInnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
            this.alienMenuControl1.MenuOuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.alienMenuControl1.MenuStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.alienMenuControl1.MinimumSize = new System.Drawing.Size(247, 330);
            this.alienMenuControl1.Name = "alienMenuControl1";
            this.alienMenuControl1.SideBar = false;
            this.alienMenuControl1.SideBarBitmap = null;
            this.alienMenuControl1.SideBarCaption = "Alien Cool Menu";
            this.alienMenuControl1.SideBarEndGradient = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.alienMenuControl1.SideBarFont = new System.Drawing.Font("Visitor TT2 BRK", 12F);
            this.alienMenuControl1.SideBarFontColor = System.Drawing.Color.White;
            this.alienMenuControl1.SideBarStartGradient = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.alienMenuControl1.Size = new System.Drawing.Size(247, 330);
            this.alienMenuControl1.TabIndex = 0;
            this.alienMenuControl1.AlienMenuItemClick += new AlienMenuControl.AlienMenuControl.AlienMenuItemClickHandler(this.alienMenuControl1_AlienMenuItemClick);
            // 
            // frmMenuTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 554);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMenuTest";
            this.Text = "Menu Control Test";
            this.Load += new System.EventHandler(this.frmMenuTest_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private AlienMenuControl.AlienMenuControl alienMenuControl1;
        private System.Windows.Forms.CheckBox chkSiderBar;
        private System.Windows.Forms.GroupBox groupBox2;
        private AlienMenuControl.AlienMenuControl alienMenuControl2;
        private System.Windows.Forms.GroupBox groupBox3;
        private AlienMenuControl.AlienMenuControl alienMenuControl3;
        private System.Windows.Forms.CheckBox chkFlat;
        private System.Windows.Forms.GroupBox groupBox4;
        private AlienMenuControl.AlienMenuControl alienMenuControl4;
        private System.Windows.Forms.ListBox lstThemes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboAlign;
        private AlienMenuControl.AlienMenuControl alienMenuControl5;

        
    }
}

