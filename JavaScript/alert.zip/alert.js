// Created by Linn White
// License: http://creativecommons.org/licenses/by-nc-sa/3.0/us/
// Please leave the above license information intact

//Script execution is NOT suspended like a normal alert/confirm box would be, so be warned
//There is an iframe hack for IE6 to fix the zindex but with "select" elements.
//"select" elements are disabled in IE6 when an alert box is showing
//Tested in Firefox 1.5+, Firefox 2.0+, Alert.ie6, IE7, Opera 9+, Safari for Windows

function Alert(options)
{
	var alertObject = this;
	alertObject.version = '1.0';
	if (!window.XMLHttpRequest) 
	{
		//simple test to check for ie6 or older browser or an older browser.
 		var ie6 = true;
	}
	var alarmWindow;
	var alarmBox;
	var alarmTitle;
	var alarmContent;
	var buttonContainer;
	var alarmButton;
	var mouseX;
	var mouseY;
	var parentElement;
	var alertY;
	var alertX;
	
	if(ie6)
	{
		var alarmFrame;
	}
	
	//The below code was found at Codylindley.com and is released under the same CC license
	var Client = 	
	{
  		viewportWidth: function() 
		{
    		return self.innerWidth || (document.documentElement.clientWidth || document.body.clientWidth);
  		},
		viewportHeight: function() 
		{
    		return self.innerHeight || (document.documentElement.clientHeight || document.body.clientHeight);
  		},
  		viewportSize: function() 
		{
    		return { width: this.viewportWidth(), height: this.viewportHeight() };
  		}
	};
	
	
	//Methods
	alertObject.Position = rePos;
	
	alertObject.Dialog = function(title, text, button, buttonEvent)
	{
		if(document.getElementById('modalWindow'))
		{
			return
		}
		createWindow('dialog', title, text, button, buttonEvent);
		rePos();
		if(ie6)
		{
			changeSelect(true);
		}
		alarmButton.focus();
	}
	
	alertObject.Confirm = function(title, text, button, buttonEvent, button2, button2Event)
	{
		if(document.getElementById('modalWindow'))
		{
			return
		}
		createWindow('confirm', title, text, button, buttonEvent, button2, button2Event);
		rePos();
		if(ie6)
		{
			changeSelect(true);
		}
		confirmButton.focus();	
	}
	
	
	//Functions
	function rePos()
	{
		var pageY = window.pageYOffset || document.documentElement.scrollTop;
		var pageX = window.pageXOffset || document.documentElement.scrollLeft;
		alarmBox.style.left = (Client.viewportWidth() - alarmBox.offsetWidth)/2 + pageX + "px";	
		alarmBox.style.top = (Client.viewportHeight() - alarmBox.offsetHeight)/2 + pageY + "px";
		if(ie6)
		{
			alarmFrame.style.left = (Client.viewportWidth() - alarmBox.offsetWidth)/2 + pageX + "px";	
			alarmFrame.style.top = (Client.viewportHeight() - alarmBox.offsetHeight)/2 + pageY + "px";
			alarmFrame.style.height = alarmBox.offsetHeight + "px";
			alarmFrame.style.visibility = 'visible';
		}
		alarmBox.style.visibility = 'visible';
	}
	
	function changeSelect(bool)
	{
		var selectBoxes = document.getElementsByTagName('select');
		for(var i = 0; i < selectBoxes.length; i++)
		{
			selectBoxes[i].disabled = bool;
		}
	}
	
	function alarm_OK(event, on_OK)
	{
		if(ie6)
		{
			changeSelect(false);
		}
		document.body.removeChild(alarmWindow);
		//if(window.addEventListener)
		//{
			//window.removeEventListener('scroll', function(){alertObject.Position()}, false);
			//window.removeEventListener('resize', function(){alertObject.Position()}, false);
		//}
		//else
		//{
			window.onscroll = null;
			window.onresize = null;
		//}
		alarmWindow = null;
		alarmBox = null;
		alarmTitle = null
		alarmContent = null
		alarmButton = null;
		buttonContainer = null;
		if(on_OK != '')
		{
			eval(on_OK);
		}
	}
	
	function alarm_CANCEL(event, on_CANCEL) {
		if(ie6)
		{
			changeSelect(false);
		}
		document.body.removeChild(alarmWindow);
		//if(window.addEventListener)
		//{
			//window.removeEventListener('scroll', function(){alertObject.Position()}, false);
			//window.removeEventListener('resize', function(){alertObject.Position()}, false);
		//}
		//else
		//{
			window.onscroll = null;
			window.onresize = null;
		//}
		alarmWindow = null;
		alarmBox = null;
		alarmTitle = null
		alarmContent = null
		alarmButton = null;
		buttonContainer = null;
		if(on_CANCEL != '')
		{
			eval(on_CANCEL);
		}
	}
	
	function mouseDown(e)
	{
		e = (e == null) ? window.event : e;
		target = (e.target) ? e.target : e.srcElement;
		if(target.id == 'title')
		{
			mouseX = e.clientX;
			mouseY = e.clientY;
			parentElement = target.parentNode;
			alertX = parentElement.style.left;
			alertY = parentElement.style.top;
			//if(window.addEventListener)
			//{
			//	window.addEventListener('mousemove', function(e){mouseMove(e)}, false);
			//	window.addEventListener('mouseup', function(e){mouseUp(e)}, false);
			//	window.addEventListener('selectstart', function(){ return false }, false);
			//}
			//else
			//{
				document.onmousemove = mouseMove;
				document.onmouseup = mouseUp;
				document.onselectstart = function () { return false };
			//}
			return false;
		}
	}
	
	function mouseMove(e) 
	{
		e = (e == null) ? window.event : e;
		newX = parseInt(alertX.split('px')[0]);
		newY = parseInt(alertY.split('px')[0]);
		parentElement.style.left = (newX + e.clientX - mouseX) + 'px';
		parentElement.style.top = (newY + e.clientY - mouseY) + 'px';
		if(ie6)
		{
			alarmFrame.style.left = (newX + e.clientX - mouseX) + 'px';
			alarmFrame.style.top = (newY + e.clientY - mouseY) + 'px';
		}
	}

	function mouseUp(e) 
	{
		e = (e == null) ? window.event : e;
		//if(window.addEventListener)
		//{
		//	window.removeEventListener('mousemove', function(e){mouseMove(e)}, false);
		//	window.removeEventListener('selectstart', function(){ return false }, false);
		//}
		//else
		//{
			document.onmousemove = null;
			document.onselectstart = null;
		//}
	}
	
	function createWindow(alertType, title, text, button, buttonEvent, button2, button2Event)
	{
		alarmWindow = document.body.appendChild(document.createElement("div"));
		alarmBox = alarmWindow.appendChild(document.createElement('div'));
		alarmTitle = alarmBox.appendChild(document.createElement('div'));
		alarmContent = alarmBox.appendChild(document.createElement('div'));
		buttonContainer = alarmBox.appendChild(document.createElement('div'));
		
		//Set up our modal Window
		alarmWindow.id = 'modalWindow';
		alarmWindow.style.height = document.documentElement.scrollHeight + 'px';
		alarmWindow.style.backgroundColor = 'transparent';
		alarmWindow.style.position = 'absolute';
		alarmWindow.style.width = '100%';
		alarmWindow.style.top = '0px';
		alarmWindow.style.left = '0px';
		alarmWindow.style.zIndex = '10000';
		//IE hack.  Overlap  z-index doo-dads
		//This is a one pixel transparent png.
		alarmWindow.style.backgroundImage = 'url(tp.png)';
		
		alarmBox.style.visibility = 'hidden';
		alarmBox.style.position = 'absolute';
		alarmBox.style.width = options.width + 'px';
		alarmBox.style.border = options.border + 'px';
		alarmBox.style.borderStyle = options.borderStyle;
		alarmBox.style.borderColor = options.borderColor;
		alarmBox.style.textAlign = 'center';
		alarmBox.style.zIndex = 101;
		alarmBox.style.background = options.contentColor;
	
		//Create an iframe
		if(ie6) {
			alarmFrame = alarmWindow.appendChild(document.createElement('iframe'));
			alarmFrame.src = "javascript:void(0);";
			alarmFrame.style.visibility = 'hidden';
			alarmFrame.style.position = 'absolute';
			alarmFrame.style.width =  options.width + 'px';
			alarmFrame.style.zIndex = 100;
			alarmFrame.frameBorder = '0';
		}
	
		//Create the title window
		alarmTitle = alarmBox.appendChild(document.createElement('div'));
		alarmTitle.id = 'title';
		alarmTitle.innerHTML = title;
		alarmTitle.style.cursor = 'default';
		alarmTitle.style.background = options.titleColor;
		alarmTitle.style.color = options.titleFontColor;
		alarmTitle.style.fontWeight = options.titleWeight;
		alarmTitle.style.padding = '1px';
		alarmTitle.style.borderTop = '0px';
		alarmTitle.style.borderBottom = '1px';
		alarmTitle.style.borderColor = options.titleBorderColor;
		alarmTitle.style.borderLeft = '0px';
		alarmTitle.style.borderRight = '0px';
		alarmTitle.style.borderStyle = 'solid';
		alarmTitle.style.marginTop = '0px';
		alarmTitle.style.marginBottom = '0px';
		if(window.addEventListener)
		{
			alarmTitle.addEventListener('mousedown', function(e){mouseDown(e)}, false);
		}
		else
		{
			alarmTitle.onmousedown = mouseDown;
		}
	
		//Create the content window
		alarmContent = alarmBox.appendChild(document.createElement('div'));
		alarmContent.style.padding = '5px';
		alarmContent.style.background = options.contentColor;
		alarmContent.style.color = options.contentFontColor;
		alarmContent.innerHTML = text;
		alarmContent.style.marginBottom = '0px';
		alarmContent.style.marginTop = '0px';
		alarmContent.style.textAlign = 'left';
	
		//Create a button container
		buttonContainer = alarmBox.appendChild(document.createElement('div'));
		buttonContainer.style.background = options.contentColor;
		buttonContainer.style.marginBottom = '0px';
		buttonContainer.style.marginTop = '0px';
		buttonContainer.style.padding = '5px';
		buttonContainer.style.clear = 'both';
		
		//Create our button
		alarmButton = document.createElement('input');
		alarmButton.type = 'button';
		alarmButton.style.border = '1px solid';
		alarmButton.style.cursor = 'pointer';
		alarmButton.value = button;
		alarmButton.onclick = function(event) {alarm_OK(event, buttonEvent);}
		alarmButton.style.paddingLeft = '5px';
		alarmButton.style.paddingRight = '5px';
		buttonContainer.appendChild(alarmButton);
		
		//Create a second button for confirm type
		if(alertType == 'confirm') 
		{
			confirmButton = document.createElement('input');
			confirmButton.type = 'button';
			confirmButton.style.border = '1px solid';
			confirmButton.style.cursor = 'pointer';
			confirmButton.value = button2;
			confirmButton.onclick = function(event) {alarm_CANCEL(event, button2Event);}
			confirmButton.style.paddingLeft = '5px';
			confirmButton.style.paddingRight = '5px';
			confirmButton.style.marginLeft = '15px';
			buttonContainer.appendChild(confirmButton);
			if(alarmButton.offsetWidth > confirmButton.offsetWidth)
			{
				confirmButton.style.width = alarmButton.offsetWidth + 'px';
			}
			else
			{
				alarmButton.style.width = confirmButton.offsetWidth + 'px';
			}
		}
		//Add event listeners
		//if(window.addEventListener)
		//{
		//	window.addEventListener('scroll', function(){alertObject.Position()}, false);
		//	window.addEventListener('resize', function(){alertObject.Position()}, false);
		//}
		//else
		//{
			window.onscroll = function(){alertObject.Position()};
			window.onresize = function(){alertObject.Position()};
		//}
	}
}
