﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeOpenXml.FormulaParsing.Utilities
{
    public abstract class IdProvider
    {
        public abstract object NewId();
    }
}
