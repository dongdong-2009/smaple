﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataPie
{
   public class DataPieConfig
    {
       //默认每个文件存储数65535行
        public static int RowOutCount = 65535;
    }
}
